---
phase: 5
title: "Evaluation và lựa chọn có điều kiện"
status: pending
priority: P1
effort: "10-14h"
dependencies: [1, 2, 3, 4]
---

# Phase 5: Final evaluation và kiểm chứng lựa chọn đã khóa

## Overview

## Current generation acceptance for evaluation

[Acceptance v1 decision](../reports/protocol-decision-261019-2341-tib-development-close-acceptance-report.md): completed và completed_with_warning đều successful generation; warning IDs không bị loại khỏi C_f/C_between/final paired coverage chỉ vì warning. Giữ clean/warning/failure denominators theo candidate/config/stratum/stage; metric errors/NULL còn được ghi riêng. Technical failures không impute0. EOS/native checks neural-only, CPU extractive controls N/A. Preferred BARTcontrol/LEDngram3/Qwen384 không final winner/admission; model/scorer/trial/resource freeze trước selection, common-coverage two-tier và final preoutcome seal giữ nguyên.

## P4 returned evidence — current audited status 2026-10-19

[Audit ZIP Colab](../reports/evidence-audit-261019-2013-tib-p4-returned-capacity-report.md) và [technical execution receipt v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/technical_execution_receipt_v2.json):159 files/155 JSON digests PASS;9 neural outputs replay offline, không inference/scoring mới. BART/LED/Qwen3 fresh3/3 trên actual Tesla T4 FP16, cùng3 staged pilot sources đã seal. LED failure đầu giữ lịch sử; corrected bundlev3 chạy thành công. Lead-3/LexRank có12 saved outputs qua hai lượt trên cùng3sources, không12unique records.

**Capacity PASS scoped3records; P4 vẫn in-progress/P5 pending.** LED repetition/incomplete endings và BART long final=first map cần development review. LED4/9 map và Qwen6/9 map+2/2 reduce chạm256tokens chưa EOS. Final9/9 EOS dưới768;0/9 cap350cuts. Giữ350maximum nhưng cap/profile chưa final-lock; không sửa config/cohort hoặc chọn model từ audit này. Numeric quotas/projection, formal-runtime scorer, effective runtime/config logging, expanded pilot và cross-session Drive reuse còn thiếu.40/300/523 giữ nguyên; full523→500→400 theo preoutcome budget;40diagnostics trong final. Không coi một mẫu mỗi stratum là measured p95/upper bound. `measured_profiles.json` projection-ready vẫn empty; raw observations lưu riêng.

Các snapshot18:02/17:03 bên dưới là lịch sử preparation/qualification; câu chưa generation/OAuth-pending ở đó đã được evidence hiện hành này thay thế. Cap/profile freeze trước selection; final seal sau lựa chọn, trước test generation.

## P4 technical execution — 2026-10-19 18:02 (historical snapshot)

- [Scorer-ready receipt](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/scorer_ready_receipt.json): pinned CPU/batch1/FP32 fixtures + actual pretrained native/window and five-metric E2E PASS; IDF=false, no corpus fit. Đây là CPU fixture scope, chưa full-corpus throughput hoặc T4/scorer budget.
- [Output policy](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/output_policy.json): user ratified eligible-train-only p95/ceil25;4.213 records,p95=333 → **350 English whitespace words maximum**, không target. [Evidence v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/output_cap_evidence_v2.json) verifies qualification/canonical/tokenizer hashes; native final reserve768 là proposal. Value derived350 thay current UNSET; **final cap lock vẫn chờ actual candidate feasibility trước selection**. Không dùng validation/test references để chọn cap.
- [Candidate profiles](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/candidate_profiles.json): năm IDs, full native token coverage/Unicode-preserving wrappers và reducers, fixed CPU Lead-3 + full-source LexRank. Local three-source smoke6/6CPU outputs và9 tokenizer plans PASS; model weights chưa chạy trên T4.
- [Compute budget](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/compute_budget.json): full523 →500 →400, diagnostics40 nằm trong final cohort. User cho Colab/Drive và runtime dưới12h; guard11.5h. Không suy runtime/GPU-hours từ token plans hoặc A100. Numeric CPU/storage/call projections và store survival chưa đủ.
- [Colab notebook](../../benchmark/experiments/notebooks/tib-p4-feasibility-colab-261019-v2.ipynb) và source-only ZIP đã upload private Drive, chỉ3 staged pilot sources/attribution, không abstracts/selection/test. Runtime T4 đã kết nối; first mount-Drive cell đang chờ OAuth consent cho client Google Drive for desktop. Auto-review từ chối Continue khi chưa có client/scope approval; không model generation nào trên Colab được xác nhận. [Runbook](../../docs/tib-p4-colab-feasibility.md).
- 134 focused/regression tests PASS. Không pilot40/selection300/final523/formal model selection mới; development40/300 và eligible-test523 giữ nguyên. [Báo cáo](../reports/implementation-261019-1802-tib-p4-readiness-report.md).


Báo một primary TIB text-only study, không benchmark độc lập theo genre/domain, không gold mới. Full qualified native test≤911 ưu tiên hoặc preoutcome fallback600→500→400 đã seal. P4 tầng A chọn config trong bốn model families trên C_f, tầng B recompute C_between selected model representatives+fixed Lead-3 control (max5 pipelines). Final kiểm chứng locked model choice, không reselect config/model/control. Cho phép no_selection; không annotation framework hoặc factuality inference từ cosine.

## Trạng thái đầu vào — 2026-10-19

Qualification/development40/300 đã seal, chưa final seal/generation/scoring. Reference ledgerA0/B9.095/C8;225 flags reviewed uncertainB, nên A-only sensitivity hiện unavailable. Test eligible frame523 không phải final evaluatedN. Source groups approximate recall unknown; bootstrap chỉ sensitivity theo groups đã biết. P5 pending; P4 phải hoàn tất scorer-ready/model-selection/final generation trước P5 analysis.

## Requirements và blockers

Final execution phụ thuộc P4 sealed protocol/K_models≤4/K_total=K_models+1≤5/config/locked validation model choice+Lead-3 guard/comparison family, P3 sealed final cohort/labels/diagnostic_spec40, selected-ID ledger/provenance. P4 sở hữu scorer spec/ready receipt, khóa trước selection theo metric contract mô tả ở đây; P5 chỉ đọc immutable profile, không cần thực hiện P5 để mở khóa P4. Mọi admitted model và fixed Lead-3 dùng cùng exact cohort; N thực≤911 hoặc fallback trước outputs,không mặc định911. W_global từ eligible native-train reference lengths+product constraint, hiện derived350/chưa final lock, phải freeze trước selection; common delivered selector/raw links/capping policy cùng identity, không per-record test-reference length steering.
Outputs thiếu vẫn báo partial với đủ denominator, không claim completed.
Không tune/chọn exclusions/đổi metric sau test scores.

## Architecture

Delivered predictions + raw links/source/ref hashes + attempt receipts → pinned scorers → item metric/cost ledger → pair intersections/group bootstrap → plots/manual diagnostics → decision.
Scorer đọc abstract riêng, không truyền ngược generator.

## Metric contract

| Outcome | Vai trò/giới hạn |
|---|---|
| ROUGE-1/2/L F1 | Primary ROUGE-L,lexical/sequence agreement |
| BERTScore F1 | Secondary semantic reference agreement |
| Source sentence similarity (SBERT adaptation) | Diagnostic transcript similarity; metric_id/formula/encoder/window pins bắt buộc; không entailment/factuality/idea retention |
| Latency/CPU/RAM/GPU/VRAM/failures | Resource/availability riêng,không nhập quality score tùy ý |
| Reference-quality sensitivity | Primary A+B pooled, A-only/exclude-B dùng cùng predictions/frozen labels, denominators riêng; không outcome filtering |

Reuse concepts bằng code/version mới; không sửa [semantic amendment cũ](../../benchmark/docs/results/rq2-tib-120-results-261013.md).
**Scorer-ready trước validation selection**: P4 đã có spec v2 và CPU fixture-ready receipt tại tib-model-benchmark-p4-261019-1802; đây chưa là formal-runtime Colab proof. P4 owner bind/version actual metric code, dependencies/model/revision/tokenizer/preprocessing, sentence/window lengths/stride/overflow, aggregation/pooling/normalization, long-source policy, IDF=false/no fit, batch/dtype/backend/device. Colab/CPU package drift cần runtime amendment và fixtures/long-input/error/cost verification; thiếu hash/rule/backend-capacity → no selection start. P5 sử dụng cùng identity đã khóa để phân tích final.
IDF/assets fit train theo frozen policy trước selection; nếu cần development pilot calibration phải khai frozen IDs, không selection/test fit. Cùng scorer identity selection/final. Amendment sau selection lưu old version, rescore **tất cả stored selection outputs của mọi tried model config và fixed Lead-3 trên cùng V**, tính lại A_f/C_f/representatives/F_between/control/C_between và rerun cả hai tầng trước final seal. Giữ masks/decisions/version cũ, không regenerate để game scorer. Không rescore đủ→no_selection/no final seal.

Theo [báo cáo xác minh](../reports/research-261019-0933-summarization-scientific-t4-verification-report.md#dataset-và-scorer), attribution source SBERTScore về đúng paper/formula chưa được xác minh đầy đủ. Study mới phải pin công thức mean_summary_sentence_max_source_sentence_cosine, sentence splitter, encoder/pooling/normalization và long-sentence aggregation nếu dùng adaptation này; dùng metric_id project-specific, không khẳng định exact replication Ye et al.2024 cho tới có evidence. BERTScore native-capacity và token-window extension có implementation IDs riêng; phải kiểm equivalence trong native capacity khi được thực thi, không gọi window extension tương đương full context. Các bất định provenance/actual pins không được biến thành VERIFIED chỉ từ plan. Không đổi tên/định nghĩa metrics của old120.
Undefined/error quality NULL; empty/technical output failures theo protocol, không tự gán0.

Optional Extractive Oracle chỉ reference-aware diagnostic ceiling theo exact metric/reference, không candidate/deployable system/new gold hoặc model–control ranking/selection input; không trộn oracle cost với deployable pipeline frontier. Attribution original TIB Lead-3/Oracle đã VERIFIED trong official HAL PDF section5.2/Table2, xem P1 evidence15:07; local splitter/caps/Oracle settings vẫn chưa chứng minh reproduction. Optional EMNLP2024 TIB-group reference-free relevance **citation/formula UNVERIFIED/default off**; nếu được phép chỉ bật bằng spec+implementation+budget pin trước selection, diagnostic không đổi primary winner hoặc post-hoc tiebreak.

## Reference-quality sensitivity

P3 sở hữu A/B/C rubric calibrated trên train/development trước outcomes và225-flag adjudication ledger; không released TIB labels/gold. A usable content+presentation relation; B uncertain short/generic/reused/unreviewed giữ nếu eligibility khác pass; C evidence-backed unusable loại reference scoring. Uncertain→B, không arbitrary30/50-word exclusion hoặc model-ROUGE-based label. Rights/structural HOLD riêng.
Primary A+B pooled, report A-only/exclude-B sensitivity từ **cùng stored predictions và frozen labels**, selected/attempted/scored/paired/group N, C exclusions/HOLD và strata counts rõ. Nếu A-only không đủ hoặc rỗng báo unavailable/shortfall, không ép A/C hay tạo labels/output mới để có result. Sensitivity không đổi selectedN/primary estimand hoặc reselect model từ final; disagreements chỉ giới hạn claim. Reconcile counts mới với historical8.769, không ép counts bằng nhau. Genre/subject/group sensitivities vẫn cùng single-study outputs, không separate benchmark cohorts.

## Paired analysis và denominator

- Primary unit là released record hợp lệ khác ID, record-weighted; giữ/group nội-final duplicates theo P3. Group-weighted/deduplicated sensitivity có denominator riêng. Source-content groups cần evidence/ngưỡng khóa; chunks/calls không độc lập.
- Sealed selectedN luôn hiện: full eligible native test≤911 ưu tiên, hoặc exact fallback600/500/400 theo frozen budget rule; frame<400 chỉ dùng toàn bộ nếu fit. Model/control attempted/completed/scored/failed/not_attempted theo strata; partial không đổi N.
- **Final descriptive contrasts** dùng pair success intersection, báo pairedN/groupN/coverage; không đòi all5 success để mô tả pair. [Validation hai tầng P4](./phase-04-candidate-selection-and-t4-benchmark-protocol.md#development-và-validation-selection-contract) dùng C_f model-family configs, rồi recompute selected representatives+fixed Lead-3 trên C_between. Không dùng C_f means khác population ranking family; final intersections tên riêng, không thay V/C_f/C_between. Pair-specific final means không reselect winner; control missingness không âm thầm bỏ khỏi coverage/guard.
- Báo exact observed paired ROUGE-L/secondary deltas trên finite frame/success intersection. Toàn test là census của eligible frame: không mô tả bootstrap như uncertainty về finite census mean đã biết. Fallback deterministic/source-stratified cũng không tự cho probability-sampling inference.
- 5.000 whole-component bootstrap resamples,seed20261019,record-weighted percentile95%intervals,fixed groups: **exploratory dependency/within-frame sensitivity** dưới giả định đã ghi,không design-based population confidence/power guarantee. Success-conditional estimates không đại diện chắc failed records.
- `K_models≤4`, fixed Lead-3, `K_total=K_models+1≤5`; contrasts=K_total×(K_total−1)/2, tối đa**10** (6 model–model+4 model–control nếu đủ5). Ưu tiên tất cả4 models+control nếu feasible. Khóa family/guard trước outputs; recommendation set chỉ bốn models, Lead-3 không learned-model winner. Không ranking lại từ final hoặc nâng runner-up nếu validation choice thiếu/không được hỗ trợ.
- Nếu formal primary family: prespecify paired test/Holm hoặc simultaneous intervals cùng estimand/assumptions trước test,không bổ sung hậu nghiệm. Formal execution trên EDA-exposed test không đồng nghĩa blind confirmatory/generalization guarantee.
- Không suy difference từ individual-arm CI overlap; delta CI qua0 không chứng minh equivalence.
- Pair intersections có populations khác: không ghép thành global ranking. Báo common-all-admitted-complete sensitivity riêng cùng coverage/missingness.
- Primary selectedN giữ nguyên; failure rate toàn selected. Missingness sensitivity/conditional estimates không đại diện chắc failed records.
- Record bootstrap không phản ánh seed variance của stochastic single realization; không ước lượng trực tiếp domain transfer từ CNN/DailyMail/arXiv sang TIB. Resampling chỉ là sensitivity trên frame/giả định đã khai báo.
- Không dropping hard IDs,missing0 hoặc unknown cost0.

## Resource reporting

Per candidate báo CPU/GPU profile,init/load/preprocess/map/reduce/generation/scorer/export/retries/wall session.
LexRank và Lead-3 CPU: generator GPU/VRAM **N/A**, không0/zero-cost; CPU latency/RAM đo thật. Neural generator GPU BART/LED/Qwen, scorer GPU/CPU budget riêng. Lead-3 fixed profile và first3 spans rõ, không full-map coverage claim.
Scorer GPU peak riêng generator peak; item sums khác session overhead,allocated/reserved/available ghi rõ.
Unknown cost NULL/counts rõ,interruption không zero; inherited generation không tính hai lần.
Quality–cost plots có units/coverage/profile; không full Pareto hoặc repeatable speed claim từ một run.
Không dùng oldQwen1.5B timing dự báo bốn candidates.

## Manual diagnostics và decision

**40 unique IDs từ chính final cohort cho toàn study**, không mỗi model/control; cùng case qua nhiều profiles không tăng caseN. P3 tạo/khóa diagnostic_spec (chưa tạo) trước final seal, P4 bind hash trước predictions, P5 chỉ đọc. Default30 source-only balanced core+10 metric extremes, không statistical guarantee. Spec khóa core IDs/quotas/strata/stable hash/tie-break, extreme quota/ranking/ties/replacement algorithm trước outputs; extreme IDs chọn cơ học sau final metrics, không trùng core. Thiếu eligible extremes thì source-only replacement theo frozen rule hoặc honest shortfall, không thêm dummy/new records/ngoài final cohort. Báo core/extreme riêng, purposive extremes không representative error rate.

Mỗi case form gồm caseID/native recordID/groupID, core/extreme/failure status, frozen A/B/C+policy hash, candidate/control profile hash, raw/delivered links/W_global/capping, source/reference spans, error type/severity nếu đủ evidence, uncertainty/reviewer/disagreement. Failures/missing summary ghi availability/error stage; **không summary không tự hallucination**. Đọc mất ý/lặp/unsupported content/reference disagreement chỉ khi đủ spans; unknown giữ unknown. Status accounting trong fixed40 total, không thêm40 mỗi model/status.

Diagnostic không gold mới/population error rates; không refilter/retrain/retune từ test review. Nếu available cases ít hơn target, báo số thật/lý do; không tạo thêm records.
Agreement-best trên cohort/config chưa là summary tốt nhất toàn diện.
Report validation selected choice/config và final evidence theo criteria khóa trước test. Final có thể hỗ trợ hoặc không hỗ trợ lựa chọn đó; nếu không hỗ trợ thì no_selection/inconclusive,không thay bằng runner-up nhờ final scores. Mọi đề xuất config/model khác là post-hoc cần study mới.
Uncertain/conflicting/coverage thiếu→no_selection; không “quality equal nên chọn rẻ” khi chưa equivalence design.
[Old120](../../benchmark/docs/results/rq2-tib-120-results-261013.md) giữ no_selection,không viết lại inference lịch sử.

## Related Code Files và ownership

Đề xuất owner P5, **chưa tạo**, trong benchmark/experiments/outputs/tib-model-benchmark-v1/evaluation/:
- metrics_per_item.csv;resource_costs.csv;paired_intervals.csv;failures.csv.
- figures/; selection_decision.json; diagnostic_case_forms.jsonl.
- Proposed benchmark/experiments/registry/protocols/tib-model-benchmark-v1/diagnostic_spec.json thuộc P3; scorer_spec.json/scorer_ready_receipt.json cùng thư mục thuộc P4. P5 chỉ đọc hashes/versions đã seal và ghi diagnostic_case_forms/report sau final metrics.
- Báo cáo Markdown tương lai trong plans/261019-0035-summarization-model-benchmark/reports/: qualitative-diagnostics.md; evaluation-report.md.
- Helper mới benchmark/experiments/scripts/tib_model_benchmark_analysis.py,tách modules P4.
P5 đọc upstream; sửa phải đúng owner/version mới,không patch receipt frozen.
Old S1/S3/120/9-pilot chỉ lịch sử bất biến; **không scheduled auxiliary S1/S3 benchmark mới** trong single-primary plan này. Mọi đề xuất future study độc lập cần explicit user request, không implied execution authorization từ optional diagnostics/profiles.

## Validation và success criteria

- Unit: scorer hashes/window/IDF fit isolation; C_f/C_between/final-pair joins, family-only delta/config tie-break, group/bootstrap seed,NULL/denominators,cost/retry sums; unique diagnostic IDs/quotas/tie rules/form fields.
- Integration: scorer-ready trước selection; amendment rescore ALL stored selection outputs rồi rerun cả hai tầng; mapping/hash population riêng và representative bất biến khi sang family comparison/final; đúng delivered policy; scorer checkpoints độc lập generation.
- E2E: selected IDs→receipts→metrics/CI/plots/decision audit được; hiện chưa chạy.
- [ ] Bảng candidates hoặc reject/partial reasons,N metric/selected rõ.
- [ ] Đủ tối đa10 contrasts của predeclared K_total family nếu data có; thiếu ghi unavailable/reason; locked model choice/Lead-3 guard không reselect từ test.
- [ ] Resources đủ stages/attempts hoặc unknown khai rõ; không ép winner.
- [ ] 40 unique diagnostics từ final cohort hoặc honest shortfall, core/extreme/failure labels/forms đủ; A+B primary/A-only sensitivity cùng predictions/frozen labels và N rõ; giữ narrow agreement/exposure/domain-transfer limits,không population error rates.

## Risk Assessment, rollback và câu hỏi mở

High: multiple comparison(cao×cao)→exploratory family;survivor bias(cao×cao)→pairN/common sensitivity/all-selected;metric overclaim(cao×cao)→claim boundary.
Rollback scorer/report lỗi bằng versioned amendment **rescore predictions bất biến**, không regenerate; nếu ảnh hưởng selection phải rescore ALL selection outputs trên cùng V, dựng lại cả tầng A/B trước final seal; giữ report cũ superseded,không regenerate/config theo test.
Còn mở: final scored/paired/group denominators (qualificationA0/B9.095/C8 đã biết, A-only unavailable), W_global/scorer/IDF pins, ratified delta/coverage/control guard, K_models/K_total, full-vs-fallback estimand/cost completeness và final có hỗ trợ locked model choice không. Effort10–14h provisional cần reassess sau pilot/gaps/diagnostic support, không measured promise.
