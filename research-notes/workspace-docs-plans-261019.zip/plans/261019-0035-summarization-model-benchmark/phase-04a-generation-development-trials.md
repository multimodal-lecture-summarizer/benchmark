---
phase: 4.1
title: Controlled generation development after returned T4 evidence
status: in-progress
created: 2026-10-19
---

# P4.1 — controlled development amendment

## User closes experimental search branch

[Decision2341](../reports/protocol-decision-261019-2341-tib-development-close-acceptance-report.md) đóng default decode search; preferred evaluation profiles là BARTcontrol/LEDngram3/Qwen384, không quality winner.512tùy chọn/disabled, không cần0exhaustion mới tiếp tục. Policy completed_with_warning đã freeze ở version mới; các đoạn trial/acceptance-pending dưới đây mô tả preparation và returned-evidence snapshots trước quyết định. Không sửa raw registry/bundles. Công việc tiếp theo chuyển sang scorer/recovery/pilot40/admission-budget; main P4 vẫn in-progress, không yêu cầu sửa BART ngay.

## Actual trial evidence returned

[Audit P4.1](../reports/evidence-audit-261019-2222-tib-p41-returned-trials-report.md):7default trials×3sources/123nodes đã completed trên actualT4,308files/281envelopes verified. BART/LED0 tái hiện baseline; LED3/4 hết repeated4gram flags nhưng còn malformed endings/formatting, Qwen384 map exhaustion0/9 nhưng reduce2/2 vẫn384cut; concise256 không giải quyết exhaustion. Cap350/cohorts và registry unchanged,512 unexecuted. P4.1 execution deliverable đã có, chất lượng/intermediate policy chưa chốt, không tự mở pilot40/selection. CPU scorer-ready scope cũ giữ; formal-runtime scorer và cross-session resume tiếp tục là stage cần evidence.

User GO in attachment19/10,21:22 authorizes development profiles/scorer preparation, not selection300. This phase executes the six-step recommendation alongside existing P4; P1–P3 unchanged. Existing [audit](../reports/evidence-audit-261019-2013-tib-p4-returned-capacity-report.md) remains baseline evidence. No new local inference is required: prepare tested runnable Colab artifacts for user execution.

## Concrete implementation and acceptance

1. Preserve the original ZIP SHA, receipts, model revisions, cap350 maximum, staged source IDs `valid:644/341/886`, pilot40/selection300/test523. New trials have independent IDs/profile hashes/checkpoint namespaces. Never claim a new trial succeeded before an actual T4 receipt.
2. Add per-node terminal `eos_observed`, `token_budget_exhausted` (reserve reached without terminal valid EOS), fixed-rule repetition and sentence-ending diagnostic flags, base and merged effective generation config. Record runtime hardware/memory/backend/versions. Missing legacy telemetry stays unknown. Reused checkpoints retain original backend evidence; new generation cost0, original cost separate.
3. Frozen trial set: BART unchanged decode/profile with stored-chain diagnostic plus one fresh telemetry control; LED control ngram0 and trials ngram3/ngram4, beam4 unchanged; Qwen control256/current prompt, reserve384/current prompt, reserve256/concise intermediate prompt. Qwen reserve512/current prompt is deferred: require successful reserve384 T4 capacity evidence, no OOM, measured memory capacity and explicit resource review before activation. Default notebook excludes512. At most8 neural profiles ×3 sources=24 outputs, default7×3=21; these reuse the same3 pilot IDs, not new cohort size. No trial repeats or automated search. Qwen reserve changes also change available input window: interpret as whole pipeline configuration, not an isolated causal effect of reserve size.
4. Causal native budgets recompute windows for every profile with context4096, wrappers/padding plus output reserve; decoder final reserve768 unchanged. Validate full source intervals and input hashes on local pinned tokenizer planning, without model inference. Do not equate word cap with native tokens.
5. Offline BART diagnostic resolves ordered reduction children, exact output clones and token overlap proxies. Full token lineage remains separate from semantic preservation. Manual semantic coverage remains pending, with no fabricated semantic score or source-code bug attribution.
6. Technical acceptance policy is `observe_continue_with_flags`: preserve bounded intermediate outputs and downstream calls with explicit flags, no hidden retry/filter/exclusion or score-based intervention. Empty/context-invalid/backend failures remain failures in attempted denominators. Formal admission policy is **pending**; no selection until the policy/profile/config/scorer/budget gates are frozen. Automatic quality flags do not prove factuality or justify relabeling reference/source eligibility.

## Deliverables

- Runtime telemetry/checkpoint integration and meaningful fixtures/regression tests.
- Versioned trial registry, source-only ZIP, unexecuted Colab notebook with session guard11.5h and logs/checkpoints on private Drive. User runs T4; A100 cannot provide T4 PASS. Package includes no references/selection/test records or model weights.
- Baseline freeze manifest and offline reduction diagnostic, implementation/evidence receipt distinguishing local checks from unexecuted T4 trials.
- Effective config logging and deterministic node seed policy versioned in trial identity. Changes to seed/config/code make new runtime identity; do not mix preexisting baseline costs/outputs into matched trial measurements.

## Dependencies retained

P4.1 controlled three-source trials → P4.2 formal-runtime scorer fixtures/cost → P4.3 fresh-runtime checkpoint resume → P4.4 full pilot40 → P4.5 profile/cap/trial/quotas/projection freeze → P4.6 selection300 (within-family config, then between-family common coverage) → decision/final seal → full eligible523 or preoutcome500→400. No final40 diagnostic records added beyond final cohort.

CPU-ready scorer receipt already exists; remaining scorer work is Colab/formal-runtime verification and throughput, not declaring CPU scorer absent. Full pilot40 and future profile changes require stage resource gates; the technical session guard is not total-study quota authorization.

## Verification and open questions

Required: EOS-vs-budget distinction including EOS exactly at cap; merged decode overrides; fixed repetition diagnostics; resumed-call cost separation; source-bound Qwen window recomputation; baseline identities untouched; notebook/ZIP hashes/schema and safe export; reduction graph tests; read-only independent code review. No GPU success or improved summary quality claimed from fixtures.

Open: actual trial outputs/VRAM/latency, effectiveness of LED anti-repeat or Qwen larger notes, semantic coverage review, final acceptance policy, measured hardware/runtime freeze, expanded pilot/scorer/resume evidence and numeric full-study quotas. Default7 trials are a bounded development proposal under user GO, not statistical power or guaranteed runtime.
