---
title: Retry every remaining failed source
status: completed
priority: P1
effort: medium
branch: untracked-notebook
tags: [colab, eda, retry]
created: 2026-10-18
---

# All-failed download retry

User authorizes new standalone Colab notebook default retrying ALL checkpoint failures, currently119, preserving214downloaded source andframe cache, showing actualnewresults/logs inline. No auth/cookies,GT,sourceidentity changes,remote executionhere,deletion,commit/push. Exactreceivedexecutedinput preserved beforeclearingoutputs.

Scout:33cells20Pythoncode,Jupyter/pandas/FFmpeg/yt-dlp. Existing config2+selectionhelper22+acquisition23+receipt31 implement representative12cap and10min batch,30min global media;preview27/coverage29 fixed interfaces. Actualreceived12/12sample recovered;214downloaded/119failed,1172images.

- [x] Scope/scout/backupexecutedinput.
- [x] Independent plan review:no blockers; selected==pool invariant andactualcommand-vsselection reporting required.
- [x] Add RETRY_FAILED_SCOPE=all-failed(default)/representative; all-failed pool from pre-existingfailedstates only, uncappedby12/samplebudget; retain representative opt-in compatibility. Old RUN_REPRESENTATIVE_RETRY switch remains backward-compatible masterenable forbothscopes.
- [x] Full scope limits300min retry/300min global,120s per source,3s gap;increase configurablemedia cap16GiB;respect freefloor/pervideo/storage and reportanyunattemptedreason. Previewbudget stays30min,identity/cache unchanged.
- [x] Genericinlineconfig/allpool/allselected/results summary,perretryprogress distinguishesoldstatusfromactualoutcome; existingCSV/JSONreceiptcontracts retainedwithadditivescope fields. Recoveryfeedsunchangedpreview/coverage;all333/9021retained.
- [x] Testsactualsaved119pool→119selected,no214downloadedselected,representative12stillworks,empty/disabled/wholebatchbudget,actualdownloadprobehash/cache/history/originalorder. Existingrepresentative5,resume8,stagebudget,full333/9021receipt regressions/schema.
- [x] Independentreview,guide/report/artifacts/plan sync.

No promiseall119recoverorfinishunderlimits; everyfailure selected, everynewattempt/nonattempt visible. Capacityandremoteavailability requireactualColabrun.

Finalize:6newall-failedtests+5representative+8resumeFFmpeg+stagebudget+full333/9021receipt regressions passed;independentreview andartifactfinalizePASS;guide/journal synced. Actualall-failedColabexecution remains pending.
