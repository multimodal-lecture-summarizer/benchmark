---
phase: 3
title: Qualification và chính sách cohort
status: in-progress
priority: P1
effort: 8-12h
dependencies:
  - 1
  - 2
---

# Phase 3: Qualification và cohort

## Overview

## Current stage — 2026-10-20 pilot40 preparation

[P4b scorer-ready](./phase-04b-formal-runtime-scorer.md) and [P4c fresh-session recovery](./phase-04c-fresh-session-recovery.md) are audited PASS in their stated scopes. [P4d](./phase-04d-pilot40-runtime.md) prepares the unchanged40-ID/five-profile technical pilot under the newly approved pilot allocation. Actual runtime preflight, pilot execution and measurements remain unverified; selection300/final test are not open. Dated evidence sections below retain their original scope and do not supersede this status. P1–P3 qualification/development decisions remain unchanged; P5 remains pending.

## P4 returned evidence — historical audit 2026-10-19

[Audit ZIP Colab](../reports/evidence-audit-261019-2013-tib-p4-returned-capacity-report.md) và [technical execution receipt v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/technical_execution_receipt_v2.json):159 files/155 JSON digests PASS;9 neural outputs replay offline, không inference/scoring mới. BART/LED/Qwen3 fresh3/3 trên actual Tesla T4 FP16, cùng3 staged pilot sources đã seal. LED failure đầu giữ lịch sử; corrected bundlev3 chạy thành công. Lead-3/LexRank có12 saved outputs qua hai lượt trên cùng3sources, không12unique records.

**Capacity PASS scoped3records; P4 vẫn in-progress/P5 pending.** LED repetition/incomplete endings và BART long final=first map cần development review. LED4/9 map và Qwen6/9 map+2/2 reduce chạm256tokens chưa EOS. Final9/9 EOS dưới768;0/9 cap350cuts. Giữ350maximum nhưng cap/profile chưa final-lock; không sửa config/cohort hoặc chọn model từ audit này. Numeric quotas/projection, formal-runtime scorer, effective runtime/config logging, expanded pilot và cross-session Drive reuse còn thiếu.40/300/523 giữ nguyên; full523→500→400 theo preoutcome budget;40diagnostics trong final. Không coi một mẫu mỗi stratum là measured p95/upper bound. `measured_profiles.json` projection-ready vẫn empty; raw observations lưu riêng.

Các snapshot18:02/17:03 bên dưới là lịch sử preparation/qualification; câu chưa generation/OAuth-pending ở đó đã được evidence hiện hành này thay thế. Cap/profile freeze trước selection; final seal sau lựa chọn, trước test generation.

## P4 technical execution — 2026-10-19 18:02 (historical snapshot)

- [Scorer-ready receipt](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/scorer_ready_receipt.json): pinned CPU/batch1/FP32 fixtures + actual pretrained native/window and five-metric E2E PASS; IDF=false, no corpus fit. Đây là CPU fixture scope, chưa full-corpus throughput hoặc T4/scorer budget.
- [Output policy](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/output_policy.json): user ratified eligible-train-only p95/ceil25;4.213 records,p95=333 → **350 English whitespace words maximum**, không target. [Evidence v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/output_cap_evidence_v2.json) verifies qualification/canonical/tokenizer hashes; native final reserve768 là proposal. Value derived350 thay current UNSET; **final cap lock vẫn chờ actual candidate feasibility trước selection**. Không dùng validation/test references để chọn cap.
- [Candidate profiles](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/candidate_profiles.json): năm IDs, full native token coverage/Unicode-preserving wrappers và reducers, fixed CPU Lead-3 + full-source LexRank. Local three-source smoke6/6CPU outputs và9 tokenizer plans PASS; model weights chưa chạy trên T4.
- [Compute budget](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/compute_budget.json): full523 →500 →400, diagnostics40 nằm trong final cohort. User cho Colab/Drive và runtime dưới12h; guard11.5h. Không suy runtime/GPU-hours từ token plans hoặc A100. Numeric CPU/storage/call projections và store survival chưa đủ.
- [Colab notebook](../../benchmark/experiments/notebooks/tib-p4-feasibility-colab-261019-v2.ipynb) và source-only ZIP đã upload private Drive, chỉ3 staged pilot sources/attribution, không abstracts/selection/test. Runtime T4 đã kết nối; first mount-Drive cell đang chờ OAuth consent cho client Google Drive for desktop. Auto-review từ chối Continue khi chưa có client/scope approval; không model generation nào trên Colab được xác nhận. [Runbook](../../docs/tib-p4-colab-feasibility.md).
- 134 focused/regression tests PASS. Không pilot40/selection300/final523/formal model selection mới; development40/300 và eligible-test523 giữ nguyên. [Báo cáo](../reports/implementation-261019-1802-tib-p4-readiness-report.md).


Qualification toàn bộ train/validation/test, chốt task/reference fit và các development roles trước outputs. Development40 pilot/300 selection đã seal; final test IDs/N chỉ seal sau validation model selection và budget gate P4, hiện chưa final seal.

## Evidence thực thi — 2026-10-19 17:03

Pinned snapshot `e6ab9fd7c6acd164f3284b8c4b17eb9d94681eee`: 9.103 canonical records có raw/normalized hashes và offset trace; native splits 7.282/910/911. Source-use policy khóa cho **local/private/noncommercial**, giữ attribution, không public text redistribution/external API transfer: 6.171 source conditional / 2.932 HOLD, 5.270 records qua combined source/reference rights. Không blanket allow toàn corpus; chuyển sang remote T4/store phải xác minh phạm vi sử dụng trước chuyển dữ liệu.

Reference policy đã calibrated/frozen trước outputs: **A=0, B=9.095, C=8 empty**. Toàn bộ225 historical reused flags được targeted review trong18 groups;226 casefold members tính cả một row ngoài historical structural frame, giữ B vì chưa đủ evidence usability chắc chắn. AI-assisted review dùng title/opening/anchor spans, không full-transcript factuality certification; A-only sensitivity hiện **unavailable**, không đổi labels để tạo A.

Source audit ghi22 accepted edges /37 records /9.082 components,7 cross-split components; tái hiện known three-record cluster. Retrieval gần đúng, recall unknown; tác giả/title/abstract reuse không tự tạo source group. Additive group replay đã kiểm lại9.103 hashes/22 accepted decisions/components sau import fix; không rerun mọi candidate comparisons, original runtime code identity chưa sealed đầy đủ.

| Native split | Source | Data eligible | Sau exposure filtering |
|---|---:|---:|---:|
| train | 7.282 | 4.215 | 4.213 |
| valid | 910 | 532 | 464 |
| test | 911 | 523 | 523 |

**40 pilot /300 selection validation đã seal, không kích hoạt fallback200**; không trùng ID/group giữa roles, old120/9 pilot hoặc protected eligible test groups. 523 là eligible test frame hiện tại, **final test chưa seal**; full-first và fallback600→500→400 giữ nguyên, chỉ xét N nhỏ hơn frame và đủ budget. Không generation/selection metrics/T4 pilot.

- [Source-use policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/source_use_policy.json), [reference policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/reference_policy.json), [reference summary](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/reference_summary.json), [source-group policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/group_policy.json).
- [Qualification policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/qualification_policy.json), [development cohort](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/development_cohort.json) bind exact IDs/groups/counts/policy hashes. Full canonical/rights/reference/group/exposure ledgers và CPU EDA receipt giữ local ignored tại `benchmark/research-data/tib-qualification-261019-1703/`.
- CPU EDA đã chạy toàn9.103 rows,4 plots, native BART/LED/Qwen token counts từ pinned tokenizer files. Illustrative window counts chỉ lower bounds chưa gồm wrappers/overlap/reduce; actual native layouts và capacity còn P4-dependent.
- **W_global derived350; final feasibility lock pending**. Scorer-ready, candidate profiles/decode/scoring capacity, numeric quotas và actual persistent-store receipts còn thiếu. Host xác minh RTX4050 Laptop6GB/16GB RAM, **không phải T4**; không suy T4 feasibility.

## Requirements và blockers

P1 đủ quyền text/abstract; P2 accounting/gaps và source/group/exposure evidence.
Đích: một primary English text-only creator-abstract-agreement study trên fixed TIB9.103 native splits. Genre/subject chỉ là representation/strata diagnostics, không independent benchmarks hoặc new gold.
Không bắt buộc annotation study; review nhỏ là diagnostic, không tạo gold.

## Architecture

Manifest mọi split + source/metadata + group/exposure ledger → eligibility/cross-split protection → source-only strata → sealed validation pilot/selection roles → P4 pilot/model selection/budget → sealed benchmark_cohort.json native test → final predictions.
Abstract dùng qualification theo rule đã định/scorer, không generator; không chọn test bằng similarity với candidate outputs.

## Qualification policy đề xuất

| Điều kiện | Quyết định trước outcomes |
|---|---|
| Transcript rỗng/cấu trúc lỗi | Loại, lưu ID/reason |
| Reference A — Usable | Có nội dung và liên quan presentation theo frozen rubric; primary nếu qua eligibility khác |
| Reference B — Uncertain | Ngắn/generic/reused/unreviewed nhưng chưa đủ evidence unusable; giữ primary nếu qua eligibility khác, sensitivity riêng |
| Reference C — Unusable | Rỗng/sai record/generic nonpresentation có evidence; loại reference scoring, ledger evidence/reason |
| Structural/rights unknown | HOLD riêng khỏi reference A/B/C; không dùng B để vượt rights/structural gate |
| Exact/source-content duplicates | Cùng released ID lặp: accounting ingestion duplicate; khác ID hợp lệ: giữ/group trong final primary census |
| Cùng tác giả/title gần | Chỉ flag, cần evidence trước group |
| Source dài | Stratum/full-coverage adapters, không quiet cut |
| Genre/domain | Representation/diagnostics trong cùng primary study; metadata không tự quality label |

A/B/C là **research usability policy đã khóa cho version hiện tại**, không nhãn có sẵn trong TIB, không gold summary/semantic-correctness certification. P3 định nghĩa rubric/evidence fields, reviewer/disagreement/uncertainty rule và calibration trên train/development trước outcomes; unresolved thì B, không bịa A/C. Empty có evidence→C; ngắn dưới30/50 words hoặc repeated/generic flag riêng chưa đủ C. Không dùng model ROUGE/secondary scores để phân loại; không outcome-driven exclusion.
Targeted adjudication225 historical reused-reference flags phải có per-ID normalized/raw hash, reuse evidence, relation-to-presentation evidence, proposed/final A/B/C, reviewer, uncertainty và policy version. Reconcile counts với8.769 lịch sử, không ép bằng lại8.769, không blanket restore/exclusion. Primary **A+B pooled**; A-only/exclude-B sensitivity dùng cùng frozen labels/predictions, báo selected/scored/paired/group denominators riêng, không sinh lại outputs hoặc đổi labels sau model scores. C/structural exclusions và rights HOLD giữ ledger riêng.
Canonical schema/normalization theo P1: `source_raw`, `source_normalized`, `reference_raw`, `reference_normalized`, `record_id`, `group_id`, `source_length` words+native tokens, `quality_flags`, `eligibility_status` eligible/flagged/excluded/HOLD với reason. Transcript là canonical input; segments chỉ sidecar, mismatch flag không tái dựng. Raw bytes/hashes/offset mapping bất biến, không semantic cleanup; no timestamps primary.

Development mới loại old120,9 pilot cũ và known source-content groups đã tuning; lưu source split và exposure lý do. Chưa tuning: nếu group trùng validation/test thì ưu tiên giữ test hợp lệ, loại linked validation khỏi cả pilot và selection **trước tuning**. Test đã linked known tuning/old outcomes thì exclude/HOLD với evidence trước final outcomes, không đổi membership sau scores. Không tự nhóm cùng author/title.
Mỗi exclusion dẫn evidence/ID/group; không khẳng định mọi dependency group đã biết. Primary full-test census giữ **mọi released record hợp lệ khác ID**, kể cả nội-test source duplicates, group để mô tả dependency; primary mean record-weighted. Deduplicated hoặc equal-group-weighted chỉ là sensitivity có population/denominator riêng, không thay census sau outcomes. Same released ID bị ingest hai lần không tạo hai units.

Trước outputs, P3 khóa source normalization, exact hash, near-overlap metric/ngưỡng số/span minimum, adjudication và unknown rule trong qualification_policy; thiếu ngưỡng đã xác minh → không seal groups. Cùng author/title hoặc repeated abstract chỉ là flags, không blanket exclusion/grouping.225 reused abstracts lịch sử cần ledger đối chiếu theo **reference-usability rule mới** (reference rỗng/unusable/mismatched có evidence); không tự reinstatement hoặc carry-forward exclusion chỉ vì lặp abstract. Giữ historical counts bất biến.
Toàn source EDA-exposed/old120 outputs đã xem. **EDA-only exposure không tự loại test**; tách nó khỏi prompt/config/outcome exposure. Chỉ nói test không dùng cho model/config selection mới nếu ledger chứng minh; không pristine unseen/pretraining-clean.

## Quy mô và sampling

- EDA9.103; qualification mọi native split. Default pilot**40 validation**, selection**300 validation**, rời theo released ID và known dependent group sau loại old120/9 pilot cũ/known-linked groups. Hiện**40 pilot/300 selection đã seal**, không fallback; final test chưa seal. Operational sizes không power guarantee.
- Chỉ khi availability qualified/group-safe validation không đủ300 sau pilot40 mới dùng fallback selection**200**, quyết định trước selection outputs và lưu reason/counts; dưới200→stop/amend scope, không lấy test bù, không tùy ý chọn250 hoặc giảm sau failure. Pilot40 không được chứng nhận đủ điều kiện chỉ từ lịch sử887.
- Seal development role IDs trước pilot; train dùng source-derived cutpoints/normalization/reference rubric và assets/IDF nếu cần, không bắt buộc generation toàn train. Model selection dùng validation outcomes trong config search budget đã định; không gọi final evidence. W_global hiện derived350/chưa final lock, do eligible native-train reference lengths+product constraint quyết định trước selection; không per-record test-reference steering.
- Hai tầng config/family P4 dùng nguyên cùng selection cohort V, không lấy thêm validation/test. C_f/C_between là score-success masks downstream, không là eligibility/split mới: không đổi selected IDs hoặc reference policy để cứu coverage. Exact masks/floors/decisions do P4 version và ghi cùng V hash; thiếu group/reference snapshot evidence vẫn chặn cohort seal riêng.
- Ưu tiên toàn bộ native test hợp lệ≤911, sau mọi rights/reference/group/tuning exclusions. Tập này là census của frame đủ điều kiện, không tự đại diện toàn corpus/lecture population.
- Fallback theo [budget contract P4](./phase-04-candidate-selection-and-t4-benchmark-protocol.md#budget-và-fallback-contract): full qualified frame luôn xét trước, sau đó xét600→500→400 chỉ khi N nhỏ hơn frame và fit conservative quota projection. Chọn largest feasible exactN, không chọn tùy ý trong khoảng. Frame400–600 vẫn full-first rồi chỉ N nhỏ hơn; frame<400 dùng toàn bộ nếu fit, không fit → blocked/no formal run. Không có approved sub400 fallback.
- Trước outputs khóa source-only representative allocation: strata/cutpoints từ source, proportional largest-remainder quotas với stable stratum tie-break, rare/unknown floor và group-preserving allocation/tie-break; verify achievable counts. Nếu group constraints không đạt exactN hoặc floors thì candidate N infeasible, không split linked groups hoặc chọn completed prefix. Đây là operational representation rule, không probability-sampling guarantee. P3 freeze thresholds/floors/rule/seed và P4 freeze quota/order trước test; thiếu trường bắt buộc → REQUIRED_NO_START.
- Ghi frame sizes,allocation,selected/excluded/group counts và deterministic selection rule; không suy xác suất chọn/population estimates từ hash sampling. Thiếu groups/validation IDs thì amendment scope/N trước outputs tương ứng; không lén dùng test cho development.
- Reference/task diagnostic development theo policy; final diagnostics**40 unique IDs từ chính final cohort**, không mỗi model: default30 source-only core+10 metric extremes, quotas/core IDs và extreme-selection algorithm khóa trước outputs; extreme IDs chọn cơ học sau metrics. Shortfall báo thật, không dummy/new records, không lọc/tune.
- Sau validation selection: seal test N/IDs/A/B/C/policy cùng K_models≤4 và fixed Lead-3 control (`K_total=K_models+1≤5`), configs/scorer/W_global/full-fallback budget reason. Không đổi N vì observed quality/runtime từng test ID; technical failures giữ denominator,không qualification exclusion/replacement.

## Related Code Files

Owner P3, **đã tạo** trong `benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/`: qualification_policy.json, reference_policy.json/reference_summary.json, group_policy.json và development_cohort.json (40/300 IDs/groups, counts, hashes, final_test_sealed=false). Full `reference_usability_ledger.jsonl`, `source_group_ledger.jsonl`, `qualified_cohort/qualification_ledger.jsonl` và counts giữ local ignored trong `research-data/tib-qualification-261019-1703/`.
Final benchmark_cohort.json/selection outputs chưa tạo; không nhầm development seal với final seal.
- benchmark/experiments/registry/protocols/tib-model-benchmark-v1/diagnostic_spec.json: P3 sở hữu, khóa targetN/core IDs/quotas/strata/ties/replacements và thuật toán chọn metric extremes trước final seal. Extreme IDs chưa biết trước metrics; P5 chỉ chọn cơ học sau final scoring. P4 bind hash spec trước predictions.
- Cohort lưu proposed/sealed state,native split,study/source/reference hashes,role(pilot/selection/final),stratum,group,decision/reason/exposure; dev seal và final seal có timestamps/version riêng.
- [Old cohort](../../benchmark/experiments/registry/datasets/tib-rq2-rq4-120-cohort-261012.json), [old protocol](../../benchmark/experiments/registry/datasets/tib-rq2-rq4-120-protocol-261012.json) chỉ đọc.
P4 đọc cohort; sửa phải P3/version mới, không hai owners cùng ghi.

## Implementation Steps

1. Ghi target population/task/source/domain và claim boundary.
2. Chốt keep/exclude/flag/HOLD rules trước candidate outputs.
3. Adjudicate duplicates/groups và lịch sử tuning/old120/pilot.
4. Đếm source→candidate→rights/qualification→group-safe availability; unknown giữ unknown.
5. Ưu tiên protected native test groups trước development allocation; chốt cutpoints/seed và ledger role validation rời nhau.
6. Calibrate rubric trên train/development, adjudicate225 flags và unknown→B; seal pilot40/selection300 hoặc availability-only fallback200 trước selection outputs. Đổi rule phải version/requalify mọi split trước outcomes liên quan; dưới200 stop/amend, không dùng test.
7. P4 trả feasibility/model selection/budget; contextcapacity xử lý bằng development adapter/candidate admission/K_models/K_total,không loại valid test vì dài/OOM. Qualification chỉ sửa do evidence dữ liệu/quyền/task theo predeclared policy; amendment hợp lệ requalify mọi split trước final seal,không dựa candidate outcomes.
8. Sau validation selection, seal toàn eligible test hoặc fallback exactN/rule/trigger cùng K_models/K_total/candidate policies, A/B/C labels/sensitivity denominators và diagnostic_spec40 trước predictions.
9. Export hashes/role/group accounting; không chọn lại ID vì quality/runtime thất bại.

## Validation và success criteria

- Unit: deterministic selection300→200 availability-only/below200-stop, một decision mỗi row, dev-role/group overlap bằng0; known-tuned/test overlap bằng0 hoặc HOLD; protected-test priority; A/B/C evidence/uncertain→B/no arbitrary short cutoff.
- Integration: source/ref hashes nối manifest, exposure roles đúng, A+B/A-only/C/HOLD accounting, frozen labels không từ model outcomes; diagnostics40 cùng final cohort, selected denominator cố định.
- E2E: cùng manifest/policy/seed tái tạo IDs; P4 seal không đổi ngầm rule.
- [x] Frame development464 validation sau exposure đủ40/300 group-disjoint; policy local-use/HOLD minh bạch trước outputs.
- [x] Mọi qualification/exposure exclusion có evidence; flags không thành outcome filtering, chưa có candidate outputs.
- [x] Rubric calibrated/frozen và225 historical flags có ledger; A+B primary, A-only unavailable doA0, rights/structural HOLD riêng; historical8.769 không ép làm số mới.
- [x] Pilot40/selection300 native validation rời ID/group/old-tuning/protected-test; test frame523 sau exposure, EDA-only không tự loại. Final seal vẫn pending.
- [ ] Full test được ưu tiên; fallback có exactN/representative rule/trigger trước outcomes, partial vẫn giữ sealedN.
- [ ] **Final seal** chỉ sau P4 gate; development40/300 đã freeze, không cấp quyền generation.

## Risk Assessment

| Rủi ro | Khả năng × tác động | Mitigation |
|---|---|---|
| Tuning contamination | Cao × cao | Exposure/group ledger, known tuning exclusions |
| Outcome-driven exclusion | Vừa × cao | Rule trước outputs, test review không lọc |
| N/groups không đủ | Vừa × cao | Count gate, sửa mục tiêu trước test |

## Compatibility, rollback và câu hỏi mở

Không sửa old120; chỉ hồi cứu. Rút proposed/sealed version lỗi, giữ reasons/attempts. Nếu test outcomes đã xem thì không tune tiếp rồi gọi independent.
Còn mở: final all-test N hoặc fallback quotas sau P4 budget/model selection, diagnostic_spec/core IDs và remote-use scope. Qualified counts/cutpoints/calibration/40 pilot/300 selection đã versioned; A-only unavailable, group recall unknown. P3 owner phải hoàn tất final seal khi P4 evidence đủ; không dùng523 frame count như sealed benchmarkN. Effort8–12h dự toán lịch sử, không measured promise.
