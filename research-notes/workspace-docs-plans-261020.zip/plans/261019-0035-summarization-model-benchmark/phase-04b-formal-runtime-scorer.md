# P4b — scorer-only formal runtime amendment v1

Status: **PASS — actual Colab T4 fixtures and21stored-output E2E audited**. [Evidence audit](../reports/evidence-audit-261020-0808-tib-colab-scorer-report.md). Scope three existing development sources only; [P4c recovery](./phase-04c-fresh-session-recovery.md) is subsequently audited PASS. Pilot40 actual execution/full-study budget/admission remain open. Historic preparation HOLD/CPU receipts unchanged.

Implements [protocol decision2341](../reports/protocol-decision-261019-2341-tib-development-close-acceptance-report.md), after the existing CPU-ready receipt. No generation, selection300 or final test is authorized by this substage.

## Fixed contract

- ROUGE-1/2/L F1 from official rouge-score0.1.2, stemmer/tokenizer unchanged; ROUGE-L remains whole-sequence LCS.
- BERTScore XLM-R layer17, pinned model/tokenizer revisions, IDF=false/no fit, no baseline rescaling, native512 and direct-ID510-content-token windows unchanged.
- Source sentence similarity retains all source sentences, batch1, sentence128, direct-token windows and content-weighted full-module pooling. Negative cosine values remain valid; this is diagnostic similarity, not factuality.
- FP32/eval, no autocast/TF32. Every metric receives the delivered summary;350word maximum unchanged. Missing/invalid inputs becomeNULL; affected semantic failures retain successful lexical scores.
- All21 saved P4.1 outputs/three existing pilot IDs are scored, including13 derived warning outputs. They are not21 independent sources and provide no model-quality ranking or throughput projection for pilot40/selection300/final523.
- Acceptance policy, dataset, source/reference bytes, cohorts, cap and historic receipts remain unchanged. Lead-3/LexRank remain in the five-candidate formal protocol; this scorer E2E package contains the21 already-stored neural development outputs only.

## Versioned runtime amendment

[Amendment v1](../../benchmark/experiments/registry/protocols/tib-scorer-colab-runtime-261020-v1/runtime_amendment.json) binds the original spec and CPU receipt, frozen scorer implementation hashes, runtime/support requirements and development matrix. Torch2.11.0+cu130/NumPy2.1.3 and CUDA T4 replace the CPU proof environment; other scorer metric pins stay fixed. Exact direct requirements are supplied; all actual transitive distribution versions are captured and checkpoint-bound at runtime. This is not a complete precomputed transitive wheel lock.

The new adapter inherits scoring/windowing mathematics. Actual readiness requires native/window equivalence within1e-5, exact long-input token preservation, native-capacity/FP32 checks, five-metric identity, full-source batching and NULL/fault fixtures on the actual runtime.

## Run and evidence

1. Upload [notebook v2](../../benchmark/experiments/notebooks/tib-p4-scorer-colab-t4-261020-v2.ipynb) to a T4 Colab runtime; upload the unchanged v1 local ZIP when prompted. V2 uses `venv --without-pip` and base `pip --python` to avoid requiring ensurepip; logs and validates the target interpreter, including partial venv repair. Keep Drive private; bundle retains attribution, source licenses, reference CC0 match and private-use constraints.
2. Verify outer ZIP, file manifest, frozen code/spec/receipt, and21input hashes. Install pinned requirements in an isolated environment; download only the two pinned scorer models and verify full asset manifests.
3. Run actual fixtures and scorer-only E2E. Save item-level metrics/failures, input lengths/routes, warnings, CPU/wall cost, RAM/VRAM peaks, GPU capacity, throughput and scorer checkpoints.
4. Export evidence ZIP. It includes source/reference/private data, so do not publish it. Weights and virtual environment are omitted.

The runner writes immutable per-run `scorer_ready_receipt.json`, `metrics.jsonl`, `cost_evidence.json`, `PASS_HOLD_report.json` plus convenient latest copies. Receipt binds actual artifact hashes. Notebook setup/abnormal-exit HOLD receipts cannot display an earlier PASS as current evidence.

Checkpoints bind code/spec/amendment/assets, actual environment and full record input hashes; atomic write/readback is required. Explicit `RESUME=True` validates a **complete** matching21-row cache and reports new E2E scorer calls0 separately from original cost and new initialization/fixture overhead. Partial/missing/corrupt cache returnsHOLD; no automatic fill/retry. A fresh output directory is needed for an explicitly authorized new attempt. This stage does not prove generation checkpoint recovery or cross-session survival.

## PASS/HOLD boundary

PASS requires actual Colab CUDA T4, exact declared pins, verified assets/code/input identities, actual fixtures, finite five-metric results for all21 rows, measured resources and checkpoint readback. Local mocks/dependency-injected tests always produceHOLD and cannot certify Colab readiness. Setup failure, wrong GPU/runtime, changed hashes, missing evidence, metric failures or session guard produceHOLD with reasons and retained denominators where inputs passed validation.

The notebook limits its session to11.5h, below the user12h limit. Download/install/Drive overhead is retained in logs; scorer receipt measures scorer subprocess phases, not total Colab billing or future full-study cost. Runtime outputs must be audited before updating this status.

## Remaining after this substage

Generation and scorer cross-session proof are subsequently closed by [P4c actual audit](./phase-04c-fresh-session-recovery.md). Remaining: [P4d pilot40](./phase-04d-pilot40-runtime.md) actual preflight/execution and measurements, later pilot scoring under reserved resources, full-study quotas and conservative projection; admission/config/cap final-lock before selection300; final seal/full523 or preoutcome500→400. Actual scoped scorer execution/audit is complete; none of these remaining gates is passed by scorer-ready alone.
