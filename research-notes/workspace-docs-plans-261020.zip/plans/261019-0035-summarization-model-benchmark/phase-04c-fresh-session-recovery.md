# P4c — fresh-session recovery before pilot40

User direction2026-10-20: close actual scorer-ready; perform fresh-session P4.1 generation and21-checkpoint scorer replay next. Pilot40 and selection remain gated. Implements decision2341; no new trials, output generation, metric recomputation, metric/policy/cohort changes or checkpoint-key amendments.

Status: **closed PASS — actual Colab T4 v2 recovery audited**. Different VM boot, original288/21 store hashes,21 generation outputs/123 nodes,21 scorer checkpoint reuses/105 unchanged values verified; zero new generation/metric calls. Executed notebook7/7 code cells matches v2, no exceptions. [Actual audit](../reports/evidence-audit-261020-1056-tib-recovery-v2-report.md). V1 HOLD and v2 preparation receipts remain historical. Pilot40 still requires its resource gates.

## Audited v2 artifacts (recovery complete)

- [A — origin handoff notebook](../../benchmark/experiments/notebooks/tib-p4-handoff-colab-261020-v2.ipynb), run in the current Colab session before deleting it.
- [B — executed fresh recovery notebook](../../benchmark/experiments/notebooks/tib_p4_fresh_recovery_colab_261020_v2.ipynb), preserved with actual outputs from the new T4 VM. Recovery is complete; no rerun is needed.
- Both use the same private local ZIP `benchmark/research-data/tib-p4-fresh-recovery-261020-v2/tib-p4-fresh-recovery-261020-v2.zip`; [preparation receipt/hash](../../benchmark/experiments/registry/protocols/tib-p4-fresh-recovery-261020-v2/preparation_receipt.json).
- [Implementation/verification report](../reports/implementation-261020-0831-tib-fresh-session-recovery-report.md). Recovery evidence is exported from notebook B; no pilot or selection runs follow automatically.

## Execution contract

1. Origin handoff notebook, run before disconnecting current Colab runtime: read existing generation/scorer Drive files and verify exact expected SHA; write a new origin witness with boot/session identity and immutable file hashes. No checkpoint replacement/upload/extraction into checkpoint stores. No package/model load required for sealing.
2. Delete/disconnect the old runtime. Start a new T4 runtime and mount Drive. Fresh recovery notebook refuses same VM boot/session or missing origin witness; witness must precede recovery. Environment/boot evidence is exported rather than treating a same-session replay as fresh.
3. Restore existing P4.1 nodes via unchanged original pipeline/checkpoint APIs and original bundle/profile/runtime identities. Reload actual pinned generation assets to independently derive the original runtime hash. A deny-generation backend raises on any cache miss; no model.generate or fallback. Recompute native source windows/lineage and compare all saved node/delivered identities; reuse costs0, original costs separately recorded. All seven historical profiles can be replayed without opening new search; pilot profiles stay BARTcontrol/LEDngram3/Qwen384 plus Lead-3/LexRank.
4. Scorer replay reads the21 original Drive checkpoints with unchanged bundle/runtime/input/assets-manifest bindings, matching existing actual-ready receipt. Reuse the stored105metric values, `new_metric_calls=0`. No scorer models/fixtures/21outputs rescoring required. This replay validates persisted scoring results and runtime identity, not a new scorer-capacity test.
5. Write new recovery receipts/logs/costs/export ZIP; all old artifacts remain unchanged. Local integrity/tests only grant preparation status, never actual fresh-session PASS.

## Gates retained

Actual Colab/Drive/new-session evidence, exact packages/environment, complete verified files and zero fallback calls required. Missing/corrupt/runtime-mismatched artifacts HOLD. Never rewrite runtime hashes or keys to force reuse. GPU reload/tokenizer/validation/restore costs remain visible once per model/session and separate from original generation/scoring costs. Historical recovery session guard11.5h. User pilot-only allocation is now approved in [P4d](./phase-04d-pilot40-runtime.md); actual resource gates and full-study allocation remain separate.

## After recovery

Pilot40 only after recovery and its resource gates pass; remaining presealed IDs with five fixed pipelines. Collect per-ID/stratum/stage latency, warnings/failures, CPU/RAM/VRAM and checkpoint costs. Prior outputs/three development sources do not automatically certify completed pilot40. Freeze actual admission/profile identities/cap350/storage/quota and conservative projection before selection300. Final target523 and preoutcome500→400 unchanged.

## Open

Pilot-only numeric resources are approved in [P4d](./phase-04d-pilot40-runtime.md); actual T4/storage/quota preflight, pilot40 execution/measurements and later pilot scoring remain open. Full-study budget, admission/profile/cap final-lock and selection300 are still gated. Existing scorer-ready and recovery are closed PASS in their audited scopes; no rerun is needed.
