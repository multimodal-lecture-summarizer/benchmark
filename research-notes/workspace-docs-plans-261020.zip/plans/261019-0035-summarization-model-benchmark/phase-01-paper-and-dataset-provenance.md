---
phase: 1
title: Paper và nguồn gốc dataset
status: completed
priority: P1
effort: 4-6h
dependencies: []
---

# Phase 1: Paper và provenance

## Overview

## Current stage — 2026-10-20 pilot40 preparation

[P4b scorer-ready](./phase-04b-formal-runtime-scorer.md) and [P4c fresh-session recovery](./phase-04c-fresh-session-recovery.md) are audited PASS in their stated scopes. [P4d](./phase-04d-pilot40-runtime.md) prepares the unchanged40-ID/five-profile technical pilot under the newly approved pilot allocation. Actual runtime preflight, pilot execution and measurements remain unverified; selection300/final test are not open. Dated evidence sections below retain their original scope and do not supersede this status. P1–P3 qualification/development decisions remain unchanged; P5 remains pending.

## P4 returned evidence — historical audit 2026-10-19

[Audit ZIP Colab](../reports/evidence-audit-261019-2013-tib-p4-returned-capacity-report.md) và [technical execution receipt v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/technical_execution_receipt_v2.json):159 files/155 JSON digests PASS;9 neural outputs replay offline, không inference/scoring mới. BART/LED/Qwen3 fresh3/3 trên actual Tesla T4 FP16, cùng3 staged pilot sources đã seal. LED failure đầu giữ lịch sử; corrected bundlev3 chạy thành công. Lead-3/LexRank có12 saved outputs qua hai lượt trên cùng3sources, không12unique records.

**Capacity PASS scoped3records; P4 vẫn in-progress/P5 pending.** LED repetition/incomplete endings và BART long final=first map cần development review. LED4/9 map và Qwen6/9 map+2/2 reduce chạm256tokens chưa EOS. Final9/9 EOS dưới768;0/9 cap350cuts. Giữ350maximum nhưng cap/profile chưa final-lock; không sửa config/cohort hoặc chọn model từ audit này. Numeric quotas/projection, formal-runtime scorer, effective runtime/config logging, expanded pilot và cross-session Drive reuse còn thiếu.40/300/523 giữ nguyên; full523→500→400 theo preoutcome budget;40diagnostics trong final. Không coi một mẫu mỗi stratum là measured p95/upper bound. `measured_profiles.json` projection-ready vẫn empty; raw observations lưu riêng.

Các snapshot18:02/17:03 bên dưới là lịch sử preparation/qualification; câu chưa generation/OAuth-pending ở đó đã được evidence hiện hành này thay thế. Cap/profile freeze trước selection; final seal sau lựa chọn, trước test generation.

## P4 technical execution — 2026-10-19 18:02 (historical snapshot)

- [Scorer-ready receipt](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/scorer_ready_receipt.json): pinned CPU/batch1/FP32 fixtures + actual pretrained native/window and five-metric E2E PASS; IDF=false, no corpus fit. Đây là CPU fixture scope, chưa full-corpus throughput hoặc T4/scorer budget.
- [Output policy](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/output_policy.json): user ratified eligible-train-only p95/ceil25;4.213 records,p95=333 → **350 English whitespace words maximum**, không target. [Evidence v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/output_cap_evidence_v2.json) verifies qualification/canonical/tokenizer hashes; native final reserve768 là proposal. Value derived350 thay current UNSET; **final cap lock vẫn chờ actual candidate feasibility trước selection**. Không dùng validation/test references để chọn cap.
- [Candidate profiles](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/candidate_profiles.json): năm IDs, full native token coverage/Unicode-preserving wrappers và reducers, fixed CPU Lead-3 + full-source LexRank. Local three-source smoke6/6CPU outputs và9 tokenizer plans PASS; model weights chưa chạy trên T4.
- [Compute budget](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/compute_budget.json): full523 →500 →400, diagnostics40 nằm trong final cohort. User cho Colab/Drive và runtime dưới12h; guard11.5h. Không suy runtime/GPU-hours từ token plans hoặc A100. Numeric CPU/storage/call projections và store survival chưa đủ.
- [Colab notebook](../../benchmark/experiments/notebooks/tib-p4-feasibility-colab-261019-v2.ipynb) và source-only ZIP đã upload private Drive, chỉ3 staged pilot sources/attribution, không abstracts/selection/test. Runtime T4 đã kết nối; first mount-Drive cell đang chờ OAuth consent cho client Google Drive for desktop. Auto-review từ chối Continue khi chưa có client/scope approval; không model generation nào trên Colab được xác nhận. [Runbook](../../docs/tib-p4-colab-feasibility.md).
- 134 focused/regression tests PASS. Không pilot40/selection300/final523/formal model selection mới; development40/300 và eligible-test523 giữ nguyên. [Báo cáo](../reports/implementation-261019-1802-tib-p4-readiness-report.md).


P1 completed cho pinned snapshot và **scoped local/private/noncommercial frame**, không blanket rights clearance. Đủ4 shards/full revision/checksums/schema15 fields/counts7.282/910/911;9.103 canonical rows có raw/normalized hashes và offsets. Source6.171 conditional/2.932 HOLD; combined source/reference5.270. Development40/300 đã seal downstream, final test chưa seal; chưa pretrained neural generation hoặc formal benchmark.

## Requirements

- Paper/source accounting tái lập, phân biệt card hiện tại với snapshot pinned.
- Creator abstract không đồng nhất về chất lượng/mục đích; chỉ là reference agreement.
- Quyền transcript/abstract/metadata và media có ledger riêng; thiếu media rights không tự chặn text nếu quyền actual text use đủ.

## Architecture

Official TIB release (9.103 records, native train/valid/test) + paper + pinned snapshot → raw/normalized manifest + evidence/rights ledger → P2/P3. Chỉ một benchmark chính text-only; không tách benchmark độc lập theo genre/domain, không tạo gold mới.
Abstract chỉ đi qualification/scorer/review được phép; generator nhận canonical transcript không timestamps, không nhận reference fields hoặc độ dài reference từng test record.
Không gửi private receipt/source sang API ngoài phạm vi được phép.

## Canonical normalization contract

| Trường bắt buộc | Quy tắc và trace |
|---|---|
| source_raw / source_normalized | Transcript gốc / bản chuẩn hóa kỹ thuật có version |
| reference_raw / reference_normalized | Abstract gốc / chuẩn hóa kỹ thuật, không viết lại |
| record_id | DOI hoặc released/source ID ổn định; giữ mapping về native row/file/ID, xử lý DOI thiếu/trùng minh bạch |
| group_id | Source-content dependency group có evidence; không thay record_id |
| source_length | English whitespace words và native tokens riêng từng tokenizer/revision/profile |
| quality_flags | Empty, short/generic/reused reference, duplicate, encoding/ASR/segment anomalies; flag không tự exclusion |
| eligibility_status | eligible, flagged, excluded hoặc HOLD; reason/evidence/policy version bắt buộc |

Chỉ NFC, whitespace và sửa encoding theo rule xác định; giữ raw bytes, raw/normalized hashes, transformation log và offset mapping về raw. Không paraphrase, sửa ngữ nghĩa, ghép câu để “làm sạch” hay thay reference. Không sửa trực tiếp bytes nguồn.
Canonical input lấy trường `transcript`. `transcript_segments` là sidecar kiểm order/time/source-coverage intervals; mismatch phải flag/adjudicate, không tự tái dựng hay thay canonical transcript. Full canonical source sẵn cho mọi pipeline; Lead-3 chọn ba câu đầu ở bước thuật toán output, không phải cắt input chung. Primary prompt không timestamp. Timestamp profile chỉ là tùy chọn ngoài primary scope, phải frozen riêng trước một thực thi được phép; không ngầm mở thêm study.

## Nguồn cần đối chiếu

| Nguồn gốc | Nội dung cần khóa |
|---|---|
| [TIB CBMI2023](https://hal.science/hal-04168911), [dataset card](https://huggingface.co/datasets/gigant/tib) | Mục tiêu, transcript/abstract, splits, limitations và reuse terms |
| [LexRank 2004](https://www.cs.cmu.edu/afs/cs/project/jair/pub/volume22/erkan04a.pdf) | Graph centrality, thuật toán và implementation |
| [BART paper](https://arxiv.org/abs/1910.13461), [checkpoint](https://huggingface.co/facebook/bart-large-cnn) | CNN/DailyMail transfer, card MIT; pin lại actual revision |
| [LED paper](https://arxiv.org/abs/2004.05150), [checkpoint](https://huggingface.co/allenai/led-large-16384-arxiv) | arXiv transfer, card Apache-2.0, long context chưa chứng minh fit T4 |
| [Qwen3 report](https://arxiv.org/abs/2505.09388), [Qwen3-4B](https://huggingface.co/Qwen/Qwen3-4B) | Instruction causal, template/thinking/decode, card Apache-2.0; pin lại |

Paper hỗ trợ lựa chọn phương pháp; popularity không phải tiêu chí. Model license không cấp quyền dataset.
Không suy toàn bộ 9.103 rows hợp pháp chỉ từ card.

Historical [báo cáo xác minh](../reports/research-261019-0933-summarization-scientific-t4-verification-report.md#nguồn-và-giới-hạn-truy-cập) ghi hạn chế truy cập lúc09:33; pinned README/HAL full paper đã recovered và verified trong evidence15:07. Đây là giới hạn truy cập, không phải evidence bác bỏ nguồn. P1 đã đối chiếu actual snapshot/card bytes+revision+checksum và per-record terms theo scoped policy17:03; amendments/remote use phải revalidate scope trước thực thi. Current URL main/model license không thay thế quyền dữ liệu. Paper/model/scorer attribution phải có evidence hoặc nhãn unverified/adaptation, không tự VERIFIED vì đã có URL.

Phân biệt official TIB với bản trung gian như `tib_01`; full snapshot SHA, raw file hashes, released-ID mapping và split counts phải khớp. Đã xác minh attribution Lead-3 và Extractive Oracle từ official HAL PDF: section5.2/PDFpage5, Table2/PDFpage7; [paper accounting](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/evidence-261019-1507/paper_source_accounting.json). Lead-3 lấy ba câu đầu transcript; Oracle dùng reference. Splitter/caps/dependency versions của local implementation vẫn chưa xác minh reproduction. Extractive Oracle chỉ là optional reference-aware diagnostic ceiling, không deployable candidate, không gold mới, không vào ranking/family decision hoặc quality–cost claims. Gợi ý EMNLP2024 reference-free relevance của nhóm TIB: citation/formula/implementation **UNVERIFIED**, default off; chỉ cân nhắc diagnostic nếu pin trước selection và đủ budget, không post-hoc tiebreak.

## Evidence bổ sung — 2026-10-19 15:07

[Latest dataset evidence](../reports/dataset-evidence-261019-1507-tib-snapshot-rights-report.md) và [source binding](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/evidence-261019-1507/source_binding.json) thay blocker thiếu shards/remote pin trước đây:4 shards/full SHA/LFS/card/schema/counts PASS. Đã đối chiếu official OpenData44.254 rows:5.592 reference có supported CC0 field match,6.503 source có conditional CC route,0 source CC0 text matches. Các số không phải eligible cohort; scope lúc15:07 chưa khóa; policy17:03 nay giữ conditional/HOLD từng row theo local-use scope. [Research quyền/paper](../reports/research-261019-1507-tib-rights-provenance-report.md) xác minh original Lead-3/Oracle attribution; local reproduction và optional EMNLP relevance vẫn chưa xác minh. Raw/full ledgers giữ local ignored; development40/300 đã seal17:03, không có quyền public redistribution.

## Evidence thực thi — 2026-10-19 17:03

Pinned snapshot `e6ab9fd7c6acd164f3284b8c4b17eb9d94681eee`: 9.103 canonical records có raw/normalized hashes và offset trace; native splits 7.282/910/911. Source-use policy khóa cho **local/private/noncommercial**, giữ attribution, không public text redistribution/external API transfer: 6.171 source conditional / 2.932 HOLD, 5.270 records qua combined source/reference rights. Không blanket allow toàn corpus; chuyển sang remote T4/store phải xác minh phạm vi sử dụng trước chuyển dữ liệu.

Reference policy đã calibrated/frozen trước outputs: **A=0, B=9.095, C=8 empty**. Toàn bộ225 historical reused flags được targeted review trong18 groups;226 casefold members tính cả một row ngoài historical structural frame, giữ B vì chưa đủ evidence usability chắc chắn. AI-assisted review dùng title/opening/anchor spans, không full-transcript factuality certification; A-only sensitivity hiện **unavailable**, không đổi labels để tạo A.

Source audit ghi22 accepted edges /37 records /9.082 components,7 cross-split components; tái hiện known three-record cluster. Retrieval gần đúng, recall unknown; tác giả/title/abstract reuse không tự tạo source group. Additive group replay đã kiểm lại9.103 hashes/22 accepted decisions/components sau import fix; không rerun mọi candidate comparisons, original runtime code identity chưa sealed đầy đủ.

| Native split | Source | Data eligible | Sau exposure filtering |
|---|---:|---:|---:|
| train | 7.282 | 4.215 | 4.213 |
| valid | 910 | 532 | 464 |
| test | 911 | 523 | 523 |

**40 pilot /300 selection validation đã seal, không kích hoạt fallback200**; không trùng ID/group giữa roles, old120/9 pilot hoặc protected eligible test groups. 523 là eligible test frame hiện tại, **final test chưa seal**; full-first và fallback600→500→400 giữ nguyên, chỉ xét N nhỏ hơn frame và đủ budget. Không generation/selection metrics/T4 pilot.

- [Source-use policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/source_use_policy.json), [reference policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/reference_policy.json), [reference summary](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/reference_summary.json), [source-group policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/group_policy.json).
- [Qualification policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/qualification_policy.json), [development cohort](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/development_cohort.json) bind exact IDs/groups/counts/policy hashes. Full canonical/rights/reference/group/exposure ledgers và CPU EDA receipt giữ local ignored tại `benchmark/research-data/tib-qualification-261019-1703/`.
- CPU EDA đã chạy toàn9.103 rows,4 plots, native BART/LED/Qwen token counts từ pinned tokenizer files. Illustrative window counts chỉ lower bounds chưa gồm wrappers/overlap/reduce; actual native layouts và capacity còn P4-dependent.
- **W_global derived350; final feasibility lock pending**. Scorer-ready, candidate profiles/decode/scoring capacity, numeric quotas và actual persistent-store receipts còn thiếu. Host xác minh RTX4050 Laptop6GB/16GB RAM, **không phải T4**; không suy T4 feasibility.

## Related Code Files

Artifact lịch sử owner P1, **audit_unsealed tại10:35**, không thay qualification policy/development seal17:03:
- [Latest audit manifest](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/audit-261019-1035/dataset_manifest.json), [rights ledger](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/audit-261019-1035/rights_ledger.json) và [complete-export receipt](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/audit-261019-1035/audit_receipt.json).
- Audit lần đầu ở root registry được giữ lịch sử; latest subdirectory có completion marker/checksums/tool hashes, không overwrite evidence.
- Code: [offline audit CLI](../../benchmark/experiments/scripts/tib_model_benchmark_audit.py), [snapshot/schema/checksum](../../benchmark/experiments/scripts/tib_model_benchmark_snapshot.py), [shared development contracts](../../benchmark/experiments/scripts/tib_model_benchmark_contract.py).
- [Implementation report](../reports/implementation-261019-1035-tib-local-audit-report.md). Paper-source-accounting15:07 và canonical normalized rows/offset mapping9.103 records17:03 đã tạo; xem evidence thực thi dưới đây.
- Downstream chỉ đọc sealed version; amendment quay P1.

Evidence chỉ đọc:
- [Workflow](../../benchmark/README.md): dataset/EDA trước evaluation, không placeholder notebook.
- [Source counts](../../benchmark/experiments/notebooks/diagnostics/rq2-tib-all-splits-eda-colab.ipynb).
- [Raw receipt limitation](../../benchmark/docs/results/rq2-tib-120-results-261013.md).

## Implementation Steps

1. Ghi paper/version/date/URL/claim/unknown; tách architecture paper khỏi checkpoint task/domain.
2. Đối chiếu local snapshot và source revision/file checksum; chỉ download sau quyền thực thi và đủ điều kiện reuse.
3. Ghi đủ canonical schema ở trên, source split/segment-sidecar/metadata và provenance trường; kiểm raw→normalized→raw offsets, không semantic rewrite.
4. Đối chiếu source splits7.282 train/910 valid/911 test; canonicalization có version, byte hashes riêng.
5. Ghi terms/license theo release và row/source URL khi có; unknown giữ HOLD, không đổi thành allow.
6. Ghi attribution/redistribution/actual text-abstract use riêng media; large data/weights không vào Git.
7. Manifest gồm revision/hashes/schema/counts/rights evidence/extraction/exposure/unknowns cho **mọi split**, giữ native train/validation/test không gộp đổi tên.
8. Ghi released record ID riêng source-content group ID: cùng ID/file lặp là ingestion duplicate cần accounting, khác released ID hợp lệ vẫn là record riêng. Repeated abstract không chứng minh nguồn trùng; overlap evidence/thresholds do P3 khóa trước outcomes. Lưu rule loại225 reused abstracts lịch sử như evidence; P3 adjudicate A/B/C, không mặc định áp lại hoặc tự khôi phục. A/B/C là proposed research policy, không released TIB labels/gold.
9. Giao manifest đủ scope cho P2; P3 chỉ chọn phần đủ quyền. Thiếu scope thì sửa mục tiêu trước selection.

## Validation và success criteria

Execution slice10:35:34 tests PASS gồm contract/snapshot/CLI và legacy dataset tests; independent scoped code-review PASS. Cached card checksum đã đo; observed split counts vẫn null, rights unreviewed, G1 HOLD. Nested schema được kiểm bằng temporary Parquet tests (struct-of-arrays/list-of-struct), chưa xác minh actual released shards. B helper là proposed/uncalibrated, không thay rubric P3 hoặc tự adjudicate225 flags. Đây là lịch sử10:35; acceptance hiện tại được backfill theo snapshot15:07 và scoped qualification17:03, không dùng test fixtures thay evidence actual rows.

- Unit tương lai: required schema, hashes, ID mapping/uniqueness, split totals, NFC/whitespace/encoding rules và offset mapping.
- Integration: manifest row → source/reference bytes đúng; canonical transcript khác segment-sidecar phải flag; reference fields không vào generator; text rights không suy từ model license.
- E2E: một record từ pinned bytes → canonical ordered text có trace, không model.
- [x] Mỗi source file pinned hoặc HOLD rõ; remote/API/LFS binding và actual rows9.103 đã xác minh trong evidence15:07.
- [x] Frame đủ evidence reuse text/abstract trong local/private/noncommercial scope; remaining unknown/HOLD không qua gate.
- [x] Paper/card của bốn model families và transfer limits được dẫn nguồn; Lead-3 attribution verified; local reproduction/model runtime và optional relevance ghi UNVERIFIED, Oracle không candidate.
- [x] Pinned manifest/canonical trace và rights policy/ledger versioned; development cohort40/300 sealed riêng, không giả final cohort/candidates đã freeze.

## Risk Assessment

| Rủi ro | Khả năng × tác động | Mitigation |
|---|---|---|
| Card drift/row rights thiếu | Vừa × cao | Pin evidence, HOLD phần chưa đủ quyền |
| Media/text rights lẫn | Vừa × cao | Ledger theo modality/actual use |
| Snapshot drift | Vừa × cao | Revision + byte hashes, không thay âm thầm |

## Compatibility và rollback

Không sửa old source/protocol/notebook hoặc license metadata lịch sử.
Rút manifest mới khỏi active reference, giữ HOLD/reasons; downstream dừng version bị rút.
Không xóa evidence để làm rights ledger “sạch”.

## Câu hỏi còn mở

Full SHA/remote inventory/checksums/counts/schema/canonical trace và original Lead-3/Oracle attribution VERIFIED. Local-use policy xử lý per-record DOI/prose/license exceptions; unmatched/không đủ grant giữ HOLD. Scope remote T4/store phải xác minh trước transfer; optional EMNLP2024 citation/formula/local reproduction còn unverified. Effort4–6h là dự toán lịch sử, không measured schedule.
