# P4d — pilot40 runtime preparation

User2026-10-20 authorizes next stage after actual P4c v2 recovery PASS. Deliver a private, hash-bound source-only Colab T4 pilot bundle and notebook. Actual execution remains user-run. No local pretrained inference; no selection300/final test, metric/config search or historical artifact changes.

Status: **prepared; local validation PASS144tests, actual Colab preflight/execution not run**. [Notebook](../../benchmark/experiments/notebooks/tib-pilot40-colab-t4-261020-v1.ipynb), private ZIP in `benchmark/research-data/tib-pilot40-261020-v1/`, [delivery report](../reports/implementation-261020-1107-tib-pilot40-preparation-report.md).

## Contract

- Exactly the existing40 sealed pilot IDs and five fixed candidates: Lead-3, LexRank, BARTcontrol, LEDngram3, Qwenr384. Common delivered cap350; same splitters/native wrappers/windows/decode and intermediate acceptance v1.
- Three previously audited pilot IDs may import the nine preferred neural artifacts only after original manifest/source/profile/runtime/checkpoint identity validation and native replay. Historical output/telemetry remains immutable; apply acceptance as a new derived pilot view. Original time separately recorded; imported outputs never enter fresh latency tails. Do not regenerate these outputs to force prospective evidence.
- Generate remaining37 neural IDs per candidate plus40 CPU controls each. Expected pilot matrix200 cells:9 imported neural +111 new neural +80 new CPU. Missing/failed/pending remain in this denominator. This is a technical pilot; it does not choose models or recompute frozen metrics. Scorer-ready and scorer recovery receipts remain dependencies, not fresh pilot scoring claims.
- Store per-node checkpoints, per-record artifacts/attempts, source-length stratum, calls/native tokens/depth, delivery lengths/cuts, clean/warning/failure, CPU/RAM/GPU/VRAM and init/checkpoint/recovery costs. Warnings remain successful technical outputs; no score-based exclusions or retries. CPU GPU/VRAM=N/A.
- User allocation confirmed: totalGPU11.5h, totalCPU23CPUh, total active wall11.5h; at most2 sessions, each<=11.5h;15% session headroom. Drive checkpoint/log2GiB; minimum local free32GiB, local working cap24GiB (different quantities); transfer cap16GiB. ScoringGPU1.5h/CPU3h and recovery0.5h are reserves inside totals. Flush after every committed node; zero automatic retries. These are authorized operating ceilings, not measured demand. Full-study allocation remains unset.
- Runtime probes enforce actual T4, exact pins, available host/device/disk and persistent-store write/fsync/rename/readback. Check remaining quotas and conservative node forecast before long work. Source order remains frozen; no long-tail removal. Session2 may resume matching committed work with cumulative budgets. Any unobserved interruption cost is explicitly unknown and conservatively reserved, never reset to zero. Exhaustion produces partial on the original40, not a smaller completed cohort.
- New versioned package/profile/acceptance/budget binding for prospective pilot checkpoints. Historical bundles/keys/read-only Drive stores never modified. Resume validates all bound identities and saved envelopes; no cached fallback on mismatches. A failed attempted node is not automatically retried on resume.

## Implementation

1. Inspect existing generation/CPU/checkpoint/acceptance modules and pinned qualification/cohort artifacts. Verify all40 source hashes/rights/eligibility, selection disjointness and original3 identities locally without model loading.
2. Add small pilot runtime modules for resource gates/monitoring, technical validation and generation orchestration. Reuse existing adapters/acceptance and original read-only replay helper; do not alter their frozen code.
3. Build private source-only bundle with pinned requirements, stage config, profile list, provenance/rights/cohort manifests and immutable historical dependencies. Export a notebook with one explicit configuration section, preflight, sequential candidate subprocesses, summary and evidence ZIP. Full session budget includes install/download/probes and export headroom.
4. Focused tests: exact40×5 coverage, immutable bindings/source-only inputs, missing quota HOLD, failed gate before model load, warnings retained, native/CPU lineage failure, safe resume/mismatch/no retry, partial denominator, no selection/test/metric calls. Compile notebook cells, inspect package hashes and ignore status. Independent review before delivery.
5. Publish preparation receipt/report and update current plan. Do not claim actual pilot PASS or grant study admission from local tests.

## Acceptance

Notebook/ZIP local and reviewable; all paths/hashes reported; preparation tests pass. User allocation is frozen; actual runtime state remains REQUIRED_NO_START until measured preflight passes. Completion requires actual returned Colab evidence for all200 cells, including explicit failures and imported/fresh distinctions.

## Open

Actual Colab resources and pilot40 execution; fresh pilot measurements and later scorer evaluation; admission/profile/cap final-lock and total-study budget before selection300.
