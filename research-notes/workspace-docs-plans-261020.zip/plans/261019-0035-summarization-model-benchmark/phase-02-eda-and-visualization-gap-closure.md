---
phase: 2
title: Bổ sung EDA và visualization
status: in-progress
priority: P1
effort: 6-8h
dependencies:
  - 1
---

# Phase 2: EDA và visualization theo gap

## Overview

## Current stage — 2026-10-20 pilot40 preparation

[P4b scorer-ready](./phase-04b-formal-runtime-scorer.md) and [P4c fresh-session recovery](./phase-04c-fresh-session-recovery.md) are audited PASS in their stated scopes. [P4d](./phase-04d-pilot40-runtime.md) prepares the unchanged40-ID/five-profile technical pilot under the newly approved pilot allocation. Actual runtime preflight, pilot execution and measurements remain unverified; selection300/final test are not open. Dated evidence sections below retain their original scope and do not supersede this status. P1–P3 qualification/development decisions remain unchanged; P5 remains pending.

## P4 returned evidence — historical audit 2026-10-19

[Audit ZIP Colab](../reports/evidence-audit-261019-2013-tib-p4-returned-capacity-report.md) và [technical execution receipt v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/technical_execution_receipt_v2.json):159 files/155 JSON digests PASS;9 neural outputs replay offline, không inference/scoring mới. BART/LED/Qwen3 fresh3/3 trên actual Tesla T4 FP16, cùng3 staged pilot sources đã seal. LED failure đầu giữ lịch sử; corrected bundlev3 chạy thành công. Lead-3/LexRank có12 saved outputs qua hai lượt trên cùng3sources, không12unique records.

**Capacity PASS scoped3records; P4 vẫn in-progress/P5 pending.** LED repetition/incomplete endings và BART long final=first map cần development review. LED4/9 map và Qwen6/9 map+2/2 reduce chạm256tokens chưa EOS. Final9/9 EOS dưới768;0/9 cap350cuts. Giữ350maximum nhưng cap/profile chưa final-lock; không sửa config/cohort hoặc chọn model từ audit này. Numeric quotas/projection, formal-runtime scorer, effective runtime/config logging, expanded pilot và cross-session Drive reuse còn thiếu.40/300/523 giữ nguyên; full523→500→400 theo preoutcome budget;40diagnostics trong final. Không coi một mẫu mỗi stratum là measured p95/upper bound. `measured_profiles.json` projection-ready vẫn empty; raw observations lưu riêng.

Các snapshot18:02/17:03 bên dưới là lịch sử preparation/qualification; câu chưa generation/OAuth-pending ở đó đã được evidence hiện hành này thay thế. Cap/profile freeze trước selection; final seal sau lựa chọn, trước test generation.

## P4 technical execution — 2026-10-19 18:02 (historical snapshot)

- [Scorer-ready receipt](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/scorer_ready_receipt.json): pinned CPU/batch1/FP32 fixtures + actual pretrained native/window and five-metric E2E PASS; IDF=false, no corpus fit. Đây là CPU fixture scope, chưa full-corpus throughput hoặc T4/scorer budget.
- [Output policy](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/output_policy.json): user ratified eligible-train-only p95/ceil25;4.213 records,p95=333 → **350 English whitespace words maximum**, không target. [Evidence v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/output_cap_evidence_v2.json) verifies qualification/canonical/tokenizer hashes; native final reserve768 là proposal. Value derived350 thay current UNSET; **final cap lock vẫn chờ actual candidate feasibility trước selection**. Không dùng validation/test references để chọn cap.
- [Candidate profiles](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/candidate_profiles.json): năm IDs, full native token coverage/Unicode-preserving wrappers và reducers, fixed CPU Lead-3 + full-source LexRank. Local three-source smoke6/6CPU outputs và9 tokenizer plans PASS; model weights chưa chạy trên T4.
- [Compute budget](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/compute_budget.json): full523 →500 →400, diagnostics40 nằm trong final cohort. User cho Colab/Drive và runtime dưới12h; guard11.5h. Không suy runtime/GPU-hours từ token plans hoặc A100. Numeric CPU/storage/call projections và store survival chưa đủ.
- [Colab notebook](../../benchmark/experiments/notebooks/tib-p4-feasibility-colab-261019-v2.ipynb) và source-only ZIP đã upload private Drive, chỉ3 staged pilot sources/attribution, không abstracts/selection/test. Runtime T4 đã kết nối; first mount-Drive cell đang chờ OAuth consent cho client Google Drive for desktop. Auto-review từ chối Continue khi chưa có client/scope approval; không model generation nào trên Colab được xác nhận. [Runbook](../../docs/tib-p4-colab-feasibility.md).
- 134 focused/regression tests PASS. Không pilot40/selection300/final523/formal model selection mới; development40/300 và eligible-test523 giữ nguyên. [Báo cáo](../reports/implementation-261019-1802-tib-p4-readiness-report.md).


EDA bao phủ fixed snapshot9.103 bản ghi ở native train/valid/test cho một benchmark TIB text-only. Reuse10 executed cells/8 PNG/0 errors; bổ sung theo covered/partial/missing matrix, không làm lại toàn notebook hoặc tạo benchmarks theo genre/domain.

## Evidence hiện tại

## Evidence thực thi — 2026-10-19 17:03

Pinned snapshot `e6ab9fd7c6acd164f3284b8c4b17eb9d94681eee`: 9.103 canonical records có raw/normalized hashes và offset trace; native splits 7.282/910/911. Source-use policy khóa cho **local/private/noncommercial**, giữ attribution, không public text redistribution/external API transfer: 6.171 source conditional / 2.932 HOLD, 5.270 records qua combined source/reference rights. Không blanket allow toàn corpus; chuyển sang remote T4/store phải xác minh phạm vi sử dụng trước chuyển dữ liệu.

Reference policy đã calibrated/frozen trước outputs: **A=0, B=9.095, C=8 empty**. Toàn bộ225 historical reused flags được targeted review trong18 groups;226 casefold members tính cả một row ngoài historical structural frame, giữ B vì chưa đủ evidence usability chắc chắn. AI-assisted review dùng title/opening/anchor spans, không full-transcript factuality certification; A-only sensitivity hiện **unavailable**, không đổi labels để tạo A.

Source audit ghi22 accepted edges /37 records /9.082 components,7 cross-split components; tái hiện known three-record cluster. Retrieval gần đúng, recall unknown; tác giả/title/abstract reuse không tự tạo source group. Additive group replay đã kiểm lại9.103 hashes/22 accepted decisions/components sau import fix; không rerun mọi candidate comparisons, original runtime code identity chưa sealed đầy đủ.

| Native split | Source | Data eligible | Sau exposure filtering |
|---|---:|---:|---:|
| train | 7.282 | 4.215 | 4.213 |
| valid | 910 | 532 | 464 |
| test | 911 | 523 | 523 |

**40 pilot /300 selection validation đã seal, không kích hoạt fallback200**; không trùng ID/group giữa roles, old120/9 pilot hoặc protected eligible test groups. 523 là eligible test frame hiện tại, **final test chưa seal**; full-first và fallback600→500→400 giữ nguyên, chỉ xét N nhỏ hơn frame và đủ budget. Không generation/selection metrics/T4 pilot.

- [Source-use policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/source_use_policy.json), [reference policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/reference_policy.json), [reference summary](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/reference_summary.json), [source-group policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/group_policy.json).
- [Qualification policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/qualification_policy.json), [development cohort](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/development_cohort.json) bind exact IDs/groups/counts/policy hashes. Full canonical/rights/reference/group/exposure ledgers và CPU EDA receipt giữ local ignored tại `benchmark/research-data/tib-qualification-261019-1703/`.
- CPU EDA đã chạy toàn9.103 rows,4 plots, native BART/LED/Qwen token counts từ pinned tokenizer files. Illustrative window counts chỉ lower bounds chưa gồm wrappers/overlap/reduce; actual native layouts và capacity còn P4-dependent.
- **W_global derived350; final feasibility lock pending**. Scorer-ready, candidate profiles/decode/scoring capacity, numeric quotas và actual persistent-store receipts còn thiếu. Host xác minh RTX4050 Laptop6GB/16GB RAM, **không phải T4**; không suy T4 feasibility.


- [EDA inventory](../../benchmark/docs/DATASET_EDA.md): 10 executed cells, 0 errors; notebook có8 PNG; 9.103 →9.002 →8.769 candidates.
- [Output nguồn](../../benchmark/experiments/notebooks/diagnostics/rq2-tib-all-splits-eda-colab.ipynb): splits7.282/910/911; structural excluded101.
- [Genre/denominators](../../benchmark/docs/DATASET_EDA.md): exact Conference/Talk7.966/9.103, exact Lecture827/9.103.
- [Old120 audit](../reports/research-261018-2225-rq2-hypothesis-evaluation-reassessment-report.md): 109 Conference/Talk, 7 Lecture thuần,97 CS thuần,120 en metadata; không chứng nhận classroom lectures.

## Requirements

P1 manifest đủ provenance là blocker. Toàn train/valid/test đã EDA-exposed; ghi exposure.
EDA không tự qualification factuality/reference quality/lecture relevance. Test EDA-exposed vẫn có thể vào final theo qualification; không gọi pristine holdout và không dùng final outputs để tune.
Không dùng final candidate outputs/test metrics chọn exclusions.

## Architecture và gap matrix

Pinned source → kiểm saved EDA → covered/partial/missing matrix → bổ sung → tables/figures/decision → P3.

| Phân tích | Gap cần đóng | Đầu ra/decision |
|---|---|---|
| Splits/structural/missing | Covered lịch sử; kiểm version/schema | Source→usable→eligible accounting từng split |
| Source length | Kiểm gaps trong saved tables/plots | Words p50/p90/p95/max, histogram/tails; strata/map–reduce projection |
| Reference length | Train/development distribution cần quyết định cap | Words p50/p90/p95/max và plots; một W_global trước selection |
| Compression ratio | Source/reference words, zero denominator rõ | Quantiles/histogram/scatter, không outcome cutoff |
| Reference anomalies | Empty/short/generic/reused frequencies còn cần ledger | N/rate/rule từng split, liên kết A/B/C policy P3; short không tự unusable |
| Duplicate/exposure | Exact/near-source groups/cross-split/tuning links | ID/group/exposure ledger và uncertainty; abstract reuse không là source duplicate |
| Genre + subject + language | Distribution theo native split/source/candidate | Lecture, Conference/Talk, subjects, rare/unknown N; representation diagnostics, không benchmark riêng |
| ASR/segment anomalies | Empty/order/time/coverage/mismatch | N/rate từng split; sidecar check so canonical transcript, không implicit reconstruction |
| Native tokens/windows tails | Tokenizer/wrapper/window policy chưa pin | BART/LED/Qwen native tokens, p50/p90/p95/max và map/reduce windows; LexRank/Lead-3 sentence/CPU tails |
| Baseline similarity | Lexical signals lịch sử có, kiểm N | Diagnostic histogram/scatter, không factuality/reference A/B/C label |

8 empty và225 reused abstracts bị loại trong EDA lịch sử sau structural filtering;900 lexical-flag candidates vẫn được giữ. P3 adjudicate từng225 flags theo rubric A usable/B uncertain/C unusable có evidence, không ép A/C khi chưa chắc; B giữ primary nếu qua eligibility khác. Không loại tùy ý abstract dưới30/50 words hoặc dùng ROUGE để đặt label. Repeated abstract riêng lẻ không xác nhận trùng transcript. Không coi8.769 là qualified frame mới bắt buộc; counts mới reconcile ledger, historical counts bất biến.
Valid eligible887 là frame lịch sử, chưa phải số validation mới đủ cho hai role rời nhau hoặc số test đủ điều kiện. Native test có911 nguồn; qualified test N tính lại theo policy mọi split.
Old120 có6 abstracts<30 words và segment flags: diagnostic, không tự loại cả cohort.
Full source/usable/candidate/proposed cohort có cột N riêng; không lẫn mẫu số.

## Development-derived output policy

**W_global derived350; final feasibility lock pending** tới khi eligible native-train reference-length distribution và product constraint được ghi/ratify trước selection. Không giữ250 words như fixed/default scientific choice. Khóa một global English-whitespace-word cap, cùng common delivered selector cho bốn model families và fixed Lead-3 control; không đổi cap theo từng test reference. Native max_new_tokens256/384 vẫn là proposals phải đánh giá lại theo W_global, decoder/context bounds và measured coverage; words không bằng tokens. Raw/delivered lengths, compression, capping/failure/cost báo riêng. Test reference length hay reference field khác không đi vào generator hoặc selector.
Train dùng policy/cutpoints/assets/IDF nếu cần; validation pilot40 phục vụ feasibility/development. Test chỉ EDA/qualification theo rule, không dùng test distribution để ratify output cap. Khi W_global/rubric đổi trên development, version/requalify/rescore đúng owner trước selection, không outcome filtering.

Availability/length plots hiện hữu không chứng minh coverage selection. Sau này báo V, config-family C_f, representatives C_between và final-pair N riêng theo [hai tầng P4](./phase-04-candidate-selection-and-t4-benchmark-protocol.md#development-và-validation-selection-contract); không dùng C_f khác population để kết luận family. EDA không chạy generation để điền các coverage này. Native token tails và225 reused-reference review đã có evidence snapshot mới; wrapper-aware windows/scorer layouts/capacity còn P4-dependent, không suy từ8.769 lịch sử.

## Related Code Files

Owner P2, **CPU EDA đã thực thi**:
- `benchmark/research-data/tib-qualification-261019-1703/eda/{summary.json,receipt.json,record_metadata.jsonl,canonical_records.jsonl.gz}` và4 PNG giữ local ignored.
- Native-token counts pin từng tokenizer/revision, serialized backend hash; không download weights hoặc inference.
- [Gap matrix](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/eda_gap_matrix.json) và [EDA summary](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/eda_summary.json) đã tạo, phân covered/open; notebook trình bày artifacts thực chạy theo execution receipt, không placeholder. Actual wrapper/map/reduce/scorer windows, LexRank/Lead-3 sentence CPU tails và W_global còn chưa freeze.
- [EDA notebook cũ](../../benchmark/experiments/notebooks/diagnostics/rq2-tib-all-splits-eda-colab.ipynb) giữ bất biến.
Downstream đọc artifact sealed; native tokenizer pins từ P4 có thể yêu cầu P2 amendment trước test seal.

## Implementation Steps

1. Đối chiếu manifest/hash với saved notebook; gắn evidence_current/planned.
2. Đánh covered/partial/missing theo units/N/version, không copy số khác snapshot.
3. Tổng hợp segment anomalies và source/author/title flags; tác giả giống không tự là duplicate.
4. Bổ sung source-versus-candidate domain/genre và length tails khi thiếu.
5. Áp canonical schema P1: raw/normalized source/reference, ID/group mapping, word/native-token lengths, flags/status/reasons; chỉ technical normalization và offset trace. Transcript là input, segments sidecar; primary không timestamps. Không dùng một tokenizer thay mọi model.
6. Sau pin tokenizer/config, hoàn thiện native counts qua P2 version mới trước selection: causal input+special+output reserve chung cap; encoder và decoder counts/caps riêng cho BART/LED, gồm padding/global attention policy. P4 có thể dùng conservative layout trước pilot, không đợi advertised-context full probe.
7. Không coi advertised context là safe T4 length; map/window counts phải dùng candidate policy.
8. Đề xuất strata/cutpoints từ source/train trước outcomes; P3 quyết định eligibility/rubric A/B/C. Báo availability theo split/group cho pilot40 validation và selection300 validation rời nhau, loại old120/9 pilot/known-linked groups. Chỉ availability thiếu mới fallback selection200 trước outputs; dưới200 stop/amend, không lấy test bù. Diagnostics40 unique IDs từ final cohort; 40 pilot/300 selection đã seal trên464 validation eligible;40 diagnostics vẫn planned, không power guarantee.
9. Từ eligible native-train lengths và product constraint, đề xuất W_global có evidence cho P4 freeze trước selection; không per-record test-reference length steering. Phân bố test được báo riêng cho EDA/exposure, không chọn cap.
10. Khi được thực thi: xuất executed notebook/tables/figures/receipt và decision; không fake output.

## Validation và success criteria

- Unit: reconcile historical9.103/9.002/8.769 với counts mới, quantiles/compression-zero-denominator/native wrappers/technical normalization.
- Integration: plots truy cùng manifest/ledger; train/development-only W_global inputs; A/B/C và source-group/exposure denominators riêng, thresholds không lấy từ model outcomes.
- E2E: tái tạo chart từ pinned input, run bổ sung không errors.
- [x] Matrix cho biết covered/open analyses và quyết định còn phụ thuộc profiles/capacity.
- [x] Figures CPU EDA có units/N/split/denominator và native token tails;4 PNG/9.103 records, không thay runtime tail measurements.
- [x] Source/data-eligible/after-exposure/development-cohort counts riêng; test EDA-exposed không gọi pristine.
- [ ] Matrix nêu đầy đủ reference/source tails, compression/anomaly rates, A/B/C ledger, duplicates/exposure, genre+subject-by-split, ASR anomalies và native-window tails; W_global chưa freeze vẫn ghi UNSET.
- [x] Scoped conditional/HOLD và A/B/C evidence giữ riêng, không tạo gold mới.

## Risk Assessment

| Rủi ro | Khả năng × tác động | Mitigation |
|---|---|---|
| Rerun EDA vô ích | Cao × vừa | Gap-first, reuse output cùng hash |
| Bias mẫu số/genre | Cao × cao | Population riêng và narrow target |
| Native context tails thiếu | Cao × cao | Wrapper-aware counts/P4 feedback trước seal |

## Compatibility, rollback và câu hỏi mở

Output mới riêng version/root, không ghi đè notebook/figures cũ. Rút bổ sung lỗi và giữ ledger; P3/P4 revalidate dependencies.
Còn mở: actual wrapper-aware windows/map-reduce/scorer layouts, reference-length/product constraint→W_global và final seal/budget. Native-token CPU tails, A/B/C225 review, source groups, eligible counts và40/300 development đã có evidence. Group recall unknown; A-only unavailable. Effort6–8h dự toán lịch sử, không measured schedule.
