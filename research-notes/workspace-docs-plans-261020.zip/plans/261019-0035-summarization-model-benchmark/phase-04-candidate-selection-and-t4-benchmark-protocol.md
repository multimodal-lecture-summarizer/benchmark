---
phase: 4
title: Tuyển chọn pipeline và protocol T4
status: in-progress
priority: P1
effort: 20-30h
dependencies:
  - 1
  - 2
  - 3
---

# Phase 4: Ứng viên và benchmark T4

## Overview

## Current stage — 2026-10-20 pilot40 preparation

[P4b scorer-ready](./phase-04b-formal-runtime-scorer.md) and [P4c fresh-session recovery](./phase-04c-fresh-session-recovery.md) are audited PASS in their stated scopes. [P4d](./phase-04d-pilot40-runtime.md) prepares the unchanged40-ID/five-profile technical pilot under the newly approved pilot allocation. Actual runtime preflight, pilot execution and measurements remain unverified; selection300/final test are not open. Dated evidence sections below retain their original scope and do not supersede this status. P1–P3 qualification/development decisions remain unchanged; P5 remains pending.

## Acceptance và priority decision — current

[User decision2341](../reports/protocol-decision-261019-2341-tib-development-close-acceptance-report.md) khóa [policy v1](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/development-decision-261019-2341/intermediate_acceptance_policy_v1.json): completed_with_warning là successful generation có flags, giữ scoring/denominators/common coverage; lỗi kỹ thuật vẫn failed/NULL. Native EOS/config checks neural-only; CPU controls dùng source/hash/algorithm/output validators, EOS=N/A. Không retry/exclude theo quality score. Priority BARTcontrol/LEDngram3/Qwen384 cộng retainedLead-3/LexRank, chưa formal admission. Search đóng,512optional/disabled. Formal-runtime scorer và fresh-runtime unchanged-P41-bundle recovery đã audited PASS; pilot allocation đã được duyệt; actual pilot preflight/measurements, full-study budget và admission còn mở; old receipts không relabel. Derived view mới bind policy riêng.

## P4.1 development amendment

Latest: [actual7trials đã audit](../reports/evidence-audit-261019-2222-tib-p41-returned-trials-report.md),21outputs/123freshT4nodes; execution/integrity PASS, generation issues chưa giải quyết hết. Prepared implementation summary bên dưới là snapshot trước user-run; không supersede audit. Registry/cap/cohorts unchanged; không config winner hoặc selection mới.

[Execution plan](./phase-04a-generation-development-trials.md) và [implementation report](../reports/implementation-261019-2122-tib-p41-development-trials-report.md) khóa default7 controlled profiles trên3sources, Qwen512 deferred. Telemetry/checkpoint identity/failure-cost và offline BART diagnostics đã có; notebook/ZIP prepared, actual trials chưa chạy. Cap350/context4096 Qwen và cohort40/300/523 giữ nguyên. Không coi prepared trials hoặc fixture PASS là formal admission/scorer/pilot40/selection evidence. Technical policy observe-and-continue-with-flags không tự retry/exclude; formal intermediate acceptance phải khóa trước selection.

## P4 returned evidence — historical audit 2026-10-19

[Audit ZIP Colab](../reports/evidence-audit-261019-2013-tib-p4-returned-capacity-report.md) và [technical execution receipt v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/technical_execution_receipt_v2.json):159 files/155 JSON digests PASS;9 neural outputs replay offline, không inference/scoring mới. BART/LED/Qwen3 fresh3/3 trên actual Tesla T4 FP16, cùng3 staged pilot sources đã seal. LED failure đầu giữ lịch sử; corrected bundlev3 chạy thành công. Lead-3/LexRank có12 saved outputs qua hai lượt trên cùng3sources, không12unique records.

**Capacity PASS scoped3records; P4 vẫn in-progress/P5 pending.** LED repetition/incomplete endings và BART long final=first map cần development review. LED4/9 map và Qwen6/9 map+2/2 reduce chạm256tokens chưa EOS. Final9/9 EOS dưới768;0/9 cap350cuts. Giữ350maximum nhưng cap/profile chưa final-lock; không sửa config/cohort hoặc chọn model từ audit này. Numeric quotas/projection, formal-runtime scorer, effective runtime/config logging, expanded pilot và cross-session Drive reuse còn thiếu.40/300/523 giữ nguyên; full523→500→400 theo preoutcome budget;40diagnostics trong final. Không coi một mẫu mỗi stratum là measured p95/upper bound. `measured_profiles.json` projection-ready vẫn empty; raw observations lưu riêng.

Các snapshot18:02/17:03 bên dưới là lịch sử preparation/qualification; câu chưa generation/OAuth-pending ở đó đã được evidence hiện hành này thay thế. Cap/profile freeze trước selection; final seal sau lựa chọn, trước test generation.

## P4 technical execution — 2026-10-19 18:02 (historical snapshot)

- [Scorer-ready receipt](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/scorer_ready_receipt.json): pinned CPU/batch1/FP32 fixtures + actual pretrained native/window and five-metric E2E PASS; IDF=false, no corpus fit. Đây là CPU fixture scope, chưa full-corpus throughput hoặc T4/scorer budget.
- [Output policy](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/output_policy.json): user ratified eligible-train-only p95/ceil25;4.213 records,p95=333 → **350 English whitespace words maximum**, không target. [Evidence v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/output_cap_evidence_v2.json) verifies qualification/canonical/tokenizer hashes; native final reserve768 là proposal. Value derived350 thay current UNSET; **final cap lock vẫn chờ actual candidate feasibility trước selection**. Không dùng validation/test references để chọn cap.
- [Candidate profiles](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/candidate_profiles.json): năm IDs, full native token coverage/Unicode-preserving wrappers và reducers, fixed CPU Lead-3 + full-source LexRank. Local three-source smoke6/6CPU outputs và9 tokenizer plans PASS; model weights chưa chạy trên T4.
- [Compute budget](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/compute_budget.json): full523 →500 →400, diagnostics40 nằm trong final cohort. User cho Colab/Drive và runtime dưới12h; guard11.5h. Không suy runtime/GPU-hours từ token plans hoặc A100. Numeric CPU/storage/call projections và store survival chưa đủ.
- [Colab notebook](../../benchmark/experiments/notebooks/tib-p4-feasibility-colab-261019-v2.ipynb) và source-only ZIP đã upload private Drive, chỉ3 staged pilot sources/attribution, không abstracts/selection/test. Runtime T4 đã kết nối; first mount-Drive cell đang chờ OAuth consent cho client Google Drive for desktop. Auto-review từ chối Continue khi chưa có client/scope approval; không model generation nào trên Colab được xác nhận. [Runbook](../../docs/tib-p4-colab-feasibility.md).
- 134 focused/regression tests PASS. Không pilot40/selection300/final523/formal model selection mới; development40/300 và eligible-test523 giữ nguyên. [Báo cáo](../reports/implementation-261019-1802-tib-p4-readiness-report.md).


Một primary TIB text-only study: bốn model families + fixed cheap CPU control Lead-3. Pilot40 validation → selection300 validation (availability-only fallback200 trước selection outputs; dưới200 stop/amend) rời ID/group → khóa lựa chọn/config → full qualified native test≤911 ưu tiên, fallback600→500→400 trước outputs nếu budget không fit.40 pilot/300 selection validation đã seal theo development_cohort17:03, không fallback200;523 eligible test frame chưa final seal. Chưa pretrained neural generation/T4 pilot, không power/feasibility guarantee. User đã cho triển khai từng stage; chỉ chạy stage khi đủ gate phụ thuộc.

## Đầu vào đã có / gate còn thiếu

[Development cohort](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/development_cohort.json) đã seal40/300; counts sau exposure4.213/464/523. [CPU EDA gap matrix](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/eda_gap_matrix.json) ghi native-token tails đã chạy, windows chỉ lower bounds; wrappers/overlap/reduce, LexRank/Lead-3 sentence CPU tails và measured capacity chưa có. [Compute preflight](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/compute_preflight.json): RTX4050 Laptop6GB, không phải T4. Local/private/noncommercial source-use scope không tự cho remote transfer. W_global final-lock/candidate admission/numeric budgets/actual T4/store receipts còn REQUIRED_NO_START; scorer đã CPU-fixture-ready. P4 owner tiếp tục hoàn tất implementation plan/adapters/evaluator và gates trước inference.

## Architecture và shortlist

Canonical transcript theo P1, toàn source sẵn cho mọi pipeline, không abstract/reference-derived per-record length hoặc timestamps → native algorithm/adapter → maps/reduce khi cần → raw final → common delivered selector/W_global → receipts → pinned scorer đọc reference riêng → P5. Segments là sidecar order/time/coverage, mismatch flag không thay transcript.

| Ứng viên sơ bộ | Profile pilot, chọn config bằng validation trước final seal |
|---|---|
| LexRank | CPU graph toàn nguồn; sentence splitter,TF-IDF normalization,similarity threshold,damping,stopwords,ties,length selector; không learned checkpoint |
| facebook/bart-large-cnn | CNN/DailyMail encoder-decoder; native window-map/reduce toàn nguồn |
| allenai/led-large-16384-arxiv | arXiv long encoder-decoder; direct nếu đo fit, không thì predeclared window-map/reduce |
| Qwen/Qwen3-4B | Instruction causal; chat-window-map/reduce; enable_thinking=False đề xuất |
| Lead-3 / fixed CPU control | Ba câu đầu của canonical transcript theo một frozen splitter, giữ source order → common delivered cap; một profile ID pins code/splitter/normalization/selector/W_global, không learned model/config search/GPU generation |

[Papers/cards](./phase-01-paper-and-dataset-provenance.md) hỗ trợ shortlist, chưa chính thức. Registry ghi keep/conditional/reject với evidence năm tiêu chí; popularity không là criterion.
Domain-transfer/adapters khác nhau → pipeline comparison, không causal architecture ranking.
Không tự thay Qwen3 thành Qwen2.5-1.5B.
Lead-3 là sanity/control thêm vào cả validation/final, không family thứ năm để tune. Full source vẫn được cung cấp, lấy ba câu đầu là thuật toán output selection; không gọi Lead-3 full map-coverage hoặc input truncation cho các model. Attribution “baseline original TIB paper” **VERIFIED** theo HAL PDF section5.2/Table2 (evidence19/10 15:07); proposed control vẫn không mặc định reproduction về splitter/caps/dependencies. Extractive Oracle optional diagnostic reference-aware ceiling, default ngoài candidate/decision/ranking/deployable cost claims; không cấp quyền chạy thêm. EMNLP2024 relevance optional **UNVERIFIED/default off**, chỉ pin formula/implementation và budget trước selection nếu được phép, không post-hoc tiebreak.

## Context và output contract

- Full canonical source available chung; bốn model families xử lý nguồn theo full-coverage contract và log native/canonical tokens/source intervals. Lead-3 khai explicit first-three-sentence algorithm và source spans đã chọn, không đòi full-source map coverage cho control này.
- Không quiet truncation/hidden top-N sentences/overlap chưa khai. Primary prompt không timestamps; timestamp input profile riêng ngoài primary scope cần freeze và authorization riêng, không ngầm thêm study.
- [BART config](https://huggingface.co/facebook/bart-large-cnn/blob/main/config.json) max_position_embeddings1024; [LED config](https://huggingface.co/allenai/led-large-16384-arxiv/blob/main/config.json) encoder16384/decoder1024/attention_window1024. CPU EDA đã pin config/tokenizer revisions/files; actual runtime candidate profiles vẫn cần bind/freeze, không hứa LED16K/Qwen32K fit T4.
- Qwen causal: `input_tokens + chat/special_tokens + max_new_tokens <= frozen_context_cap`; template/thinking/assistant prefix đều được đếm. Không suy encoder-decoder dùng cùng công thức.
- BART/LED: `encoder_tokens + special_tokens`, sau frozen padding, phải ≤ encoder cap; decoder prefix + generated tokens/EOS phải ≤ decoder cap riêng. BART input native1024, LED decoder native1024 chỉ là giới hạn config cần pin lại, không bảo đảm W_global words. LED global-attention positions/mask, attention-window padding và backend khóa/hash; padded length cũng phải fit.
- Map/reduce xử lý **tất cả ordered source intervals và tất cả notes**, giữ dependency/coverage ledger từng layer. Group nhiều notes phải có fan-in≥2, không singleton pass-through loop; mỗi reduction layer giảm nghiêm tổng native note tokens, đồng thời note count phải tiến tới1. Freeze prompt/intermediate caps, max_depth và progress check trên pilot; non-progress/depth hit/empty result là failure giữ selected ID.
- Một note đơn lẻ vượt reducer input cap: chia thành ordered token-safe subnotes rồi reduce theo policy đã freeze, vẫn đủ source lineage; nếu không bảo đảm progress/caps thì failure, không input truncation. Final conversion phải fit native decoder/output reserve; word selector chỉ áp output, không được cắt source/notes để fit.
- LexRank toàn nguồn, kiểm O(n_sentences²) RAM; sparse/block chỉ nếu frozen-equivalent method, không LLM rewrite.
- Sentence-unit policy phải ghi cách xử lý ASR thiếu dấu câu bằng splitter frozen; không âm thầm thay bằng ASR segments.
- **W_global derived350; final feasibility lock pending** đến khi eligible native-train reference-length distribution + product constraint quyết định một global English-whitespace-word cap trước selection.250 words không fixed/default scientific choice. Không dùng test reference length hay reference field bất kỳ để điều khiển generator/selector; không per-record oracle length. Native max_new_tokens256/384 chỉ proposals phải reassess theo W_global, tokenization và measured capacity; words không bằng native tokens. Intermediate budgets riêng phải freeze/công khai.
- Common deterministic sentence-boundary delivered selector: giữ thứ tự raw sentences, nhận câu hoàn chỉnh còn fit W_global; không câu nào fit thì failure theo rule. LexRank raw extractive selection và Lead-3 first3 phải log trước common delivered selector, không dùng reference để chọn câu hoặc bản raw/delivered tốt điểm hơn.
- Lưu raw_final/delivered_final/hash/word counts/length_capping flags/violations; chấm delivered, giữ raw audit. Không chọn bản có metric tốt hơn.
- Compression/depth/window policy freeze trước test, log realized counts; cùng cap không bằng cùng compute.

## Decode và identity

Pin checkpoint SHA/tokenizer/config/code/libs/license,precision/quantization,adapter/prompts/windows,selector,seeds,hardware.
LexRank pin implementation/assets/config thay checkpoint weights. Lead-3 pin một fixed code/splitter/profile/selector identity; đổi identity cần preselection amendment, không metric-tune control hoặc trials.
Qwen3 non-thinking card gợi ý T0.7/top_p0.8/top_k20; pilot kiểm candidate-appropriate profiles,per-ID seed mapping. Trước model selection khóa danh sách/budget config search và criteria; chọn config trên selection validation,khóa exact identity trước test.
Không ép oldgreedy/seed42 mọi candidate rồi gọi fair. Qwen greedy deviation cần development justification, không gọi card recommendation.
Một stochastic repetition là single realization; record bootstrap không đo seed variance. Pilot-only seed sensitivity tùy chọn, cost riêng.
Qwen4B FP16 đầu tiên,batch1/cap bảo thủ;4-bit chỉ theo predeclared pilot decision với candidate identity mới; không hidden fallback/test-OOM config change.

## T4 profile đề xuất và capacity gate

Bảng sau là **layout đề xuất trước pilot**, chưa frozen registry/chưa đo. Host đã xác minh RTX4050 Laptop6GB/16GB RAM, không phải T4. Không cam kết các profile fit, không bắt buộc chạy full32K. Mỗi map/reduce/final stage phải có profile riêng kể cả khi dùng cùng giá trị.

| Pipeline/stage | Dtype/batch | Input và output proposal | Decode/backend phải khóa |
|---|---|---|---|
| LexRank / graph + final | CPU /1 record | Toàn source; delivered≤W_global (UNSET) | Sparse/dense graph method, splitter/ties; đo graph RAM O(n²) |
| Lead-3 / fixed control | CPU /1 record | Canonical transcript → first3 sentences → delivered≤W_global (UNSET) | Frozen splitter/code/selector/profile ID; đo CPU/RAM, generator GPU/VRAM N/A |
| BART / map, reduce, final | FP16 /1 | Encoder≤1024 kể cả specials/padding; decoder prefix+EOS+output≤1024; đề xuất max_new_tokens256/256/384 | Deterministic beam4 proposal; decoder cap độc lập encoder |
| LED / map, reduce, final | FP16 /1 | Encoder cap4096 proposal; decoder≤1024; max_new_tokens256/256/384 proposal | Beam4; global mask/padding/attention_window/backend pins |
| Qwen3-4B / map, reduce, final | FP16 /1 | Context4096 proposal; max_new_tokens256/256/384 được reserve trong context | Non-thinking, T0.7/top_p0.8/top_k20 proposal; KV-cache/backend pins |
| ROUGE / scorer | CPU /1 proposal | Full delivered/reference theo scorer spec | Tokenization/stemming/code hash |
| BERTScore / scorer | FP32 /1 proposal | Frozen pair-window policy/native caps | Model/tokenizer/backend/IDF pins; capacity đo riêng |
| Source sentence similarity / scorer | FP32 /1 proposal | Frozen source/sentence windows/native caps | SBERT adaptation/formula/encoder/window/backend pins; provenance và capacity đo riêng |

Mọi row/stage bổ sung measured identity: dtype, batch, beam/search, input/output caps, attention backend/version, KV cache on/off/type/device, device map, offload location, quantization bits/config hoặc none, padding side/multiple/mask và tokenizer. Không BF16 mặc định, không auto device-map/offload ẩn. 4-bit Qwen là candidate profile identity mới chỉ khi predeclared pilot decision cho phép. Backend compatibility phải thực đo trên T4; không giả FlashAttention supported. Generator/scorers load/unload tuần tự, **không GPU concurrency**.

Ghi host RSS/system used/available peak và GPU allocated/reserved/device-used peak/available, sampling method và stages riêng. Target≤12GiB/free≥2GiB chỉ headroom proposal, actual fit mới là gate. Optional development capacity ladder2K/4K/8K/16K với stop khi OOM/headroom/host/quota fail; chỉ thử mức native hợp lệ, BART không nâng khỏi1024. LED/Qwen có thể giữ conservative4K nếu fit; không xem quảng cáo context là yêu cầu mở full context.

## Development và validation selection contract

1. P3 đã seal pilot40 và selection300 validation rời theo ID/group, loại old120/9 pilot cũ/known-linked groups; chỉ availability thiếu300 mới fallback200 trước selection outputs, dưới200 stop/amend không lấy test. Chọn trước3 pilot short/medium/long gồm extreme source-only, batch1; mở full pilot sau native bounds/measured memory gate. P2 eligible native-train reference distribution+product constraint→P4 freeze W_global trước selection. P4 tạo/khóa scorer spec/receipt theo P5 metric contract và verify capacity trước selection; không phụ thuộc thực hiện P5. P3 rubric A/B/C đã calibrated/frozen, A+B primary; A-only hiện unavailable vìA0, không tự relabel sau scores.
2. Trước pilot inference freeze `pilot_metric_tuning_trial_cap_per_candidate`, `pilot_feasibility_probe_cap_per_candidate`, `pilot_total_profile_cap`, probe record IDs và stop order, optional seed-repeat cap. Phân loại metric-tuning vs context/backend feasibility, đều giữ profile-change history và cost. Trước selection freeze exact allowed config list/hash, `selection_trial_cap_per_candidate`, `selection_total_profile_cap`, resource stop rule. Cap là numeric bắt buộc do quota quyết định; thiếu → **REQUIRED_NO_START** cho stage. Không unlimited search, không hứa equal trials/equal compute fairness.
3. P4 sở hữu scorer-ready receipt hash toàn metric code/libs/model/revision/tokenizer/preprocessing/window/aggregation/IDF corpus+weights/batch/backend. IDF/assets fit trên train theo policy frozen trước selection; nếu thật cần pilot-calibration phải khai development-only IDs và freeze, không selection/test fit. Scorer amendment sau selection bắt buộc rescore **mọi stored selection output của mọi tried model config và Lead-3** cùng V, rerun cả tầng A/B trước final seal; không regenerate để tối ưu scorer. Giữ old scores/decision/masks và amendment chain; thiếu stored outputs để rescore đủ→no_selection/no final seal.
4. **Hai tầng trên cùng sealed selection V=300 validation (availability fallback200), không thêm split/N.** Trước outputs khóa bốn model-family IDs, allowed config lists/trial caps/config exact-tie priorities và **một fixed Lead-3 control profile, không trials**. Config admission chỉ theo status/coverage/resource rules đã freeze, không bỏ config vì quality để thay intersection. Scored-success là generation-complete + primary ROUGE-L F1 scorable; BERTScore secondary, source similarity diagnostic có coverage/missingness riêng, lỗi đó không tự xóa primary/gán0. Báo attempted/completed/scored/failed/not_attempted trên toàn V/strata cho cả control; NULL không0. Mọi model trial/attempt/cost và control attempt/cost giữ đủ.
5. **Tầng A — config trong từng family f.** Gọi A_f là tập config admitted theo rule đã khóa; khóa observed membership từ status trước tổng hợp quality. Tính C_f = giao các scored-success IDs của A_f trong V, chỉ cho family f. Mọi config của family được so sánh bằng record-weighted mean ROUGE-L F1 trên đúng C_f. Chọn max mean; exact tie theo frozen config priority, cuối cùng stable profile ID. Không yêu cầu config thắng sibling≥0.01, không suy statistical equivalence/superiority từ chọn config đại diện. Một config admitted vẫn có thể là đại diện nếu đạt coverage; A_f rỗng hoặc C_f thiếu floors → family config-stage fail, không tự chuyển config sau khi xem family comparison.
6. **Coverage gate ở từng tầng.** Ratify/freeze trước selection: mỗi admitted model config/control scored coverage≥95% overall và≥90% mỗi **predeclared source-length stratum** của V (ví dụ short/medium/long, cutpoints P3). Mỗi C_f/C_between đạt≥90% overall,≥80% mỗi source-length stratum, commonN≥180 và≥20 mỗi nonempty source-length stratum, mẫu số theo V. Không áp floor20 cho mọi rare genre/subject/A/B/C cell; các cell đó báo N/shortfall diagnostics riêng. Allocation không thể đạt floors→amend scope trước outputs/no-start. Đây là engineering policies, không power/precision guarantee. C_f fail→family không representative; C_between/control fail→no_selection. Không bỏ đối thủ/hard IDs để cứu coverage.
7. **Tầng B — selected model representatives + fixed Lead-3 control (tối đa5 pipelines).** Đóng băng F_between gồm model families pass tầng A/resource admission trước quality aggregation. Mỗi family một r_f; control không vào tầng A/C_f/config search. Freeze control admission/coverage/failure rule trước outputs; Lead-3 phải có ≥95% overall/≥90% stratum scored coverage như config, missingness/cost báo riêng. Tính mới C_between = giao primary scored-success IDs của mọi admitted r_f **và fixed Lead-3**; không giao mọi tried/historical configs. Recompute tất cả representative/control means và paired deltas trên đúng C_between; C_f means không dùng ranking giữa family. Đại diện/control profile không đổi để cứu common coverage. Dưới2 model families hoặc common/control gate fail→no_selection; không bỏ control âm thầm để cứu winner, báo membership/reasons đầy đủ.
8. **Model-family recommendation, không config/control recommendation.** Proposal leader trong bốn model families phải hơn mỗi rival model representative≥0.01 absolute ROUGE-L (scale0–1), giữ chiều delta ở source-length strata đủ floor. Lead-3 là sanity/quality guard: predeclare leader không kém fixed control trên C_between và strata đủ floor (delta≥0); guard fail/reversal/missing control→no_selection, không chọn Lead-3 thành learned-model recommendation hoặc bỏ control sau scores. Ratify guard/delta/ties trước selection. Tie/practical-small model difference, coverage fail hoặc reversal ở model-pair intersection/stratum đủ floor→no_selection; pair-specific means chỉ diagnostics. Không sibling-delta0.01, không suy equivalence để chọn rẻ. Chỉ bốn model families thuộc recommendation set.
9. **Không bảo đảm common coverage khi tăng trials.** Coverage95% từng config không đảm bảo intersection90%; M profiles cho union bound max(0,1−0.05M), không failure prediction. Trial caps/allowed lists khóa trước outputs. Extra model config chỉ ảnh hưởng family-local C_f; C_between chỉ selected representatives+fixed control. Family-local intersection fail thì báo fail, không bỏ config theo quality. Sau family comparison không mở trials, đổi representative/control, hạ floors hoặc đổi membership để tìm winner. Ghi V/A_f/C_f/r_f/F_between/control/C_between, actualN/stratumN/groupN, all hashes/membership reasons/decision versions.
10. Khóa representatives, `K_models≤4`, fixed Lead-3 và `K_total=K_models+1≤5`, locked validation model choice hoặc no_selection. Ưu tiên cả4 models+Lead-3 final nếu gates/budget cho phép. Resource-based subset phải predeclare rule/lý do trước seal; không recompute validation population/recommendation chỉ vì giảm K_models. Không giữ được selected model→no_selection/blocked, không nâng runner-up. Final outcomes kiểm chứng choice/contrasts đã khóa, không tune/reselect. Cùng identity reuse outputs, không double-count/candidate cherry-picking; scorer amendment rescore ALL tried model/control selection outputs và rerun tầng A/B trước seal.

Tầng B reuse representative+Lead-3 predictions/per-item scores cùng V/scorer identity; recompute aggregates/deltas trên C_between, không thêm cohort hoặc nhân đôi generation. Additional aggregation/scorer-amendment cost riêng, inherited generation không double-count. Max5 pipelines→max10 paired contrasts, gồm model–model và model–control; optional reference-quality/group/genre diagnostics không tạo study mới hoặc đổi recommendation set.

## Budget và fallback contract

Trước mỗi stage, protocol phải có numeric `total_gpu_hours`, `total_cpu_hours`, `total_wall_hours`, `max_sessions`, `session_wall_hours`, `session_headroom_fraction`, `persistent_storage_bytes`, `local_working_storage_bytes`, `transfer_bytes`, `scoring_gpu_cpu_hours`, `checkpoint_bytes`, `checkpoint_flush_seconds`, `recovery_time_hours`, `retry_limit_per_node`, `retry_cost_reserve`, toàn bộ profile/probe/trial caps và accounting scope. Unknown numeric quota = **REQUIRED_NO_START**, không suy feasibility từ16GB host hay nominal T4. 12h/session và30%headroom chỉ proposal cần ratify, không tổng budget. Quyền ghi actual checkpoint store là gate riêng.

Projection base/conservative theo candidate×source-length stratum: measured normalized map/reduce/final **calls per record**, native token lengths/layers/depth và latency tails(p50/p90/p95/max theo N thật), CPU graph/control/scoring, init/load/preprocess/export/transfer/checkpoint/recovery/retry reserve/session overhead. Báo sample support và uncertainty của tail; thiếu đo→chưa pass conservative gate. Không dùng oldQwen1.5B timing hoặc số final summaries thay calls. Neural generator GPU chỉ BART/LED/Qwen; LexRank và Lead-3 CPU, GPU/VRAM generation **N/A**, không zero-cost. Scorer GPU/CPU và mọi costs báo riêng.

| Stage, một profile mỗi model và một fixed control | Model finals (4 families) | Lead-3 finals | Total finals, không phải calls |
|---|---|---|---|
| Pilot40 | 160 | 40 | 200 |
| Selection300 | 1.200 | 300 | 1.500 |
| Availability fallback selection200 | 800 | 200 | 1.000 |
| Full qualified test≤911 | ≤3.644 | ≤911 | ≤4.555 |
| Budget fallback test600/500/400 | 2.400/2.000/1.600 | 600/500/400 | 3.000/2.500/2.000 |

Counts tối đa giả cả4 models admitted; thực `K_models×N` + `N` control, K_total≤5. Chưa gồm additional configs, maps/reduce calls, probes/seed repeats, retries, scorers/checkpoints; tính riêng ledgers/quota. Tầng B reuse selection outputs, không nhân đôi counts.

Deterministic decision trước test: (a) full qualified frame≤911 qua nhiều phiên nếu conservative projection fit **mọi quota**; (b) nếu không fit, xét600→500→400, chỉ N nhỏ hơn qualified frame, chọn largest feasible N có P3 source-only representative/group/floor allocation đạt; (c) frame<400 chỉ full frame nếu fit; (d) không mức nào fit → **blocked/no formal run**. Với frame400–600 cũng xét full trước, rồi chỉ smaller allowed N; không tăng frame, không sub400 fallback. Thứ tự/quota/exactN/IDs/strata/group rule và K/config/scorer identities seal trước predictions. Không tự giảm N/quota sau outcomes: thiếu quota sau seal → partial trên nguyên sealedN, không completed-prefix replacement.

## Related Code Files và ownership

Owner P4; một shared contract đã có trong P1 foundation, mọi runtime artifacts khác vẫn đề xuất:
- [Development pipeline registry](../../benchmark/experiments/registry/models/tib-summarization-pipelines-v1.json) đã tạo: five IDs/four model families+fixed CPU Lead-3, W_global/revisions/scorer receipt UNSET, state development_unsealed. Shared contract/tests sinh ten contrasts và model-only recommendation IDs từ registry. Chưa có runtime coverage masks/adapters/evaluator; không coi foundation là P4 hoàn tất hoặc profile seal.
- benchmark/experiments/registry/protocols/tib-model-benchmark-v1.json.
- benchmark/experiments/registry/protocols/tib-model-benchmark-v1/{scorer_spec,scorer_ready_receipt}.json; P4 tạo/seal/amend, P5 chỉ đọc immutable versions.
- benchmark/experiments/scripts/tib_model_benchmark_*.py (modules runtime nhỏ,snake_case theo scripts), **ngoại trừ tib_model_benchmark_analysis.py thuộc P5**. P3 sở hữu diagnostic_spec; P4 bind hash cùng final seal trước predictions. Scorer_spec/scorer_ready_receipt thuộc P4 như trên.
- benchmark/experiments/outputs/tib-model-benchmark-v1/{pilot,selection,predictions,receipts}/.
- Trong selection/: family_config_selection.json, family_comparison.json và comparison_sets.jsonl do P4 sở hữu; lưu riêng cả hai tầng, không tạo các artifacts này trong phiên lập kế hoạch.
Notebook mới chỉ khi dataset/cohort qualified và execution cụ thể, không placeholder.
Không sửa [frozen pair](../../benchmark/experiments/scripts/rq2_tib_benchmark_pair.py); [receipt section_summaries](../../benchmark/experiments/scripts/rq2_tib_benchmark_pair.py) có trong code, raw artifacts local chưa chứng minh.
Không kế thừa legacy truncation/mock/estimated usage; chỉ reuse helpers được trace/verify, runners version mới.

## Failure và resume contract

Mọi selected ID có attempted/completed/failed/not_attempted,error stage/type,source/prompt/profile hashes,intervals/counts/raw-delivered và timing/memory.
OOM/empty/decode/coverage/length/scorer errors không làm ID biến mất; missing quality NULL, không0.
Qualification là dữ liệu/task/rights; runtime/OOM/context failure không phải lý do loại test/replacement hoặc đổi common cohort. Dừng budget sau seal: partial report trên nguyên N,K/config đã khóa; không gọi completed subset là fallback.
Retry rule/limit freeze trước; cùng identity khi hợp lệ, append mọi attempt/cost,unknown timing NULL.

Durable checkpoint đơn vị **map/reduce node**, không đợi xong record. Key gồm study/source/record/profile/adapter hashes, layer/node, ordered child hashes và source-coverage intervals; payload gồm output/token counts, stable node RNG seed, timing/memory, hash/version. Seed=stable hash(study,record,profile,layer,node,base seed), **không thêm attempt index**. Resume chỉ reuse committed node đúng dependency/input/profile hash; thay child invalidates descendants, không silent recompute successful incompatible outputs.

Write temp→flush/fsync theo store capability→verify hash/readback→atomic commit marker/rename (hoặc manifest commit protocol được kiểm chứng với actual store). Interrupted partial files không committed, không reuse. Scorer checkpoints tách khỏi generation, bind delivered/reference/scorer hashes; scorer retry không rerun generator. Mỗi attempt/cost append riêng với attempt ID; committed node lineage kế thừa không double-count cost. Unknown interrupted cost vẫn NULL/unknown ledger, không0.

Trước full pilot đo checkpoint durability/readback, flush interval, outage window/loss bound và restore time trên **actual authorized persistent store**; session-local disk không đủ multi-session durability. Plan không cấp quyền Drive hay tự giả mounted Drive bền. Store unavailable → stop trước quota loss bound, giữ partial ledger; không claim resumable nếu chưa verify. Resume kiểm device/backend/libs/profile compatibility; hardware drift ghi receipt và timing strata riêng, reprobe capacity trước tiếp tục. Không từ một run hay khác máy suy repeatable speed.

Config change tạo profile mới trước test; không trộn versions. Sau final seal không tự đổi adapter/precision/seed hoặc retry policy để cứu OOM.

## Validation và success criteria

- Unit: causal vs encoder/decoder bounds/padding/global masks, recursive progress/overflow/depth, full-source family coverage, Lead-3 fixed first3/control identity, W_global common selector/raw-delivered lengths/LexRank ties; stable seeds; C_f model-only/C_between representatives+control/floors/guard/trial/quota accounting; no sibling delta; NULL.
- Integration: scorer-ready trước selection/IDF isolation/no test-reference fields vào generation-selector; amendment rescore toàn stored model/control outputs rồi rerun A/B; 40/300→200 availability-only isolation; unload/reset; atomic nodes/dependency invalidation/scorer-only retries/no double-count; store/hardware mismatch.
- E2E: staged long-tail pilot→validation selection→final seal→interruption/resume/export/scorer failure; hiện chưa chạy.
- [ ] Keep/conditional/reject log đủ; failed test IDs giữ denominator.
- [ ] Pilot/selection receipts hỗ trợ budget full test nhiều phiên; fallback chỉ pretest có trigger/rule,không promise throughput.
- [ ] Model config representatives chọn nội-family C_f; C_between recompute selected representatives+fixed Lead-3; no sibling-delta/no C_f cross-family ranking. K_models/K_total và locked model choice/guard từ validation; final giữ cohort/identities, không reselect.
- [ ] Full-source available mọi pipeline; bốn families full coverage, Lead-3 explicit first3 output selection; W_global từ development và native/intermediate budgets frozen trước selection/test tương ứng.
- [ ] Raw/delivered/violation/attempt ledger đủ audit; interruption giữa map/reduce, partial commit và restore actual store được kiểm chứng trước final; không test fallback.
- [ ] Numeric quotas/trial caps/admission/common floors/scorer-ready đủ trước stage, không REQUIRED_NO_START còn mở; insufficient comparison→no_selection.

## Risk Assessment, rollback và câu hỏi mở

High: OOM/context(cao×cao)→native bounds/progress/T4 profiles;timeout/storage loss(cao×cao)→numeric quota/atomic durable nodes;selection survivor bias/scorer drift(cao×cao)→C_f/C_between riêng/floors/scorer-ready+full rescore hai tầng;trial-induced common loss(vừa×cao)→family-local comparison pool và fixed representatives;LexRank RAM(vừa×cao)→CPU graph profile;transfer confound(cao×cao)→pipeline claim.
Rollback rút profile/protocol mới, giữ attempts/cost, quay pilot/reseal trước test. Test exposed không dùng tune rồi gọi independent.
Còn mở: pinned configs/safe native windows/FP16 T4 fit/CPU graph RAM; W_global350 (derived eligible train; final lock sau feasibility); search/quota caps; K_models/K_total và guard ratification; full-test projection/fallback trigger/N; actual persistent-store durability. Effort20–30h provisional cần reassess sau gap/rubric/cap/pilot evidence, không measured promise.
