---
phase: 2
title: Freeze artifacts
status: completed
effort: ''
---

# Phase 2: Freeze artifacts

## Overview

Bind exact frame IDs, released box/transcription GT and study-specific rules.

## Implementation Steps

Create immutable manifest, ignored derived GT, HOLD ledger, protocol and implementation receipt. Preserve initial receipt; verified receipt records the invalid-coordinate handling fix without changing data or metric definitions.

## Success Criteria

- [x] 546 frames /15317 GT objects /5 courses /140 groups frozen. Three held frames contain62 objects. Matching, normalization, failure rules and exploratory uncertainty fixed.
