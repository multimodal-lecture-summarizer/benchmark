---
title: Freeze IIIT-CVID validation spotting cohort and protocol
description: >-
  546 exposed validation frames and 15317 released GT objects; data/scoring
  freeze only.
status: completed
priority: P2
branch: ''
tags: []
blockedBy: []
blocks: []
created: '2026-10-13T16:23:16.388Z'
createdBy: 'ck:plan'
source: skill
---

# Freeze IIIT-CVID validation spotting cohort and protocol

## Overview

Data/scoring freeze completed before spotting model outcomes. Candidate runtime/model configuration is the next separate gate. See [scientific report](../reports/spotting-freeze-261013-2321-scientific-protocol-report.md).

## Phases

| Phase | Name | Status |
|-------|------|--------|
| 1 | [Verify evidence](./phase-01-verify-evidence.md) | Completed |
| 2 | [Freeze artifacts](./phase-02-freeze-artifacts.md) | Completed |
| 3 | [Validate contracts](./phase-03-validate-contracts.md) | Completed |

## Dependencies

Uses completed IIIT-CVID EDA/adjudication and recognition artifact audit. No active dependency. No model inference or transition/keyframe evaluation authorized by this plan.
