---
phase: 1
title: Verify evidence
status: completed
effort: ''
---

# Phase 1: Verify evidence

## Overview

Establish selection and coordinate conventions from source data and primary scientific references.

## Implementation Steps

Recompute source hash, decode all validation frames, inspect XML anomalies, compare released crop pixels under three coordinate conventions; read ICDAR competition paper and author publication identity.

## Success Criteria

- [x] All 549 validation pairs and 15379 objects inspected; all raw half-open crops match, both inclusive alternatives zero. Score-independent annotation decisions and claim limits fixed.
