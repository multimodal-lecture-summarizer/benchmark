---
status: completed
scope: standalone Colab CPU acquisition and EDA notebook
---
# MLPDataset Colab download and analysis

## Scope and acceptance

Deliver `benchmark/experiments/notebooks/diagnostics/mlpdataset-slide-transition-eda-colab.ipynb`, unexecuted clean user-run template. Preserve the executed local research notebook and its hash-bound evidence. Reuse existing annotation EDA cells without importing workspace files. No detector, model weights, GPU requirement, cohort freeze or production selection.

- Bootstrap dependencies, optional Drive mount and configurable persistent run directory; work without repository clone.
- Download and verify both pinned author annotation ZIPs and source snapshots; show full annotation/ASR/release accounting and figures.
- Select media deterministically: default first source ID per speaker proxy; configurable all/anomalies/manual. Display every selected and unselected source ID.
- Public normal video downloads, live bounded logs, per-file/session disk/time limits, resumable checkpoints with input/config bindings and video hashes. Preserve failures; no cookie/client circumvention.
- ffprobe metadata, requested-time frame triplets before/at/after sampled labels including terminal/anomalous marks. Preview is not automatic semantic qualification; retain requested timestamps and video identity.
- Export CSV/JSON/PNG plus evidence ZIP excluding source videos and raw access logs; optional browser download.
- Verify syntax, configuration constraints, reuse binding, real cached annotation execution and real FFmpeg frame extraction on a deterministic generated test clip; do not claim live Colab/YouTube success from local checks.

## Steps

- [x] Review plan and existing notebook reuse points.
- [x] Build self-contained Colab template and guide/report.
- [x] Verify local annotation path, media helpers and final notebook structure.
- [x] Review artifact; report CPU setup and remaining live Colab verification.

## Unresolved

Colab's current public YouTube access may still return HTTP 403. GPU does not resolve this network condition. Actual runtime/storage depend on selected videos; no duration guarantee.
