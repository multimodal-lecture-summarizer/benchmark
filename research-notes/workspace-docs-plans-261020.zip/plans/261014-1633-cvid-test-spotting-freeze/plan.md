# CVID released-label test spotting freeze

Status: complete; policy/plan, implementation and final artifacts accepted by advisory code-reviewer on 2026-10-14. Frozen 1,754 frames / 40,063 released objects; influence 1,751 / 40,023. Full source re-decode, full-GT consistency/oracle/empty/missing verification and byte-identical replay passed; 34 focused tests and 155 local links passed. No OCR inference or source GT edits. Date: 2026-10-14.

## Scope and acceptance

Freeze the native test released-frame endpoint after completed all-split EDA. Deliver a versioned GT policy, full source-frame decision manifest, selected/excluded IDs, local box/transcription JSONL and tamper-evident freeze receipt. Reuse existing scoring semantics without altering validation, candidates, raw annotations or executed EDA. No inference, GT correction, publication, commit or production selection.

- Primary: every geometry-valid native test frame, expected 1,754 / 40,063 objects; retain all released XML labels, including apparent semantic errors and selective math/logo/interface labels.
- Hold entire frame for decode/parse/pairing failure, invalid or out-of-bounds/nonpositive box, normalized blank transcription or unresolved difficult flag. Do not drop a bad object while retaining its frame: this would create unlabelled regions that affect FP accounting. Expected sole exclusion: test/24/25/00_31_56_00006.png, 40 objects. Correct decoded image dimensions only in derived metadata (97 selected frames); never clip boxes or rewrite XML.
- No invented ignore regions or post-hoc semantic/lexical filter. Every unmatched prediction remains an FP for the released-label endpoint, even if it could depict genuinely visible unannotated text. Recall is recall of annotated instances; precision is annotation agreement, not verified exhaustive visible-text precision. Unknown annotation recall prevents exhaustive-OCR claims.
- Diagnostic sensitivity only: remove the entire 3 pre-existing test frames containing the 4 uncertain/apparent-disagreement objects in the fixed EDA sample; retain all predictions and GT on remaining frames. Freeze explicit IDs before spotting outcomes. This is observed-flag influence analysis, not corrected gold, a noise bound or evidence that all remaining labels are clean. No object-level forgiveness. Primary denominator unchanged.
- Inherit matching/normalization/failures from pinned validation protocol/scorer; test-specific protocol fixes 7 course clusters, paired 2,000-draw bootstrap seed 20261014, conditional exploratory intervals; folder bootstrap secondary. Primary pooled end-to-end Hmean, detection P/R/F1, full counts, per-course and source-group tables; macro-course summaries also required. Report original and sensitivity results together, never select the better endpoint.
- Scientific bases: dataset paper (word boxes, no equations/symbols, course partitions, IoU > .5); Northcutt et al. 2021 (test-label noise can destabilize comparisons); Nosek et al. 2018 (fix analysis choices before outcomes). These motivate our study-specific decisions, not official dataset protocol equivalence or external preregistration.

## Implementation and review

1. Review policy/plan before implementation; record sources and limitations.
2. Add a dedicated deterministic freeze builder and contract tests under benchmark/experiments/scripts and benchmark/tests. Reuse frozen_write/hash/normalizer helpers. Re-read pinned ZIP test PNG/XMLs and compare exact identities/text/coordinates against hashed EDA; verify saved reviews. New registry JSONs under benchmark/experiments/registry/datasets, full local GT under ignored experiments/outputs/iiit-cvid-spotting-test-261014. Canonical frame IDs follow existing Frames/test/... convention; retain EDA ID alias test/... explicitly.
3. Preflight all frozen outputs before writing, reject any differing existing version. Hash-bind EDA notebook/execution receipt/ledgers, source ZIP, inherited protocol/scorer, prior candidate registry (unchanged validation binding; separate explicit test-use binding) and builder. No source/video independence inferred from course folders. No OCR package/model import or inference.
4. Validate source counts, all IDs, geometry, unchanged text, coverage partition, oracle/empty/sensitivity score counts, replay byte identity and changed-artifact rejection. Request final reviewer audit. Update current documentation (README and existing benchmark/EDA indexes) with additive status; preserve historical executed notebook claims.
5. Root report in plans/reports states exact inclusion/exclusion, sensitivity IDs, artifact hashes, tests and scientific limits. Test freeze does not satisfy pending candidate runtime-loading gate.

## Remaining limits

EDA-exposed test, uncertified semantic GT/completeness, sampled model-assisted semantic flags, no authenticated video identities or universal writer-disjoint proof, unknown pretraining overlap and historical model-use completeness. Corrected/exhaustive annotation endpoint requires independent adjudication and a new GT/cohort version. Generic notebook manifest validator has a pre-existing incompatibility; unrelated runner code stays unchanged.

## Delivery

[Completed policy/freeze report](../reports/gt-policy-261014-1633-cvid-test-spotting-freeze-report.md). Freeze receipt SHA-256 `9504e34f69b16f4b63893184e5decf2e3d88d7251833b0efbb85f2eb883438dd`. Final independent read-only review rechecked all selected GT rows and artifact/replay/input/module identities, with no remaining blocker. Candidate runtime loading remains the next gate before common-cohort inference.
