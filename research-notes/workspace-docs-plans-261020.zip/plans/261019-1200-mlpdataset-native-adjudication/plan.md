---
title: MLPDataset event mapping and native-frame follow-up
status: completed
delivery_status: preparation_complete
runtime_status: native_extraction_complete_adjudication_pending
created: 2026-10-19
---

# Authorized scope

Continue saved targeted review. Deliver a source-bound diagnostic event ledger for all82queued marks, explicit repeated-label mapping proposals, a deduplicated native-frame job queue and a separate standalone CPU Colab notebook reading existing Drive media. Preserve both executed notebooks, all raw annotations, protocol-v1 rules and original caches. No download, model inference, source edits, GT/cohort certification or fabricated full-source inspection.

# Context and contracts

Python/FFmpeg diagnostic workspace. Existing ReviewRunner, exact PTS helpers, source stager and inline HTML renderer already tested. Executed underscore targeted notebook contains48ready contexts/1771frames from16sources,14historical controls and20policy edgeholds. Only full research source videos are on Drive. Review output is diagnostic: native endpoint null until actual native frames manually adjudicated. Multiple changes in one window cannot automatically map repeated labels to one event.

# Acceptance

1. Review all33distinct sampled frame sequences; preserve82originalmark identities with observation/evidence/status. Existing14historical controls stay coarse,20sourceedgeholds stay unresolved unless evidence supports more.
2. Record every observed replacement/return/title/build/non-target event with original-PTS sampled brackets; bracket not midpoint/native endpoint. Duplicates map proposals only, no label deletion.
3. New extraction uses true all-frame mode (no temporal select/drop/duplicate), exact integerPTS/timebase, constant resized diagnostic width permitted; native refers temporal cadence, not spatial original resolution. New jobs bind sourcehash, original annotations and bracket evidence. Separate output sibling, finite deadlines/quota/freefloor, checkpoints/interrupt and all-job status persistence.
4. No auto-certified event or annotation write. Source-edge jobs may be terminal policy context and cannot alone prove source-edition equivalence. Untouched protocol rules/eligiblecohort remain pending.
5. Tests use real FFmpeg synthetic hardcut/VFR-or-nonzero-timebase fixtures, native consecutive-frame counts, cached reuse, altered source, deadline/interrupt and generated notebook cells. Existing default sparse extraction remains compatible.

# Steps

- [x] Read current source, protocol, executed outputs and prior audit.
- [x] Independent plan review PASS; native provenance, cadence proof, all-event preservation and all82 interruption ledger requirements incorporated.
- [x] Parent full sampled-window review, diagnostic ledger and source-bound native job queue.
- [x] Worker native-mode extraction and standalone notebook, focused tests.
- [x] Independent final code/protocol review and local verification.
- [x] Synchronize guide/manifest and report actual remaining external work.

# Ownership

Parent owns registry ledger/jobqueue, visual review, notebook assembly coordination, docs/report. Worker owns explicit native extraction helper extension/buildscript/testfiles; no unrelated edits. Reviewer read-only. Scientific rules immutable. Fullsource extraction/manualnative decisions remain external until user runs next notebook.

Unresolved: exact native endpoints, event-to-original mapping for repeated rows, source-edge equivalence and full-scope completeness/grouping/provenance. No user clarification required for preparation.

## Reviewed implementation requirements

Native jobs explicitly bind protocol, ledger, bracket evidence, all original-row hashes and bounds in checkpoint keys; no synthetic annotation time. Deduplicate extraction windows only. Decode passthrough and independently probe presentation PTS, including VFR and identical consecutive frames; cadence not assumed from filter removal. Keep old/new guard context; incomplete guards remain HOLD. Separate output, staging and embed budgets; all jobs/all82 statuses persisted before extraction and on interruption.

## Final preparation evidence

Full33distinct sampled sequences reviewed;82original identities retained;37new-context observed changes (33primary candidates/4auxiliary). Fourteen repeated groups have11shared-single/2multiple-unresolved/1auxiliary proposals. All official dispositions HOLD/null endpoints.64native jobs/38sources/123.653s requested footage;75rows selected for extraction and7historical rows visible without re-extraction. Both executed notebooks unchanged.

Final verification54tests plus4subtests passed21.19s; independentreview PASS; workflow finalize artifact gate PASS exit0;103Markdown links/YAML checked. Native notebook246032bytes SHA256779fd7a00ca8a2d9549d356ca4d4c1f4f33ef95decbab418c4e34379c0cc42ef. [Report](../reports/implementation-261019-1200-mlpdataset-native-adjudication-report.md).

## External follow-up (not completed by preparation)

- [x] Actual64-job CPU Colab native extraction completed:64ready,3,553frames,0omissions/saved errors. Executed output audited2026-10-19; manual qualification remains pending.
- [ ] Native endpoint/effect review and final original-to-event mapping, source-edition equivalence.
- [ ] Full-scope completeness, dependence/provenance and GT/cohort/split qualification before evaluation.
