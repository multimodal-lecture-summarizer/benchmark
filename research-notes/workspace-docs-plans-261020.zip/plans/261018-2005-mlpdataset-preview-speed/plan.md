# Continue cached preview with larger time budget

Status: completed locally; Colab throughput pending. Scope: standalone MLPDataset notebook. Preserve media/frame cache keys, render output and all333/9021 accounting.

Evidence: supplied preview log138 new frames,1172 cache hits,1602 requests not attempted under30minutes. Each run_logged frame currently recursively scans analysis/log trees at preflight, process polls and postflight. Drive scan contribution measurable by call count; actual source I/O contribution unknown. No all-source runtime speedup claim.

- [x] Read actual helpers/callers, prior tests, planner review; preserve input notebook backup.
- [x] Default preview120minutes and DOWNLOAD_MEDIA=False for continuation, unchangedRUN_NAME/source/frame identities and scheduling.
- [x] Exact canonical one-output FFmpeg command only: one full quota snapshot per process, then tracked temporary PNG/log growth plus free-space checks; all other commands retain full scans. Sole writer perRUN_NAME; new baseline each frame.
- [x] Test baseline callcount failure then optimized pass; quota preflight/output/log growth/truncation, lowdisk/timeouts, fallback, interruption/cache and existing acquisition/receipt regressions.
- [x] Independent review and docs/report; clearly distinguish local evidence from actual Colab throughput.

Unresolved: measured throughput improvement and source read cost on Colab/Drive.
