---
title: Complete targeted MLPDataset event adjudication
status: completed
created: 2026-10-19
---

# Deliverable

Finish manual review of all64completed native windows and all82targeted original rows using saved3553frame presentations/logs, historical coarse controls and immutable protocol. Produce a versioned final-targeted decision ledger plus flat CSV, explicit event/row mappings, final EDA conclusions and updated status docs. Preserve333/9021inventory, all raw labels, protocol rules and all executed notebooks. No new download, model run, timestamp overwrite or invented formal full-source GT/cohort freeze.

# Evidence and constraints

Native notebook SHA bfa246af81cb2e610d3f3961f889de5db8d7002b22bf012397318ad2c6c3b876. Extracted per-frame JPEG presentation paths/hashes and integerPTS in outputs/mlpdataset_native_executed_review_261019/frame-ledger.json; full embeddedFFmpeg logs also local. CaptionPTS match logs, source-job/bundle binding matches frozen queue. Runtime reported ready only after checking independentffprobe; raw checkpoint/probeJSON/PNG hashes remain onDrive, not independently rehashed local. Native refers temporalcadence, images are scaled. Never claim missing evidence fetched or3553frames fully visuallycertified from an overview. Inspect transition neighborhoods at frame cadence. Hardcut lastold/firstnew adjacent; fades/rotations retain explicit uncertainty if onset/end indistinguishable. Missing source equivalence remainsHOLD rather than epsilonclamp. Class exclusions do not require invented timestamps.

# Acceptance

- Every82row has final targeted disposition included/excluded_non_target/hold, concrete reason and binding; every37new-context event and6historical target contexts accounted, plus any newlyobservedcandidate explicitlyseparate.
- Native endpoint fields derive only from visually inspected exactPTS pairs; no score/model-driven labels, midpoint or globalshift. For uncertainty usebrackets andHOLD.
- Resolve repeated-label mappings where oneobservedprimaryevent is clear. Multiple-events cases retain explicit manualmappingor concreteHOLD; noautomaticduplicate deletion.
- All20sourceedge cases given finaltargeted policydecision/HOLDreason; sevenunselectedhistorical rows accounted bycoarse evidence without nativecertification.
- New immutable registry version references priorledgerhash, executednotebookhash, evidence/log/presentationhashes, originalannotationsourcehashes andprotocolhash. No previousledgerrewrite.
- Machine validation of fullcoverage/references/PTS adjacency/bounds/disposition consistency/hash integrity; independentscientific review beforefinalizing.
- Complete targeted review can have justifiedHOLDs. No assertion of9kmark completeness/independentsourcegroups/rights/frozencohort from thisqueue.

# Ownership and steps

- [x] Readprotocol/currentevidence/priorplan.
- [x] Independent planreview.
- [x] Parent reviewsnew37events, sourceedges/repeats; historicalworker reviewsnative004/005/008/009/010/017only.
- [x] Buildfinalversioned82row ledger/CSV and validateallproofbindings.
- [x] Independentreview; updatedocs/report/decisionstate.

Unresolved scopeoutside targetedcompletion: full-source missing-event completeness, verifieddependence/rights andcohort/splits. Rawsource/probeJSON/PNGcache remainsDrive, local audit reliesonboundexecutedoutput/logs andpresentationcopies.

# Completion

Final v2:82 original rows=40 included_local_review/11 excluded_non_target/31 HOLD;43 canonical observations,35 local PTS points,28 mapped unique primary points. All3553 JPEG hashes and64 log/PTS sequences verified. Independent scientific review PASS on ledger SHA ba47a871675375f839c773318e206889c84c7c9dcb4576c8b66e925e215d3483. [Report](../reports/dataset-adjudication-261019-1504-mlpdataset-final-review-report.md). No new Colab run or raw annotation change. Completion covers this targeted queue only; formal GT/cohort gates remain open.
