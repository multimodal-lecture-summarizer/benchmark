# Remove retired14-mark diagnostics

User no longer wants the fixed14mark investigation in generalEDA. Remove WIDE/DENSE/REVIEW config and helper/runnercells, hardcoded historical video IDs/retry defaults, draft tables/exports and all dense-specific coverage/receipt fields. Do not use empty placeholder dense tables.

Keep full333/9021 inventory, all-media selection, original media acquisition identity/checkpoints, resourcebudgets, and uniform automatic preview rule (anomalies plus first/middle/last per source, bounded by cap). Preview has three requested offsets for every selectedmark, no targetoverrides. Fullmarkcoverage still retains allrecords and identifies unviewedmarks. Preserve historical evidence/backups; no dataset/media/cache deletion.

Updateguide to currentflow, no14/42 targets. Validate no retiredsymbols/IDs in current notebook, AST/schema, actualFFmpeg genericpreview on knownfixture, fullledger conservation/unknownmedia cases and fullreceipt execution. Independent review before/after.

Status: completed. Removed retired runtime path, no dummy tables. Independent review passed. All20codecells/schema,333/9021 conservation and missing/failure cases, actualFFmpeg genericpreview/stale exclusion, actualreceiptconstruction/strictJSONserialization passed. Newall-source Colab run pending.
