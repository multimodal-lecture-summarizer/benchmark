# MLPDataset targeted retry and wide preview

Scope: modify the existing Colab notebook and its guide. Preserve executed per-speaker evidence in an ignored backup; prepare a clean rerunnable notebook with inline outputs.

- Keep per-speaker selection, Drive RUN_NAME and acquisition identity unchanged; reuse and verify completed video hashes.
- Enable retry for failed ID 2NgUY8f1pa8 only. Retain historical attempts and logs; a retry may still return HTTP 403. No cookies or external credentials.
- Expand the eleven ambiguous/context/edge marks from the saved audit to offsets -5,-2,-0.5,0,0.5,2,5 seconds. If the retried video succeeds, use wide preview for its normal sampled marks too.
- Keep ordinary three-frame previews for other marks. Bind the full configuration into the preview hash, retain source hashes, and report outside-video/budget/decode status explicitly. Do not clamp times or certify semantics.
- Show target/config tables, labeled frame grids, ledger and receipt inline; no ZIP. Clear stale execution outputs only after backing up the supplied notebook.
- Validate notebook schema, Python syntax, targeted retry eligibility, preview offset/target selection and real FFmpeg extraction including edge cases. Do not perform live Colab/media acquisition locally.

Acceptance: only target failed checkpoints are eligible for retry; successful sources are reused; target marks show seven labeled requests; ordinary marks show three; receipt describes actual config and statuses. No dataset/GT/model changes.

Status: completed. Plan and implementation reviewed without blockers. Notebook schema/Python syntax passed; real FFmpeg fixture passed 24 requests (17 decoded, 7 outside-video), explicit-target union beyond cap, retry allowlist and zero-budget stale exclusion. Colab retry/wide-preview results pending user execution.
