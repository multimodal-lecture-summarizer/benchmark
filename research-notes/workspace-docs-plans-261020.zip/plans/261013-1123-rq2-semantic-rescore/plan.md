# RQ2 semantic scoring recovery

## Follow-up planning — 2026-10-18

The [RQ2 scientific improvement plan](../261018-2118-rq2-scientific-improvement/plan.md) owns the remaining independent Drive receipt/ledger audit and notebook-checksum reconciliation. It preserves the original generation and semantic v2 amendment, and proposes a separate future study. Planning does not authorize another rescore or generation run.

Create a standalone evaluation-only Colab notebook, preserving the executed original notebook and frozen generation modules/protocol. Inputs: original sealed 120-record receipt, dispatch ledger, frozen manifest/protocol and source/reference bundle from Drive. No Qwen loading, generation or label changes.

Implementation: subclass the old semantic scorer with token-ID windowing and SentenceTransformer forward/pooling; no text re-tokenization or truncation. Record a new scorer identity/amendment. Rescore all 120 pairs with CPU or GPU in a new directory, checkpoint per record, retain failures, explicitly resume interrupted scoring only. Verify original hashes and bind resume to source inputs and scorer/device/code. Never reuse the 28 old semantic scores. Inherit unchanged generation costs; record rescore costs separately.

Notebook: separate validation, dependency setup, scorer loading, scoring, aggregation, full tables/plots and export cells. Include coverage, per-stratum deltas, exploratory intervals, paired plots, missingness/failures, source text examples, original generation costs and new scoring costs.

Verification: review plan, token coverage/length and short-input equivalence checks; runtime receipt integrity, changed identity rejection, resume/failure retention tests; notebook schema/source parsing and embedding consistency. Test real long-sentence tokenization if cached pinned model/tokenizer available. Do not claim Colab or 120-record semantic execution completed locally.

Status: preparation and Colab execution complete (2026-10-13 notebook evidence). Plan reviewed by implementers, final code reviewed and no-data plot blocker fixed. 14 focused tests passed (5 real offline model-pipeline tests, 7 runtime recovery tests, 2 partial/empty visualization tests). Standalone notebook schema, source syntax, embedded byte equality and frozen original hashes verified. Original executed notebook retained. Actual T4 pinned-encoder/valid208 preflight passed; all 120 pairs rescored with zero failures/interruption/pending, six executed code cells and six PNG. Reference and 240 displayed predictions match original notebook. Independent audit of Drive receipts/ledger remains pending; this is not a winner claim. Handoff: `docs/rq2-tib-semantic-rescore-v2.md`; results: `docs/rq2-tib-120-results-261013.md`.
