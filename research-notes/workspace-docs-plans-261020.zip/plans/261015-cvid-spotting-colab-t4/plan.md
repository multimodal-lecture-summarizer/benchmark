# CVID spotting Colab T4 implementation

Status: notebook/runner prepared and locally verified (75 tests); actual Colab T4 preflight pending. TESTR blocked by author checkpoint HTTP403 and excluded before comparison.

## Requirements and acceptance

- Deliver an unexecuted runnable Colab notebook, portable source/data bundle builder, six-candidate registry, isolated environment specifications, real model adapters, preflight, immutable checkpoints and receipts.
- Preserve the frozen 1,754-frame / 40,063-object test endpoint, scorer and existing CPU artifacts. New CUDA execution has distinct identity; no CPU prediction reuse.
- Lock accessible model artifacts and upstream revisions now where possible. Never substitute fabricated hashes; unresolved acquisition or compatibility blocks the affected candidate before test inference.
- Install each candidate in a separate environment. Seal resolved packages, source/config/weights, Python, CUDA/GPU, actual model loading and fixed train-image forward-pass evidence before test access. Resume rejects any identity change.
- TESTR must build and execute genuine polygon + transcription inference on train preflight before it can enter comparison. A failure produces a durable failed-gate receipt, not a successful model result.
- Notebook acquisition, preflight, inference, resume, scoring, sensitivity, visualization and export run from the same bundled code. Comparison requires complete same-cohort candidates and discloses unavailable candidates.
- Local verification covers contracts, fail-closed paths, notebook syntax, bundle integrity and regression tests; no claim of executed Colab/T4 or TESTR verification without remote evidence.
- No commit, push, Miro change, training, tuning on test or changes to previous freeze/runtime files.

## Work sequence

1. Review plan and identify portable interfaces/artifact provenance.
2. Add artifact/environment acquisition contracts, new candidate adapters and TESTR gate.
3. Add portable orchestration, cohort extraction/verification, checkpoints, scoring and analysis.
4. Build Colab notebook and portable bundle; document usage and status in root report.
5. Run focused tests and adversarial review; repair defects and regenerate bundle.

## File ownership for parallel implementation

- Artifact/runtime worker: new `spotting_colab_candidates.py`, `spotting_colab_environments.py`, `spotting_colab_adapters.py`, optional new artifact helper and registry; tests for those files. Do not modify existing modules.
- Notebook/bundle worker: new `build_spotting_colab_notebook.py`, `spotting_colab_notebook.py`, notebook and bundle script; tests for those files. Consume root orchestration CLI contract.
- Root: new portable orchestration/data/checkpoint/analysis modules and CLI, root report, integration tests, review.

CLI contract: `python -m experiments.scripts.run_spotting_colab --bundle-root ROOT --work-root WORK --output-root OUT COMMAND`; commands `prepare`, `preflight`, `run`, `analyze`, `status`; optional `--candidate ID` on preflight/run. `prepare` verifies packaged bindings and source data, resolves environments/artifacts without test inference. `preflight` seals load plus train forward-pass. `run` requires preflight seal and resumes immutable per-frame records. `analyze` only scores complete candidate streams.

Runtime worker interface proposal: `prepare_candidate(candidate, work_root) -> prepared dict`; `preflight_candidate(candidate, prepared, train_paths, receipt_path) -> receipt`; `load_colab_candidate(candidate, prepared) -> (predict(path), runtime dict)` invoked inside candidate environment worker, never imported in notebook kernel. Interface adjustments must be communicated before callers are written.
