# CVID comparison v2 readiness

Scope: complete the user-run six-candidate T4 comparison with PGNet qualification evidence, without executing model code or altering frozen cohort/protocol/candidates/scorer. No upload, cloud execution, Miro, commit or push.

Audit findings: v2 template installs uv into live Colab kernel despite isolation claim; missing explicit all-six preflight gate before test; existing display skips frame-score/full-prediction gz exports; no frame viewer; no detailed step-by-step guide; PGNet passed evidence not represented in delivered bundle.

Implementation plan reviewed against actual modules/schema:

1. Verify user evidence ZIP and snapshot audit provenance/receipt as additional registry artifacts; never import its predictions/preflight as comparison completion.
2. Isolate orchestrator through existing prepare_environment(scoring profile) with exact declared direct packages. Retain existing bootstrap/driver fixes. Keep model environments/config and data FROZEN hashes intact.
3. Add presentation/status functions and a frame-review helper. Show all primary frame rows, all metric/sensitivity/course/folder/macro/CI/failure tables and six figures; retain/download full native transcription exports, offer any-frame GT/prediction viewer with full text, polygon and error information. Clearly separate geometry overlays from scorer matches.
4. Update builder for reproducible notebook generation with live phase/worker logs, all-six explicit gate, bound data/config tables, audited PGNet qualification, fresh r2 run ID, end-to-end denominators/failure accounting and partial export. No live-kernel package install, no score-based sample selection.
5. Rebuild canonical comparison bundle and bind new SHA, preserve qualification bundle and v1 artifacts. Update documentation/README with verified qualification vs unexecuted comparison.
6. Focused tests for guards, artifact verification and native review contracts; static parse all cells/nested code, compare frozen artifacts/candidate registry before/after, validate bundle membership/hash and PGNet qualification identity. No model download/install/inference tests.

Acceptance: two-file delivery plus manual guide; all six candidate configs unchanged; cohort1754/GT40063 preserved; test blocked until six correct gates; actual outputs only, full item-level evidence accessible; failure export works without analysis; user can resume unchanged run and inspect all requested dimensions.

Open gate: actual six-candidate T4 prepare/preflight, complete test inference and full analysis remain user-run and unverified until receipts are returned.
