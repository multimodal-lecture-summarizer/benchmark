---
title: TIB 120-record paired evaluation
status: execution_reported_receipts_pending
date: 2026-10-12
---

# TIB 120-record paired evaluation

## Follow-up planning — 2026-10-19

The [current five-stage summarization plan](../261019-0035-summarization-model-benchmark/plan.md) supersedes the [2026-10-18 proposal](../261018-2118-rq2-scientific-improvement/plan.md) for future research: all-split qualification, disjoint validation pilot/model-selection subsets, and final evaluation over the entire eligible native test split, with a predefined resource fallback. The independent receipt audit below remains a historical evidence limitation, separate from the new cohort. Completed notebook evidence is recorded in [the dated results](../../benchmark/docs/results/rq2-tib-120-results-261013.md). This documentation update does not reopen generation or change the frozen 120-record protocol/results.

Status (2026-10-13): 120-ID cohort, protocol, guarded notebook and local package validated. User reports RQ2 running; live runtime and model-evaluated coverage have not been audited. Independent code review findings resolved. Earlier access limitation below is historical preparation context.

## Prepared next stage — 2026-10-13

Use the [RQ2/RQ4 post-run handoff](../../docs/rq2-rq4-post-run-handoff.md): exact receipt/export files, offline identity and dispatch checks, metric-specific denominators, missingness, frozen group sensitivity and same-run resource reporting. Audit completed raw evidence before updating evaluated counts. RQ3 remains context/evidence-GT blocked; the handoff defines its narrower answer-only qualification path and OCR alternative. No frozen code, notebook, cohort, protocol or active output changed during this preparation.

## Authorized output and acceptance

Execute the existing RQ2 plan in order: a source-reviewed, score-independent 120-ID cohort (40 per frozen token stratum), immutable protocol and source/reference/group/scorer hashes, a standalone guarded Colab notebook and data handoff, then GPU execution if an accessible authorized Colab runtime exists. Preserve existing pilot, historical cohorts and application code. Never describe preparation as model evaluation.

Python research workspace: `benchmark/`; existing bundle loader validates full source and reference checksums. Existing S1/S3 pair runner supports counterbalanced order, partial checkpoints and failure continuation. Pilot runtime logs dispatches and soft deadlines. Legacy aggregation uses item bootstrap and must not silently serve as grouped analysis. Creator references were exposed in EDA.

## Sequence

1. Verify full 8,769 pool, cached exact token ledger and nine pilot IDs. Review source audit. Declare creator `valid` as evaluation frame if feasible; preserve all eligible valid lengths/flags. Deterministic SHA ordering within <=4271, <=7142 and >7142 source-token strata; no score or abstract-text selection. Record dependence relations and unresolved course identity.
2. Freeze 120 IDs and source/reference hashes, group ledger, generation/scorer implementation, estimand, missingness and timeout policies before generation. Primary result is a record-weighted mean S3−S1 among successful pairs in the finite balanced cohort, with the successful count in each stratum and all missing IDs shown. With failures it is conditional on success, not a full-120 effect. Group bootstrap resamples whole components and recomputes the record-weighted mean; it is exploratory sensitivity only, with conservative author components as additional sensitivity. Do not claim population superiority or power.
3. Bind runtime to the frozen protocol, code identity, input hashes, fixed T4/batch-2 profile. Counterbalance S1/S3, preserve every selected ID, no automatic retry/replacement; unknown failed usage stays unknown. Separate generation and metrics. Soft 10h generation session deadline and 12h overall session deadline, checked between calls; resumptions preserve identity/history and never imply uniform uninterrupted timing.
4. Produce standalone notebook with embedded sources and reviewed data ZIP. Validate frozen inputs before library/model installation. Source-only context preflight must retain all IDs and stop rather than silently truncate/fallback. Render progress, item/arm/scorer coverage, failures, paired metrics and costs in outputs.
5. Run focused tests for corruption, identity mismatches, selection determinism, failure retention, resume and grouped aggregation; obtain independent review. Run on accessible Colab T4 if available; otherwise report the concrete environment limitation with a runnable handoff.

## Constraints

One checkpoint/configuration/repetition; pinned Qwen2.5-1.5B FP16, chunk 512, common intermediate allocation 96 times larger chunk count, final 384, seed 42. Equal allocated output caps do not mean equal actual input/output compute. No new control arm or outcome-driven tuning. Primary ROUGE-L; secondary pinned BERTScore and source SBERTScore separately. Preserve semantic predictions on scorer failure. Report 120 selected denominator even if stopped; no zero imputation. Existing data remains ignored and uncommitted. No commit/push requested.

## Unresolved before execution

Opening the signed-in Google Drive was rejected by automatic approval review because the user had not explicitly authorized access to private Drive content. To complete the Colab run, the user must authorize access to Drive and uploading the frozen 120-record text bundle/manifest/protocol into `MyDrive/RQ2_TIB_120_20261012/data`. Whether a Tesla T4 runtime is available long enough remains unverified. Course identity is not authoritative; inferential claims remain bounded accordingly.

## File ownership and checks

| Slice | Files | Check |
|---|---|---|
| Cohort | `benchmark/experiments/scripts/rq2_tib_frozen_cohort.py`, 120 manifest, ignored 120 bundle | Exact 40/40/40, deterministic score-independent IDs, hash/group audits |
| Runtime | `benchmark/experiments/scripts/rq2_tib_frozen_runtime.py`, analysis helper | Identity, no silent retry, all-ID coverage, grouped sensitivity |
| Handoff | New formal notebook/builder, frozen protocol, owning RQ2 plan/README | No dependency/model work before input validation, Colab source imports, notebook parses |

Risk: same-author grouping may combine independent talks; it is sensitivity only. The cross-split source audit does not exhaust within-valid similarity. If any freeze identity differs, stop and generate a new versioned cohort/protocol/run root; retain the old manifest and checkpoints. Rollback is deleting only this new handoff and reverting scoped source edits; no historical receipts are overwritten.
