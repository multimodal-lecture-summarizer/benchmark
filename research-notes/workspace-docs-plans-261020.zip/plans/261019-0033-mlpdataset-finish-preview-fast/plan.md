---
title: Finish cached preview with RAM staging and lightweight inline galleries
status: completed
priority: P1
created: 2026-10-19
---

# Finish cached preview and avoid repeated heavy rendering

Status: plan reviewed; implementation authorized by user request.

## Requirements and scope

Deliver edited standalone notebook at the user-specified underscore path and synchronize the existing hyphenated clean runner. Preserve the246.6MB executed input byte-for-byte under experiments/outputs before clearing outputs. SameDrive/RUN_NAME, all333media/9021marks, source/frame identities, offsets/render/checkpoint semantics unchanged. Continue every currently missing request dynamically (the supplied run has388); never hardcodeIDs/counts or redownload source media. DOWNLOAD_MEDIA=False,120-minute preview budget.

Keep all requested rows and decoded images accessible directly in output. Replace858Matplotlibgrids with grouped HTML galleries using display-only JPEG thumbnails; originals stay untouched. Default groups collapsed, all decoded requested frames included, complete status/time labels, rawPNGpath visible, bounded batch progress. No source-specific filtering. No regenerated/saved grid PNGs. Preserve raw-frame/checkpoint export hashes and full coverage. Thumbnail derivatives never enter GT, source or frame hashes.

Use bounded in-process RAM cache for small frame/checkpoint file reads, validating stat fingerprint on every reuse; changed/missing/corrupt files cannot reuse old bytes. Reuse within-run verified bytes for display and digest to avoid duplicate Drive reads, with eviction by configured byte cap. Cache only under this run's analysis frame directory; media/archive/source reads retain streamed hash behavior. Clear RAM between kernels without affecting persistent Drive checkpoints.

Stage source videos lazily only when a missing frame needs extraction. Prefer bounded dedicated /dev/shm RAM scratch on Linux when space permits, otherwise local runtime scratch; fallback to original Drive source on unavailable/too-small staging. Verify copied SHA256 matches source binding before use. LRU source staging cap2GiB (also respect actual scratch free space and memory headroom); small-file RAM cap256MiB. Sequential extraction/checkpoint writes retained; no unsafe parallel-writer accounting. Delete only owned runtime scratch, never Drive media/cache. Include staging time in global extraction deadline and recompute remaining time before process launch. Warm source copies reused across a triplet/tasks; no copy on fully cached rerun. Count staging copies/hits/fallbacks and gallery completion in output/receipt.

No annotation repair, cohort freeze, inference, summarization work, external credentials/deployment or commit/push.

## Touchpoints and validation

- Cell2 digest and config: bounded cache options; frozen dataset/runtime/identity defaults unchanged.
- Cell22 read_frame_checkpoint + helpers: RAM read wrapper preserves readable-image/hash/path checks and existing return contracts; new scoped staging/gallery helpers.
- Cell27 missing-frame loop: source staging only for pending work; per-frame checkpoint and fair scheduler retained; HTML gallery after extraction with progress. Receipt must remain available without heavy Matplotlib output.
- Cell31 additive I/O/gallery evidence; sources/frames/artifact hashes remain honest.
- Tests: old858grid output versus new all-frame gallery coverage, zero Matplotlib/savegrid calls, RAM hit/invalidation/eviction/limits, staged SHA/fallback/deadline/cleanup, no staging on cached rerun, interruption keeps completed frames, missing/corrupt redecodes, old keys/caches readable, all333/9021 accounting/receipt. Controlled real FFmpeg fixtures; actualColab throughput not claimed locally.

## Pipeline

- [x] Scout exact notebook, observed outputs, existing helpers/tests; backup completed.
- [x] Independent plan review; conditions below incorporated.
- [x] Implement bounded cache/staging and lightweight gallery; synchronize clean notebooks.
- [x] Focused tests, independent review, existing regressions and full receipt checks.
- [x] Guide/reports/evidence and final Colab handoff.

Review conditions: copy in chunks with deadline/free-space checks and finally cleanup, unique owned scratch only, memoize capacity fallback per source fingerprint; contained resolved cache paths and size/mtime_ns/ctime_ns fingerprints; escape all HTML and show unavailable slots; thumbnail failures remain presentation-only and cannot damage source/frame/checkpoints or prevent receipt. Test zero-decoded and interrupted paths.

Unresolved: actual Colab RAM/scratch capacity and measured throughput. Conservative fallback required.

Final evidence: [implementation report](../reports/implementation-261019-0033-mlpdataset-finish-preview-fast-report.md). Local Windows test limitations explicitly retained; actual Colab throughput pending.
