---
title: MLPDataset preview resume
status: completed
priority: P1
effort: medium
branch: untracked-notebook
tags: [notebook, eda, cache]
created: 2026-10-18
---

# Preview checkpoint resume and source-group fairness

Mode:auto, moderate scoped notebook fix. User authorized ck:fix. No commit/push or acquisition authentication changes.

## Diagnosis

Exact symptom from saved receipt:1423 preview_budget_not_attempted,343 decoded,38 source videos; two source groups have zero images. Run same cell twice with matching Drive/RUN_NAME: FFmpeg reprocesses successful requests instead of reusing them. Expected existing valid frames reused, subsequent budget expands coverage. Root cause cell27 resets rows, never reads frame ledger, always invokes FFmpeg and overwrites ledger at end; global filename binding includes execution budgets. Why now: full-release30-minute cutoff exposed deterministic order; path untracked, no commit introducer. Blast radius:cell22 helpers,27 preview/cache,29 coverage,31 receipt, guide and current focused tests. Media202 cache identity and all333/9021 records retained.

## Acceptance and work

- [x] Scout/diagnosis; executed notebook preserved without modifying media.
- [x] Stable per-frame bindings, validated legacy-ledger migration, atomic per-frame checkpoints surviving interruption.
- [x] Mark-level turns across all source groups/videos, prioritizing least covered; all pending/failed/outside requests retained.
- [x] Inline reused/new counts and group coverage, receipt evidence includes reused frames/checkpoints.
- [x] Exact before/after repro, real FFmpeg and cache invalidation/path-safety/interruption/fairness tests; full inventory and receipt regressions.
- [x] Independent code review, guide/report/journal, workflow artifact finalize gate.

No semantic timestamps repaired. New Colab execution remains external validation.
