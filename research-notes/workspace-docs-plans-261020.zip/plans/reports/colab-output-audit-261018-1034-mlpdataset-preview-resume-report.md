# Executed preview-resume Colab audit

Receipt2026-10-18T03:33:02Z =10:33:02 UTC+7. Notebook20/20 code cells executed consecutively1–20; no saved exception. Read-only review; notebook outputs preserved.

## Resume result

343 legacy frames migrated and reused; all343 request keys and frame SHA values match previous saved ledger. None launched a new process.332 additional requests started and all332 decoded.675 cumulative decoded frames,675 checkpoint artifact entries. Ledger1794 rows unique byvideo/index/offset and reconciles receipt:675 decoded,1092 preview_time_budget unattempted,27 outside_video; no current preview timeout/decode failure.

Visual evidence expanded38→118 videos and116→228 unique marks.221 marks have3 frames,5 have2,2 have1.10/10 source groups now have images. Cached/new labels visible in saved grids. Source groups (videos with images/marks with images):anat-1=16/25;anat-2=3/9;bio-1=11/18;bio-3=7/14;bio-4=18/26;dental=33/73;ml-1=10/22;psy-1=2/6;psy-2=5/15;speaking=13/20. Frame evidence covers228/9021=2.53% of released marks;8793 remain without any visual evidence. Generic diagnostic request queue still covers598 marks; its completion would not certify all9021 labels.

## Media and diagnostics

202 downloaded/131 historical failed. Acquisition attempted_this_run=False for all333 records:202 reused,131 retry_not_eligible. Thus this run does not retest whether missing sources are still blocked; their retained last errors are bot-confirmation messages. No added downloads and no recovery claim.

Format discovery:46 command_completed,1 timeout (AMwWMcncTmQ),286 not attempted after diagnostic time budget. This shows format discovery worked for some queried sources this run; it does not prove missing video download recovery.

Storage~3.63GiB media below8GiB,analysis/log~0.308GiB below1GiB; no cap stop. Remaining preview work stopped at30-minute extraction time.

## Inventory and visual review

333 videos/9021 unique marks conserved, excluded0,10 source groups, numeric parse errors0.5523 marks have reported media duration;5514 within it,9 at/after end,3498 unknown. No timestamp repairs/semantic certifications.

Viewed saved grids40,100,227.2NgUY8f1pa8 mark54 and55mhfZSENKc mark40 show old slide at annotation and different slide at+0.5s; bfOusdt4LJ0 mark0 at29.7768s shows an animated intro across allthree frames, insufficient to certify a slide transition. These3 illustrative observations do not constitute a228-mark semantic audit. Current offsets±0.5s.

## Next steps and limits

Resume preview to extend validated image coverage; cached frames now prevent duplicate extraction. Acquisition recovery for131 sources remains a separate task. Semantic event classification/boundary refinement needs more direct review; do not repair timestamps from three still frames alone. Saved notebook receipts/checkpoint hashes were reconciled with embedded ledgers; Drive binary artifacts were not independently fetched/rehashed.

Unresolved:1092 queued frame requests,8793 marks without visual evidence,131 source download failures not retried this run, semantic/timebase/source-rights qualification.
