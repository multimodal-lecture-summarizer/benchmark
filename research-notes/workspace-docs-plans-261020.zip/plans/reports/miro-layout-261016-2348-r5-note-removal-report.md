# R5 note removal and compact layout

Removed exactly four note widgets identified in user screenshot: protocol/failure rules, candidate/runtime/grouping, evidence receipt, and seven-course composition. Explicit user request authorizes these four deletions. Before SVG retained under benchmark/experiments/outputs/r5-notes-removal-261016-2348/.

Moved existing chart from local x6800 to x3400; scale4.1 unchanged. Frame width reduced12300→9000, height3400 unchanged. Chart measured bbox30780,5980,5248,2952 remains inside frame27380,5800,9000,3400. Clear of left tables by at least704px; right margin352px, bottom268px. Three original tables/title/chart retained; no metrics/source/notebook edits. Readback confirms four notes absent and three tables plus chart present.

Unresolved questions: none.
