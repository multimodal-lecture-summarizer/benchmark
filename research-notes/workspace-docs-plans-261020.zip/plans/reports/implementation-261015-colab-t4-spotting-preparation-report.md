# CVID spotting: notebook Colab T4 và gate thực thi

15/10/2026. **Đã chuẩn bị và kiểm tra local; chưa chạy trên Colab T4; TESTR chưa đủ điều kiện so sánh.**

## Artifact bàn giao

- [Notebook](../../benchmark/experiments/notebooks/iiit-cvid-spotting-colab-t4.ipynb): bảy code cells chưa chạy, không tạo output model giả.
- [Bundle tự chứa](../../benchmark/experiments/outputs/iiit-cvid-spotting-colab-t4-inputs.zip): **181 files / 1.782.460 bytes**, code/registry/protocol/GT; không cần code chưa push từ GitHub.
- SHA256 bundle: `ff44fdfc654decea11d91ef1bc89912074e12c0a2928386b0db53eb8109aa148`; notebook chứa đúng digest.
- [Registry mới](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-colab-t4-candidates-261015.json), [CLI](../../benchmark/experiments/scripts/run_spotting_colab.py): `prepare`, `preflight`, `run`, `analyze`, `status`.
- [Receipt chuẩn bị local](../../benchmark/experiments/outputs/cvid-colab-t4-preparation-261015.json): notebook/bundle/registry hashes, data coverage, tests và các cờ `t4_verified=false`, `testr_verified=false`.
- [Bằng chứng artifact/runtime](worker-261015-1003-colab-t4-candidate-runtime-artifact-lock-report.md), [review độc lập](code-reviewer-261015-1007-colab-t4-spotting-report.md), [plan](../261015-cvid-spotting-colab-t4/plan.md).

## Candidate và mức độ khóa

| Candidate | Artifact/config | Environment dự kiến | Trạng thái |
|---|---|---|---|
| EasyOCR CRAFT + English G2 | Giữ weights/package wheel/config cũ; đổi GPU và tắt quantization CPU | Python3.10.16, EasyOCR1.7.2, Torch2.5.1+cu121 | Artifact khóa; chờ T4 preflight |
| Paddle v3 det + v4 rec | Giữ weights/package wheel/threshold/decoder/grouping; GPU, tắt MKLDNN | Python3.10.16, PaddleOCR2.8.1, PaddleGPU2.6.2; CUDA11/cuDNN8 wheels và loader paths riêng | Artifact khóa; chờ T4 preflight |
| Tesseract English LSTM | Fixed English tessdata_best commit/SHA; OEM1/PSM11/TSV level5 | CPU, Tesseract5 binary/linked libraries seal trên VM | Traineddata/config khóa; binary pending Colab |
| docTR FAST-base + PARSeq | Hai checkpoint đã tải/hash; tắt cả auxiliary orientation predictors | Python3.10.16, docTR0.12.0, Torch2.5.1+cu121 | Artifact khóa; chờ T4 preflight |
| PP-OCRv6 medium | Hai HF revisions cố định; configs đã tải/hash; parameter SHA từ LFS metadata | Python3.10.16, PaddleOCR/PaddleX3.7.0, PaddleGPU3.3.0 | Artifact expectations khóa; bytes/load pending Colab |
| TESTR R50 Polygon Total-Text | Source/config pin; author checkpoint HTTP403, chưa có trusted model hash | Python3.8.20, Torch1.10.1+cu113, Detectron2v0.6, nvcc11.3 | **Blocked, conditional; chưa eligible** |

Không gọi toàn bộ môi trường là đã resolve/xác minh: mới khóa direct requirements, Python và artifact expectations. Lần `prepare` trên Linux resolve đầy đủ transitive graph, giữ/hash wheels và installed files, chạy pip check rồi seal **trước preflight/test**. GPU là profile mới; không nối prediction CPU vào run này.

TESTR có adapter thật và đường build custom ops nhưng registry cố ý `locked=false`. Không dùng checkpoint thay thế hoặc bịa hash. Khôi phục checkpoint tác giả cần registry/bundle mới, xem xét provenance rồi build/load/forward pass thật. Hash file được cung cấp chưa chứng minh nguồn gốc. Chưa có cơ sở nói TESTR chạy được trong profile này.

## Data và gate

Giữ nguyên **1.754 frame / 40.063 GT**, archive SHA `b5b562580e250ee3336462b7699bc79d0d1149d3b8cc82f1b221a0d0ce4fb489`, GT/cohort/protocol/scorer/influence/frame-ID hashes. Notebook tải đúng pinned HF revision hoặc dùng source ZIP trên Drive rồi kiểm hash. Bundle không chứa ảnh.

Local đã kiểm archive thật và mọi selected PNG hash. Preflight chọn frame train đầu tiên theo thứ tự từ điển cho mỗi decoded image size, không dùng model score hoặc GT labels: **9 frame**.

```text
Frames/train/1/1/00_00_50_00001.png
Frames/train/12/1/00_00_33_00001.png
Frames/train/15/1/00_03_25_00001.png
Frames/train/16/1/00_09_38_00001.png
Frames/train/17/10/00_08_10_00001.png
Frames/train/21/1/00_02_38_00001.png
Frames/train/22/1/00_01_20_00001.png
Frames/train/4/1/00_09_55_00001.png
Frames/train/5/1/00_01_07_00001.png
```

Chỉ vào test sau khi load thật, forward train, schema/hình học hợp lệ và có ít nhất một observation. Preflight không đo accuracy/tune threshold. Worker test replay cùng train warm-up để nạp lazy native libraries, rồi so runtime seal trước test. Receipt bind data/code/config/weights, installed bytes, GPU/driver/backend/precision và mapped native `.so` hashes. CUDA/cuDNN khác dù cùng version string vẫn bị từ chối resume. Đường native Linux chưa chạy local Windows.

## Checkpoint và báo cáo

- `prepared-data.json` giữ data/code bindings và preflight IDs/hashes.
- Mỗi candidate có `prepared.json`, passed `preflight.json`, logs/failure receipts, `run-identity.json`, từng frame checkpoint, `predictions.jsonl` và `candidate-complete.json` khi đủ coverage.
- Lỗi inference giữ zero predictions và toàn bộ GT thành FN. Resume chỉ chạy test frame chưa commit; không đổi config hoặc retry để chọn prediction tốt hơn.
- `.execution.lock` chặn concurrent writers. Nếu VM bị kill để lại lock, phải kiểm tra không còn worker trước khi gỡ; không tự phá lock.
- Drive lưu output và runtime cache tách riêng. Cache giữ full wheelhouse/resolved graph/seals; session mới rebuild offline và phải khớp installed digest. System libraries/driver/Tesseract binary khác vẫn có thể chặn resume; offline reconstruction trên Colab chưa được xác minh.
- Năm candidate chính phải hoàn tất cùng cohort mới có comparison. TESTR chưa đủ gate được công bố trong eligibility, không ngăn bảng năm candidate. Nếu TESTR đã pass, phải hoàn tất full cohort mới được chấm chung.
- Scorer cũ với Python3.11/Unicode14: E2E Hmean, detection P/R/F1, failure, IoU>0.75/case-sensitive/three-frame influence, per-frame/course/folder, macro-course means và exploratory cluster bootstrap so với Paddle anchor cố định.
- Sáu plots cho primary, detection P/R/F1, sensitivity, course, failures và paired CIs; visualization receipt bind CSV hashes. Evidence ZIP chứa receipts/logs/checkpoints/metrics/figures; wheelhouse nhiều GB nằm riêng.

## Cách chạy

1. Upload notebook lên Colab. Đặt bundle tại `MyDrive/OCR/iiit-cvid-spotting-colab-t4-inputs.zip` hoặc sửa `BUNDLE_ZIP`.
2. Chọn T4; giữ `RUN_ID` để resume cùng identity, đổi run/version nếu thay code/config/weights.
3. Chạy cells theo thứ tự: verify → prepare → train preflight → test inference → analyze/plots → export. Cell export có thể chạy riêng sau gián đoạn để lấy partial evidence.
4. Output: `MyDrive/OCR/cvid-spotting-t4-261015-v1`; cache: thư mục cùng tên cộng `-runtime-cache`.

## Xác minh local

**75 tests passed**: acquisition/TSV, immutable checkpoints, train-only gate, gate→infer→failure→resume, tamper rejection, notebook/bundle/figure/export và regression scorer/freeze/runtime/CPU checkpoint cũ. Notebook syntax/nested downloader syntax hợp lệ; bảy code cells unexecuted. Bundle exact membership/hash và frozen bindings đã kiểm.

Lần đầu regression ở sandbox Temp gặp bốn lỗi rename của CPU module cũ; rerun với pytest basetemp trong workspace qua 75 tests, không sửa module cũ. Console pyreadline in cảnh báo teardown sau exit0; lần cuối không có test failure. Review độc lập không còn defect critical đã xác nhận.

## Giới hạn và câu hỏi còn mở

- Chưa có Colab T4: imports, GPU forward passes, peak VRAM, thời lượng và full inference pending. Không coi notebook đã chuẩn bị là benchmark result.
- TESTR cần author checkpoint xác thực được và custom-op environment tương thích trước comparison.
- CVID annotation chọn lọc/test đã EDA-exposed: kết luận là released-label agreement, không exhaustive gold/blind test/production winner. Không so tốc độ Tesseract CPU với neural T4 như cùng thiết bị.
