# MLPDataset video-only selector and JavaScript setup fix

Date: 2026-10-17, Asia/Bangkok. User authorized fixing the diagnosed Colab download failure.

## Root cause and change

All ten saved format inventories expose <=360p video-only streams and no combined stream within that cap. The previous `best` selector requires combined audio/video and therefore matches nothing. The supplied runtime also reports no enabled JS runtime, absent Deno, and Node20 only. Failed attempts were intentionally retained by `RETRY_FAILED=False`.

Updated the same Colab notebook. Setup upgrades `yt-dlp[default]`, installs the official Deno npm distribution under runtime storage, verifies Deno >=2.3, and prints executable/version. Download and format discovery commands both pass `--js-runtimes deno:<actual-path>`.

New selector prefers <=360p MP4 video-only streams over HTTPS, then MP4 other protocols, other video-only formats, and combined streams. Every fallback retains the height cap; audio-only streams cannot match. EDA frame extraction does not need audio. No resolution increase, label edit, scoring or model inference.

Default run is `mlpdataset-eda-261017-v3`, manual source `-8QB3Rbeqoc`, to qualify one real acquisition first. Full annotation EDA remains 333 IDs. Acquisition identity v3 records selector and Deno/yt-dlp/EJS versions without transient executable paths. Old run directories and failures remain untouched. Expand to `per-speaker` or `all` after examining the first source's outputs.

Full inline logs/checkpoints/receipt/frame previews remain. No result ZIP. Exact received notebook is backed up in ignored `benchmark/experiments/outputs/mlpdataset_download_fix_261017/received-before-fix.ipynb`. Annotation cells 4–18 remain unchanged; modified setup/configuration/media/receipt outputs are cleared.

## Validation

- Plan and artifact review approved; no blocking issue found.
- Real yt-dlp selection logic applied to video-stream metadata reconstructed from all ten saved actual format inventories: old selector 0 matches for every source; new selector 1 valid MP4/HTTPS match per source, height <=360. No network access or successful download inferred from this test.
- Schema/AST and preserved annotation cells checked. Focused real FFmpeg/frame/checkpoint/process tests pass, including interrupted-attempt persistence, stale-frame exclusion, long-log rendering and URL sanitization.
- Fresh-kernel cached-data notebook validation passed 18/18 code cells with zero error outputs; it excludes installer/Drive/network/JS execution. Local environment lacks EJS; validation configuration explicitly records `not-installed-offline-validation`, rather than installing into the user's global environment or claiming runtime verification.
- Official setup references: [yt-dlp EJS](https://github.com/yt-dlp/yt-dlp/wiki/EJS), [Deno npm installation](https://docs.deno.com/runtime/getting_started/installation/).

## User run

Upload the revised notebook and run from setup with accelerator **None**. Keep the default new run name and single manual ID initially. Review actual download command, Deno/yt-dlp versions, acquired file metadata and frame triplets. Save the notebook with outputs. No commit/push.

## Unresolved

Actual npm/Deno installation and video acquisition on Colab remain user-run and unverified here. Fixing selection/runtime configuration does not guarantee media-server access; if a different error appears, retain its full log. Source-video edit/timebase correspondence and semantic boundary correctness remain separate qualification steps.
