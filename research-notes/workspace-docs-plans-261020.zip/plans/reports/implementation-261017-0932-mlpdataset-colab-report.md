# MLPDataset standalone Colab notebook

Date: 2026-10-17, Asia/Bangkok. Scope: prepare user-run CPU acquisition/EDA; no live Colab execution or detector benchmark.

## Delivered

- [Clean Colab notebook](../../benchmark/experiments/notebooks/diagnostics/mlpdataset-slide-transition-eda-colab.ipynb): 27 cells, 17 code cells, dependencies/configuration/Drive included; no repository clone or local helper imports.
- [Run guide](../../docs/mlpdataset-colab-guide.md): CPU setup, selection, resume, budgets, artifacts and limitations.
- Existing executed local EDA and its receipt bindings preserved unchanged.

## Behavior

Both pinned author annotation ZIPs download and verify known SHA-256. Twelve author source files acquire from pinned revisions. The notebook embeds full all-ID annotation/release/ASR/spoken EDA, plots, raw-order anomalies and dependence diagnostics.

Default source-media selection is the lexicographically first ID per speaker proxy (10 videos). Options: all 333, structurally flagged sources or manual IDs. All selected/unselected IDs remain visible. Ordinary public yt-dlp downloads use up to 360p with per-file, total-run-folder, remaining-free-space and download-time budgets; logs update during acquisition. Completed files require identity/hash/probe checks on reuse. `.part` downloads may continue; failures remain until explicit retry. An interrupted attempt persists its status/history, with the process group cleaned up. Successful retries clear the current error but retain attempt history.

Frame extraction prioritizes anomaly marks then first/middle/last, capped per video. Before/at/after previews retain requested timestamps, source/frame SHA-256, configuration binding, observed time and unreviewed semantic verdict. Outside-duration requests are unavailable rather than silently clamped. Fresh temporary frame files prevent stale-success inference. Current evidence lists exclude prior selections/offsets. A separate preview-time budget applies.

Evidence ZIP contains current CSV/JSON/PNG artifacts and checkpoints, excluding source videos/ZIPs and private access logs. Two summary figures are included in the hash manifest. Drive persistence is optional and requires the user's normal Colab mount consent.

## Validation

- Plan review and artifact review completed. Two initial blockers—process cleanup on interruption and stale preview export—fixed and re-reviewed; no remaining blocker reported.
- Notebook schema/AST and clean unexecuted delivery state checked.
- Fresh local kernel validation passed all 17 code cells with zero error outputs, verified all exported artifact hashes and matched the finalized template code except the bootstrap/configuration overrides. It uses real cached author archives/source snapshots; only environment setup, Drive and network download switches are overridden. This does not test the Colab installer/mount/network path.
- Focused helper checks use an explicitly generated two-second test video, not dataset evidence: real ffprobe, five valid preview decodes, negative/EOF requests, identity mismatch rejection, stale-file rejection/export exclusion, timeout cleanup and persisted simulated interruption pass.
- Windows `KeyboardInterrupt` injection caused a native console exit anomaly despite completed assertions. Final interruption regression uses a `BaseException` subclass, checks actual process termination and retained attempt, and exits 0. Actual Colab UI interruption remains untested.
- No full application test/build needed: application code and shared runtime contracts untouched. No commit/push.

## User steps

Upload the notebook to Colab, set accelerator **None**, run setup/config then remaining cells in order. Default Drive destination: `MyDrive/MLPDataset_EDA/mlpdataset-eda-261017-v1/`. Run `per-speaker` before expanding acquisition. Set `MEDIA_SCOPE='all'` to select the full source inventory; time/disk limits continue to apply. Retain the executed notebook with outputs and `mlpdataset-eda-evidence.zip`.

## Unresolved questions

Live Colab/Drive/YouTube acquisition has not run here and may still return HTTP 403. GPU does not resolve network access. Exact recovered-video edit/timebase, terminal-mark interpretation, source rights/dependence and semantic boundary correctness remain separate qualification steps.
