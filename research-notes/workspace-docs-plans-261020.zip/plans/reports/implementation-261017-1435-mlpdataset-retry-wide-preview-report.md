# Targeted HTTP 403 retry and wide preview

Updated the standalone Colab notebook and docs/mlpdataset-colab-guide.md. Keep per-speaker selection and v3 Drive/cache acquisition identity. RETRY_FAILED=True with allowlist [2NgUY8f1pa8] retries only that failed source; completed videos retain hash/probe checks and reuse. Prior attempt logs remain inline.

Eleven explicit context/edge marks now use seven requests at -5,-2,-0.5,0,0.5,2,5 seconds. Normal sampled marks remain three requests; newly recovered retry-video marks use seven. Explicit targets are unioned after the automatic sampling cap. Target availability, labeled grids, full ledger, missing media, retry policy and preview config/hash are inline. Out-of-range times are not clamped. Semantics remain unreviewed.

Preserved supplied executed per-speaker notebook in ignored experiments/outputs/mlpdataset_retry_wide_preview_261017/received-per-speaker-executed.ipynb before clearing stale outputs from runner. No ZIP generated.

Validation: notebook schema and all 18 Python cells parse. Acquisition identity/selector/cache/process guard AST unchanged. Independent code review found no blockers. Actual FFmpeg generated clip validated 24 requests: 17 decoded and 7 outside-video; explicit targets survive automatic cap; frame names unique; zero-budget pass excludes stale decoded frames and keeps fresh status grids. Local Agg backend emits expected noninteractive display warning; Colab renders inline.

Unresolved: live HTTP 403 retry may still fail; expanded Colab outputs await user execution. Package/runtime identity drift stops reuse explicitly. No source rights, edit equivalence, semantic GT or benchmark cohort certification added.
