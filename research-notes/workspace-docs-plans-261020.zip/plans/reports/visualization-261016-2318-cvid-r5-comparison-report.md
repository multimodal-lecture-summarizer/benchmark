# CVID R5 visual comparison

Added one visual comparison panel inside existing Miro spotting frame, extending frame width into verified empty canvas. Original text/tables/values unchanged. Chart bbox (34180,5980,5248,2952) stays inside frame (27380,5800,12300,3400), 450px clear of nearest prior content and 248px from the frame right edge. Four views: sorted pooled E2E Hmean; detection P/R/F1 heatmap; pooled vs unweighted seven-course Hmean; three predeclared sensitivity variants plus primary. All six pipelines shown with numeric labels. Pooled and macro bars share limits; heatmap scales declared. PGNet-docTR gaps +7.47pp pooled/+0.35pp macro. No significance or production-winner claim.

Source: committed R5 metrics.csv and macro-course-means.csv; hashes verified before/after. No scoring or inference rerun. PNG visually inspected and legend/footer overlap fixed. Standalone SVG/PNG/PDF, HTML, build script and receipt at benchmark/experiments/outputs/r5-visual-comparison-261016-2318/. Miro readback confirms dashboard values and measured bounds.

Unresolved questions: none for this presentation update.
