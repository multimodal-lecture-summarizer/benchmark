# Dense MLPDataset boundary analysis

Updated standalone Colab notebook and docs/mlpdataset-colab-guide.md. Keep per-speaker selection, Drive RUN_NAME v3, acquisition checkpoint identity and existing wide-preview code unchanged. The supplied executed notebook is backed up at benchmark/experiments/outputs/mlpdataset_dense_boundary_261017/received-wide-preview-executed.ipynb. Clean runner has20 code cells with no stale outputs.

## Evidence carried forward

Latest received run:10/10 downloaded, HTTP403 recovered on attempt2,137 decoded/9 outside-video requests across30 sampled marks (14 wide). Prior visual inspection is recorded as14 draft entries, each bound to source SHA, released annotation time and executed-notebook SHA. Five marks on18SixEz5GDE/8OrCdgHcMVM show new slide/end card between+0.5 and+2s; recovered-source three marks show new slide by+0.5s. Remaining cases include intro/outro/blank/credits/start/end. No fixed source shift or GT repair follows from these samples.

## New behavior

For fourteen existing wide marks, add an embedded CPU-encoded MP4, dense selected frames at least0.25s apart, motion plot and three largest adjacent-frame change pairs. Full inline ledgers include integer PTS, rational time base, source elapsed time, offset, frame/source/config hashes, requested/effective windows and extraction/clip statuses. Candidate brackets remain semantic unreviewed. Draft categories are distinct from annotation; annotation_repairs_applied=0 and semantic_verified_boundaries=0.

Input seek uses videoorigin+elapsedwindowstart-formatorigin. Annotation offsets subtract videoorigin only. Input duration bounds decoding. IntegerPTS/timebase avoids showinfo printed-time rounding. Streamduration is preferred; nonzeroorigin without streamduration fails explicitly. Failed/partial extraction never publishes its frames. Budget/size failures never claim stale clip success. Clips reset playback time and show their source window. Separate15-minute dense budget,60-second process cap and3MiB per embedded clip. No ZIP or model inference.

## Validation

Schema and Python AST for all20 cells passed. Original acquisition/helper/wide-preview source unchanged. Independent code review found and resolved printed-PTS precision compatibility and timestampseek issues; final review clear. Actual FFmpeg fixture with known cut2s was tested at origins0,5 (audio/containerorigin0), and10000.010026 with fractionalseek. Highest-motion brackets1.8–2.066667 and1.833333–2.1 contain the true cut. Corrupt index/PTS/timebase rejection, negativeorigin parser, start/EOF windows, zero-budget stale exclusion, clip embed cap, complete runner and disabled branch passed. Embedded MP4 HTML contains a dataURI. Local Agg display warning is expected; Colab uses inline display.

Validation evidence: benchmark/experiments/outputs/mlpdataset_dense_boundary_261017/local-validation/validation.json. Source videos remain on Drive; fixtures are explicitly local test content, not research evidence.

Unresolved: new dense Colab execution and manual semantic decisions; recovered-source edit/timebase equivalence; full-dataset media/label coverage, rights/dependence and eventual evaluation policy. User should upload updated notebook, keep RUN_NAME/Drive and Run all withoutGPU.
