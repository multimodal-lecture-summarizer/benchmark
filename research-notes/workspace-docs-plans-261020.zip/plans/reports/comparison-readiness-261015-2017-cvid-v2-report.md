# CVID comparison v2 delivery review

15/10/2026. Scope: prepare user-run comparison, no agent model execution/upload/installation.

PGNet qualification independently rechecked against user ZIP SHA25655663a24c6156933015d42c642f827d6627f4875daca1f16af88b0c598613d2e: CRC/member hashes, runtime/prepared/registry/config binding, nine train IDs,199 predictions,one invalid polygon, no test inference. Audit provenance and raw receipt added as separate registry artifacts; never used as comparison gate or test completion.

Audit corrections: isolated orchestrator via existing prepare_environment; no kernel pip install. Preserve bootstrap/driver fixes. Explicit ALL6 current-attempt + bound-receipt gates before any test. Add status/log display, complete metric/sensitivity/course/folder/macro/CI/failure tables, all primary frame IDs, full text export access, any-frame GT/native prediction viewer and recorded-call cost accounting. Native confidence preserved where supplied; no synthetic PGNet confidence. Comparison uses new r2 identity.

Cohort/config/scorer unchanged: all seven FROZEN entries match; current six-candidate registry digest matches audited qualification registry.1754frames/40063GT. Both original five anchors and PGNet exact config/weights thresholds/grouping retained. Qualification ZIP unchanged (ee6c45d306f9684299cc0eb0492ffe962b1f3ac03cc0b31c2d3019456e01eb0a); v1 retained. Only canonical comparison bundle replaced; no extra ZIP variants created.

Validation:34 focused local tests passed across review guards, bootstrap/loader, candidate, PGNet, state and notebook contracts.10 comparison code cells and nested acquisition program parse; outputs empty/execution_count=null. Bundle190files/1825289bytes verified with exact membership/hash coverage, explicit notebook binding, corrected source bytes, frozen cohort/GT/scorer and unchanged registry. No actual six-candidate Linux install/preflight/test/analysis execution attempted.

Notebook SHA256: fa918d71ffd1095974d7473ba9a59936e40d50a5d51b856670faaf0fb0f323f1
Bundle SHA256: 9b5cc303a2665806e17733e6c06ffc419464c33d163232a60924fe5413215d4d

Source: [notebook](../../benchmark/experiments/notebooks/iiit-cvid-spotting-colab-t4-v2.ipynb); [manual guide](../../docs/cvid-spotting-comparison-v2-colab-t4-run-guide.md).

Unresolved user-run gates: actual T4 prepare/preflight for all six pipelines (only standalone PGNet is currently verified), full test inference/completion, scored analysis and rendered full results, offline reconstruction/resume after VM loss. Existing tests cannot certify these runtime outcomes. Partial failures stay evidence; no production model selection.

