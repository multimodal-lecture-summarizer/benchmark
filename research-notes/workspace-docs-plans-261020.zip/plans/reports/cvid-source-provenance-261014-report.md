# CVID source linkage and prior-test-use audit

Audited 2026-10-14, Asia/Bangkok. Advisory audit; no inference, GT edits, cohort freeze or automatic exclusions.

## Source evidence and credibility

1. Hash-pinned author archive: `benchmark/research-data/iiit-cvid-source/IIIT-CVid.zip`, SHA-256 `b5b562580e250ee3336462b7699bc79d0d1149d3b8cc82f1b221a0d0ce4fb489`. Direct member reads give strongest release-level evidence.
2. [Author paper](https://cdn.iiit.ac.in/cdn/cvit.iiit.ac.in/images/ConferencePapers/2018/localizing-recognizing-text.pdf), Section III/Table II. Primary methodological source; release metadata can qualify its general claims.
3. Local historical receipts and saved notebooks below establish observed local scope, not exhaustive worldwide/model-pretraining history. These are project evidence, not independent replications.

## Linkage granularity

- ZIP has 24 course-level and 811 video-level `metadata.txt` members. All 811 video members declare `Complete name` (local media filename). All 811 metadata byte sequences differ.
- The 22 video-level metadata files containing HTTP URLs are all `Frames/test/7/12` through `/33`: their URLs are generic MIT OCW copyright/terms URLs. None of the 811 video metadata files supplies a stable per-video source URL.
- Course metadata supplies a course page, playlist or example YouTube URL. This proves a declared course association, not which source URL belongs to each numeric video folder. Titles and local filenames provide lookup leads; joining folder number to playlist index without verification would be guessing.
- No cross-split exact `Complete name` collisions were found. Generic filenames such as `mod01lec01.mp4` recur within multiple train courses, so basename alone is not a globally unique video identity. Frame timestamps only locate time within a released group; they do not authenticate source videos.
- README explicitly describes course folders, video folders and `hh_mm_ss_counter` frame names; it does not provide a per-video URL mapping or source-video hashes. README SHA-256: `3f1df4555acf1f63def701d1775c3994b2596573ea0cda8c21bf3e11be06c294`.

## Writer/course separation

Course IDs and declared course URLs are separated by split, as the all-split inventory reports. However, paper Section III infers disjoint writers from disjoint courses, which the shipped metadata does not universally support:

| Released course | Declared instructor |
|---|---|
| train/1 Advanced Data Structures | Erik Demaine |
| train/5 Introduction to Algorithms | Erik Demaine and Srinivas Devadas |
| val/6 Algorithms for Planar Graphs and Beyond | Erik Demaine |

Course metadata SHA-256, respectively: `a342fa7eab5a5d4894a2226e1e73a9381c627ab3b53e6d5b816150ba2e78d526`, `81ead8420917a353d06083e7c2d34dd725d2a708437d4289bcd6dbff9fdc5e6e`, `77b48edeaaa0db69504bfedf92e3b709e03e694978ac32fe0c7ea227fc9e65bc`.

This is a declared-instructor overlap, not proof that the same person wrote every selected frame. No explicit named instructor is shared between native test and the other splits in `courses.csv`, but entries such as “Various MIT Professors” and “Various Professors of IIT Bombay” are unresolved writer identities. Therefore use **native course-held-out**, not verified writer-disjoint or source-video-independent.

## Historical test exposure

| Evidence | Supported conclusion |
|---|---|
| `benchmark/experiments/outputs/dataset_readiness_260926/20260926T101747121197Z/bundle/summary.json` | Historical screening included all 1,755 test frames. SHA-256 `ba3741dc37b6879f2d04b13bf9a05dab543a41ae5eecae987d4c57c783c74d85`. |
| `benchmark/experiments/outputs/dataset_qualification_261010/iiit-cvid-qualification-receipt.json` and `benchmark/plans/reports/tedlium-cvid-followup-261010-report.md` | All splits decoded/read; evaluated count zero. Receipt SHA-256 `5173ec68a60845d0969374f60c1017bb39b861e6b8ea466cefae32086482ad86`. |
| `benchmark/experiments/outputs/ocr_validation_261009/paired_full.summary.json` | EasyOCR/PaddleOCR recognition scope explicitly 15,379 validation crops, 140 groups, five courses. SHA-256 `699411901daefe2bf219fda4a5c1a74c850632cef0509f594ba9743678f73237`. |
| `benchmark/experiments/notebooks/iiit_cvid_ocr_comparison_colab.ipynb` | Saved source acquires only Crops/val and Frames/val; explicit no-test runner scope. |
| `benchmark/experiments/notebooks/diagnostics/iiit-cvid-validation-ocr-eda.ipynb` | Validation notebook; historical all-split receipt included as context. Older claim that only val exists locally is now superseded. |
| `benchmark/experiments/outputs/phase2_iiit_cvid_d2/official/full/runs/00c_dataset_eda_and_freeze.run.json` | Literal repeated `aaaa`, `bbbb`, `cccc` hashes; not trustworthy provenance despite status `real`. Do not treat this as verified execution evidence. |

The inspected artifacts show EDA test exposure and validation-only OCR runs. They do **not** show test-score-based model tuning. They also do not prove every historical run is accounted for. Model-pretraining contamination remains unknown.

## Ranked recommendation and trade-offs

| Rank | Endpoint | Fit / trade-off / risk |
|---|---|---|
| 1 | Existing native test with frozen candidates and explicit prior-EDA disclosure | Best fit for released course generalization; uses existing labels and requires no invented mapping. Residual per-video/writer and pretraining uncertainty limits claims. Complete visual candidate adjudication before freezing. |
| 2 | Additional independently sourced course/writer-held-out dataset | Stronger external validation if source/video/writer identities and GT are verified; higher acquisition/annotation cost and adoption burden. Add only if broader deployment claims are needed. |
| 3 | Pool train/val/test or call val an independent final test | Reject for final evaluation: destroys the intended separation and confounds development with evaluation. |

Model settings must remain selected without test scores. A score-independent audit of test quality does not itself invalidate test evaluation; disclose its exposure and avoid calling it blind/untouched. No maturity/community/breaking-change assessment applies to this static provenance decision; primary risks are incomplete identity and historical-run records.

## Remaining questions

- Can author or authenticated course records provide exact video-folder-to-source mapping? No mapping verified here.
- Do vague course instructor groups overlap test writers? Unknown; no frame-level writer identification performed.
- Are all old test model runs inventoried? No exhaustive historical search or sealed Colab/Drive audit performed.
- Are the 469 dHash candidates repeated content? Parent visual audit must adjudicate; filename/URL separation does not answer this.
- Are pretrained model weights uncontaminated by CVID? Unknown; no training-data provenance proof available.
