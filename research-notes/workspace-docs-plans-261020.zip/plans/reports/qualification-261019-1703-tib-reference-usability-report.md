# TIB reference-usability qualification, 2026-10-19

Implemented and executed offline on all four pinned Parquet files, revision `e6ab9fd7c6acd164f3284b8c4b17eb9d94681eee`. Canonical source is released `transcript`; segments remain sidecar evidence. No generation, model API, candidate outcomes or similarity-score cutoff used.

## Policy and calibration

`benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/reference_policy.json` was serialized before full-ledger processing. Calibration inspected entire abstracts and first 1,200 transcript characters of train:0–5. Topic-related openings alone did not justify A; boilerplate or shortness did not justify C. Frozen rubric: empty normalized reference C; uncertain nonempty reference B; nonempty A/C require explicit reviewed presentation-relation evidence. B remains primary-reference eligible, subject to independent rights, source, group and exposure gates.

Technical normalization: NFC plus whitespace collapse, case-sensitive. Historical reproduction uses the unchanged helper's strip/casefold/whitespace normalization, without NFC. No old helper, EDA notebook, old120 input or output was edited.

## Results and reconciliation

| Split | A | B | C empty | Source rows |
|---|---:|---:|---:|---:|
| train | 0 | 7,276 | 6 | 7,282 |
| valid | 0 | 909 | 1 | 910 |
| test | 0 | 910 | 1 | 911 |
| All | 0 | 9,095 | 8 | 9,103 |

Exact historical chain reproduced: 9,103 source → 9,002 legacy structurally eligible → 8 empty + 225 reused flags → 8,769 historical broad pool. These historical numbers are preserved rather than imposed on new eligibility.

Current case-sensitive NFC reference reuse over all rows is 224 records / 17 groups. Historical casefold reuse is 225 / 18 groups after structural filtering. `train:4447` and `train:7123` share only under historical casefold grouping (GeoServer description). `train:5322` enters current all-row reuse but had legacy `invalid_segment_times`; canonical text eligibility is independently decided downstream. A repeated abstract does not establish a duplicate source or grant cohort admission.

## Targeted review

All 18 shared-reference groups / 226 all-row members were inspected, including all 225 historical flags. Reference worker reviewed groups0–8; root reviewed groups9–17. Each group review inspected its entire abstract, every member title and a source topic-anchor passage or source opening when no anchor was available. Every member has source/reference hashes, raw-character source span coordinates and excerpt hash in `historical_reuse_group_reviews.json`. Raw review excerpts remain only in ignored `research-data/.../reference_review_packets.jsonl`.

All 225 historical members receive **reviewed uncertain B**. Broad chemistry-course descriptions generally relate to their presentation contexts but lack episode-specific coverage. The short chromatography reference and case-varying GeoServer description do not demonstrate mismatch. Administrative openings and noisy ASR remain uncertainty, not evidence of C. This is real targeted review with a deliberately limited scope; it does not certify full-transcript coverage, factual correctness, or all9,103 references as manually reviewed. Other nonempty rows retain default B. A-only sensitivity is unavailable because no A was certified.

## Artifacts and verification

- Helper: `benchmark/experiments/scripts/tib_model_benchmark_references.py`.
- Tests: `benchmark/tests/test_tib_model_benchmark_references.py`.
- Compact registry: `reference_policy.json`, `reference_summary.json`, `historical_reuse_group_reviews.json` under qualification root above.
- Ignored evidence: `reference_usability_ledger.jsonl`, `reference_summary.json`, `historical_reuse_review.jsonl`, `reference_review_packets.jsonl` under `benchmark/research-data/tib-qualification-261019-1703/`.
- Narrow plus unchanged legacy-helper tests: **21 passed**. A post-test pyreadline console destructor reports Windows invalid-handle warning; pytest exit0 and all assertions pass.
- Full-ledger invariants: 9,103 unique IDs, 225 reviewed historical flags, eight C excluded from reference primary, every B reference-primary eligible; no raw source/reference text or predictions in ledgers. Large evidence paths verified ignored.
- Frozen policy SHA-256: `5562791aba7b8125bba765f58388d86f1ccac3eccfa05ed5cd95bdf963a789fd`.
- Full reference ledger SHA-256: `4c5f98b59cce0fbd333253cb2321613ab022baf1cf8863269e4f53116c8b8e4a`.
- Historical review ledger SHA-256: `eec9709fec495aaf0d9d924fafafe7d463447a1e13d152b30461042a6dfb2df3`.

Reproduce base ledger in a **new empty destination** with helper `--data <pinned data> --policy <frozen policy> --output <ignored output> --compact <registry qualification root>`, then attach frozen targeted evidence with the same arguments plus `--apply-reviews <historical_reuse_group_reviews.json>`. Existing base ledger/historical ledger/summary destinations are rejected before source processing. Never overwrite frozen policy; amendments need a new version and requalification.

Review hardening validated in the additive `reference_review_validation_v2.json` receipt: all **226 inspected source spans / 226 members**, including all225 historical flags, match actual pinned canonical transcript excerpts, raw source/reference hashes, technical-normalized reference hashes, integer/end-exclusive character bounds and excerpt SHA-256. The read-only `--validate-reviews` path writes this new receipt exclusively and preserves all existing evidence ledgers and summaries byte-for-byte. Current helper SHA-256: `447290d958628faee43375a4bb998415fe2daee4dbe79d27b0a0914f98659e20`. Added overwrite/source-span/hash-forgery tests; focused plus unchanged legacy tests now **30 passed**. Base ledger and historical-review SHA-256 values above remain unchanged.

## Unresolved questions

Independent rights/source/group/exposure qualification and downstream cohort gates belong to other owners. Reference `cohort_seal_ready=false` means this helper cannot certify those gates, not that B is a blocker. No cohort IDs, output cap, model result or final selection was sealed here. Full-reference factual/manual adjudication remains outside the completed targeted reuse review.
