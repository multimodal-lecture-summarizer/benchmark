# CVID all-split inventory and spotting independence

Audit: 2026-10-14, Asia/Bangkok. Source read only; no OCR inference, GT edits, automatic duplicate exclusions or new cohort freeze.

## Conclusion

CVID contains **5,475 released frame/XML pairs and 137,745 word boxes with nonblank XML transcriptions**, across train, val and test. The 546-frame cohort is a derived validation endpoint, not the complete dataset.

**Native test is the appropriate candidate for a course-held-out spotting comparison after development on train/val.** It contains 1,755 frames / 40,103 objects; applying the existing score-independent whole-frame HOLD policy leaves **1,754 mechanically eligible frames / 40,063 objects**. This count is an inventory result, not a newly frozen test cohort or a declaration of complete scientific qualification.

Release course IDs, course/video folder groups and literal declared course URLs are disjoint across splits. Exact byte and decoded-RGB duplication checks found zero duplicate frame groups. However, source-video identities and 469 cross-split perceptual candidates remain unresolved, including 62 val/test pairs. Test images and labels have already been read in historical EDA. Describe a future qualified test endpoint as **native course-held-out, integrity-audited, previously observed test**; do not call it blind, untouched or proven independent of model pretraining.

## Reproducible evidence

- [Audit script](../../benchmark/experiments/scripts/inventory_cvid_splits.py), invoked from `benchmark` with `python -m experiments.scripts.inventory_cvid_splits`.
- [All-split machine receipt](../../benchmark/experiments/registry/datasets/iiit-cvid-all-split-inventory-261014.json).
- [Full frame ledger](../../benchmark/experiments/outputs/cvid-all-split-inventory-261014/frames.csv), [annotation issues](../../benchmark/experiments/outputs/cvid-all-split-inventory-261014/annotation-issues.csv), [course metadata](../../benchmark/experiments/outputs/cvid-all-split-inventory-261014/courses.csv), [perceptual queue](../../benchmark/experiments/outputs/cvid-all-split-inventory-261014/cross-split-dhash-candidates.csv). Outputs remain local and ignored.
- Source: `benchmark/research-data/iiit-cvid-source/IIIT-CVid.zip`, 2,427,254,987 bytes; SHA-256 `b5b562580e250ee3336462b7699bc79d0d1149d3b8cc82f1b221a0d0ce4fb489`.
- Read `IIIT-CVid/Readme.txt`, all frame PNG/XML pairs, top-level crop label lists and course metadata directly from that archive. Successfully decoded every frame, parsed every XML and hashed every original PNG/XML; ZIP reads enforce member CRC. Crop PNG counts and path coverage were inventoried; all crop pixels were not decoded again in this audit.
- Fresh PNG/XML hashes match the October 10 frame ledger for all 5,475 pairs. Fresh perceptual screening reproduces its 469 candidate pairs / 263 implicated frames.

## Source split inventory

| Native split | Frame PNGs | XMLs | Boxes | Nonblank XML transcriptions | Crop PNGs / crop label rows | Courses | Folder video groups |
|---|---:|---:|---:|---:|---:|---:|---:|
| train | 3,171 | 3,171 | 82,263 | 82,263 | 82,263 / 82,263 | 12 | 395 |
| val | 549 | 549 | 15,379 | 15,379 | 15,379 / 15,379 | 5 | 140 |
| test | 1,755 | 1,755 | 40,103 | 40,103 | 40,103 / 40,103 | 7 | 276 |
| **Total** | **5,475** | **5,475** | **137,745** | **137,745** | **137,745 / 137,745** | **24** | **811** |

Counts are source observations, not sample-size or power guarantees. Folder video groups are release identifiers, not independently verified video URLs. All three splits have paired XMLs, zero orphan XMLs, zero empty frames, zero blank normalized transcriptions and zero unresolved `difficult` flags. Crop indexes have no missing/orphan paths or repeated paths after separator normalization.

`frames-train-img.txt` and `frames-test-img.txt` enumerate their XML members exactly, with zero missing/extra/duplicate rows. Despite its README mentioning a val frame list, the ZIP contains no `frames-val-img.txt`; the val inventory therefore comes from sorted PNG/XML pairs.

### Paper versus archive

The [original author paper, Table II](https://cdn.iiit.ac.in/cdn/cvit.iiit.ac.in/images/ConferencePapers/2018/localizing-recognizing-text.pdf) reports train 3,170, val 549, test 1,755 and total 5,474 frames. This hash-pinned ZIP and its own train index both contain **3,171 train frames**, giving 5,475 total. Word totals agree with the paper. Record this one-frame release/paper discrepancy; the evidence does not identify an authoritative frame to discard.

The paper describes word boxes and word transcriptions, seeded by TextSpotter and manually annotated in LabelImg, with all course frames assigned to a single partition. Older local descriptions calling every object a text line should not override these source semantics. The authors exclude equations and symbols from annotation; this endpoint measures agreement with released word labels, not exhaustive mathematical OCR. Counts and provenance documentation do not verify every transcription's semantic correctness.

## Geometry qualification under the existing validation policy

| Native split | KEEP | Metadata-only repair eligible | Whole-frame HOLD | Invalid boxes | XML-size mismatches (all frames) | Mechanically eligible frames | Objects on eligible frames |
|---|---:|---:|---:|---:|---:|---:|---:|
| train | 3,135 | 20 | 16 | 18 | 23 | 3,155 | 81,606 |
| val | 543 | 3 | 3 | 3 | 3 | 546 | 15,317 |
| test | 1,657 | 97 | 1 | 1 | 98 | 1,754 | 40,063 |
| **Total** | **5,335** | **120** | **20** | **22** | **124** | **5,455** | **136,986** |

Metadata-only repair means using the decoded PNG dimensions in derived records, preserving XML labels and box coordinates. Four size-mismatch frames also have box errors and remain HOLD. No box is clipped, no annotation is inferred and no source XML is changed.

Test HOLD frame: `test/24/25/00_31_56_00006.png`, object index 36, box `[-2, 4, 28, 19]`. This frame contains 40 objects, so holding the entire frame removes 40 objects, not one. Its resolution requires author evidence or explicit independent reannotation; neither happened here.

The earlier September readiness workflow also produced a 546-frame validation count through perceptual screening. That is a different selection rule; the October spotting manifest's 546 comes from three invalid-geometry frame holds. Do not substitute the historical manifest merely because counts coincide.

## Transcription GT: XML and crop indexes differ

For frame spotting, ground truth is the transcription in each XML `<object><name>` attached to its own box. Crop recognition uses top-level `train.txt`, `val.txt` and `test.txt` path-label records. Those are not byte-equivalent label sources.

| Split | Video groups whose normalized label multiset differs | Unmatched XML label observations versus crop index |
|---|---:|---:|
| train | 62 | 158 |
| val | 3 | 6 |
| test | 41 | 74 |

All observed group-level differences disappear when `/` in XML labels is hypothetically replaced by `-`, e.g. `m/c` versus `m-c`. This is a diagnostic comparison only. Counts are unmatched observations in group-level multisets, not a proven per-box crop alignment. The audit **does not** apply this rewrite to GT or normalization.

Use unchanged XML transcription for spotting, as already fixed by the validation protocol. The prior crop-recognition metrics retain their original crop-index references. A recognition-only subanalysis against XML would be a different reference endpoint and must be named accordingly. Lexicon/vocab files are decoding aids, not box-linked GT; no lexicon is admitted by the frozen spotting protocol.

## Split separation and leakage qualification

| Split pair | Shared course IDs | Shared course/video groups | Shared literal declared course URLs | dHash candidate pairs |
|---|---:|---:|---:|---:|
| train / val | 0 | 0 | 0 | 8 |
| train / test | 0 | 0 | 0 | 399 |
| val / test | 0 | 0 | 0 | 62 |

No exact frame-byte or decoded-RGB duplicate groups were found, within or across splits. The perceptual rule is the existing 64-bit grayscale dHash, Hamming distance <=6; it gives 469 cross-split candidate pairs involving 85 train, 7 val and 171 test frames. These are review candidates, not confirmed duplicates or automatic exclusion instructions. Distinct declared course URLs support the released course partition but do not establish underlying video identity, handwriting identity or absence of transformed/reused content.

Exposure evidence:

- [October 10 qualification report](../../benchmark/plans/reports/tedlium-cvid-followup-261010-report.md): all train/val/test PNG/XML pairs decoded and annotations inspected; no model inference ran in that audit.
- September readiness summary `benchmark/experiments/outputs/dataset_readiness_260926/20260926T101747121197Z/bundle/summary.json`: already screened all 1,755 native test frames; its `retained_cross_split_hits=0` belongs to that historical screening protocol, not this new queue's adjudication.
- Historical OCR receipt `benchmark/experiments/outputs/ocr_validation_261009/paired_full.summary.json` explicitly scopes the EasyOCR/PaddleOCR comparison to 15,379 validation word crops. The currently frozen candidate registry also binds validation. These inspected artifacts do not establish an exhaustive history of every prior model run on test.
- EDA exposure alone does not prove performance-based test tuning. Conversely, lack of a test result in these inspected artifacts does not prove test was never used. Qualification must disclose this distinction.

## Which split to use

| Split | Appropriate role | Independence qualification |
|---|---|---|
| train | Training or development; diagnostic data | Not the primary final-test split. If its scores inform choices, it is development data. |
| val | Current 546-frame descriptive spotting comparison; threshold/grouping development | Already exposed and used for crop-recognition comparison; do not present it as independent final evaluation. |
| test | Preferred final comparison on new released courses, with fixed candidate settings | Structurally suitable; 1,754 frames / 40,063 objects mechanically eligible. Conditional on a separately frozen test cohort/protocol and remaining independence gates. Previously integrity-audited, not blind. |

Keep train/val/test separate. Do not increase the final denominator by pooling all splits. Do not use test crop labels, lexicons, examples or model scores to choose weights, thresholds, grouping or preprocessing. Lock candidate identity first, complete score-independent test qualification, then run paired inference and report end-to-end Hmean plus detection P/R/F1, with dependence-aware reporting by source group/course.

## Next gate and unresolved questions

The next gate for independent spotting is **test qualification and protocol freeze**, not an immediate 5,475-frame pooled run:

1. Adjudicate cross-split content/source candidates, prioritizing the 62 val/test pairs; do not discard them based only on dHash. If train informs model choices, also resolve train/test candidates.
2. Verify source-video mapping as far as recoverable and document residual uncertainty; course metadata URLs alone are not per-video identity proof.
3. Audit the scope of historical test model use and retain the previously observed-test disclosure. Preserve unknown model-pretraining overlap as a limitation.
4. Predeclare the negative-coordinate test-frame HOLD, 97 metadata-only overrides, XML transcription source, matching/normalization/failure rules and candidate bindings in a new test manifest. Do not mutate the existing validation freeze.

Open issues: one-frame paper/archive discrepancy; unresolved geometry/source-content candidates; unverified semantic transcription correctness; completeness of historical test inference provenance; unknown model-pretraining overlap. No test cohort has been frozen or inference launched by this audit.
