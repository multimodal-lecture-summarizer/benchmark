# Continue MLPDataset preview with preserved cache

Status: implementation, independent review and local regression verification complete. Real Colab throughput pending.

## Change and evidence

User log:1172 cache hits,138 new frames,1602 requests left pending under30minutes. No crash shown. Current notebook scanned the entire analysis/log trees at process preflight, polling and postflight for every frame. A real FFmpeg fixture reproduced8 recursive scans for one frame; the new regression failed on that baseline and passes with exactly1 scan after optimization.

Default preview budget increases30→120minutes. `DOWNLOAD_MEDIA=False` makes the notebook continue from existing video/cache checkpoints instead of reattempting remote source failures; users can explicitly enable it for acquisition. Drive and `RUN_NAME=mlpdataset-eda-261017-v3` are unchanged.

Only the exact existing14-argument single-output FFmpeg command with its temporaryPNG confined to FRAME_DIR and log confined to LOG_DIR uses the new resource guard. Before each process, take one full analysis-byte snapshot. Subtract old tracked file sizes, then add current temporary-image/log sizes during polling and post-exit validation. Actual free disk floor remains checked. A fresh snapshot for every next frame incorporates checkpoint/grid/other output changes between processes. All other command forms retain existing full scans; process signatures and result schemas unchanged. The initial scan remains inside the process timeout; a scan consuming the budget prevents process launch.

Assumption: one writer notebook perRUN_NAME during FFmpeg execution. No media/frame deletion, cache-key changes, timestamp edits, render changes, fairness changes or acquisition policy edits. Cell27 preview source and cell23 acquisition source remain identical. Only execution budget changes the preview run binding; stable frame keys still accept validated prior cache.

## Verification

- Final speed/quota suite8/8 PASS6.694seconds. Covers one scan per frame, real output quota overflow, preflight limits, log growth/truncation, nested roots, previous temporary files, fresh snapshots, low-free floor, unknown-command fallback, slow snapshot timeout and unchanged cache contracts/defaults. The eighth test executes actual acquisition with DOWNLOAD_MEDIA=False, preserves failed checkpoint bytes and then reuses existing preview frames without launching any process.
- Independent reviewer reran7/7 PASS3.117seconds; no blocker found.
- Preview resume8/8 PASS31.105seconds, including cached reruns, changed budgets, interrupted checkpoints, source/path/hash validation, migration and scheduling.
- Existing stage-budget checks passed with real FFmpeg/process/resource guards.
- Sequential HTTP403 recovery rerun13/13 PASS9.717seconds. Full333-state/9021-mark receipt replay passed with unchanged histories, strict JSON and every emitted artifact hash.
- Final schema/AST check passed:33cells,20code cells, clean outputs.17 other code-cell sources, including acquisition, preview loop, full coverage and setup, are unchanged from the input backup. Shared helper definitions for media/frame identity and cache are unchanged. Tested mirror matches the notebook. Final notebookSHA256: `5c7c9a178362a8ee96c904a06370050ac9ef20609e2e8800890cb6cd3ed862b3`.

Initial new preflight fixture had an empty analysis tree and incorrectly expected a1-byte cap to be exceeded before any file existed. Added an existing analysis file to exercise the intended condition; no production workaround. A parallel HTTP403 regression run encountered transient Windows state.tmp rename permission denial; the sequential rerun passed as recorded above. Direct invocation of the new test file cannot import package tmp: use `python -X utf8 -m tmp.validate_mlpdataset_preview_speed`.

## Colab continuation

Upload the revised notebook, keep the same Drive/RUN_NAME and use CPU Run all. DOWNLOAD_MEDIA=False skips remote retry work but still validates completed source caches. Existing valid frames are reused; only missing/invalid requested frames are decoded. Default120minutes bounds extraction after cache validation; cache validation, output rendering and final receipt hashing are additional wall time. Source/annotation counts remain333/9021. A fixed large speedup is not established by the8→1scan-count fixture.

Unresolved: measured Colab/Drive throughput improvement; source-read versus filesystem-scan contribution; actual remaining preview work after the next run.
