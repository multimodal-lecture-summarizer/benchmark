# Colab T4 spotting review

Scope: new `benchmark/experiments/scripts/*spotting_colab*.py`, candidate registry, generated notebook, bundle and focused tests. Reviewed against `plans/261015-cvid-spotting-colab-t4/plan.md`; existing CPU scorer/freeze bindings are preserved by hard-coded SHA verification. Review only; no code edits.

## Assessment

No confirmed critical defect remains in the reviewed source after the fixes below. This is preparation qualified by local contract checks, not proof of successful Colab installation, T4 inference or TESTR verification.

## Findings repaired during review

- TESTR lacked explicit conditional eligibility and blocked the five-primary workflow. Registry and CLI now distinguish conditional exclusion from required-candidate failure.
- Display code initially offered figures without generating them. Analysis now creates comparison/failure, sensitivity and course figures.
- Analysis initially lacked independent registry, prepared-artifact and runtime-payload seal checks. These checks now reject stale receipt chains.
- Ephemeral Colab wheels would have forced fresh dependency resolution on resume. Notebook now configures a per-run Drive cache; candidate/scoring environments retain exact wheels and reconstruct offline, comparing installed-file identities.
- Tesseract TSV relied on a configuration file absent from its custom tessdata directory. Adapter now requests `tessedit_create_tsv=1` explicitly.
- Native CUDA dependencies were not identified beyond version strings. Runtime now hashes mapped Linux shared objects after train preflight and repeats train warmup before test admission. Legacy Paddle declares CUDA 11 runtime packages and uses candidate library search paths.

## Verification

- Fresh combined candidate/notebook/state suite: **19 tests passed**, including immutable resume, altered/foreign checkpoint rejection, train-only/nonempty gate, successful gate→inference→failure retention→resume, ZIP traversal/membership, notebook nested-code syntax and figures.
- Portable archive verification passed for 181 exact manifest members; generated notebook embedded its ZIP SHA at that check. Source changes after this check require final bundle/notebook regeneration.
- Exception handling retains failed test frames with zero predictions and their GT denominator. Gate failures prevent candidate inference. An exclusive output lock prevents concurrent CLI writers; interrupted locks require inspection.
- Test cohort remains 1,754 frames / 40,063 objects. Matching/normalization use unchanged frozen scorer; sensitivities reuse predictions. No test-score-driven tuning was introduced.

## Remaining verification limits

- Linux CUDA library loading, package resolution, Drive FUSE behavior and offline environment reconstruction were not executed on T4 locally. Actual train preflight must establish eligibility.
- TESTR author checkpoint remains unavailable/unlocked. The six-selection registry must not be described as six runtime-ready or evaluated models. TESTR must remain excluded until exact artifact acquisition, compatible custom-op build and genuine train inference pass.
- No test inference, complete comparison, hardware timing equivalence or production-winner claim follows from these contract tests.

## Recommended final gate

Regenerate and verify the final notebook/bundle pair after the last edits, run the full focused regression set, and report prepared/unexecuted status plus TESTR exclusion. Remote T4 preflight is the next execution gate.

## Unresolved questions

- Do the pinned Paddle CUDA profiles and cached environments load/reconstruct on the actual Colab runtime?
- Can the declared TESTR author checkpoint be recovered and its CUDA 11.3 custom-op environment executed?
