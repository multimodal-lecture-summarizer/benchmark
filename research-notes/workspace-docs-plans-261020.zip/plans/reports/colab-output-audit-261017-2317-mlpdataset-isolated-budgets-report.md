# Executed isolated-budget notebook audit

Saved run receipt:2026-10-17T16:15:31Z (23:15:31 UTC+7). Read-only notebook audit; outputs retained, no code/annotation changes or remote rerun.

## Execution and inventory

All20 code cells executed consecutively1–20 with no saved exception. Full333 videos/9021 unique released marks retained, excluded0. Source group proxies10. Ledger totals match receipt. Metadata/ASR/spoken EDA remains full release coverage; semantic accuracy is not estimated.

## Acquisition

202 downloaded,131 failed,0 unattempted.202 cached IDs/hashes match previous run. All131 missing sources were attempted this run and failed with YouTube bot-confirmation message;13 previous403 failures and1 old disk-budget failure did not recover.117 previously unattempted sources now have actual failed attempts. This does not mean117 cached videos were lost.

No resource-cap stop: media~3.63GiB below8GiB; analysis/log~0.22GiB below1GiB; actual free~190.77GiB. Format diagnostics:51 bot-confirmation failures,1 timeout,281 not attempted after5-minute budget.

## Preview

1794 requests:343 decoded,1423 preview_time_budget not attempted,27 outside_video,1 timeout.343 decoded frames cover116 unique marks in38 videos;113 marks have all3 frames,3 partial. Only116/9021=1.286% marks have visual evidence.1794 requests represent598 generic diagnostic marks, not full semantic annotation inspection. Source groups anat-2 and bio-3 have zero visual coverage despite available downloaded sources. No shared media-cap blockage remains.

Visually inspected5 saved grids (0,20,50,80,115):3 examples show old slide at annotation and changed slide at+0.5s;1 example shows new slide already at annotation;1 example shows same text with layout/motion change, insufficient to certify a new slide. These observations are illustrative, not a semantic verdict on116 marks. Current preview offsets are±0.5s, not±5s. No timestamps repaired.

## Next work

1. Add safe checkpoint reuse and fair source-group scheduling to preview. Current code restarts extraction from first source and overwrites ledger each run, so unchanged Run all can repeat early sources instead of expanding coverage. Preserve source/config/frame hash validation and cumulative statuses.
2. Resolve source acquisition separately from EDA budgets; bot-confirmation errors require a different authorized acquisition context. Repeating current public-no-cookies path alone has no successful recovery evidence. Current automatic retry policy may skip these newly classified bot failures unless explicitly allowed.
3. Expand visual inspection before any timestamp decision. Full release inventory is complete; complete source media/semantic labels are not qualified.

Unresolved:131 unavailable sources,8905 marks without any visual evidence, complete semantic event labels/source timebase/rights qualification. Local saved outputs do not verify Drive artifact bytes against receipt hashes.
