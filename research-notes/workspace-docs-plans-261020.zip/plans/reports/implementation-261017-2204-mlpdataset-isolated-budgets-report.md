# MLPDataset isolated budget fix

Implemented in the standalone Colab notebook. Preserved exact executed input in benchmark/experiments/outputs/mlpdataset_stage_budgets_261017/received-full-run-executed.ipynb before clearing outputs.

- Separate media8GiB and analysis/log1GiB caps; actual free floor1GiB, download analysis reserve0.5GiB. Preflight before spawn, monitored limits and final quota check. Format and preview ignore media cap.
- Data-driven HTTP403 and budget-failure retries enabled. Saved evidence identifies13 HTTP403 and1 legacy disk stop;202 downloaded checkpoints are reused after existing identity/hash/probe validation. No fixed source list.
- Detailed runner/preview reasons, return codes, elapsed times and process-start flags. Current scheduling skips distinct from historical attempt reasons. No empty/stale preview success or blank grids.
- Full333-video/9021-mark inventory retained. Preview budget30minutes; no retired fixed14-mark workflow. Receipt records budgets, storage snapshots and reasons.

Validation: real local FFmpeg preview with media cap exceeded; format independence; media/analysis cap, free floor and reserve; timeout, exit7, spawn error, quick writer postcheck; actual generic preview and stale exclusion. Actual saved-state retry eligibility:13HTTP403+1legacy disk stop. Identity-related function AST unchanged. Full333/9021 coverage conservation and original order passed. Actual receipt cell replay with333 historical states passed strict JSON, preserved histories and every artifact hash. Independent review found no blockers. Evidence under benchmark/experiments/outputs/mlpdataset_stage_budgets_261017 and mlpdataset_full_inventory_261017/local-validation.

Open work: run revised notebook on Colab with matching Drive/RUN_NAME; live acquisition availability and visual/semantic transition qualification remain unverified. No annotation timestamp changed.
