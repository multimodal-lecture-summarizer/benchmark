# MLPDataset: HTTP403 recovery implementation

Status: locally verified; remote Colab execution pending. Date: 2026-10-18.

## Evidence and change

The stopped run's pasted log contains86 completed retry states:81 downloaded and5 failed during data transfer with HTTP403. Retry87 had started. These are partial results; the final current failure pool must come from Drive checkpoints, not an assumed fixed5 or119.

The notebook now retries recognized transfer403/no-format failures through primary selection, default-client HLS, then Safari HLS. A maximum of3 commands share the configured120-second source window, including checked pauses, probe and hashing. Resource/global limits remain active. Authentication, rate limits, unavailable sources, timeouts and invalid/missing media stop recovery. Final filesystem/checkpoint I/O may extend elapsed wall time beyond the checked deadline.

Alternate profiles use separate partial-file directories and format-specific names. Existing media and partials remain intact; all profile files count toward source quota. Success requires a completed file, readable positive duration and SHA256. Attempts record actual profile, selector/client arguments and successful nested file path. The baseline cache identity remains unchanged.

Running/interrupted states join the dynamic retry pool. Every command is checkpointed; an interrupted command or validation is recorded. Source counts and command counts are separate: one recovered source can require two or three processes. Structured runner errors now populate before display. Source/profile pauses default7seconds; request sleep0.75seconds. Fresh format diagnostics default off, while saved history remains visible.

Setup pins reproduce all86 observed identities: yt-dlp2026.8.19, EJS0.8.0 and Deno2.9.6. Removed blind upgrade behavior. Full333-video/9021-mark inventory, cache identity helpers and existing preview/coverage code remain unchanged. No annotation timestamp edits.

## Research and review

The [research report](research-261018-1335-mlpdataset-http403-recovery-report.md) compares official guidance with the pinned release. The [pinned client source](https://raw.githubusercontent.com/yt-dlp/yt-dlp/2026.08.19/yt_dlp/extractor/youtube/_base.py) warns about android_vr403 behavior, so it was excluded. Public HLS remains an experimental recovery route, not an established remedy for these five sources. No cookies, proxy or token-provider installation.

Independent review found a real deadline gap: slow quota scans/checkpoint writes could consume the remaining source budget before process launch. Remaining time is now recalculated immediately before launch; the runner also refuses to spawn after its own preflight deadline. Regression tests reproduce both paths. Final independent setup review found no blocker.

## Verification

- Focused recovery:12/12 tests passed in7.610seconds, including saved86 states, real local child-process failures,403→HLS, Safari fallback, authentication/resource/timeout stops, corrupt/missing media, interruption/history, nested FFmpeg preview, slow-Drive deadlines and installer pins.
- Actual acquisition cell replay: one source/two commands produces correct recovery/process/source counts and profile evidence; rerun reuses validated media without another download process.
- Representative retry:5tests passed; all-failed retry:6tests passed; preview/cache resume:8tests passed.
- Stage resource/budget checks passed. Full333/9021 inventory and actual333-state receipt replay passed, including strict JSON, preserved histories and artifact hashes.
- Notebook schema/AST:33cells,20code cells, clean outputs. Protected cache/helper definitions and preview/coverage sources match the input backup. Embedded helper/acquisition sources match tested mirrors.

Controlled local transport fixtures establish orchestration behavior. No live YouTube request, pip/npm installation or Colab package resolution was executed locally. New remote recovery results cannot be claimed yet.

## Run on Colab

Upload the revised standalone notebook. Keep the same Drive and `RUN_NAME`, use CPU, then Run all. Completed valid media/cache are reused; the current failed/interrupted pool is read from checkpoints. Review profile attempts, recovered/failed source counts and the final receipt directly in output. See [Colab guide](../../docs/mlpdataset-colab-guide.md).

Unresolved: actual server-side403 cause; public HLS availability; final Drive counts after interruption; actual Colab package resolution and recovery outcome.
