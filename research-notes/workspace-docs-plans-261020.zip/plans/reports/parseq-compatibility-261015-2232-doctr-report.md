# docTR PARSeq legacy checkpoint compatibility

User worker traceback establishes load_state_dict(strict=True) failure on four decoder attention normalization keys. R2 status reports five other pipeline train gates passed and zero committed test frames. Full receipts for those five were not supplied for independent audit.

Root cause: runner used raw model.load_state_dict rather than docTR0.12's PARSeq backward-compatibility policy. Official python_doctr0.12.0 wheel SHA25640a72665e15f766be628ef11ee40cc1ce8bc700a076e5f481f7c34c8da4dd99a downloaded/read without installation or model execution. PARSeq.from_pretrained explicitly removes exactly these four unused pre0.11.1 parameters; see [upstream1911](https://github.com/mindee/doctr/issues/1911). Official utility filters this allowlist then rejects all other key mismatches. The adapter correction is stricter: shallow-copy state preserving metadata/tensors, remove only this exact unused allowlist, load all remaining current-model parameters with strict=True. Used legacy layers, unknown keys, missing/current shape mismatches still fail.

No frozen checkpoint rewrite, weights/config/package/cohort/protocol/threshold/grouping/scorer change. Runtime records exact removed keys and policy. In-memory compatibility matches official semantics; actual docTR T4 load/forward still requires user-run train preflight.

Delivery: current canonical notebook/bundle updated; new OUT cvid-spotting-t4-261015-v2-r3. Existing r2 runtime cache reused for exact sealed wheel/weight acquisition without importing old preflight/test receipts. docTR runs first in preflight; failure exposes its worker traceback automatically and blocks subsequent test. All six require fresh r3 gates because bundle/source identity changed; r2 output preserved.

Local validation:39 regression/contract tests passed. AST check confirms exact allowlist equals official wheel source. Seven FROZEN identities and six-candidate registry match prior qualification; notebook/bundle/r3/cache binding verified, ten code cells remain unexecuted. No Linux model installation or T4 inference by agent.

Notebook SHA256:134753d09db7282c1ba42235d1db6f8b0c7aa8d4fa34d6ffd45e099ae02bd267.
Bundle SHA256:6c29be45a71891a67f2b2d44e1c275f64daa2b87209984b12937e3c34bb43f0d.

Unresolved: actual strict PARSeq load, nine train forwards and all-six comparison admission on r3, then full test/analysis. User should download current pair, replace Drive bundle, keep OUT/cache defaults and run notebook sequentially; do not alter or delete r2 receipts.
