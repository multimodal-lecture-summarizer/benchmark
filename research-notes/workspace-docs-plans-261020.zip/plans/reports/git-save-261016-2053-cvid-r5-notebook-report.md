# CVID R5 Git save

Status: completed locally; no push.

Executed notebook: benchmark/experiments/notebooks/results/iiit-cvid-spotting-colab-t4-v2-r5-executed.ipynb

SHA256: 1d9324b39dda7fc5b28d0d179bd3533b1bcfa12394c2a3126d1a0b6c65bd47a7

Saved 66 scoped files and narrowly scoped .gitattributes. Preserved original executed outputs, clean Colab template, locked runtime/protocol registries, compact results, six figures, receipts and benchmark documentation. Literal -text rules preserve frozen artifact bytes across platforms.

Commits:

- `c4db5782f7e3a0f33ad379ad8cca5a6e9ddcdc1c fix(research): retain frozen artifact bytes across platforms`
- `779e302f06f302924e5d6c9267824451f7640390 fix(research): preserve executed notebook evidence bytes`
- `c9ebc1306d8f134999fda8217efc768925d725d7 feat(research): archive audited CVID R5 notebook and results`
- `3248e535ab8aa90fd8feec894c58006d83884c07 feat(spotting): preserve locked Colab T4 runtime and admission checks`

Verification: all scoped files tracked; artifact inventory matches HEAD bytes; template hash verified; index empty. Seven focused notebook tests and scoped secret scan passed before commits. No inference/scoring rerun.

Full evidence ZIP, data, weights, caches and full prediction exports remain outside Git. Unrelated historical untracked work retained.

Unresolved questions: none for this local save.
