# R4 evidence audit and R5 runtime warm-up correction

2026-10-16, Asia/Bangkok. Model execution remains user-operated Colab only.

## Evidence audited

Source: C:/Users/hung/Downloads/cvid-spotting-t4-261015-v2-r4-evidence.zip
SHA256:239bf4c4caf6c2a3064577310597bb7bcdc0a0b06d7eb243cf5aba15b1c54fec
7,973,026bytes,1,795 unique members, CRC passed. Exact manifest membership, all file bytes/hashes verified. Prepared-data frames match frozen cohort1,754/40,063 and all7 scientific hashes. Bundle-manifest binding matches delivered R4 sources; six candidate configs/prepared/runtime gate digests and train-only admission verified.

All six train preflights passed. EasyOCR gate/run/completion bindings agree; all1,754 checkpoints validate payload/image hashes and exact aggregate,1,754 status=ok, no recorded frame errors. Accuracy not scored here. Paddle legacy, Tesseract and docTR aborted at binding comparison before test. PP-OCRv6/PGNet have no inference attempts in ZIP. R4 run log ends without normal phase completion; stale execution lock and no process were reported by user. No evidence establishes why original orchestrator stopped. Second run was blocked by that lock.

## Confirmed source issue and limits

Preflight called predictor, record validation, Image.open, prediction_polygon; inference warm-up called predictor only. Lazy library work could therefore differ before native_libraries seal. This asymmetry is confirmed; R4 actual mismatch runtime was never persisted, so exact differing fields remain unknown. No claim of CUDA/OOM failure or proven absence of environment drift.

## Correction

Shared observe_train runs the original preflight sequence in both phases using only sealed train IDs/pixels. Full native path/byte hashes, configuration, prepared and data/bundle binding equality retained. Invalid predictions follow the same frozen geometry policy; no accuracy selection, weights change or test tuning.

Mismatch persists immutable unique diagnostic JSON with expected/actual binding/runtime, recursive field differences and no-test-started marker, then rejects admission. Notebook displays full differences; final export includes snapshots. Added verify command replays train in a fresh isolated process without test pixels and seals train-replay.json. All6 replay receipts must bind current preflight/runtime before notebook test; actual infer rechecks its own runtime independently.

R5 uses fresh output identity, CACHE_ID r2. R4 output/lock/EasyOCR records untouched. No cross-bundle record import. R5 full comparison needs fresh gates and tests, including EasyOCR; R4 completed evidence remains separately auditable. Models already present in WORK can reuse checked bytes; runtime cache covers wheels/seals, not guaranteed persistent model files.

## Local validation

51 focused unit tests passed, including identical decoding/geometry before snapshot, library drift rejection, mismatch snapshots before test access, train-only verify receipts and notebook admission wiring. No package installs, model inference or Colab execution performed.11 code cells plus embedded source parse; rebuilt193-file bundle, CRC/membership/byte hashes and7 frozen hashes checked. Delivery hashes recorded in readiness receipt and notebook manifest.

## Unresolved

Actual R5 T4 preflight/replay/full test pending. Exact R4 runtime field mismatch cannot be recovered from supplied ZIP; R5 diagnostics will capture any repeat. R4 initial orchestrator termination reason unknown. No full comparison scores or selection established.
