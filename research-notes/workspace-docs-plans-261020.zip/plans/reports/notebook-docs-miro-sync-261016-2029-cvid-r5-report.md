# R5 saved notebook, documentation and Miro synchronization

2026-10-16 Asia/Bangkok. User requested direct update of Downloads/iiit_cvid_spotting_colab_t4_v2.ipynb, progress documents, then Miro. No model/Colab inference, new evaluation, Git commit or dataset/scorer/config changes.

## Notebook

Original downloaded notebook SHA256:36b2caea65ae959be78df3c6ea92696a79f1eb106123641a96646d59f4293285
Reviewed SHA256:1d9324b39dda7fc5b28d0d179bd3533b1bcfa12394c2a3126d1a0b6c65bd47a7
Original archived under benchmark/experiments/outputs/cvid-r5-final-audit-261016/notebook/iiit_cvid_spotting_colab_t4_v2.original.ipynb. Reviewed archive and user Downloads file are byte-identical. Updated summary/results/limits and annotated2 historical failed cells. Preserved every original code cell, execution count and output exactly. Existing6embeddedPNG hashes match final visualization receipt; all12primary Hmean values match savedHTML; final export output matches evidence SHA358a51fa96576cbb77820bcbe2177f1b7658556f0e7af1a0355a9276d7b38151. Includes9GT/6candidate any-frame review. This is resumed/recovered execution provenance, not an error-free sequential fresh-kernel claim.

Clean runner template updated only presentation summary and MPLBACKEND=Agg on render subprocess before import. Its current SHA:9f7198dd20dd8ab0a6a344322136536e0aabbe08d4548434d1494eafbb7d61f1. Original executed-template SHA11c15fea6025af2fe751aac9dbc5f652475f6bda6a7e7ac7c39c9dac8fde5090 retained as bound_execution_template_sha256. Existing bundle SHA40291c603b60eb564a66a182d12ae50cf4b19579954fac5c69c22d87c8ae57df unchanged. No bundle regeneration/source mutation.

## Documents

Updated benchmark README, docs index/BENCHMARK/DATASET_EDA, master plan, notebook manifest/readiness, root run guide and final audit report. Consolidated stale spotting pending claims into complete audited6candidate status; preserved no_selection and crop-recognition endpoint. Corrected crop recognition audit scope from its existing13/10 report: integrity/saved-score audit passed, actual model binaries and full fresh-kernel replay unverified. Next gate is independent slide-transition→keyframe media/timebase/GT/cohort/protocol readiness, not an automatic new benchmark.

## Miro

Board uXjVHLTov6k=: existing spotting detail3458764686684583588, dataset3458764686983654054, overview3458764686684081699 and index3458764686683741481 updated from fresh reads. Existing tables updated in place with stable row/field IDs; candidate table now6systems, results table11rows. Metrics, macro/course/grouping sensitivity, runtime/preflight/replay/recovery/export proofs and claim limits reconciled. Crop recognition scores/frame unchanged; only obsolete spotting cross-reference in its dataset table updated. No delete/new duplicate section.

Table/rendered bounds checked: left dataset table x27460y4350w1241h862; candidate x29060y4350w1016h676; results x27460y5620w2922h1784. Minimum horizontal gap to right text798; results bottom7404 inside spotting frame bottom7570 with166margin. Dataset table ends7817 inside enlarged frame7985 with168margin. Crop source table updatedcrossref ends417, safely before its separate result table819.

An initial sparse empty-table scale update was rejected by automatic approval review as potential content overwrite. No changes applied by that call; retried safely with all11current rows/headers retained and only scale changed. Approved update/readback preserves every row; no deletion. Native board edits otherwise succeeded with no failed items.

## Validation

7 focused notebook tests passed; AST parses all clean and reviewed code cells; original code/output equality passes; original/reviewed backups and Downloads SHA verified. Current template/bundle/manifest/readiness hashes consistent. All scoped relative doc links and whitespace checked. Standard docs validator unavailable in configured locations; focused checks used. Fresh Miro readback confirms6candidates/11resultsrows, finalmetrics/no_selection and layout spacing; crop metrics preserved. Source/data/evidence scientific bindings unchanged.

Unresolved: original0byte checkpoint root cause remains unknown; no independent new model run or fresh-kernel replay performed. No production winner or new task benchmark authorized by this update.
