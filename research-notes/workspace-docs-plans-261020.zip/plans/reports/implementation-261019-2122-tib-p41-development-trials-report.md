# P4.1 — controlled generation development package

**Đã triển khai instrumentation, diagnostic và notebook/ZIP; chưa chạy các trial mới trên T4.** User GO trong attachment21:22 được áp dụng cho development. P4.2–P4.6 vẫn phụ thuộc actual trial/scorer/resume/pilot/budget evidence; không selection300/final523 mới.

## Artifacts để người dùng chạy

- [Notebook P4.1](../../benchmark/experiments/notebooks/tib-p41-development-colab-261019.ipynb):6 code cells, không outputs/execution counts.
- [Private source-only ZIP](../../benchmark/research-data/tib-p41-261019-2122/tib-p41-development-261019.zip).
- [Trial registry](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/development-trials-261019-2122/development_trials.json), [package receipt](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/development-trials-261019-2122/package_receipt.json), [baseline freeze](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/development-trials-261019-2122/baseline_freeze.json).
- [P4.1 execution amendment](../261019-0035-summarization-model-benchmark/phase-04a-generation-development-trials.md).

Upload ZIP vào private `MyDrive/TIB_P41_DEVELOPMENT_261019/`, mở notebook trên T4 và chạy tuần tự. Checkpoints/logs ở thư mục đó, tách baseline `TIB_P4_FEASIBILITY_261019`. Nên bắt đầu runtime T4 mới; guard11.5h gồm setup, không reset timer để vượt guard. Cell cuối gom code, source-only inputs, registry, receipts, attempts, logs và outputs thành evidence ZIP để tải về. Model weights tải đúng pinned revisions, không nằm trong ZIP. Không cần upload lại baseline ZIP.

ZIP SHA256 `51593e37d868ba05d5fb1c2dfb2ef8eaa95467ca8b6ff1ddeac56b7dd3efefa8`; notebook SHA256 `2a437a6f2886b73b7d74c543dfc8f9237060ef6710fd3c5753aeabcfe7ffd6b4`. Raw sources/weights/ZIP giữ local/private, ZIP được Git ignore.

## Trial matrix đã định trước

| Trial | Thay đổi | Default |
|---|---|---|
| bart-control | Giữ model/decode/reserves, thêm fresh telemetry control | Có |
| led-ngram0 | Explicit baseline no_repeat_ngram_size0, beam4 | Có |
| led-ngram3 | no_repeat_ngram_size3, các setting khác giữ nguyên | Có |
| led-ngram4 | no_repeat_ngram_size4, các setting khác giữ nguyên | Có |
| qwen-r256 | Baseline prompt/reserve256 với seed policy mới | Có |
| qwen-r384 | Map/reduce reserve384, recompute windows | Có |
| qwen-concise-r256 | Prompt intermediate gọn hơn, reserve256 | Có |
| qwen-r512 | Map/reduce reserve512, recompute windows | **Deferred** |

Default7profiles×3sources=21neural outputs; tối đa8profiles×3=24 nếu trial512 được mở riêng. Đây là ba IDs `valid:644/341/886` đã có trong pilot40, không thêm bản ghi hoặc trial repetitions. LED giữ beam4; Qwen final reserve768/context4096; mọi pipeline dùng cap350maximum. P1–P3,40/300/523 và diagnostics40 trong final không đổi.

Trial512 yêu cầu explicit resource-review flag, receipt `qwen-r384` actualT4 completed3/3 đúng candidate/profile/registry/source hashes và ít nhất1GiB **measured** total-minus-reserved headroom. Guard này là điều kiện vận hành, không bảo đảm trial512 fit. Không tự bật512 hoặc thử thêm config khi xem output. Registry/model/profile/bundle/runtime hashes đi vào checkpoint identity; trial store namespaces độc lập.

Qwen đổi reserve làm đổi input window cùng lúc: diễn giải là so sánh toàn pipeline config, không isolated causal effect của reserve. New node seed1729 phụ thuộc source/stage/layer/node, không phụ thuộc trial/profile; windows có thể khác nên không coi là matched-content random experiment. Old baseline dùng mapping khác và giữ nguyên: archive-vs-new không là RNG replication có kiểm soát.

## Runtime và acceptance policy

- Per node ghi base generation config, explicit overrides, merged effective config và max_new_tokens theo stage. `generate` internal adjustments (derived max_length/special-token fallbacks) chưa được quan sát; provenance ghi rõ. Production development runner yêu cầu complete base config và known EOS IDs.
- Phân biệt terminal `eos_observed`, `output_reserve_reached`, `token_budget_exhausted` (chạm reserve **và** không terminal EOS), `terminal_eos_is_forced_candidate`. EOS đúng tại reserve không tự là natural completion; `natural_completion_verified=false`.
- Fixed diagnostic rules version `p41-generation-diagnostics-v1`: Unicode-word regex/casefold4grams, flag khi một4gram xuất hiện≥3; sentence-ending flag nếu sau bỏ closing quote/bracket, ký tự cuối không thuộc `.!?…`. Đây là heuristic, có false positives/negatives, không factuality/completeness proof.
- Technical policy `observe_continue_with_flags`: giữ intermediate output bounded và downstream calls, lưu flags, không hidden retries/filtering/exclusion. Empty/context/backend failures giữ trong attempted denominator. **Formal acceptance policy chưa frozen, selection chưa được mở.** Không thay cách xử lý sau selection/test scores.
- Reused node ghi nguyên backend telemetry/original wall cost, new-attempt time0. Backend failure/deadline/empty output ghi measured spent time vào cả saved attempt và record events. Pre-call deadline ghi0/no generation. Failed call không kế thừa telemetry node thành công trước.
- Runtime identity bind actual package/inference dependencies, CUDA/dtype/device capacity/backend/device map/tokenizer class và model asset hashes. Không reuse outputs giữa môi trường inference khác chỉ vì GPU cùng tên.

## BART diagnostic và native planning

[BART diagnostic](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/bart_reduction_diagnostic_v1.json) chạy offline trên stored outputs, không model/scorer. Cả3 ordered graphs và full token lineage PASS. `valid:886`:26map→3reducers→1reducer→final; exact clone truyền qua `reduce:1:0`, `reduce:2:0` và singleton final, cuối cùng bằng `map:0:0`.

Diagnostic giữ ordered child identities khi hashes trùng, báo exact clones, per-child lexical overlaps và compression ratios. Không kết luận lỗi code hoặc semantic retention từ lexical overlap. `semantic_coverage_review=pending`; native edge hashes kiểm consistency, module này không tự re-tokenize chúng. Unsupported split topology được báo unresolved; integrity violations không bị che.

[Native plans](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/development-trials-261019-2122/native_window_plans.json):24 tokenizer-only plans của8profiles×3sources, full-source coverage PASS. Qwen wrapped/padded input+stage reserve≤4096. Không tăng output reserve mà giữ input3840. Reduce call counts vẫn unknown trước generation, không dùng planning như measured T4 memory/latency.

## Verification và limits

**129 P4 unit/regression tests PASS** trên final code,39,84s. Full focused set gồm các test_tib_benchmark modules; không phải full application/repository test suite. Package readback PASS:6 unexecuted cells,24 pinned-tokenizer plans, isolated ZIP imports, current module hashes và baseline unchanged.

Local fixtures/regressions kiểm EOS-at-cap vs exhaustion/possibleforcedEOS, effective overrides, repetition heuristics, successful→failed telemetry, failed cost accounting, reuse identity/time, deferred512 bindings, native window repartitioning và ordered diagnostic graph. Package kiểm CRC/memberSHA/current source hashes, isolated ZIP imports, source fields không reference,6 cells syntax/schema/unexecuted và immutable baseline hashes. Không load model weights hoặc chạy neural inference/scorer trong vòng này.

Independent review đã phát hiện và xử lý3 vấn đề trước đóng gói: runtime identity thiếu fields, failed-node costs thiếu trong record events, deferred512 receipt binding thiếu. Final review không còn blocker trước build. Builder là exclusive-create; nếu fail giữa chừng phải inspect partial output dirs, không xóa/rerun mù.

Baseline raw archive SHA `46ad3fb937f7089839865e7a35ff14a63e90f9f0b15490c156d715c7265e7abb`, v2/v3 ZIPs, proposed registry, original receipts và source-only IDs đã verify unchanged. CPU scorer fixture-ready receipt vẫn có hiệu lực trong scope cũ; chưa có formal-runtime scorer-ready/throughput mới.

## Còn mở

Actual7trial outputs/T4 memory/latency; LED anti-repeat có hiệu quả hay không; Qwen reserve/prompt có giảm truncation và bảo toàn ý hay không; manual semantic coverage review; formal intermediate policy/profile/cap freeze; formal-runtime scorer/cost; cross-session resume; fullpilot40 với measurement support; numeric full-study quotas/projection trước selection300. Không winner hoặc cải thiện chất lượng nào được xác nhận từ local fixtures.
