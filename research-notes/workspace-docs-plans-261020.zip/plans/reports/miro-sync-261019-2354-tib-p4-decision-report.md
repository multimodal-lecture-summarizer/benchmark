# Miro sync — TIB P4 evidence và decision2341

Đã cập nhật board hiện có [Đề tài TTTN & DATN](https://miro.com/app/board/uXjVHLTov6k=/), không tạo board khác, không xóa widgets hoặc thay quyền truy cập.

- Khung [RQ2 chi tiết](https://miro.com/app/board/uXjVHLTov6k=/?moveToWidget=3458764686684583693): thêm19/10 evidence dưới phần cũ; frame height3500 giữ nguyên images/TIB120 lịch sử.
- Thẻ RQ2, subtitle và footer trong [Tổng quan nghiên cứu](https://miro.com/app/board/uXjVHLTov6k=/?moveToWidget=3458764686684081699) phản ánh current model-benchmark status.
- Nội dung:9.103raw/4.213train/464valid/523eligible-test;40pilot/300selection seal;21outputs/123nodes trên actualT4 đã audit; limitations LED/Qwen/BART; đóng decode search; ưu tiênBARTcontrol/LED3/Qwen384; acceptance warning retained;350wordmaximum;scorer/recovery/pilot/budget gatesHOLD.
- TIB120/semanticv2 và CVID evidence giữ riêng; không quality winner/new selection/final claim.
- Write1:3created/3updated/0deleted; write2 layout-only3updated. No failed items. Final readback content/positions confirmed; title-to-body gap52px, prior-image-to-new-title gap255px, body inside frame with428px bottom margin; overview footer spacing76px.
- Board preview published, preview_available=true. Scorer-only implementation is the next step after authorized local commits; no formal-runtimePASS claimed.

Còn mở: actual formal-runtime scorer execution, fresh-session recovery, fullpilot40, final admission/quotas/projection.
