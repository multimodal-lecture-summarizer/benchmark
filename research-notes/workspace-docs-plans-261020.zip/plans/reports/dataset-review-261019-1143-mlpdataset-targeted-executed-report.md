# Kiểm tra lượt chạy targeted review MLPDataset

Ngày 2026-10-19. Kiểm tra file thực tế `benchmark/experiments/notebooks/diagnostics/mlpdataset_targeted_review_colab.ipynb` (tên hiện tại dùng dấu gạch dưới), SHA256 `37ed288b6e69ef3ccc58930670c3a502366a31a9701855b97123d9da3da92f08`. Notebook khoảng66.47MB; không sửa notebook hoặc annotation.

## Kết quả thực thi

- 11/11 code cells đã chạy theo thứ tự1–11; không có exception Python được lưu.
- 48/48 yêu cầu mới từ16video đạt `ready`; 1.771frame và48clip được nhúng trực tiếp. Không lỗi trích xuất hoặc hiển thị, không còn yêu cầu trích mới pending.
- Ledger đủ82khóa duy nhất:48ready +14historical_coarse_review_available +20source_edge_policy_hold.20HOLD là chính sách/qualification biên nguồn, không phải20lần tải hoặc trích thất bại.
- Có144processlaunches,0failures;48context được tạo mới,0reviewcachehits. Source hashing16lần, source-cache reuse32lần. Cache gốc vẫn là đầu vào; không có tác vụ download.
- Staging sử dụngRAM, peak426.83MiB,16copies/32hits/0fallbacks; thời giancopy3.74giây. Bộ đếm deadline60phút còn3347.82giây tại receipt cuối: khoảng252.18giây từ khởi tạo runner đến receipt, gồm cả hiển thị/ghi kết quả; không phải timing riêng củaFFmpeg hay toàn bộ mount/setup.

## Kiểm chứng bằng chứng

Hash queue, protocol và notebook EDA gốc khớp các giá trị đã chốt. Mọi binding của48case khớp videoID, originalindex, timestamp, sourceSHA/path/duration trongqueue. Trích48MP4 từ HTML và kiểm lạiSHA256:48/48khớp receipt. Đối chiếu toàn bộ1.771frame với integerPTS/timebase, origin và cửa sổ hiệu dụng:khớp. PNG gốc ởDrive chưa được rehash tại máy này; JPEG trongoutput là bản trình bày. Fullsource bytes không được tải/re-hash lại ởlocal; savedrunner ghi nhận sourcehash verification.

Hai cửa sổ bị cắt hợp lệ theo biên: `2xr4P0WGKSA:0` bắt đầu ở0thay vì-0.733giây; `9GmySN5P408:24` kết thúc ở885.623643giây thay vì889.656giây. Không coi phần ngoài video là thiếuframe cần retry.

## Nhận xét preview

Đã xem8overview sheets, mỗi sheet6case và8sample/case, để screening đủ48case; xem thêm toàn bộ sampled frames của8case trọng điểm3,8,9,10,14,28,33,47. Đây là đánh giá trực quan chẩn đoán, không phải chứng nhận toàn bộ nativeframes hoặc GT.

**Nhãn lặp cần mapping sự kiện.** Có14nhóm có cùng chuỗiPTS+frameSHA, với15rowbổ sung:48request tương ứng33chuỗi frame khác nhau. Điều này không có nghĩa chỉ33sự kiện thật. Các row original cần được giữ để quyết định chúng là nhãn dư hay các sự kiện riêng bị gán cùng timestamp. Ví dụ `E_3gxQWaCoQ:24/25` chứa hai lần đổi: biểu đồ learningrate sang trangtiêuđề rồi sang agenda. `-a5-EHnZ_XA:7` còn thể hiện Diffuse→Focal→Diffuse→BRONJ trong một cửa sổ.

**Sai lệch thời gian không đồng nhất.** `2xr4P0WGKSA:26` released2190.7665s nhưng sampledslidecũ còn ở2191.6800s, slidemới thấy ở2191.9600s. `37z_tJD81y8:68` released3971.7774s nhưng cũ còn ở3974.5333s, mới thấy ở3974.8000s. Cả hai cần kiểm nativeframes; các bracket này là khoảng giữa samplecũ/mới, không phải timestamp sửa hay effectinterval được chứng nhận. Không dịch tất cả timestamp cùng một lượng, không dùng collarphụ để che vấn đề nhãn.

**Các trường hợp không phải replacement nội dung rõ ràng.** `2xr4P0WGKSA:0` giữ titlepage trong cửa sổ dù giảngviên chuyểnđộng. `9GmySN5P408:24` giữ One Optimal Force đến gầnEOF. `lBI8DXevsDk:40/41` là References→presenter→copyright/outro, cần phân loạiauxiliary theo protocol. Không nhận các thay đổi này làm primaryGT chỉ vì hìnhảnh khác nhau.

**Đổi qua lại là sự kiện cần xét riêng.** `KDVP_WAIUXs:5` cho thấy Appliance→Crossbite→Appliance khoảng252.9–254.8s. Không thể suy ra một mốc duy nhất từ ảnhđầu/cuối giống nhau.

## Kết luận và bước tiếp

Phần thu thập preview mới đã hoàn tất: không cần rerun toàn bộ notebook hay tải video. Tối ưuRAMstaging/hiểnthị hoạtđộng trong lượt này; không suy rộng thành cam kết runtime cho các nguồnkhác.

Protocol v1 tiếp tục rules_frozen; GT/cohort vẫn pending, evaluation_ready=false. Có0annotationrepairs và0nativeeventcertifications. Cần dùng bằng chứng đã lưu để lập quyết định sự kiện/mapping cho14nhóm timestamplặp, đánhgiá cácauxiliary/sourceedge và xácminh nativeendpoint quanh những khoảng đổi đã khoanh. Chỉ trích framegốc cục bộ cho các bracket cần xác nhận; không cần lặp lại48cửa sổ. Đánhgiá completeness toànscope, source-dependence/provenance và freezeeligiblecohort vẫn là các gate riêng; preview quanh nhãn không chứng minh không có missedGT.

Bằng chứng local: [audit](../../benchmark/experiments/outputs/mlpdataset_targeted_review_executed_261019/audit-summary.json), [receipt](../../benchmark/experiments/outputs/mlpdataset_targeted_review_executed_261019/review-receipt.json), [8quan sát trọng điểm](../../benchmark/experiments/outputs/mlpdataset_targeted_review_executed_261019/targeted-visual-observations.csv). Các output nằm trong thư mục ignored; không commit dữ liệu lớn.

Còn chưa chốt: event mapping/loại sựkiện và nativeendpoint;20sourceedgeHOLD; các gatecompleteness/grouping/provenance/GT-cohort. Không có câu hỏi làm rõ cần người dùng trả lời để xác nhận kết quả chạy hiện tại.
