# Cache replay correction, 2026-10-15

User evidence: C:/Users/hung/Downloads/orchestrator-reconstruction-diff.json
SHA256: 43b07589a494d792bd858c06c7d39c3627f463c6794b80a81940611c6239d2b9

Observed: Python/interpreter unchanged;19 packages have identical versions, no missing or modified files, and exactly one added dist-info/REQUESTED each. Cached snapshot self-consistency passes. This is direct-request metadata drift caused by installing the entire resolved freeze with -r, not evidence of changed package code.

Correction: verify cached wheel hashes first; reconstruct only the unsealed ephemeral WORK/environments/<candidate>/venv with uv venv --clear; install original declared roots offline with the complete freeze as --constraint. Reject targets outside WORK/environments, sealed targets and symlink venvs. Keep the full snapshot digest comparison, REQUESTED metadata, original seal and wheel hashes. No manual marker deletion, hash bypass, model/config/threshold/grouping/cohort/scorer changes.

Delivery: canonical v2 notebook and ZIP rebuilt, RUN_ID r4, CACHE_ID r2. Persistent cache contains wheels/environment seals; model files are reused only when still present in WORK with matching hash, otherwise reacquired from locked sources.

Validation:43 focused unit tests passed;11 notebook code cells and embedded download script parse, unexecuted outputs. Bundle membership and frozen scientific bindings verified separately. No package installation, model loading/inference or Colab execution performed locally for this correction.

Pending: user runs first3 code cells on Colab T4 to verify exact offline reconstruction; then prepare, docTR-first ALL6 train preflight, full1754-frame comparison and evidence export. Previous qualification remains separate and cannot admit new comparison gates.
