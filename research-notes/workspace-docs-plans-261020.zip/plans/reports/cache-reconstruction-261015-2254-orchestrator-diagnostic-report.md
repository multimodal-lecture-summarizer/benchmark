# Orchestrator offline reconstruction mismatch

User trace reaches exact installed snapshot comparison after offline installation from r2 cache. No model loading or test inference reached. Mismatch alone does not identify corrupted code, package-version differences, interpreter differences or metadata differences.

Code audit found a concrete replay asymmetry: original pip install requests declared root requirements, replay requests entire pip freeze via -r. pip writes REQUESTED markers for direct requests; environment snapshot hashes those marker files. This can produce differing installed digests with identical code/versions. It is a plausible cause, not yet established as the sole cause of this user runtime. No actual expected/actual diff supplied.

Added read-only diagnostic to the notebook's reconstruction exception branch and standalone docs/colab-environment-reconstruction-diagnostic.py. It compares Python/interpreter hash, package versions and missing/added/changed file hashes, verifies cached snapshot self-consistency, prints complete diff and saves orchestrator-reconstruction-diff.json to r3 Drive output. No install, model import, cache/venv deletion, seal normalization or bypass. Bundle/source/model settings and RUN_ID remain unchanged; notebook SHA metadata updated.

Local validation: diagnostic and all notebook code cells parse. No Colab diagnostic or reconstruction/model code executed by agent. Existing model/loader tests were not repeated for this read-only presentation change.

Next gate: user runs diagnostic on currently failed rebuilt environment, or updated notebook captures next failure automatically. Review exact diff before choosing replay correction. Preserve cache and expected seal; do not ignore REQUESTED metadata or overwrite installed_digest merely to pass.

Unresolved: exact user-runtime mismatch and whether root-only replay with resolved constraints reproduces the original environment.
