# PGNet preflight bootstrap correction

Historical preparation snapshot. Current delivery was consolidated into canonical ZIPs; superseded variant files were deleted by user request. See [current guide](../../docs/cvid-joint-spotting-colab-t4-run-guide.md) and [cleanup record](../../docs/pgnet-delivery-cleanup-261015.md); old hashes below describe their dated snapshot.

User log: host `/usr/bin/python3` (3.13) failed `venv` during ensurepip, before candidate environment/model loading. Exact underlying ensurepip stderr is not present; do not assert a specific missing OS package. Code additionally treated an existing bootstrap interpreter as successful installation, allowing a partial venv to skip uv installation on retry.

Fix: create venv with `--without-pip`; probe uv, and if unavailable use host pip's documented `--python` targeting that interpreter to install `uv==0.8.22`. Retain exact version check; do not silently replace a usable wrong version. No kernel package installation, dependency/model pin change, test inference or GPU operation.

Validation: three mocked local regression checks passed (fresh unseeded environment, partial ensurepip recovery, existing wrong version rejection). Both delivered notebooks' code cells parse and retain null execution counts/empty outputs. Repacked ZIP comparison proved only `spotting_colab_environments.py` and corresponding manifest differ; original ZIPs preserved. Qualification still contains identical nine train images and no test images. Actual Linux bootstrap/package installation and T4 forward remain unverified.

New qualification SHA256: `231918bcb11629c8fcf4b438d57f1120ad0023cf09124ac8413672dc926d1d62`.

New comparison bundle SHA256: `c4192236f0e9d688c82790836650cd97c4e6452207fad5ca3f286194c050b7be`.

Instructions: export current failed evidence, save executed notebook, upload updated preflight notebook, choose fresh T4 runtime, upload bootstrap-fix qualification ZIP, run cells in order and inspect full receipt gates. No full test until gate passes.

Unresolved: user-run bootstrap and GPU train-forward result; detailed original ensurepip stderr if further diagnosis is needed.
