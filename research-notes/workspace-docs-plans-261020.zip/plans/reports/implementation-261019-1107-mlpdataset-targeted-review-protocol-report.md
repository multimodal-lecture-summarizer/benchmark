# MLPDataset targeted review and protocol delivery

Date: 2026-10-19. Preparation complete; external Colab execution and scientific qualification remain pending.

## Outcome

Frozen protocol v1 rules and prepared a provenance-bound targeted review notebook. Original source annotations and the executed EDA notebook remain unchanged. No repaired annotations, certified native-frame endpoints, frozen eligible cohort, detector comparison or confidence intervals are claimed.

The completed EDA covers 333 sources, 9,021 marks and 186.634 hours. Its sparse preview work is complete: 2,913 available frames, including all 388 previously remaining successful requests; 48 requests fall outside source bounds, with zero pending sparse requests. The 987 visually screened marks are diagnostic coverage, not certified GT; 8,034 released marks have no visual preview. Dental dominates video counts, and source-group/series labels are proxies rather than verified independent speakers.

## Targeted evidence and observations

The deduplicated queue contains **82 marks from 42 videos across all 10 groups**. Selection preserves original indices and every selection reason: ambiguous detailed observations, all 15 nonincreasing rows and adjacent rows, all 18 beyond-end rows, source-start cases and 14 historical dense controls. Queue identities bind to current analysis CSV hashes, original annotation times/hashes and saved source SHA values.

All 14 locally available historical clips were matched against current source/annotation identities and their saved clip hashes. Their contact sheets were inspected. These clips support coarse observations only; illustrative playback sampling is not native endpoint evidence.

| Coarse observation in selected historical clips | Count | Interpretation |
|---|---:|---|
| Instructional content replacement | 6 | Includes delayed or rotating effects; sparse before/at/after frames can miss the effect |
| Intro/outro, credits or source boundary | 7 | Auxiliary/non-target context under primary protocol |
| Content followed by unresolved blank | 1 | Retain HOLD; no new slide confirmed within available window |

These selected counts do not estimate dataset prevalence or annotation accuracy. In particular, ALRJCeVT0fQ index 7 remains unresolved; the clip shows a figure change before the released mark and blank content afterward. Montage padding beyond available clip duration is not a video event.

The operational queue comprises 14 historical coarse contexts, 20 additional source-edge policy HOLDs and **48 contexts requiring new extraction**. All 82 retain explicit statuses. Full research videos are on Drive, so the remaining extraction was not run locally.

## Frozen rules and remaining gates

The primary event is an internal full instructional-slide replacement. Its point is the last fully old **native decoded frame before effect onset**. Record last-old, onset, effect-end and first stable new separately. Fades do not use their midpoint/end as a substitute. Instructional title/agenda changes may qualify; intro/outro, lecturer motion, cursor motion, builds and true source boundaries are separately classified. Unresolved blank intervals remain held.

Original released and reviewed tracks remain separate. No sorting, deduplication, epsilon correction, global shift or automatic acceptance from motion scores. A final released row is not automatically EOF; do not drop all 326 final-row flags. Eighteen small beyond-end timestamps require source/timebase checking. Seven unlabeled videos are not negatives.

Scoring matches events per video using maximum-cardinality one-to-one matching, then minimum total absolute error with deterministic ties. Primary collar is 0.5 seconds; secondary collars 1 and 2 seconds are fixed before predictions. These are protocol choices, not an attributed official dataset metric. Report pooled, per-video and per-group counts plus macro-group results. Held/ignore intervals block a source from formal comparison rather than create free prediction zones. Failed/missing detector output cannot silently become an empty prediction list.

Formal evaluation additionally requires native endpoint decisions, full-scope annotation completeness, source-dependence/near-duplicate grouping, provenance and a bound eligible GT/cohort manifest. Targeted review of released marks cannot establish missing-event recall. All groups have been EDA-exposed, so no unseen blind holdout is claimed. Cluster-bootstrap intervals are planned only; component membership, cohort and implementation remain pending.

## Colab handoff

Use [standalone CPU notebook](../../benchmark/experiments/notebooks/diagnostics/mlpdataset-targeted-review-colab.ipynb), Run all with the same Drive account and default RUN_NAME `mlpdataset-eda-261017-v3`. It contains 18 cells, including 11 unexecuted code cells. It reads existing cache; it performs no downloads and does not rerun EDA. Results go to a separate sibling directory ending `-targeted-review-v1`.

Default selection extracts only the 48 missing contexts at +/-5 seconds, with 0.25-second diagnostic sampling. All 14 historical clips are embedded. Budgets are 60 minutes, 0.75 GiB review output, 1 GiB free-space floor and up to 2 GiB runtime source staging when headroom permits. These are limits, not a runtime estimate or completion guarantee. FFmpeg/ffprobe must be available.

Source hashes, original mark bindings, extraction configuration and artifact hashes are validated. Complete checkpoints resume; failed retries preserve an existing ready checkpoint. Deadline, storage and interruption paths terminate the active child and persist an all-82-case ledger, including not-attempted cases. Gallery failures are tracked separately. Inline MP4 HTML avoids the previous IPython Video constructor issue; no Matplotlib rendering is required. Manual decision templates start held and never certify GT automatically.

## Verification

Fresh combined local test run: **50 passed plus 4 subtests**, exit 0, 21.07 seconds. Independent notebook/helper/scorer runs also passed (8/13/29 tests). Real FFmpeg synthetic fixtures exercise notebook cells, nonzero stream origin, exact PTS mapping, EOF clipping, cache reuse/corruption, source changes, deadlines, interruption cleanup and checkpoint preservation. The scorer includes an exhaustive small matching oracle. Coverage was not measured. These are local Windows tests, not a Colab/Drive execution claim.

Independent final review: PASS, no blockers after fixing interrupted-run persistence for all 82 statuses. Current docs, guide, master plan and notebook manifest are synchronized. Relevant Markdown links resolve and YAML parses. The workflow artifact gate passed finalize (exit0) with five validated artifacts. An initial metadata classification put rejected scientific assumptions in the disproven-delivery-claims field; this was corrected before the passing gate. No code changed after the passing test run.

Evidence: [test receipt](../../benchmark/experiments/outputs/mlpdataset_targeted_review_261019/local-validation/targeted-review-test-receipt.json), [JUnit](../../benchmark/experiments/outputs/mlpdataset_targeted_review_261019/local-validation/targeted-review-tests.xml), [protocol](../../docs/mlpdataset-slide-transition-protocol.md), [queue](../../benchmark/experiments/registry/datasets/mlpdataset-targeted-review-queue-v1.json).

SHA256: executed EDA `5a1b0622cd046c42df3e12b8347fb07864056f6bbe0301be6b9824f4c55c9c64`; handoff notebook `54ee66902c467cced50da2eb160883abcc3622ba7220d9f2ed89107279c6be5c`; queue `7f780108d50f8560eeaf709fcdf4bfbd2572890566b3acf4738a3f61956d50a9`; protocol `c213748c2ca733dae518e8629f7f0c86a1bd64231575d96ca460e4a1c03d0dc2`.

Unresolved: actual extraction/review of 48 Drive contexts; native-frame endpoint/effect decisions and ambiguous source mappings; full-scope completeness; provenance, grouping and GT/cohort/split freeze. No clarification is needed for completed preparation delivery.
