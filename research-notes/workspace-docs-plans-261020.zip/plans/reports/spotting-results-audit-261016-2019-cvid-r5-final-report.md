# CVID R5 final evidence audit, 2026-10-16

All six candidate inference and scoring artifacts verified. Selection remains no_selection.

## Evidence and scope

Source: C:/Users/hung/Downloads/cvid-spotting-t4-261015-v2-r5-evidence (2).zip
SHA256:358a51fa96576cbb77820bcbe2177f1b7658556f0e7af1a0355a9276d7b38151
41,770,411bytes;10,649 unique members; ZIP CRC, exact export membership and all byte/hash entries passed. Separate all-prediction-text.csv.gz is byte-identical to the ZIP artifact (SHA37b49a49f776fcbd1509c1bbe039a2e9cc070d4dd5981b2e7e5952f65057a422).

Cohort:1,754 test frames/40,063 released GT, seven course proxies/276 folder groups, one held source frame and97 metadata-only repairs. Frames and all7 frozen scientific hashes match. All six preflight/replay/runtime/prepared/config/completion bindings and worker-source hashes match current R5 bundle; no cross-bundle import.

All10,524 checkpoint wrappers validate exact canonical bytes against sealed aggregates, frame image hashes and record hashes. All six aggregate hashes match completion receipts. Analysis summary binds exact gates/completions/predictions/data/registry/bundle. No status=error frame records; no inference failure rows. Operational resume failure remains separately retained.

DocTR zero-byte checkpoint recovered from its original hash-verified aggregate; recovery journal/readback hash matches3,158-byte checkpoint. Original0-byte file retained. No model rerun or changed prediction. Recovery source evidence remains traceable.

## Primary results (percent)

| Candidate | E2E P | E2E R | E2E Hmean | Det P | Det R | Det F1 | Macro-course E2E H |
|---|---:|---:|---:|---:|---:|---:|---:|
| PGNet TotalText joint | 49.06 | 42.59 | 45.60 | 81.12 | 70.44 | 75.40 | 28.01 |
| docTR FAST + PARSeq | 32.78 | 45.55 | 38.13 | 52.28 | 72.65 | 60.81 | 27.66 |
| Tesseract5 best English CPU | 25.49 | 32.06 | 28.40 | 44.19 | 55.57 | 49.23 | 14.28 |
| EasyOCR | 9.19 | 6.16 | 7.38 | 48.32 | 32.40 | 38.79 | 7.10 |
| Paddle DBv3 + Recv4 | 10.88 | 4.95 | 6.80 | 28.67 | 13.04 | 17.92 | 7.46 |
| PP-OCRv6 Medium | 10.33 | 4.71 | 6.47 | 22.74 | 10.37 | 14.24 | 7.44 |

PGNet leads pooled primary Hmean45.60%, ahead of docTR38.13% by7.47percentage points. This is descriptive performance on the frozen released-label endpoint, not a production choice. Macro-course Hmean is28.01% versus27.66%, a much narrower0.35pp gap. DocTR leads4/7 course proxies; PGNet leads3/7. Course20 contains17,097/40,063 GT (42.68%) and favors PGNet80.17% versus docTR67.69%; pooled and equal-course averages answer different questions.

## Sensitivity (E2E Hmean percent)

| Candidate | Primary | IoU>0.75 | Case-sensitive | Observed-flag influence |
|---|---:|---:|---:|---:|
| PGNet TotalText joint | 45.60 | 26.00 | 45.57 | 45.63 |
| docTR FAST + PARSeq | 38.13 | 13.03 | 23.30 | 38.15 |
| Tesseract5 best English CPU | 28.40 | 11.51 | 19.22 | 28.42 |
| EasyOCR | 7.38 | 3.02 | 3.00 | 7.38 |
| Paddle DBv3 + Recv4 | 6.80 | 2.63 | 1.93 | 6.81 |
| PP-OCRv6 Medium | 6.47 | 1.86 | 2.21 | 6.48 |

Removing the3 predeclared observed-flag frames leaves1,751frames/40,023GT; maximum pooled change is0.0294pp. Ranking stable across the fixed variants. Strict IoU reduces all scores substantially. Case sensitivity reduces most pipelines while PGNet changes little. These sensitivities do not establish causal architecture effects.

Bootstrap:40 reported comparisons,2,000 draws each, fixed seed20261014; anchor always Paddle DBv3+Recv4. Primary course-level intervals for PGNet and docTR relative to this anchor exclude zero; EasyOCR/PP-OCRv6 intervals cross zero; Tesseract course interval crosses zero while folder interval does not. No direct PGNet-versus-docTR CI was computed; significance between those two is not established. Only7 course proxies, exploratory unadjusted intervals and unproven folder independence limit inference.

## Grouping and error interpretation

Native output granularity materially differs. GT has only11 multiword transcriptions/40,063objects (0.027%). Output regions containing multiple whitespace-separated tokens: EasyOCR34.30%, Paddle legacy40.99%, PP-OCRv6 50.51%, Tesseract/docTR/PGNet0%. This supports grouping mismatch as a plausible contributor to low one-to-one released-word matching scores for line-oriented outputs; it does not quantify its causal contribution. Keep frozen grouping, no post-hoc test-driven splitting. Compare packaged systems, not bare recognition networks.

| Candidate | Native regions | Invalid polygons | Empty text |
|---|---:|---:|---:|
| EasyOCR |26864|34|10|
| Paddle DBv3+Recv4 |18218|11|157|
| Tesseract |50381|0|0|
| docTR |55668|0|66|
| PP-OCRv6 |18270|0|59|
| PGNet |34785|66|0|

Invalid geometry/empty text remained in frozen scoring rules. Zero failed frames means no frame-level recorded execution failures; it does not mean accurate text, valid geometry or exhaustive detection. Detection and spotting matching are optimized independently, so differences cannot be treated as a pure recognition-error decomposition.

## Export and visualization verification

48 pooled metric rows,42,078 sensitivity frame rows,13,584 group rows,48 macro-course rows,40 bootstrap rows,10,524 native-text frame-candidate rows. Counts and declared hashes match. Pooled TP/FP/FN recomputed from every frame-score row; precision/recall/Hmean formulas and GT denominators verified. Macro-course means recomputed from7 reported course scores; bootstrap point differences checked against pooled anchor metrics. Polygon/text matching itself and bootstrap resampling were not independently rerun.

Six figure files match visualization receipt, bound to analysis-summary hash. Primary and course-breakdown charts visually inspected; all six hashes checked. Inline-backend error was resolved by MPLBACKEND=Agg in the visualization subprocess; no package/source/scientific binding changes. Saved-output notebook subsequently supplied and audited16/10: all6 embedded PNGs match final evidence byte hashes and all12 primary Hmean values occur in saved HTML. Original code/output pairs retained including2 historical error outputs, successful repair/render and final export SHA. Reviewed copy saved with original backup; no claim of error-free sequential fresh-kernel replay.

## Limits and next gate

Test was exposed in EDA; annotations selective and semantic/exhaustive GT uncertified. Scores measure agreement with released labels, not all visible text. No production winner, causal architecture conclusion or CPU/GPU speed comparison. Crop recognition remains separate. Do not tune this test or combine old crop scores with spotting Hmean. Preserve R5 inputs/configs, both original and recovered evidence ZIPs, recovery journal, analysis exports and visualization receipt. No further OCR rerun is necessary for this completed comparison.

Unresolved: exact cause/time of original empty checkpoint unknown; saved-output notebook audit complete; production/external-cohort qualification remains outside this audit.
