# P4d pilot40 — runtime preparation under approved allocation

Status: **preparation only; actual Colab preflight and pilot execution unverified**. User approved the next technical pilot after audited [scorer-ready PASS](./evidence-audit-261020-0808-tib-colab-scorer-report.md) and [fresh-session recovery PASS](./evidence-audit-261020-1056-tib-recovery-v2-report.md). These two closed checks need no rerun. [P4d contract](../261019-0035-summarization-model-benchmark/phase-04d-pilot40-runtime.md) governs this preparation; selection300 and final test remain gated.

## Approved pilot scope

Exactly the existing40 pilot IDs and five profiles: Lead-3 fixed control, LexRank frozen control, BART control, LED ngram3 and Qwen reserve384. Common delivered cap350; source/native window/prompt/decode and intermediate acceptance v1 unchanged. No r512, extra decode search or model choice.

Expected coverage is200 record×pipeline cells:9 historical preferred neural imports on three existing pilot IDs,111 fresh neural outputs and80 fresh CPU outputs. Import requires exact historical source/profile/runner/runtime/checkpoint identities and native replay. Imported generation cost, current restore overhead and fresh generation cost stay separate; imported records do not enter fresh latency tails. Missing/failed/pending cells retain the original denominator40 per candidate. Exhaustion yields partial, never a reduced completed cohort.

This bundle is a source-only generation/resource pilot. No new metric calls are executed; scorer-ready and recovery are immutable dependencies. Later pilot scoring uses the reserved resources and frozen scorer; neither technical generation completion nor cached scores demonstrate fresh40-record scoring coverage.

## Allocation versus measured needs

| User-approved ceiling | Value |
|---|---:|
| Total GPU |11.5GPU-hours|
| Total CPU |23CPU-hours|
| Cumulative active wall |11.5hours|
| Sessions |At most2, each≤11.5hours|
| Session headroom |15%|
| Drive checkpoint/log allocation |2GiB|
| Minimum local free space |32GiB|
| Local working storage cap |24GiB|
| Transfer cap |16GiB|
| Scoring reserve inside totals |1.5GPU-hours /3CPU-hours|
| Restore reserve inside wall total |0.5hour|
| Automatic retries |0|
| Flush |After every committed node|

These are authorized operating ceilings, not measured demand or a completion guarantee. Two sessions do not double any total. On two logical CPUs,23CPU-hours corresponds to11.5wall-hours at continuous full use; it is not extra runtime.

Internal conservative scheduling defaults partition these same ceilings:5.75h session slice,1.5h scoring wall reserve,0.5h transfer wall,0.25h checkpoint wall and0.75h session overhead. They are operational reservations, not separately measured needs or additional user allocations. Actual accounting and remaining-budget checks determine whether new work can start.

## Implementation inspected

Read the actual pilot builder, notebook generator, runtime, technical validation and resource/session modules before updating this report:

- [Bundle builder](../../benchmark/experiments/scripts/tib_pilot_bundle.py) binds the sealed40 source records, rights/cohort identities, preferred profiles, actual scorer/recovery receipts, acceptance and pinned runtime requirements. Sources omit abstracts/reference fields.
- [Technical validators](../../benchmark/experiments/scripts/tib_pilot_validation.py) check exact40 ordered IDs/five profiles/cap350, source hashes/strata, frozen policy and dependency hashes; CPU source-span/delivery and neural native-ID/window/telemetry checks are separate.
- [Runtime](../../benchmark/experiments/scripts/tib_pilot_runtime.py) separates historical imports from prospective generation, writes versioned pilot identities/receipts and retains failure/pending accounting.
- [Resource guards](../../benchmark/experiments/scripts/tib_pilot_resources.py) and [session ledger](../../benchmark/experiments/scripts/tib_pilot_session.py) enforce cumulative allocation/bundle bindings, session identity, remaining resources and durable checkpoint accounting. A failed or interrupted attempt cannot be silently retried by resume.
- [Notebook generator](../../benchmark/experiments/scripts/tib_pilot_notebook.py) creates a user-run T4 notebook: validate package/allocation, bootstrap dependencies, run candidates sequentially, summarize/export private evidence. Session2 uses the same package/store with explicit resume, never resets the ledger.

Prepared artifacts and local test/compile/hash results are recorded separately from actual execution evidence. Final package/notebook identities and validation counts must come from the completed preparation checks; this report does not invent or infer them from source inspection.

## Status reconciliation

Swept all phase files in the active [master plan](../261019-0035-summarization-model-benchmark/plan.md). Current pointers now distinguish P4b/P4c scoped PASS from P4d preparation and P5 pending. P1–P3 statuses, qualification/development seal, historical decisions/receipts and dated raw evidence remain unchanged. No final study admission, selected model or test seal is created.

## Final local delivery verification

- **144/144 tests PASS**,28.06s, including new pilot modules and frozen acceptance/checkpoint/generation regression. Actual private builder→validator→allocation→session integration passes; six modules/four clean notebook code cells parse. Independent review has no outstanding delivery blockers. No pretrained models, downloads or actual inference in these checks.
- Notebook: `benchmark/experiments/notebooks/tib-pilot40-colab-t4-261020-v1.ipynb`, SHA256 `e6298659fd29d8c1dbf43724e7bb697849a51d9cf7e8c6f9acf4fcf8c2427571`.
- Private ZIP: `benchmark/research-data/tib-pilot40-261020-v1/tib-pilot40-261020-v1.zip`, 651488bytes, SHA256 `08c44f0db3a849976037922fbd665736a8465645b120a40f219b305135752e62`. All50 bound files match the generated package and current source. Large/private sources and ZIP remain ignored, not public artifacts.
- Budget/protocol are versioned at `benchmark/experiments/registry/protocols/tib-pilot40-261020-v1/compute_budget.json` and `pilot_protocol.json`; `local_validation.json` records preparation evidence. Allocation is authorized; **actual runtime state remains unverified until notebook preflight**, not blanket PASS.
- Run first session with `RESUME=False`; upload the ZIP in Colab T4. For a second VM, use the same ZIP/Drive store and `RESUME=True`. Completed candidates restore verified records without downloading/loading their model again. Failed/interrupted attempts do not silently regenerate. Session closure after compression is exported separately from the active ledger snapshot.
- CUDA peaks reset per record, initialization peaks separate. Failed backend time/resources retained. GPU capacity accounting includes setup/CPU/wait while the T4 session is active; neural-work wall time is separate. Unknown lost-session usage is conservatively charged; it is not a measured zero.
- A known Windows pyreadline3 destructor warning appeared after pytest success; process exit0. Default sandbox temporary-directory rename access was avoided by a workspace-local test directory.

## Remaining

1. Actual Colab T4 preflight: exact pins, available RAM/VRAM/local free/working storage, Drive quota and write/fsync/rename/readback, transfer and remaining cumulative budgets.
2. User-run technical pilot and returned ZIP plus executed notebook audit. Record per-ID/stratum/stage calls, latency, warnings/failures, output lengths/cuts, CPU/RAM/GPU/VRAM and initialization/checkpoint/export costs.
3. Later pilot scoring under the frozen scorer/reserved budget; then measured conservative projection and formal admission/profile/cap/storage/full-study budget freeze before selection300.

Unresolved: actual runtime/storage/quota availability, whether all200 cells fit within the allocation, fresh pilot measurements and later scoring. Full-study resources and admission remain unapproved/unmeasured. Target final523→500→400 is unchanged.
