# TIB bounded local source-use policy

2026-10-19, Asia/Bangkok. Implements source-use qualification only; no model execution, public text release, A/B/C reference adjudication or cohort seal.

## Decision and measured accounting

Frozen policy: `benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/source_use_policy.json`. The policy was saved before the actual decision ledger, without consulting model outputs. Its recorded freeze timestamp is actual local time; the directory identifies the work slice.

| Native split | Records | Source conditional / allowed locally | Source HOLD | Reference CC0 supported | Both rights gates |
|---|---:|---:|---:|---:|---:|
| train | 7,282 | 4,949 | 2,333 | 4,468 | 4,215 |
| valid | 910 | 616 | 294 | 568 | 532 |
| test | 911 | 606 | 305 | 556 | 523 |
| Total | 9,103 | 6,171 | 2,932 | 5,592 | 5,270 |

These are rights-only availability counts, not qualified A+B counts, selected IDs, sealed cohorts or run feasibility. `conditional` has `allowed_for_current_local_use: true` only within the recorded local/private/noncommercial constraints. Each boolean gate is JSON boolean, never a truthy string. Reference use is separate; source rights never clear an unmatched abstract.

Source HOLD reasons: 2,582 lack a per-record current grant, 328 have older ND versions pending adaptation analysis, 17 have nonopen InC URIs, five have incomplete attribution evidence. Missing current-export rows do not inherit permissions from representative pages or raw permissive labels. All 26 representative mappings remain evidence, not an exhaustive grant.

## Scope and version handling

Current source-record CC URI is read from the complete previously scanned official Open Data evidence. Attribution retains author/title/URL/exact URI/full original license prose and modification notice. Raw license hashes are checked against the full snapshot rights ledger for every row. Source use remains conditional on rights the source licensor can grant; it does not certify unrelated third-party rights, legal exceptions or all dataset reuse.

The internal workflow constrains local private noncommercial analysis, retains attribution, and excludes public source/reference/expressive-output sharing and external API text transfer. NC conditions are satisfied by the actual constrained noncommercial use, not by an academic label alone. SA obligations for future sharing remain recorded; private adaptation does not require publishing adaptations.

Exact observed versions and jurisdictions are preserved. Official primary legal codes reviewed: [BY 2.0 Belgium](https://creativecommons.org/licenses/by/2.0/be/legalcode.fr), [BY 3.0 Germany](https://creativecommons.org/licenses/by/3.0/de/legalcode), [NC 2.0 Germany](https://creativecommons.org/licenses/by-nc/2.0/de/legalcode.de), [NC 3.0 Germany](https://creativecommons.org/licenses/by-nc/3.0/de/legalcode), [SA 3.0 Germany](https://creativecommons.org/licenses/by-sa/3.0/de/legalcode), [SA 3.0 US](https://creativecommons.org/licenses/by-sa/3.0/us/legalcode), [NC-SA 3.0 Germany](https://creativecommons.org/licenses/by-nc-sa/3.0/de/legalcode), plus the corresponding unported BY/SA/NC/NC-SA 3.0 and SA/NC-SA 4.0 codes. Existing [rights research](research-261019-1507-tib-rights-provenance-report.md) supplies BY 4.0 and CC0 evidence. The single NC-SA 3.0 US route was checked against its [official deed](https://creativecommons.org/licenses/by-nc-sa/3.0/us/); its legal-code URL was inaccessible through the web tool, so no legal-code retrieval is claimed for that port.

[BY-ND 4.0](https://creativecommons.org/licenses/by-nd/4.0/legalcode.en) and [BY-NC-ND 4.0](https://creativecommons.org/licenses/by-nc-nd/4.0/legalcode.en), section 2(a)(1)(B), support producing/reproducing adaptations without Share; the latter additionally requires noncommercial use. Older ND versions remain HOLD, without guessing that 4.0 terms apply. No CC0 source-transcript route was invented: the source evidence has zero matching released transcript fields.

165 rows flag released BY-SA prose mentioning noncommercial use; raw prose stays intact and current authoritative URI controls this bounded decision. One DOI difference, `train:3780`, remains a flag rather than an automatic wrong-record exclusion: its source gate passes the NC-ND4 private-use route; its unmatched reference gate remains HOLD.

## Artifacts and verification

- Implementation: `benchmark/experiments/scripts/tib_model_benchmark_rights.py` (162 lines after review fix, standard library).
- Focused tests: `benchmark/tests/test_tib_model_benchmark_rights.py`; 59 passed after review fix (initially 41). One harmless installed `pyreadline3` console teardown message followed pytest exit 0.
- Full ignored ledger: `benchmark/research-data/tib-qualification-261019-1703/source_use_ledger.jsonl`.
- Ignored receipt: `benchmark/research-data/tib-qualification-261019-1703/rights_summary.json`.
- Policy SHA-256: `bea92cab0d00ea870925899fe151a52b1581960d7c03eb8d21e18972a6c24249`.
- Ledger SHA-256: `ad0f85960ffd7cc92609636ab34e1b0ca9e76252a3823e0ba982cf263c1f5dc5`.

Receipt binds exact field ledger, full raw rights ledger, provenance summary, representative URI evidence, frozen policy and implementation hashes. All 9,103 decisions were independently replayed from those inputs and compared exactly; raw prose, strict booleans, combined rights gates and policy/ledger hashes passed. Git ignore confirmed for both large local outputs. Input snapshot and earlier evidence unchanged. CLI refuses to overwrite existing qualification outputs.

Review fix at 17:14: unknown route decisions such as `DENY` previously could fall through as conditional. Validation now accepts only exact `conditional`/`hold` decisions in nonempty mappings of route objects; malformed/unknown decisions raise before returning any permission. Eighteen additional cases cover typos, missing/invalid decisions and malformed route mappings. The valid frozen policy, source-use ledger and original receipt remain byte-for-byte unchanged. All 9,103 decisions replayed exactly in memory with the corrected tool; counts unchanged. New ignored `benchmark/research-data/tib-qualification-261019-1703/rights_validation_review_fix_receipt.json` binds original policy/ledger/summary/tool hashes, new tool SHA-256 `196b0eaf8a1c0d850a75ed0d869124f2151af7b4c052ee1b7d5dab5f50962596`, tests and successful unchanged-decision replay. The original receipt's tool hash describes the original generation; the new validation receipt records the reviewed implementation.

Reproduction from repository root:

```powershell
python benchmark/experiments/scripts/tib_model_benchmark_rights.py --policy benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/source_use_policy.json --fields benchmark/research-data/tib-evidence-261019-1507/field-rights-ledger-v2.jsonl --raw-rights benchmark/research-data/tib-evidence-261019-1507/local-audit/rights_ledger.json --output benchmark/research-data/tib-qualification-261019-1703-replay
```

## Unresolved questions

Additional per-record grants could resolve missing-current-grant and reference HOLD rows; older ND adaptation versions require separate analysis if expansion is needed. This implementation does not decide public sharing, changed commercial purpose, external API transfers or jurisdiction-specific exceptions.
