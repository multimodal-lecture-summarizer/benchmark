# IIIT-CVID spotting: cohort and scoring freeze

Protocol version/date: `iiit-cvid-spotting-validation-261013`, 2026-10-13. Verification completed 2026-10-14, Asia/Bangkok.

**Completed:** frame IDs, exact released box/transcription GT, annotation decisions, matching, normalization and failure rules. **Not executed:** spotting model inference. Candidate detector/recognizer weights, adapter and operating thresholds must be frozen before that next run.

## Frozen artifacts

- [Cohort manifest](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-validation-261013-cohort.json): all 549 source frame IDs and hashes, dimensions, counts, decisions; 546 selected IDs.
- [Machine-readable protocol](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-validation-261013-protocol.json).
- [Freeze receipt](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-validation-261013-freeze-verified-261014.json): artifact and implementation hashes, coordinate evidence and Unicode/runtime identity.
- [Local derived GT](../../benchmark/experiments/outputs/iiit-cvid-spotting-validation-261013/ground-truth.jsonl): selected frame IDs, source object indexes, unchanged boxes and transcriptions. This output is Git-ignored; no raw-image or transcription redistribution is performed.
- [Local HOLD ledger](../../benchmark/experiments/outputs/iiit-cvid-spotting-validation-261013/annotation-holds.json).
- [Reference scorer](../../benchmark/experiments/scripts/spotting_metrics.py), [freeze builder](../../benchmark/experiments/scripts/freeze_iiit_cvid_spotting.py), [contract tests](../../benchmark/tests/test_spotting_metrics.py), [scorer verification](../../benchmark/experiments/outputs/iiit-cvid-spotting-validation-261013/contract-verification.json).

Hashes:

| Artifact | SHA-256 |
|---|---|
| Source ZIP | `b5b562580e250ee3336462b7699bc79d0d1149d3b8cc82f1b221a0d0ce4fb489` |
| Cohort manifest | `4657eedf5c527a2fc6ff7e4ba8c6508ad032f805f19ab93d1e1c6fcf2c72f9cb` |
| Derived GT JSONL | `238731f770cb4765fca54d9c9062c48588881559b2bb2c5a467582d0f1e018d1` |
| Protocol | `8fde6c6d6dab81c7321b68c09738253b143c5a22fb96f2b38912c3471616e55e` |

## Cohort and estimand

Select every released **validation** frame that passes the predeclared annotation-validity screen, independent of spotting outcomes. No subsampling by visual difficulty, course preference or model quality. Source: `staghado/IIIT-CVid`, revision `8159222f11460bff70bec7990ade19c468755fe4`, verified local ZIP identity above.

| Scope | Frames | XML objects |
|---|---:|---:|
| Source validation | 549 | 15,379 |
| Selected spotting cohort | 546 | 15,317 |
| Held geometry frames | 3 | 62 |
| Selected frames with derived dimension repair | 3 | Included above |

| Course | Selected frames | Selected objects | Course/video groups |
|---|---:|---:|---:|
| 11 | 129 | 2,907 | 36 |
| 13 | 68 | 1,452 | 23 |
| 19 | 196 | 7,757 | 46 |
| 2 | 82 | 1,859 | 28 |
| 6 | 71 | 1,342 | 7 |
| Total | 546 | 15,317 | 140 |

The estimand is pooled spotting performance against released annotations on these **546 eligible exposed validation frames**. The cohort differs from the 15,379-crop recognition cohort. Excluding invalid edge annotations changes the target population; it does not establish performance on all 549 frames or on edge-truncated words. Source course 19 supplies 50.64% of selected GT objects, so per-course tables are mandatory. There are zero exact duplicate selected image hashes; this does not establish semantic independence.

## Annotation decisions and coordinate evidence

KEEP 543 structurally valid pairs. For three metadata-only mismatches, use decoded PNG dimensions in derived metadata; source XML, label text and box coordinates remain unchanged:

- `Frames/val/11/27/00_45_38_00009.png`: XML 2×1 → decoded 608×482.
- `Frames/val/19/11/00_16_20_00005.png`: XML 2×1 → decoded 960×546.
- `Frames/val/2/11/00_04_59_00001.png`: XML 2×1 → decoded 1280×720.

HOLD entire frame when a box exceeds PNG bounds; retain every source annotation for review. No clipping or selective removal of the offending word:

| Frame | Offending object index | Label | xmax / PNG width | All objects held |
|---|---:|---|---:|---:|
| `Frames/val/2/23/00_20_38_00006.png` | 4 | `p5` | 1281 / 1280 | 16 |
| `Frames/val/6/1/00_43_16_00008.png` | 7 | `r-d` | 641 / 640 | 15 |
| `Frames/val/6/4/01_16_06_00008.png` | 6 | `hand` | 641 / 640 | 31 |

Indexes are zero-based source XML order. Any later authorized annotation repair requires a new cohort/protocol version; do not overwrite this freeze.

Coordinate convention is supported by exhaustive source evidence: every one of **15,379 source validation XML objects** produces a decoded RGB crop that matches an author-released crop in the same course/video folder when using raw `(xmin, ymin, xmax, ymax)` boundaries. Neither VOC one-based-inclusive nor zero-based-inclusive alternatives match any of those object crops. The check uses dimensions plus SHA-256 of decoded RGB pixels and does not infer transcription correctness or uniquely identify duplicate crop instances.

Use continuous rectangle edges, area `(xmax-xmin)*(ymax-ymin)`, with no minus-one shift or inclusive plus-one area. Prediction polygons remain polygons, including rotated quadrilaterals; do not replace them with enclosing axis-aligned rectangles. Adapters must map predictions back to original-frame coordinates before evaluation.

All 15,379 source validation objects have `difficult=0` and `truncated=0`; the source contains 1,684 normalized one-character labels, 33 labels containing whitespace and two literal `*` labels. The study preserves the original XML object granularity, including multi-token objects, and all selected literal labels. No guessed ignore convention, short-word filtering, punctuation stripping or dHash-based deletion is applied. Nonblank text and crop agreement are not proofs of label truth or annotation-author/QC provenance.

## Scientific basis and deliberate study choices

The [ICDAR 2015 competition paper](https://imlab.jp/publication_data/1469/C02.pdf) motivates scoring localization and transcription together, an IoU threshold of 0.5, case-insensitive transcription evaluation, pooled counts and F-score. Its short-word, punctuation and do-not-care conventions belong to its datasets. They are not appropriate defaults for lecture annotations containing formulas, digits and short symbols, so this protocol deliberately preserves those labels. This is a **study-specific released-label spotting metric**, not a reproduction of an official ICDAR leaderboard.

The [dataset paper author's publication page](https://kris314.github.io/publication/inst-vids/) identifies *Localizing and Recognizing Text in Lecture Videos*, ICFHR 2018. It does not resolve the XML annotation creator or quality-control method. The live CVIT project URL returned unrelated content during this review, and direct paper-PDF retrieval failed; neither is used to certify label provenance or to assert the original dataset's complete evaluation protocol.

Maximum-cardinality matching is an explicit study choice: it makes TP counts independent of arbitrary prediction ordering and avoids greedy undercounting when overlaps are ambiguous. It does not grant one prediction multiple words of credit. Retaining original object granularity also exposes word/line grouping errors. Before inference, adapters must freeze grouping/splitting rules using image/model output only; GT boxes, GT transcriptions and previous recognition predictions cannot guide segmentation or decoding.

## Matching, normalization and metrics

Within each frame, use **IoU strictly greater than 0.5**. Equality fails. Detection uses maximum-cardinality one-to-one geometry matching. Spotting uses a separate one-to-one graph whose edges require both eligible IoU and exact normalized transcription equality. Every unmatched prediction is FP; every unmatched GT object is FN. Duplicate predictions, merged words and split words receive no special rescue credit.

Primary normalization: Unicode **NFKC → casefold → whitespace split/join**, Unicode database 14.0.0. Keep digits, punctuation, accents and literal `*`. Examples: `Ａ*２` → `a*2`, `Straße` → `strasse`; `a*2` differs from `a2`, and `café` differs from `cafe`. No fuzzy match, CER tolerance or dataset lexicon. Case-sensitive sensitivity uses NFKC and the identical whitespace handling, with no casefold.

Primary **micro end-to-end Hmean = 2TP/(2TP+FP+FN)**, calculated after pooling counts across frames. Also report spotting P/R, detection P/R/F1, all count denominators, per-course and per-group results. Detection/spotting use independently optimized matches, so their TP gap is not an exact count of recognition errors. The earlier GT-crop recognition audit remains a separate endpoint.

Predeclared sensitivities reuse the same predictions: IoU >0.75, and case-sensitive normalization at IoU >0.5. They cannot replace the primary result after outcomes are inspected.

For paired uncertainty, enumerate all 5^5=3,125 ordered course-cluster bootstrap resamples, retain all objects/frames in each drawn course and recompute the difference in pooled Hmean. Use percentile indices stated in the JSON. This is exploratory because five course proxies cannot support strong population inference. A secondary 2,000-draw bootstrap uses sorted course/video groups, Python `random.Random(20261013)`, keeping all frames/objects within each group. It assumes group independence conditional on courses; that assumption remains unverified. Do not report unseen-course superiority or a production winner.

## Failure and execution rules

- Frame inference error: retain frame and all GT in the denominator, record error, use zero predictions; no retained partial predictions.
- Missing record: convert to `missing_record` error and expose it in the failure ledger. Never silently score only the intersection of successful candidate frames.
- Successful empty output: all GT are FN but distinguish this from an engine failure.
- Recognition failure after successful localization: retain the valid polygon with empty transcription; it can be a detection TP but is not a spotting TP against nonblank GT.
- Invalid polygon: finite numeric coordinates, positive area, simple geometry and image bounds are required. Retain invalid predictions as FP in both endpoints; no clipping or geometry repair.
- Duplicate/extra frame IDs or malformed record schema: reject the run. At most one logged transient I/O retry before committing; no score-based best-of retry. Resume only matching cohort/protocol/model/config/source identities.

Before model inference, freeze detector and recognizer versions/weight hashes, preprocessing and inverse transforms, confidence thresholds/NMS/grouping, decoder, resource profile and output schema. Published defaults or disjoint source-train development may inform configuration; frozen validation GT/outcomes must not tune them. Recognition-only wrappers are insufficient for spotting. This execution gate is pending and does not reopen the completed data/scoring freeze.

## Verification and reproduction

Source ZIP hash recomputed; all 549 validation PNG/XML pairs decoded/parsed from the pinned ZIP; exhaustive 15,379-object coordinate checks completed. Frozen artifact and implementation hashes verified. Reference environment: Python 3.11.1 / Unicode 14.0.0 / Pillow 12.3.0 / Shapely 2.1.2 / GEOS 3.13.1. [Scoped requirements](../../benchmark/experiments/scripts/requirements-spotting.txt) avoid changing OCR inference environments; use Python 3.11 and verify Unicode/GEOS identity before scoring.

`python -m pytest tests/test_spotting_metrics.py -q` in `benchmark`: **17 passed**. Covers ambiguous one-to-one matching, prediction ordering, duplicates, empty text, exact IoU boundary, invalid polygons, missing/error frames, malformed schema and pooled denominators. A harmless `pyreadline3` destructor warning appeared after successful test completion (exit 0); it was not an evaluation failure.

Full-GT contract check: treating unchanged GT boxes/text as oracle predictions gives detection and spotting TP=15,317, FP=FN=0, Hmean=1. Empty outputs retain 15,317 FN; omitting every frame records 546 failures with the same FN total. These are scorer checks, **not model inference or benchmark results**.

To reproduce derived artifacts from the verified local source ZIP:

```powershell
cd C:\Users\hung\Documents\GitHub\multimodal-lecture-summarizer\benchmark
python -m experiments.scripts.freeze_iiit_cvid_spotting
```

The builder rejects changed existing frozen files. Its receipt includes Python/runtime and implementation identities; use the recorded environment for byte-identical receipt reproduction, or use a new version when deliberately changing the environment or protocol. Preserve the ignored GT/hold ledgers with source ZIP and frozen manifests.

## Unresolved questions and next gate

- Annotation creator/QC provenance and semantic meaning of the two literal `*` labels remain unresolved; preserve labels and limit claims to released-label agreement.
- Folder identity and cross-course/video source dependence are not independently certified. Prior cross-split dHash candidates do not establish leakage or independence; no unseen claim is made.
- Candidate runtime/model/configuration freeze is the **single next gate** before a same-frame spotting comparison. Slide-transition/keyframe evaluation remains a separate later task with its own GT readiness.
