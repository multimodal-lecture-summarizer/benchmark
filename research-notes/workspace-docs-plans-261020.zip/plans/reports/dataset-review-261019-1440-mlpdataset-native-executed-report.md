# Kiểm tra notebook native MLPDataset đã chạy

Ngày19/10/2026. File thực tế: `benchmark/experiments/notebooks/diagnostics/mlpdataset_native_review_colab.ipynb`,102.585.725bytes; SHA256 `bfa246af81cb2e610d3f3961f889de5db8d7002b22bf012397318ad2c6c3b876`. Giữ nguyên notebook và annotation.

## Thực thi đã hoàn tất

11/11code cells chạy theo thứ tự1–11;0exception Python được lưu. **64/64job đều ready**, từ38video. Gallery đủ64job và **3.553/3.553frame**, không lỗi hiển thị,0ảnh bị bỏ do ngân sách. Payload JPEG base64 khoảng95,24MiB, dưới mức128MiB. Không còn job trích frame của hàng đợi này chờ xử lý.

Queue/protocol/ledger bindings khớp phiên bản đã bàn giao. Mã helper trong notebook khớp AST và nội dung chuẩn hóa với bản đã kiểm thử; khác rawhash của cell do chuẩn hóa newline khi lưu notebook, không phải thay đổi logic. Caption của toàn bộ3.553frame khớp index,integerPTS/timebase và logFFmpeg; thứ tự tăng dần và thuộc đúng cửa sổ half-open của từngjob. Tất cả origin suy ra bằng0. Code ready chỉ được trả sau khi so PTS trích với independentffprobe.

Giới hạn kiểm chứng: notebook không in toàn bộ native-review-receipt/checkpoint/native-probeJSON hay bảng hashPNG gốc. Các file đó còn trênDrive. Lượt kiểm local đối chiếu log/caption và bindings, không rehash lại fullsource/PNG hoặc độc lập phát lại ffprobe. Output không cung cấp đủ timing/stagingmetrics nên không kết luận thời gian chạy hay peakRAM. Không cần rerun chỉ để trích lại64job đã sẵn sàng.

## Nhận xét trực quan

Đã screening đủ64cửa sổ bằng8overview sheets. Đã xem toàn bộ frame ở các sheet ngắn của job001/002/012/013/028/029 và các sheet trọng điểm của job019. Chưa chứng nhận endpoint toàn bộ sự kiện trong64job.

Bảy cặp frame liền kề cho thấy các điểm cuối slide cũ sau đây; đây là quan sát ứng viên được lưu riêng, chưa ghi đè nhãn gốc hay freezeGT:

| Video / sự kiện | Frame cuối slide cũ (s) | Frame đầu slide mới (s) |
|---|---:|---:|
| -a5-EHnZ_XA: Diffuse→Focal |355.800000|355.833333|
| -a5-EHnZ_XA: Focal→Diffuse |357.733333|357.766667|
| -a5-EHnZ_XA: Diffuse→BRONJ |358.066667|358.100000|
| 2xr4P0WGKSA: Self-Attention→Attention Function |2191.880000|2191.920000|
| 37z_tJD81y8: computation→Encoder-Decoder |3974.600000|3974.633333|
| E_3gxQWaCoQ: plot→title |1844.800000|1844.833333|
| E_3gxQWaCoQ: title→agenda |1846.500000|1846.533333|

Hai video đầu về machine learning xác nhận lệch nhãn theo các mức khác nhau:2191.88−2190.7665=1.1135s;3974.6−3971.7774=2.8226s. Không có cơ sở dịch toàn bộ timestamp cùng một lượng. Hai mốc E_3 cùng timestamp gốc vẫn chứa hai sự kiện riêng; nativepreview xác nhận cần mapping, không tự dedup theo thời gian.

**Ca màn trắng ALRJCeVT0fQ đã rõ hơn:** nội dung còn ở848.96s; blank bắt đầu849.00s và còn đến frame cuối856.96s của nguồn dài857s.200frame cuối có11biến thể JPEG; đã xem đủ11biến thể, chỉ khác con trỏ trên nền trắng, không thấy slide nội dung mới sau blank. Vì vậy không coi đoạn này là hiệu ứng chờ một slide mới; mapping của nhãn848.761s vẫn HOLD, không chuyển nó thành timestamp sửa tự động. Trước blank còn có đổi hình ở847.04/847.08s, cần xét riêng nội dung/animation khi lập quyết định sự kiện.

Các windowEOF khác giữ slide cuối hoặc endcard; source-start giữ trang đầu. Frame ở biên không chứng minh source-edition equivalence. Điều kiện cohort/completeness/provenance không được suy ra từ thành công trích frame.

## Trạng thái bước tiếp theo

Thu thập nativepreview của hàng đợi đã hoàn tất. Giữ cache và toàn bộ outputs; chưa cần chạy lại notebook này. Công việc tiếp theo là adjudication các sự kiện còn lại bằng bằng chứng đã lưu: last-old/effect-onset/effect-end/first-stable-new, mapping nhãn lặp, loại auxiliary và sourceedge. File template vẫn giữ đủ82row HOLD/null vì notebook không tự chấm nhãn; điều đó không có nghĩa64job thất bại.

Bằng chứng: [audit JSON](../../benchmark/experiments/outputs/mlpdataset_native_executed_review_261019/audit-summary.json), [bảy cặp frame và terminal blank](../../benchmark/experiments/outputs/mlpdataset_native_executed_review_261019/native-visual-observations.json), [job audit](../../benchmark/experiments/outputs/mlpdataset_native_executed_review_261019/job-audit.json). Đây là outputs local ignored; không commit media lớn.

Còn chưa chốt: toàn bộ endpoint/effect và original-event mapping; source-edition equivalence; completeness,dependence/provenance và GT/cohort/split. Không có lỗi tải/trích/hiển thị nào cần retry được thấy trong outputs hiện tại.
