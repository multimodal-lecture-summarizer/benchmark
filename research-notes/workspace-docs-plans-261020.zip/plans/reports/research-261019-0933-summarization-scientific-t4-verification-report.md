# Xác minh khoa học và T4 cho kế hoạch benchmark tóm tắt mở rộng

- Thời điểm bắt đầu: **2026-10-19 09:33, Asia/Bangkok**. Nguồn web truy cập ngày 2026-10-19.
- Phạm vi: [kế hoạch hiện hành](../261019-0035-summarization-model-benchmark/plan.md), đặc biệt [P3 qualification](../261019-0035-summarization-model-benchmark/phase-03-dataset-qualification-and-cohort-freeze.md), [P4 selection/runtime](../261019-0035-summarization-model-benchmark/phase-04-candidate-selection-and-t4-benchmark-protocol.md), [P5 metrics](../261019-0035-summarization-model-benchmark/phase-05-evaluation-and-model-selection.md).
- Chỉ nghiên cứu/đọc tài liệu và tính toán minh họa. Không sửa plan, tải weights/dataset, chạy model/EDA/benchmark, chọn IDs hoặc tạo freeze receipt.

## Kết luận

Khung hiện tại có cơ sở cho benchmark **creator-abstract agreement**, với T4 là nền tảng cần qualification. Không tìm thấy bằng chứng buộc phải giảm quy mô đã thống nhất. Cũng chưa có bằng chứng đo thực để xác nhận bốn pipeline chạy đủ toàn test trong một ngân sách cụ thể.

Xác minh tiếp phát hiện một điểm selection cần làm rõ trước freeze: plan đang đưa mọi candidate/config vào cùng comparison set, nhưng yêu cầu leader hơn mỗi rival ít nhất0.01. Khi một family có nhiều config gần nhau, quy tắc có thể trả no_selection vì cạnh tranh nội-family. Intersection chung cũng co lại theo số config. Đây là hệ quả logic của protocol, không phải lỗi model hay kết quả benchmark.

Quy mô giữ nguyên: EDA9.103; qualification mọi split; pilot30–50 validation; selection200–400 validation rời pilot; ưu tiên toàn bộ native test hợp lệ≤911, fallback400–600 định trước nếu ngân sách không đủ; error analysis30–50 unique cases tổng. Các kích thước không bảo đảm power hoặc runtime.

## Mục lục

1. [Phương pháp và giới hạn](#phương-pháp-và-giới-hạn)
2. [Ma trận bằng chứng](#ma-trận-bằng-chứng)
3. [Ước lượng bộ nhớ](#ước-lượng-bộ-nhớ)
4. [Selection và nhiều cấu hình](#selection-và-nhiều-cấu-hình)
5. [Dataset và scorer](#dataset-và-scorer)
6. [Điều kiện để chuyển sang thực thi](#điều-kiện-để-chuyển-sang-thực-thi)
7. [Nguồn và giới hạn truy cập](#nguồn-và-giới-hạn-truy-cập)
8. [Câu hỏi chưa giải quyết](#câu-hỏi-chưa-giải-quyết)

## Phương pháp và giới hạn

- Áp dụng ck:research và project-organization; lưu báo cáo trong plans/reports.
- Cấu hình research.useGemini không có: dùng mặc định false, không gọi Gemini.
- **5 lượt công cụ web**, gộp các URL/query liên quan; không vượt giới hạn skill. Đối chiếu 12 nguồn chính được liệt kê dưới đây; đây là card/config/docs và trang abstract/bibliography, không phải systematic review toàn văn mọi paper.
- Ưu tiên NVIDIA, Google, nhà phát hành checkpoint/dataset, Hugging Face docs và paper gốc. Tài liệu cổ điển dùng để xác minh định nghĩa; thông số/runtime phải theo actual pinned revision khi triển khai.
- Từ khóa: TIB reference filtering/splits; Qwen3 head_dim/KV cache; LED encoder/decoder/global attention; FlashAttention/Turing compatibility; BERTScore/SBERTScore; model-selection bias.
- Phân loại: **xác nhận bằng nguồn**; **suy luận/tính toán tĩnh**; **chưa xác minh bằng actual runtime hoặc snapshot**. Không chuyển giữa các loại bằng một nhãn PASS tài liệu.

## Ma trận bằng chứng

| Giả định | Kết quả kiểm chứng | Hệ quả |
|---|---|---|
| T4 hỗ trợ FP16, VRAM16GB | Xác nhận bởi [NVIDIA](https://www.nvidia.com/en-us/data-center/tesla-t4/) | FP16 là hướng hợp lý; không suy usable GiB hoặc model fit từ nominal capacity |
| Qwen3-4B causal, có GQA | [Config hiện tại](https://huggingface.co/Qwen/Qwen3-4B/blob/main/config.json) ghi36 layers,8 KV heads,head_dim128 | Đủ để ước lượng KV; chưa chứng nhận actual allocation/latency |
| BART native context1024 | [Config BART](https://huggingface.co/facebook/bart-large-cnn/blob/main/config.json) xác nhận1024 và beam4 | Cần map/reduce cho nguồn dài; encoder/decoder bounds tách riêng |
| LED encoder16384,decoder1024 | [Config LED](https://huggingface.co/allenai/led-large-16384-arxiv/blob/main/config.json) xác nhận; attention_window1024 | Encoder proposal4096 nằm trong native bound; chưa chứng minh fit T4 |
| LED summarization global attention | [Docs LED](https://huggingface.co/docs/transformers/en/model_doc/led) khuyên global attention ở token đầu | Pin mask/padding/backend; không dùng global mọi token mặc định |
| Mỗi phiên Colab luôn đủ12h/T4 | **Không được bảo đảm**; [FAQ Google](https://research.google.com/colaboratory/faq.html) nêu thời lượng phụ thuộc availability/usage | Tiếp tục giữ multi-session/checkpoint và numeric quota gate |
| 95% coverage,delta0.01,commonN180 là chuẩn khoa học | Không xác lập trong đợt xác minh này; plan đã gọi chúng là engineering proposals | Phải có lý do vận hành, đơn vị và thời điểm khóa; không gọi statistical significance/power |
| Full test≤911 tự chứng minh suy rộng | Không; đây là mô tả eligible released frame dưới policy | Giữ exposure/group/qualification và finite-frame claim limits |
| Whole-tree/node resume đã bền | Chưa có actual persistent-store receipt | Contract đúng hướng nhưng durability/loss window còn phải kiểm khi được phép |

Các config ở URL main là bằng chứng kiểm tra hiện tại, **không phải checkpoint pin của study mới**. Pin JSON/config/generation_config/tokenizer/libs phải được tạo trước stage tương ứng. BART/LED còn có generation defaults riêng; không suy chỉ beam/max_new_tokens là toàn bộ decode identity.

## Ước lượng bộ nhớ

Tính tĩnh từ [Qwen config](https://huggingface.co/Qwen/Qwen3-4B/blob/main/config.json), giả định batch1, một sequence, FP16 KV không quantize/offload, toàn context nằm trong cache:

```text
KV bytes/token = 2(K,V) × 36 layers × 8 KV heads × 128 head_dim × 2 bytes
               = 147456 bytes/token
```

| Cached tokens tổng | KV-cache lý thuyết |
|---:|---:|
| 4096 | 0.5625 GiB |
| 8192 | 1.125 GiB |
| 16384 | 2.25 GiB |
| 32768 | 4.5 GiB |

Trọng số4B ở2bytes/parameter khoảng7.45GiB; đây là xấp xỉ. Chưa tính activations, logits/prefill temporaries, CUDA workspace/context, allocator và khác biệt backend. Proposal4K vì thế có cơ sở để thử trước, **không phải chứng nhận peak≤12GiB**. KV growth được [Hugging Face](https://huggingface.co/docs/transformers/en/kv_cache) xem là vấn đề memory riêng; weight quantization và KV quantization/offload là các lựa chọn khác identity.

BART/LED không dùng công thức KV causal trên: phải đo encoder states, decoder self/cross-attention cache và ảnh hưởng beams riêng. LexRank cần RAM host theo số câu/cấu trúc graph; chưa có sentence-tail/graph receipt mới để chứng nhận.

Backend FlashAttention/Turing chưa được xác minh đến ma trận hỗ trợ chính thức của đúng implementation/version trong giới hạn lượt nghiên cứu. Không dùng các kết quả tìm kiếm mirror/fork làm bằng chứng tương thích. Giữ gate backend thực đo và không mặc định bật flash_attention_2.

## Selection và nhiều cấu hình

### 1. Cạnh tranh nội-family

[P4 bước4–6](../261019-0035-summarization-model-benchmark/phase-04-candidate-selection-and-t4-benchmark-protocol.md#development-và-validation-selection-contract) dùng toàn admitted candidate/config comparison set, rồi yêu cầu leader hơn mỗi rival≥0.01. Protocol chưa phân định rival là config hay family representative.

Ví dụ logic, **số giả định, không phải dữ liệu study**:

| Config | Mean ROUGE-L trên cùng IDs |
|---|---:|
| Family A/config1 | 0.300 |
| Family A/config2 | 0.299 |
| Family B/config1 | 0.250 |

Nếu rival gồm mọi config, A1 chỉ hơn A2 bằng0.001 nên không thể thành leader theo rule, dù cả hai hơn B rõ về observed mean. Đây là lựa chọn bảo thủ hợp lệ nếu đích là một configuration độc nhất thắng mọi configuration; nó không tự tương đương câu hỏi chọn family/pipeline phù hợp.

**Khuyến nghị trước freeze:** tách hai quyết định: chọn một config đại diện mỗi family bằng validation rule/tie-break đã khai báo; sau đó so sánh các family representatives trên một common-complete population chung. Không đổi cohort hay tăng N. Mọi tried configs/costs vẫn ghi đầy đủ. Final test tiếp tục độc lập khỏi tuning và không chọn lại winner. Công trình về [selection bias](https://jmlr.org/papers/v11/cawley10a.html) hỗ trợ nhu cầu tách lựa chọn khỏi đánh giá; nó không xác nhận delta0.01 hoặc coverage95% cho TIB.

### 2. Intersection phụ thuộc số trial

Với M configs trên cùng N records, mỗi config missing tối đa5%, union bound chỉ cho:

```text
common_fraction >= max(0, 1 - 0.05 × M)
```

Nếu missing sets rời nhau,4 configs có thể chỉ chung80%;12 configs chỉ40%;16 configs chỉ20%. Đây là ví dụ toán học về các bố trí failures khả dĩ, **không dự đoán failure thực tế, không giả định độc lập**.

Do đó coverage95% từng config không bảo đảm common coverage90%. Rule trả no_selection khi không đủ common coverage là nhất quán; nhưng tăng trials có thể làm khó đạt gate dù không giảm coverage của từng config. Phải khóa rõ comparison set theo từng quyết định và cách nối population giữa config selection/family comparison. Không chữa bằng cách bỏ đối thủ sau khi thấy quality hoặc hạ coverage từ test outcomes.

### 3. Ngưỡng practical và strata

Delta0.01 trên scale0–1 là một ROUGE point, không phải1% relative. Floors180/20 và coverage thresholds chỉ là policy vận hành. Cần ratify trước selection với task/cost rationale; strata-sign consistency là ràng buộc bổ sung, không bằng chứng population superiority. Seed variance của Qwen một realization vẫn chưa được record bootstrap đo.

## Dataset và scorer

[TIB card](https://huggingface.co/datasets/gigant/tib) xác nhận9.103 records, splits7.282/910/911, transcripts tự động và abstracts khác nhau về độ dài/mục đích. Card cũng mô tả loại repeated abstracts ở bước xây dựng dữ liệu vì chúng có thể là mô tả chung cho nhiều video. Vì local EDA vẫn ghi225 reused abstracts, cần so sánh exact snapshot/normalization/ID ledger trước kết luận policy mới. Lặp abstract không chứng minh lặp source; abstract chung thiếu tính đặc thù vẫn có thể không phù hợp làm reference. Card có license theo record, không tự chứng nhận reuse terms của toàn snapshot.

[BERTScore paper](https://arxiv.org/abs/1904.09675) định nghĩa đối chiếu token bằng contextual embeddings. Local [semantic code](../../benchmark/experiments/scripts/rq2_tib_benchmark_metrics.py) khai báo short-input official implementation và long-input token-window extension, không phải full-context encoder vô hạn. Nếu dùng lại, phải báo metric identity/window/coverage và kiểm equivalence trong native capacity; không lấy “all tokens processed” làm chứng minh ngữ cảnh nguyên vẹn hoặc metric tương đương mọi trường hợp.

[Sentence-BERT](https://arxiv.org/abs/1908.10084) hỗ trợ sentence embeddings/cosine, không tự chứng nhận factuality. Local code ghi source score là mean của max cosine từ mỗi summary sentence đến source sentences, dùng multilingual MPNet và window aggregation. Attribution “Ye et al.2024” có trong code/tài liệu cũ; đợt này chưa truy được đúng đoạn định nghĩa paper gốc để chứng nhận exact replication. Khi pin scorer mới, ghi công thức/checkpoint/aggregation trước; nếu chưa truy đủ provenance, gọi rõ project-specific source sentence similarity thay vì khẳng định tái lập nguyên paper.

Không bắt buộc thêm human-gold framework cho phạm vi agreement. 30–50 error-analysis cases vẫn là diagnostics; các nhận xét không thành population error rates.

## Điều kiện để chuyển sang thực thi

| Gate | Có thể xác minh tĩnh ngay | Còn cần dữ liệu/đo thực |
|---|---|---|
| Selection | Làm rõ config-vs-family rival/common sets; khóa tie/admission/trial rules | Qualified validation allocation và status/score coverage |
| Dataset | Trace snapshot/schema/rights/reference policy | Exact eligible IDs/groups; đối chiếu225 reference cases |
| Models/scorers | Native bounds/config fields, explicit identity schema | Actual backend load/prefill/decode/scorer capacity |
| Budget | Required fields, full-first/fallback algorithm, toàn stages/calls | GPUh/CPUh/quota, token/call tails, transfer/checkpoint cost |
| Durability | Node keys/hashes/seeds/commit state machine | Actual store write/readback/restore/loss window |
| Final run | Pretest seal và all-selected failure accounting | Chỉ mở sau các gate trên, khi có phạm vi thực thi |

Đề xuất thứ tự tiếp theo: làm rõ selection hai tầng; chốt static scorer identity và reference rules; sau đó mới chuẩn bị pilot hữu hạn theo budget/rights đã khai báo. Không dùng kết quả nghiên cứu tài liệu này để vượt gate capacity.

## Nguồn và giới hạn truy cập

Nguồn chính đã đối chiếu; ngày tài liệu lịch sử phục vụ nền tảng, ngày truy cập đều2026-10-19:

1. [NVIDIA T4 specifications](https://www.nvidia.com/en-us/data-center/tesla-t4/) — hardware vendor.
2. [Qwen3-4B card](https://huggingface.co/Qwen/Qwen3-4B) — model publisher.
3. [Qwen3-4B config](https://huggingface.co/Qwen/Qwen3-4B/blob/main/config.json) — model publisher.
4. [BART-large-CNN config](https://huggingface.co/facebook/bart-large-cnn/blob/main/config.json) — model publisher.
5. [LED-large-arXiv config](https://huggingface.co/allenai/led-large-16384-arxiv/blob/main/config.json) — model publisher.
6. [Transformers LED docs](https://huggingface.co/docs/transformers/en/model_doc/led) — library documentation.
7. [Transformers KV cache docs](https://huggingface.co/docs/transformers/en/kv_cache) — library documentation.
8. [Google Colab FAQ](https://research.google.com/colaboratory/faq.html) — service provider.
9. [TIB dataset card](https://huggingface.co/datasets/gigant/tib) — dataset publisher.
10. [BERTScore,2019/2020](https://arxiv.org/abs/1904.09675) — original paper abstract/version record.
11. [Sentence-BERT,2019](https://arxiv.org/abs/1908.10084) — original paper abstract/version record.
12. [Cawley & Talbot,2010](https://jmlr.org/papers/v11/cawley10a.html) — original selection-bias paper page.

Giới hạn: HAL paper page timeout và document URL không truy cập được; pinned TIB README qua blob/raw đều không truy cập được bằng web tool. Không kết luận current card bằng pinned snapshot. GPU optimization docs bị redirect, không thu được ma trận backend tương thích cần thiết. Search SBERTScore tìm được references liên quan nhưng chưa đủ xác minh đúng paper/formula. Không dùng mirror/community snippets để nâng các mục này thành VERIFIED. Không gọi thêm web sau lượt thứ5.

## Câu hỏi chưa giải quyết

1. Rival trong selection là mọi config hay mỗi family representative? Protocol hai tầng/common sets/tie-break cụ thể nào được chọn?
2. Actual pinned model/scorer/library revisions, dtype/backend và decode defaults là gì?
3. Exact rights/reference-usability/group counts của snapshot, đặc biệt225 reused abstracts, đã có ledger đủ chưa?
4. Numeric quotas/trial caps, T4 peak/runtime/scorer tails và checkpoint-store receipt thực tế là bao nhiêu?
5. Citation gốc/definition của source SBERTScore adaptation sẽ được pin thế nào?
