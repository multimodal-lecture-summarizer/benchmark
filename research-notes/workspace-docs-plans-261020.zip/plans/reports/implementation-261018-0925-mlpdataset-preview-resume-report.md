# MLPDataset preview resume fix

Status: implemented, local verification passed, independent review passed. Confidence high for local resume/fairness contract; new Colab execution pending. Original executed notebook preserved at benchmark/experiments/outputs/mlpdataset_preview_resume_261018/received-executed.ipynb.

## Cause and change

Old cell27 initializes rows anew, always invokes FFmpeg, never consumes prior ledger and overwrites ledger on completion. Its global image key binds budget/selection, while fixed video order exhausts30minutes on early sources. Saved run had343 images/116 marks/38 videos and1423 unattempted frame requests.

New stable per-frame key binds source SHA, video/index/annotation/requested time/offset and render transform. Cache excludes execution budgets/selection. Source identity from existing acquisition verification preserved. Successful cache requires contained PNG path, matching SHA/request metadata and readable480px image. Compatible legacy v2 receipt/config/ledger is hash-checked; ambiguous duplicates ignored. Legacy343-frame migration depends on real Drive files and will be confirmed by next Colab outputs.

Each new completed frame writes atomic checkpoint before processing next request. Failed in-flight frame may rerun after interruption; completed checkpoints survive. Scheduler rotates one mark triplet per source-group turn and rotates videos within group, favors lower validated coverage/attempts. Missing groups retained. Per-run table retains every requested offset, pending/failure/outside statuses and validated cumulative decoded evidence; cache_hit/process_started/new counts distinguish reused/new work. Rendering follows bounded extraction, displaying all current cached/new grids inline. Receipt includes used checkpoints and frame hashes. No ZIP.

## Verification

Baseline exact same-config rerun:3 successful requests invoke FFmpeg3 more times. Fixed rerun:0 new processes with valid decoded frames retained, including zero extraction time.8 real-FFmpeg tests passed; latest exact rerun assertion independently rerun. Tests cover corrupt/missing images, annotation/source/offset invalidation, contained path safety, legacy migration/bad binding, interruption, three short runs expanding to1/2/3 groups, video/mark rotation and missing source group. All exported fixture artifacts exist and hash.

Existing stage-budget test passed (media/analysis/free/reserve/timeout/process behavior). Full333/9021 inventory/coverage regression and receipt-cell replay using333 historical states passed strict JSON/history conservation/every artifact hash. Schema and20 code-cell AST checks passed. Only notebookcells22/26/27/31 source changed; acquisition/identity/budget functions,config,fullEDA andcoverage source unchanged. Updated old zero-budget test intentionally:validated cache now stays decoded instead of being discarded. No unplanned regression found.

Guide/journal updated. Notebook remains standalone CPU Colab; same Drive and RUN_NAME. No GT timestamp, network authentication, media selection, API or source download identity change. No commit/push.

Unresolved: new Colab run, actual Drive cache migration count,131 bot-confirmation download failures, wider semantic label/timebase qualification. Reused/new preview counts are visual evidence, not semantic accuracy.
