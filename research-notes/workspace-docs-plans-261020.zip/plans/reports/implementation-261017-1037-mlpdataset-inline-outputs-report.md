# MLPDataset inline outputs revision

Date: 2026-10-17, Asia/Bangkok. User requested inspection entirely through notebook outputs, without an evidence ZIP.

## Changes

Updated the existing Colab notebook directly. Exact supplied executed bytes retained in ignored `benchmark/experiments/outputs/mlpdataset_inline_revision_261017/received-executed-colab.ipynb`, SHA-256 `c114e0d26e6abd70d6d3370e3d6a253d67478363f1dc2eb7d6c799e518f361f5`.

Unchanged annotation EDA cells and outputs preserved byte-equivalent at cell level. Edited configuration/helpers/download/preview/receipt cells have execution counts and outputs cleared, with an introductory note explaining the retained historical annotation outputs and required rerun.

- Every process log renders in full, including fast download errors and FFmpeg failures. Logs sanitize URLs before HTML escaping; no head/tail truncation in the complete rendered log.
- Every acquisition checkpoint and historical attempt displays inline, including available older attempt logs and explicit missing-log notices.
- New independent, bounded `yt-dlp --verbose --list-formats` diagnostics show commands, complete format/warning logs, status and errors. Runtime inventory shows relevant executable paths/versions only. Older format logs replay inline. Diagnostics do not change download status, selection or format filters.
- Zero decoded frames display an explicit explanation, including cases with only decode/budget failures.
- Final output includes all states, receipt, source/configuration bindings, diagnostic history, artifact SHA-256 table and actual coverage.
- Evidence ZIP creation and browser-download parameter removed. CSV/JSON/checkpoint persistence remains for resume. Save the executed `.ipynb` with outputs for inspection.

## Verification

Plan/artifact review approved. Schema/AST checks passed; retained EDA cells compared exactly with received notebook; edited downstream outputs cleared. Real FFmpeg/process regression tests passed, including full long-log rendering, HTML escaping, signed URL removal, stale-frame handling, timeouts and interrupted-attempt persistence. Fresh-kernel offline notebook validation passed 18/18 code cells with zero error outputs. It uses cached real author annotation ZIPs and disables Drive/network/media/format acquisition; no claim of live Colab download success.

## User rerun

Upload the edited notebook and run from the first cell. Existing acquisition identity remains compatible (`mlp-colab-media-v2`); existing failed checkpoints remain visible with `RETRY_FAILED=False`. Format diagnostics still execute independently. Keep all notebook outputs via **File → Download → Download .ipynb**. No result ZIP is needed.

## Unresolved questions

The prior user run failed all 10 downloads with unavailable-format errors. Live format inventory and complete extractor warnings are required to identify the cause; this change exposes them rather than guessing or altering the selector. Successful video acquisition, actual Colab interruption behavior and source alignment remain unverified.
