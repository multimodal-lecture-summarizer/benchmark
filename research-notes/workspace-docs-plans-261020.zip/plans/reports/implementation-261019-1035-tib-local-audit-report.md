# TIB summarization — thực thi foundation P1

Ngày19/10/2026, bắt đầu10:35 Asia/Bangkok. Windows/PowerShell, host16GB RAM; chưa xác minh T4.

Đã bắt đầu thực thi theo [plan hiện tại](../261019-0035-summarization-model-benchmark/plan.md), không thiết kế lại nghiên cứu. P1 in-progress; P2–P5 pending.

## Đã triển khai và kiểm chứng

- Offline audit CLI đọc snapshot local, checksum, Parquet footer/schema/counts và provenance columns. Không dùng dataset loader/network/download/model. Missing shards→observed counts null; không dùng declared README counts thay measurement.
- Snapshot input bất biến; output phải là thư mục mới ở ngoài snapshot, không overwrite. Hash cùng stable file handle trước/sau audit và kiểm file identity; input đổi giữa audit→fail.
- [Latest export receipt](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/audit-261019-1035/audit_receipt.json) có completion marker, checksums của ba JSON và tool hashes; tất cả unsealed. Export lần đầu trước completion-marker enhancement được giữ ở root registry như lịch sử.
- [Registry](../../benchmark/experiments/registry/models/tib-summarization-pipelines-v1.json) có Lead-3/LexRank/BART/LED/Qwen3. Shared comparison contract sinh5 candidate IDs/10 contrasts; recommendation/config-search set chỉ4 model families. Lead-3 fixed CPU; output cap/profile revisions/scorer-ready chưa khóa.
- Helper reference đề xuất: nonempty unreviewed→B; B flagged-but-eligible chỉ nếu rights và structure là explicit boolean PASS. Nonempty A/C cần pre-outcome evidence; empty→C. Không nhận model metrics. Đây chưa phải calibrated/frozen P3 policy hoặc adjudication225 flags.
- Code-review sửa rồi recheck PASS: truthy-string gate bypass, mutable expected counts, nested sidecar schema, checksum/file-version race, output-inside-snapshot boundary.

## Kết quả audit local thực tế

[Manifest](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/audit-261019-1035/dataset_manifest.json): cached revision directory `e6ab9fd7c6acd164f3284b8c4b17eb9d94681eee` có README, không có native data shards. Card bytes/checksum đã ghi, nhưng directory name không tự xác minh remote revision/file binding. Observed train/valid/test đều null; chưa có per-record rights evidence.

| Gate | Trạng thái thực tế |
|---|---|
| G1 Dataset | HOLD: thiếu shards/count/schema measurements, remote binding và text/abstract reuse review |
| G2 Qualification | Pending: helper semantics có tests; rubric/calibration/225 flags/group/exposure chưa thực hiện |
| G3 Cohort | Pending:0 selected IDs, chưa seal40/300 hoặc200 |
| G4 Scorer/model | Pending: development registry có5 IDs; chưa profiles/revisions/W_global/scorer-ready |
| G5 Compute | Pending: chưa T4/capacity/call-tail/storage/quota/checkpoint pilot |

Các truy cập web đến pinned HF API/card và HAL trong lượt này không thành công; không có evidence remote/paper mới được xác minh. Cached README mô tả creator abstract có độ dài/style/quality khác nhau; không suy rights hoặc factuality từ đó.

Kiểm thêm các dataset directories hiện có và HF downloads metadata: hai cache metadata entries TIB đều trỏ README của cùng revision, chưa tìm thấy native TIB shards trong các vị trí đã kiểm. Không coi đây là tìm kiếm toàn bộ ổ đĩa hoặc bằng chứng dữ liệu không tồn tại ở nơi khác.

## Validation

Từ `benchmark/`:

```powershell
python -m pytest tests/test_tib_model_benchmark_contract.py tests/test_tib_model_benchmark_snapshot.py tests/test_rq2_tib_benchmark_dataset.py -q
```

**34 passed.** Tests dùng real temporary Parquet/schema/files/subprocess CLI; có regression input mutation, gate type, no-overwrite, snapshot containment, completion hashes và five-ID contract. Legacy dataset tests vẫn pass; legacy runner chưa bị sửa. Không chạy toàn bộ suite hoặc neural models vì thay đổi chỉ ở các modules mới độc lập.

Strict plan CLI valid/0 issues: P1 in-progress, P2–P5 pending.65 local links trong9 tài liệu đều resolve; `git diff --check` sạch. Readback receipt đối chiếu3 exported JSON và3 tool hashes:0 mismatches. Không đánh dấu acceptance P1 hoàn tất từ các kiểm tra phần mềm này.

P1 chưa hoàn tất; schema/card audit không chứng nhận canonical row normalization/offset trace, source-group safety hay reuse rights. Chưa triển khai adapter, actual coverage masks hoặc evaluator; chưa EDA gap-closure, generation, selection, final benchmark, T4 pilot, download, commit/push. Native test và historical120 evidence giữ nguyên.

## Còn cần giải quyết

Có native shards đã được phép dùng hoặc đủ evidence để lấy chúng; đối chiếu remote SHA/file hashes; xác minh transcript/abstract reuse và paper provenance. Sau đó mới đo schema/counts/normalization trên dữ liệu thực và chuyển P2/P3. G4/G5 cần scorer/profile và T4 measurement, không thể suy từ34 unit tests.
