# R5 full inference audit and one-checkpoint recovery preparation

Source: C:/Users/hung/Downloads/cvid-spotting-t4-261015-v2-r5-evidence (1).zip
SHA256:fadb656015d797af4d8a383082c0a45bf19be334b6b6b2ea334b62df54bf6de3
31,667,630bytes;10,628 unique ZIP members;CRC and exact export membership/file hashes all passed.

All six candidate aggregates contain exactly1,754 records in frozen cohort order (10,524 total), all status=ok. Aggregate bytes match each completion SHA. Gate/train-replay/run-identity/completion bindings agree, including runtime hashes; prepared/config/source digests match current R5 code and frozen six-candidate registry. Prepared-data matches original1,754 frames/40,063 GT, all7 scientific bindings and current bundle-manifest digest.

10,523 checkpoint files equal their canonical record wrappers rebuilt from sealed aggregates, including frame image hash, binding and record SHA. One exported checkpoint is0bytes:

doctr_fast_base_parseq_t4/records/Frames/test/14/18/00_02_05_00001.png.json

DocTR aggregate SHA:a0c67b6c66cebfd402facaadd81c706f1b856de28ce237849989a639f1999efe
Canonical reconstruction:3,158bytes;SHA ce3e6fddb2e6d7ed09cca3196eaba7c21b90795c74ccfff27779999cbfba8222
Its original prediction is recoverable from the sealed aggregate. No claim establishes whether persistent truncation or a transient Drive read produced the empty export; script treats an already intact target as no-op.

Prepared standalone docs/recover-cvid-r5-doctr-checkpoint.py (SHA eb37609abaebe9740a162c5296b73f4f32f9d59cadbf29f6189fb4251029fd4d). Checks no live runner/worker and no execution lock; verifies exact audited receipt/data bytes and aggregate hash/IDs; reconstructs only the known frame; requires target empty or already identical, rejects other nonempty content. Preserves zero-byte original and recovery journal outside records, atomically replaces only known empty target, verifies readback and records completion. Changes no bundle/weights/config/seals/predictions; no OCR/model runs. Recovery is user-operated on Colab, not applied here.

Four local tests passed: exact restoration and idempotence; changed aggregate rejected; changed nonempty checkpoint preserved; execution lock blocks write. Audit artifacts in benchmark/experiments/outputs/cvid-r5-checkpoint-recovery-261016/. Existing R5 bundle/notebook hashes unchanged.

After RECOVERY PASS or ALREADY VERIFIED, continue original notebook scoring cell; scorer independently validates all checkpoints, aggregate equality and frozen bindings. Do not rerun Full cohort inference. Keep original run failure ledger as history; it is not a per-frame OCR failure. Export new final evidence after scoring/plots.

Unresolved: exact cause/time of empty read unknown; Colab repair/readback and full scoring/metrics pending. Zero status=error records does not imply correct OCR text/geometry. No winner established.
