# Miro sync — actual scorer/recovery and prepared Pilot40

Updated existing [Đề tài TTTN & DATN board](https://miro.com/app/board/uXjVHLTov6k=/), keeping historical TIB120 and other tasks separate. No new board, deleted items or access changes.

## Published status

- [RQ2 research detail](https://miro.com/app/board/uXjVHLTov6k=/?moveToWidget=3458764686684583693): actual Colab T4 scorer-ready PASS21outputs/105finite metrics; actual fresh-session v2 recovery PASS123nodes/21outputs and21scorer reuses, zero new calls. Historic v1 HOLD remains historical.
- P4d Pilot40 is **prepared, not executed**:144local tests PASS; unchanged40 sources/five profiles/cap350; planned200cells split9verified historical neural imports +111fresh neural +80fresh CPU. No model winner or selection/final claim.
- User allocation: cumulative11.5GPUh/23CPUh/11.5active-wallh, maximum2sessions,15%headroom; Drive2GiB, localfree32GiB distinct from workingcap24GiB, transfer16GiB. Scoring1.5GPUh/3CPUh and restore0.5wallh are inside totals. Zero automatic retries; partial retains cohort40.
- Scorer metrics/window/tokenizer/IDF=false unchanged. Actual T4/storage/quota checks, pilot execution/measurements/scoring, admission and full-study projection remain pending. Selection300 and final523→500→400 remain gated. The2–4h duration is only an operating estimate.
- [Research overview](https://miro.com/app/board/uXjVHLTov6k=/?moveToWidget=3458764686684081699): RQ2 card, subtitle and current footer reflect the same status. Historical19/10 heading explicitly marked historical.

## Verification

First update:2created/5updated/0deleted, no failed items. Final layout update:1updated, no failures. A sparse position/frame patch was rejected by automatic review as potentially blanking text/shrinking content; it was not applied. The safe update kept frame size and full text unchanged while moving the body using a complete latest-read SVG. No blocked action remains.

Readback confirms four historical images retain exact SVG attributes/positions; current title is y3307,h56, body y3420,h754, leaving57px between them and826px to the frame bottom. Current body stays within the existing3200×5000 frame; TIB120 frame below remains separate. Other task cards/content preserved. Board preview published successfully (`preview_available=true`).

Commit scope: reviewed benchmark implementation/notebooks/compact evidence and an updated outer docs/plans archive; private research-data/export ZIPs remain ignored. No inference/scoring rerun or push requested.

## Open

Actual Pilot40 Colab preflight/execution and returned evidence; later pilot scoring, admission/profile/cap final-lock and full-study budget before selection300/final test.
