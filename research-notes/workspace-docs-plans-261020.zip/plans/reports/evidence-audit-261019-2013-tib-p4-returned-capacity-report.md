# P4 — audit ZIP feasibility do người dùng chạy trên Colab

**Kết quả: scoped T4 capacity PASS cho BART/LED/Qwen3 trên ba staged pilot sources. Chưa formal admission, chưa hoàn tất pilot40 hoặc khóa cap/profile.** Không chạy lại inference, benchmark hay reference scoring trong lần audit này.

## Evidence và tính toàn vẹn

- ZIP người dùng cung cấp: `tib-p4-evidence-20261019T131542Z.zip`,266.844 bytes; SHA256 `46ad3fb937f7089839865e7a35ff14a63e90f9f0b15490c156d715c7265e7abb`.
- ZIP CRC và toàn bộ159 manifest files PASS;155 JSON envelope digests PASS;4 logs khớp receipt status. Bản gốc, extracted outputs và audit script/result giữ trong ignored `benchmark/research-data/tib-p4-261019-1802/returned-evidence-20261019T131542Z/`; ZIP không đưa vào Git.
- [Capacity observations](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/capacity_observations_v1.json) và [technical execution receipt v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/technical_execution_receipt_v2.json) là evidence hiện hành, thay trạng thái preparation/OAuth-pending trước đây. Receipts và bundles lịch sử không sửa.
- Ba IDs đúng cohort đã seal: `valid:644`, `valid:341`, `valid:886`, thuộc pilot40, không thuộc selection300. Sources197/4.321/20.409 whitespace words; không đưa reference vào generation hoặc audit scoring.
- Offline replay dùng pinned local tokenizers, prepared bounds/wrappers và **stored generated tokens/text**, không gọi model. Cả9 neural outputs khớp input hashes, source lineage, checkpoint keys, attempts, delivered selector và output hashes. Cả67 neural node calls xác minh native token reserves và CUDA receipts. BART/Qwen bind bundlev2; LED thành công bind bundlev3. Algorithm modules không đổi giữa hai bundles.
- Hai CPU smoke artifacts có12 outputs (hai lượt lặp của cùng6 candidate-record pairs), không phải12 unique records. Lead-3/LexRank selected sentences và delivered output/hash khớp replay; floating sentence scores LexRank kiểm với rel_tol1e-12/abs_tol1e-15. Không suy CPU peak RAM từ neural RSS.
- Returned assets ghi hashes model/config/tokenizer; pinned tokenizer bytes khớp independent local tokenizer receipts. Audit không tải lại weights để kiểm độc lập weights bytes với official repository. Model revision/profile identity và actual generation artifacts đã đối chiếu; không nâng claim thành độc lập tái lập inference.
- Publication readback PASS: raw/aggregate SHA bindings, cohort/profile identities, YAML và21 evidence links.6 focused checkpoint/budget-receipt regression tests PASS. Python phát nonfatal `pyreadline3 Console.__del__` warning khi thoát trên Windows; test process exit0, không phải lỗi Colab/model.

## Đo được trên T4

| Model | Success | Nodes map/reduce/final | Peak RSS GiB | CUDA allocated/reserved GiB | Load seconds | Total seconds |
|---|---:|---:|---:|---:|---:|---:|
| BART | 3/3 fresh | 31/5/3 | 2,99 | 1,00/1,08 | 23,34 | 81,75 |
| LED | 3/3 fresh | 9/2/3 | 3,35 | 1,73/2,17 | 27,62 | 108,30 |
| Qwen3 | 3/3 fresh | 9/2/3 | 5,88 | 11,72/13,23 | 165,31 | 446,95 |

Tesla T4, torch.float16; torch2.11.0+cu130, transformers4.57.6, huggingface-hub0.36.2, numpy2.1.3. RSS sampled process peak; CUDA peaks include load. Total seconds gồm snapshot/load và generation cho ba nguồn, không phải steady-state throughput. GPU total memory/host available RAM/driver và một số dependency versions chưa được receipt ghi đủ; không tự điền từ nominal T4.

Qwen cần giữ tải model/scorer tuần tự. Chưa có cơ sở coi13,23GiB reserved là headroom bảo đảm cho mọi context/output hoặc config khác.

LED failure đầu `capacity-1792414388613396545.json` xảy ra trước load do thiếu `.bin`,5,43s, giữ nguyên lịch sử. LED success `capacity-1792415490815698217.json` khớp corrected downloader. BART success `capacity-1792414297487990724.json`; Qwen success `capacity-1792414400687501832.json`. Không cộng failure vào successful output denominator hoặc xóa retry cost.

## Output cap, native reserves và chất lượng development

[Development review](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/development_output_review_v1.json) ghi các flags trước selection:

| Model | Delivered words short/medium/long | Map256 exhausted, no EOS | Reduce256 exhausted, no EOS |
|---|---:|---:|---:|
| BART | 61/44/63 | 0/31 | 0/5 |
| LED | 234/211/126 | 4/9 | 0/2 |
| Qwen3 | 94/136/153 | 6/9 | 2/2 |

Cả9 final nodes kết thúc EOS dưới reserve768;0/9 delivered outputs vượt/cắt bởi cap350;0 forced-word-boundary. Điều này không chứng minh intermediate notes không bị cắt: LED và Qwen có reserve exhaustion trước EOS như bảng. Giới hạn350 là maximum, không target, không ép output đủ350 từ.

- LED `valid:341` lặp cụm “the role of women in open source”21 lần và kết thúc giữa cụm. `valid:644` dài234 từ trên nguồn197 từ, lặp và kết thúc “and there are a number of”. `valid:886` lặp câu cuối. Đây là diagnostic flags trên development; chưa có formal chất lượng/factuality labels hoặc tỷ lệ tổng thể.
- BART `valid:886` final bằng chính xác first map output, SHA `f44e760f1828b273a3aeb2647d80643f8167c909ad282100ac9f10b944717faa`. Token lineage có toàn bộ25.895source tokens, nhưng equality này cho thấy nguy cơ mất nội dung qua reducer. Không đồng nhất input coverage với semantic preservation.
- `resolved_generation_config` trong receipt là **base defaults trước kwargs overrides**, không phải merged effective config. Qwen base temperature/top_p0.6/0.95 bị profile kwargs0.7/0.8 ghi đè. Cần lưu effective stage config rõ ràng trước final freeze; không đổi decode từ audit này.
- LED warning `25895 >16384` do tokenization toàn source. Offline replay xác nhận actual prepared generation inputs theo profile≤4096; không có full25.895token model call. TensorFlow CUDA warnings không phủ định actual CUDA generation.

Giữ p95-derived cap350; **chưa khóa cuối cùng** khi output/reserve review và formal profile admission còn mở. Không đổi model family, bỏ record, giảm cap hay tối ưu bằng selection/test outputs. Profile amendment nếu cần phải version trên development, giữ toàn bộ trial evidence và đo lại capacity cho config mới.

## Store, budget và trạng thái nghiên cứu

[Mounted-store evidence](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/mounted_store_evidence_v1.json) xác minh6 probes và integrity/readback của returned artifacts. Đã có write/fsync/rename/readback trên Drive; **chưa chứng minh fresh-runtime reuse/cross-session survival hoặc storage quota**. Không dùng việc ZIP tải về được để tự coi mọi durable checkpoint gate PASS.

`measured_profiles.json` giữ empty vì schema đó yêu cầu projection-ready support/stratum bounds/capacity fields; không gán p95/upper bound từ một record mỗi stratum. Observed per-record costs đã lưu riêng trong capacity observations. [Compute budget v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/compute_budget_v2.json) cập nhật observed store gates và bind capacity observations; [projection status v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/projection_status_v2.json) đã chạy verifier và vẫn REQUIRED_NO_START do thiếu gate receipts. Còn thiếu tổng quotas, storage, đầy đủ trials, scorer cost và conservative projection. Original budget/projection snapshots giữ nguyên. Không ngoại suy81/108/447s cho523 records. Chuỗi ưu tiên523→500→400 giữ nguyên,40 diagnostic cases nằm trong final cohort.

P4 vẫn in-progress, P5 pending;40 pilot/300 selection và523 eligible-test frame không đổi; final test unsealed. Ba mẫu là staged capacity, không phải completed pilot40. Không model winner hoặc quality ranking mới.

## Còn mở

1. Development review repetition/semantic attrition và intermediate reserve policy; version config amendment nếu cần, ghi merged effective generation/runtime identities.
2. Pilot đại diện/tail measurements trong ngân sách được cấp; không coi một mẫu mỗi stratum là bảo đảm p95 hoặc power.
3. Scorer trên formal runtime và throughput/cost; fresh-session Drive restore/reuse, storage quota.
4. Tổng ngân sách CPU/GPU/session/storage, trial accounting và projection; profile/cap final-lock trước selection. Sau lựa chọn hai tầng mới final cohort/diagnostic seal trước test generation theo protocol.
