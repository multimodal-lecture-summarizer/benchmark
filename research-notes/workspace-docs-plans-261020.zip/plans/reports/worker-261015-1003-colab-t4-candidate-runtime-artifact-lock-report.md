# Colab T4 candidate artifacts and isolated runtime preparation

Date: 2026-10-15. Scope: six-candidate registry, five practical adapters, conditional TESTR adapter/build gate, acquisition, isolated package environments and subprocess entry point. No local CUDA/T4 execution occurred.

## Delivered

- New `iiit-cvid-spotting-colab-t4-candidates-261015.json` contains six scientific selections; five have expected model hashes, TESTR remains explicitly conditional and blocked.
- Original EasyOCR1.7.2 and PaddleOCR2.8.1 package wheel hashes, model bytes, calls, thresholds and native grouping retained. Execution explicitly changes to CUDA FP32, disabling Easy dynamic CPU quantization and Paddle MKLDNN. No old CPU predictions are reused.
- docTR0.12.0 `fast_base` and `parseq` checkpoints downloaded from author URLs and fully SHA256 hashed: `688a8b3489e9f5d0290c476c6272ec3b18de3ee646c8a0dc158203b1a9c62ace` / `56125471b17e660253c4179c3fbf3c906c34606d898148895dbb84db257d98ba`. Source tag resolves to commit `97d4006d00447ecbaee00a8a3b4882d6e6ce1eea`. Both orientation predictors explicitly disabled; official source confirms disabled predictors load no auxiliary weights. Original framework defaults otherwise require extra orientation checkpoints even with `detect_orientation=False`.
- Tesseract `tessdata_best/eng.traineddata` downloaded at commit `e12c65a915945e4c28e237a9b52bc4a8f39a0cec`, SHA256 `8280aed0782fe27257a68ea10fe7ef324ca0f8d85bd2fd145d1c2b560bcb66ba`. Native TSV word output uses OEM1/PSM11, keeping empty/low-confidence words. Exact Tesseract5 system executable and linked library bytes are sealed during Colab preparation; binary is not currently supplied/verified locally.
- PP-OCRv6 medium model repositories pinned to author HF commits: detector `8e0f56fb2ef86b461d99cfc7ac5c137738985f61`; recognizer `e5a92bcbc5cc1b494628e458d267778f0704fd7c`. Expected parameter SHA256 from author LFS metadata `85218d2e3d98f5a21c58b4220627be923a97aee5db3cc71f39536ab31ac53960` / `1b01c79a914587933f615569e75de54f2e638ebb5d3f3b3c1b38c24ede8c7319`. `inference.json` and `inference.yml` downloaded and hashed for both models. Parameters will be downloaded and verified in Colab; they were not downloaded locally.
- Model environments use managed Python3.10.16, fixed direct package requirements, Torch2.5.1+cu121 or separate Paddle2.6.2/Paddle3.3.0 cu118 environments. Official Paddle index verified the actual Python3.10 Linux GPU wheels. Score environment uses Python3.11.11, preserving Unicode14 normalization; matplotlib3.10.1/numpy1.26.4/Pillow11.1.0/shapely2.0.7 fixed.
- First Linux `prepare` resolves remaining transitive dependencies, retains all wheels, hashes every wheel and installed distribution file, checks `pip check`, and seals before train preflight. These transitive graphs are not claimed pre-resolved locally. `SPOTTING_CACHE_ROOT` persists wheelhouses and seals to Drive; a fresh session reconstructs offline and refuses any installed digest mismatch. Persistent scoring environment follows the same mechanism.
- Legacy Paddle2.6.2 PyPI metadata has no native CUDA wheel dependencies. Explicit CUDA11.8/cuDNN8/cuBLAS/cuFFT/cuRAND/cuSOLVER/cuSPARSE/NCCL wheels are added to its environment, with verified package versions. `prepared.library_paths` exposes venv NVIDIA library directories; orchestration must prepend them to `LD_LIBRARY_PATH` before launching Python. Modern Paddle3.3 uses its own resolved GPU native dependencies, avoiding a forced legacy cuDNN8 downgrade.
- Worker checks model/config/package binding before loading, requires T4 for neural candidates and sends actual model runtime fingerprint to root durable train-preflight/checkpoint callback. Weight download cannot silently accept changed bytes; archive traversal and symlinks fail closed.

## TESTR outcome and gate

Official TotalText polygon checkpoint URL returned HTTP403 on 2026-10-15. A full model SHA256 could not be authenticated/acquired. Therefore TESTR is **not verified, not prepared and not comparison-eligible**.

Pinned TESTR source commit `f369f138e041d1d27348a1f6600e456452001d23` and Detectron2v0.6 commit `d1e04565d3bec8719335b88be9e9b961bf3ec464` are verified upstream. Actual conditional adapter uses native polygons and the author's `_decode_recognition` function, with no lexicon. Legacy build path requires Python3.8.20/Torch1.10.1+cu113 and actual nvcc11.3 before compiling Detectron2/AdelaiDet custom ops; incompatible current Colab toolkits fail closed.

`lock_testr_checkpoint` creates a new registry from a recovered checkpoint and declared author provenance, never overwrites the current registry. A byte hash alone does not authenticate provenance. A recovered artifact still requires the actual source build, model loading and train-frame polygon/transcription forward pass before test access. No arbitrary alternative checkpoint or test-score-driven replacement is permitted.

## Verification

Five focused contract tests pass: six-selection/TESTRblocked status; empty/low-confidence TSV observations; unlocked/changed artifact rejection; archive traversal rejection before extraction; new immutable TESTR recovered-artifact registry behavior. New modules compile. No dependency installation, model inference, T4 preflight or TESTR build was performed locally.

Network DNS failed inside the restricted sandbox. Read-only official metadata/weight acquisition succeeded with escalation. Web raw-source cache fetches also failed; direct official HTTPS source reads were used. Author TESTR checkpoint remained HTTP403.

## Primary evidence

- [docTR0.12.0 FAST source](https://github.com/mindee/doctr/blob/97d4006d00447ecbaee00a8a3b4882d6e6ce1eea/doctr/models/detection/fast/pytorch.py), [PARSeq source](https://github.com/mindee/doctr/blob/97d4006d00447ecbaee00a8a3b4882d6e6ce1eea/doctr/models/recognition/parseq/pytorch.py), [orientation disabled path](https://github.com/mindee/doctr/blob/97d4006d00447ecbaee00a8a3b4882d6e6ce1eea/doctr/models/classification/zoo.py).
- [Tesseract TSV/OEM/PSM](https://tesseract-ocr.github.io/tessdoc/Command-Line-Usage.html), [fixed English traineddata](https://github.com/tesseract-ocr/tessdata_best/blob/e12c65a915945e4c28e237a9b52bc4a8f39a0cec/eng.traineddata).
- [PP6 detector revision](https://huggingface.co/PaddlePaddle/PP-OCRv6_medium_det/tree/8e0f56fb2ef86b461d99cfc7ac5c137738985f61), [PP6 recognizer revision](https://huggingface.co/PaddlePaddle/PP-OCRv6_medium_rec/tree/e5a92bcbc5cc1b494628e458d267778f0704fd7c), [official GPU cu118 wheel index](https://www.paddlepaddle.org.cn/packages/stable/cu118/paddlepaddle-gpu/).
- [TESTR author checkpoint table and code](https://github.com/mlpc-ucsd/TESTR/tree/f369f138e041d1d27348a1f6600e456452001d23), [Detectron2 fixed release](https://github.com/facebookresearch/detectron2/tree/d1e04565d3bec8719335b88be9e9b961bf3ec464).

## Unresolved

- Actual Colab T4 package resolution/import/forward behavior for all neural candidates.
- Exact Tesseract5 system binary/version on supplied Colab VM and whether binary/libraries remain identical on future sessions.
- Recovery/authentication of author TESTR checkpoint and compatible CUDA11.3 build environment. TESTR cannot currently enter comparison.
