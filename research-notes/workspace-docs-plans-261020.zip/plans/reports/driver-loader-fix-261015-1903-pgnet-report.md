# PGNet host driver lookup correction

Historical preparation snapshot. Current delivery was consolidated into canonical ZIPs; superseded variant files were deleted by user request. See [current guide](../../docs/cvid-joint-spotting-colab-t4-run-guide.md) and [cleanup record](../../docs/pgnet-delivery-cleanup-261015.md); old hashes below describe their dated snapshot.

User diagnostic attachment `0c2b8be5-6b2b-4665-9c94-6422acd80f59/Pasted text.txt` establishes paired evidence on the same runtime: TeslaT4/driver580.82.07 present; exact worker loader cannot load libcuda.so.1 or libcuda.so, CUDA runtime count returns35, PaddleGPU2.6.2 CUDA11.8 sees0 devices. Adding inherited `/usr/lib64-nvidia` makes both driver libraries load, cuInit=0, driver count=1, CUDA runtime count=1/code0 and Paddle count=1. The driver-version error was downstream of missing driver library lookup, not evidence requiring driver downgrade.

Root cause: both qualifier and full-comparison launcher replaced LD_LIBRARY_PATH with wheel library paths, discarding host driver lookup. Shared helper now keeps wheel paths first, appends inherited paths, removes duplicates/empty linker entries. Runtime native binary sealing remains intact. No package, weight, candidate config, threshold, grouping, frame or GT changes.

Validation:14 bootstrap/loader/candidate/PGNet contract tests plus15 checkpoint/notebook tests passed (29total). Delivered notebooks and repair cell parse without cell execution. Repacked ZIPs differ only in three launcher/environment Python files plus manifest; all other members identical to previous bootstrap-fix release. No agent-run model inference, GPU operation or package installation.

Qualification driver-fix SHA256: `ee6c45d306f9684299cc0eb0492ffe962b1f3ac03cc0b31c2d3019456e01eb0a`.

Comparison driver-fix SHA256: `d0b1d32d6a5cc3df2202e275494db5d94d9e0cba3939b5d06a8b35cbec31e555`.

User-run repair cell validates exact ZIP/members/train cohort, preserves failed evidence in history, refuses modification of a preflight-sealed run, updates runner code/manifest and reuses existing sealed environment and weights. User then reruns original Step4, checks receipt, displays predictions and exports. New-runtime workflow uses updated notebook/driver-fix ZIP.

Unresolved: genuine PGNet model loading/forward on nine train images and full bound receipt remain pending. Paddle device visibility alone does not prove model inference readiness or test accuracy.
