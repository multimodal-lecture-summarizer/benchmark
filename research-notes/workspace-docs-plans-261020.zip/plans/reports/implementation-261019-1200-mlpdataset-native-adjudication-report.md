# MLPDataset: sampled event mapping and native-frame handoff

2026-10-19. Preparation complete. Actual native research-frame extraction and endpoint adjudication remain pending on Colab.

## What is now resolved

Reviewed every displayed frame in the **33 distinct sampled sequences** from the completed48-context run, including the matching repeated sequences. The source-bound ledger preserves all82original identities and original line numbers. Manual observations are pinned to the exact reviewed receipt SHA, explicit case key, source SHA, released timestamp and sampled PTS/frame-hash sequence; reordered or replaced evidence fails closed before any judgment is applied.

Within the newly extracted contexts, recorded **37 observed changes:33 primary instructional-replacement candidates and4 auxiliary changes**. These are diagnostic observations, not native-certified GT. The six historical instructional candidates remain a separately identified coarse evidence layer and are not added to the37 count as if newly inspected native events. The ledger and CSV retain every original row; no labels were deleted, sorted or retimed.

The14 repeated-sequence groups now have explicit mapping proposals:

| Proposal | Groups | Meaning |
|---|---:|---|
| Shared single primary event | 11 | Multiple original rows point toward one observed replacement; a proposed relation, not automatic deletion |
| Multiple events, mapping unresolved | 2 | Fast dental changes and optimization title/agenda contain distinct events; timestamp equality does not prove duplicate events |
| Auxiliary only | 1 | References/presenter/credits episode does not supply a primary instructional replacement |

Original-row proposals total50target-after-qualification,8non-target and24held. These are counts of original rows, including repeats, **not50distinct events**. All82 official dispositions remain HOLD and native endpoints remain null until endpoint/mapping qualification.

## Important evidence

- `-a5-EHnZ_XA`: Diffuse→Focal→Diffuse→BRONJ. Intersected old/new observations across overlapping sampled windows while preserving all three event identities.
- `E_3gxQWaCoQ:24/25`: plot→instructional section title→agenda. Two changes inside the repeated-timestamp context; original-to-event mapping still proposed.
- `KDVP_WAIUXs:5`: Appliance→Crossbite→Appliance. Matching first/last images cannot reduce this to no change.
- `NQtXvfJCtxo:1/2`: figure changes on the Skull page are kept auxiliary; the subsequent full Cranium page replacement remains a separate primary candidate.
- `2xr4P0WGKSA:26` and `37z_tJD81y8:68`: old content remains beyond the primary0.5s collar after the released time. Their sampled brackets are retained without midpoint repair or global timestamp shift.
- Same-heading pages in nutrition, cell structure and caption evaluation replace their body content. Heading equality alone is not an event rule.
- Outright source starts, final-source context and credits remain separate from instructional replacement. Twenty additional source-edge cases retain policy HOLD; native EOF footage will not establish media-edition equivalence by itself.

## Next notebook

[CPU native-frame notebook](../../benchmark/experiments/notebooks/diagnostics/mlpdataset-native-review-colab.ipynb),16cells,246032bytes, prepared and unexecuted. Use the existing Drive account and `RUN_NAME=mlpdataset-eda-261017-v3`; Run all. No video acquisition, package install or inference.

Its frozen queue has **64 extraction jobs across38sources**, touching75original rows and retaining statuses for all82. The seven unselected rows already have historical non-target/start/end context; they remain visible and unqualified where necessary. Overlapping extraction windows are merged, while all event IDs and row identities remain separate. Requested window lengths total123.653seconds; this is video duration, not a runtime estimate. Six historical target windows are re-examined, and the unresolved ALRJ blank context extends7seconds beyond its previous window.

Native means every temporal presentation frame, including identical consecutive frames; diagnostic PNGs are resized to480px width. Independent ffprobe presentation PTS must match the complete extracted sequence. Exact integer-PTS half-open windows, nonzero stream origin and VFR are supported. A bounded5s read tail accommodates packet reordering, with only requested frames retained. This validates temporal extraction; it does not classify the last old frame or certify GT automatically.

Inputs and both executed notebooks remain read-only. Outputs go to a separate sibling `<RUN_NAME>-native-review-v1`. Defaults:60minutes,0.75GiB review output,1GiB free-space floor,2GiB staging and128MiB inline image payload. Images are230px lazy previews in collapsed scrollable galleries. Every retained frame has a PTS caption. If the image budget is exceeded, omitted inline images are explicitly counted and their retained paths remain visible; logs/captions are additional output. Extraction and display statuses stay separate.

Source, protocol, original annotation/evidence hashes, job bounds and configuration bind each checkpoint. Completed outputs are hash-validated before reuse; source bytes are checked once per source/session and fingerprints rechecked. All-job and all82-row receipts are persisted before work, per job and on interruption. Manual templates stay HOLD/null. Do not run simultaneous writers into the same new review folder.

## Verification and review

Final combined local run: **54 tests plus4subtests passed in21.19s**, exit0. Independent reviewer also ran54+4 in28.89s, before the final gallery-budget tuning; the final combined run covers that tuning. Tests cover real FFmpeg known cuts, VFR, nonzero origins, consecutive identical frames, exact PTS cadence, cache corruption/source changes, resource/deadline/interruption cleanup, all-job/all82 persistence and standalone notebook-cell execution. Observation-binding tests reject receipt/order/source/time/frame-PTS/hash drift. Coverage was not measured. An early root-CWD test attempt failed scorer import setup and was rerun correctly from benchmark; an earlier Windows console-finalizer warning occurred after passing parent tests, and the final run completed cleanly.

Independent final review PASS after correcting observation-to-receipt provenance binding. The current33 dedup groups were checked not to cross source identities. Existing sparse extraction/scoring tests remain passing. Docs, guide, manifest and master plan synchronized;103local Markdown links and YAML parse checked. No changes to application logic or frozen protocol rules.

Native notebook SHA256 `779fd7a00ca8a2d9549d356ca4d4c1f4f33ef95decbab418c4e34379c0cc42ef`; queue `d4d75bf8b791abc5436edf2a938442eacd2a1e42fa83f4614813ce2d5c54e97e`; ledger `0754c88ed1aaf99f2d030f878d736190cbaa9a895c453909d9bbb509837a5815`. Both executed evidence notebook hashes remain unchanged.

Artifacts: [82-row CSV](../../benchmark/experiments/registry/datasets/mlpdataset-sampled-adjudication-v1.csv), [bound ledger](../../benchmark/experiments/registry/datasets/mlpdataset-sampled-adjudication-v1.json), [native queue](../../benchmark/experiments/registry/datasets/mlpdataset-native-review-queue-v1.json), [final test receipt](../../benchmark/experiments/outputs/mlpdataset_native_review_261019/local-validation/final-test-receipt.json). Workflow finalize gate PASS, exit0, with all five required artifacts. No commit/push or research-native execution performed.

Unresolved: actual64-job Colab execution; native last-old/effect endpoints and repeated-row mapping qualification; source-edition equivalence; full-scope annotation completeness, dependence/provenance and GT/cohort/split freeze. No additional user clarification required for this preparation delivery.
