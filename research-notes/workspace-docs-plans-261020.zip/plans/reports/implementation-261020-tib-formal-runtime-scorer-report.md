# P4 formal-runtime scorer — implementation complete, execution HOLD

Implements [protocol-decision-261019-2341](./protocol-decision-261019-2341-tib-development-close-acceptance-report.md). **No actual Colab scorer execution has occurred. Formal-runtime readiness remainsHOLD.**

## Delivered

- [Colab T4 notebook](../../benchmark/experiments/notebooks/tib-p4-scorer-colab-t4-261020-v1.ipynb):12 cells/6code cells, execution countsNULL, outputs empty; outer ZIP and file hashes checked before execution. Latest-run markers prevent a historic PASS from certifying a failed current attempt.
- Local private ZIP: `benchmark/research-data/tib-scorer-colab-runtime-261020-v1/tib-scorer-colab-runtime-261020-v1.zip`,361437bytes, SHA256 `b24cf8d737d0c822305b8c2698155f8b36a59a434f08fc57de622e2d6eb0d9e4`.
- [Versioned runtime amendment](../../benchmark/experiments/registry/protocols/tib-scorer-colab-runtime-261020-v1/runtime_amendment.json), [pinned direct requirements](../../benchmark/experiments/registry/protocols/tib-scorer-colab-runtime-261020-v1/requirements-colab-t4.txt), [prepared scorer receipt](../../benchmark/experiments/registry/protocols/tib-scorer-colab-runtime-261020-v1/scorer_ready_receipt.json), [HOLD report](../../benchmark/experiments/registry/protocols/tib-scorer-colab-runtime-261020-v1/PASS_HOLD_report.json) and [unmeasured metric/cost status](../../benchmark/experiments/registry/protocols/tib-scorer-colab-runtime-261020-v1/metric_cost_evidence_status.json).
- [Substage instructions and boundaries](../261019-0035-summarization-model-benchmark/phase-04b-formal-runtime-scorer.md).

The ZIP contains19 hash-bound files: frozen code/tests/spec/CPU receipt, new runtime modules, requirements, amendment, derived acceptance view and21stored outputs/references from the same three pilot IDs. No selection or test records, generation adapters or generation weights are packaged. Keep private; attribution/licenses, conditional source-use restrictions and allowed reference scoring are retained.

## Frozen scientific contract

ROUGE1/2/L F1, BERTScore and source sentence similarity retain the existing code/formulas, pinned models/tokenizers, sentence splitter, native capacities512/128, long-input direct-ID windows, full-source batching and IDF=false/no fit. The new CUDA adapter overrides loading/runtime verification; metric mathematics are inherited. FP32/eval/batch1/noautocast/TF32disabled. The exact CPU receipt and frozen scorer files remain unchanged.

Torch2.11.0+cu130 and NumPy2.1.3 match the observed generation environment rather than CPU proof2.6.0+cu124/2.4.6. This does not prove scorer compatibility. Direct runtime/support dependencies are pinned; all effective transitive versions are recorded and checkpoint-bound. Duplicate system/venv distributions resolve to the effective version. Official version metadata checked: [sentence-transformers5.7.0](https://pypi.org/pypi/sentence-transformers/5.7.0/json), [torch2.11.0](https://pypi.org/pypi/torch/2.11.0/json). Actual Colab installation/loading remains unverified.

All21 stored outputs/three sources are retained, including8clean+13warning under the unchanged derived acceptance policy. These are technical scorer E2E inputs, not21 independent sources or a config/family quality comparison. No model ranking/admission follows.350maximum and cohorts40/300/523 remain unchanged.

## Verification completed locally

**54 tests PASS**, exit0:35new runtime/backend/notebook guards and19frozen scorer/window regressions. One existing SentenceTransformer import deprecation warning; no test failures. Tests use controlled local encoders/faults, not downloaded scorer-model or actual Colab evidence.

Coverage: inherited methods unchanged; FP32/layer17/fast-tokenizer/IDF checks; native/long probes; five-metric identity; full-source batching; NULL/missing/nonfinite/semantic-exception behavior; warning retention; modified hashes/cohort/matrix rejection; checkpoint corruption/partial/missing handling;0new E2E calls on complete cached replay; resource/support-pin HOLD; effective venv versions; stale PASS notebook guard. Any dependency-injected test execution is explicitlyHOLD/scorer_readyFalse.

The real CLI was invoked locally with **no model asset directory**. It returned exit2/HOLD before model loading, retained21unattempted records withNULL metrics and reported0new scoring calls,0generation calls, actual_colab_executionFalse/T4False. [Local guard evidence](../../benchmark/experiments/registry/protocols/tib-scorer-colab-runtime-261020-v1/local-guard-evidence/scorer_ready_receipt.json) is clearly separated from Colab readiness. Its elapsed time is preflight cost, not model/scorer throughput.

All19 packaged files and outer ZIP/manifest/notebook bindings verified; all6code cells compile; frozen spec/code/CPU receipt hashes checked. No dataset/cohort/acceptance/historic receipt edits. No generation, selection300 or final test was run.

## What actual Colab will produce

Each actual attempt writes immutable per-run receipts and latest copies of `metrics.jsonl`, `cost_evidence.json`, `PASS_HOLD_report.json`, `scorer_ready_receipt.json`; artifact hashes are bound in the receipt. Actual fixtures include native equivalence≤1e-5, exact long-input token preservation, native capacities, observed BERT settings, identity and failure policy. Resources include initialization/fixtures/scoring/checkpoint costs, CPU seconds/threads, sampledRSS, GPU total/peak allocated/reservedVRAM, item lengths/routes/latency, descriptive throughput/tails and checkpoint storage.

Checkpoint keys bind spec/amendment/code/input/assets/runtime. Atomic write/readback required. `RESUME=True` validates a complete21-row cache; missing/partial/corrupt checkpoints HOLD without automatic fill/retry. New E2E time/calls0 on reuse remain separate from original scoring and new model/fixture overhead. Cross-session generation recovery stays a separate gate. Interrupted asset download/mixed complete manifests may need explicit review; no silent reset or dependency relaxation.

Colab PASS requires actualT4 + exact declared pins + valid assets/hash identities + all actual fixtures + all21finite metric rows + measured resources + checkpoint readback. Sessionguard11.5h includes notebook subprocess budget; install/download logs stay exported, whereas scorer cost receipt covers its subprocess phases. No full-study cost extrapolation from these three sources.

## Miro and commits before implementation

[Existing Miro board](https://miro.com/app/board/uXjVHLTov6k=/) updated and read back: current eligibility/cohorts,21output/123node evidence, closed decode search, warning retention and pending scorer/recovery/pilot/budget gates. Existing historical120 evidence is separate. [Sync report](./miro-sync-261019-2354-tib-p4-decision-report.md).

Before scorer implementation: benchmark commits `c1a4313`, `84b5634`, `89b1ce4`; application commit `3210630`. Existing outputs preserved; no push. Outer documentation/plans were archived with a manifest because the outer workspace itself is not Git. New implementation receives a separate local commit after verification.

## Unresolved

Actual Colab dependency resolution/load, native/long fixtures,21-output metrics/cost/resources and scorer checkpoint evidence/audit. Numeric total-study/storage budget, generation cross-session recovery, pilot40, admission/final config/cap lock and selection/final gates remain open. Preparing this package resolves none of those execution gates.
