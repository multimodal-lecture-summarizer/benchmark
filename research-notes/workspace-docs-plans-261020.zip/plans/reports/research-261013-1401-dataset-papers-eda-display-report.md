# Dataset papers, EDA status and Miro display

Research: 2026-10-13, Asia/Bangkok. Scope: 19 dataset/source entries in the existing Miro overview. Five batched web calls; primary papers, author repositories and publisher pages only. Local EDA status comes from saved workspace evidence, not paper claims. Applied ck:research and ck:project-organization (advisory: plans/reports).

## Findings and source mapping

| Dataset/source | Paper or official source | EDA evidence | Qualification note |
|---|---|---|---|
| TIB | [TIB (CBMI 2023)](https://hal.science/hal-04168911) | ĐÃ EDA toàn bộ text/metadata 9.103 nguồn; 10 code cells. Media video chưa EDA đầy đủ. | Paper gốc; URL HAL đối chiếu qua card tác giả; HAL hiện chặn bot. |
| IIIT-CVID | [Localizing and Recognizing Text in Lecture Videos (ICFHR 2018)](https://cdn.iiit.ac.in/cdn/cvit.iiit.ac.in/images/ConferencePapers/2018/localizing-recognizing-text.pdf) | ĐÃ EDA ảnh/nhãn: full ZIP 5.475 frame và 15.379 crop val; geometry/duplicate có ledger. | Paper LectureVideoDB liên quan OCR; mapping chính xác mirror IIIT-CVID chưa xác minh độc lập. |
| TED-LIUM Release 3 | [TED-LIUM 3 (2018)](https://arxiv.org/abs/1805.04699) | ĐÃ EDA inventory; sample 50 WAV decode/hash, 42 nhãn hợp lệ. CHƯA EDA lại toàn bộ waveform. | Paper release 3. |
| EduVidQA | [EduVidQA (EMNLP 2025)](https://aclanthology.org/2025.emnlp-main.1760/) | ĐÃ EDA chú giải: 7 cells, 4 plots, 5.234 rows. CHƯA EDA video/transcript. | Paper ghi 5.252 QA; CSV pinned EDA thực đọc 5.234, giữ hai mẫu số riêng. |
| LVVO | [Lecture Video Visual Objects (2025)](https://arxiv.org/abs/2506.13657) | ĐÃ EDA released images/labels: 7 cells, 1.000 ảnh, 1.580 box. CHƯA source-video EDA đầy đủ. | Paper 4k tổng; cohort hiện tại LVVO_1k thủ công. |
| MLPDataset | [Lecture Presentations Multimodal Dataset (2022/ICCV 2023)](https://arxiv.org/abs/2208.08080) | ĐÃ EDA annotation ZIP: 8 cells. CHƯA EDA source-media alignment. | Repo MLP fork LPM; không coi là paper scene-cut tổng quát. |
| AccessMath | [Whiteboard Video Summarization via Spatio-Temporal Conflict Minimization (2017)](https://doi.org/10.1109/ICDAR.2017.66) | ĐÃ EDA annotation/keyframe: 6 cells, 3 plots. CHƯA EDA original video/timebase đầy đủ. | Paper dùng AccessMath; tác giả phát hành code/dataset. |
| LectureMath | [FCN-LectureNet (IEEE Access 2021)](https://doi.org/10.1109/ACCESS.2021.3099427) | ĐÃ EDA annotation/keyframe: 6 cells, 3 plots. CHƯA EDA original video/timebase đầy đủ. | Paper/release LectureMath. |
| MaViLS | [MaViLS (2024)](https://arxiv.org/abs/2409.16765) | CHƯA CÓ EDA notebook/cohort được xác minh trong workspace; mới khảo sát paper. | Paper video-to-slide alignment. |
| LectureVideoDB | [Localizing and Recognizing Text in Lecture Videos (2018)](https://cdn.iiit.ac.in/cdn/cvit.iiit.ac.in/images/ConferencePapers/2018/localizing-recognizing-text.pdf) | CHƯA CÓ EDA cohort riêng dưới tên này; EDA thực chạy được ghi ở IIIT-CVID. | Paper gốc LectureVideoDB; không cộng như cohort độc lập với mirror OCR. |
| VISTA | [What Is That Talk About? (ACL 2025)](https://aclanthology.org/2025.acl-long.310.pdf) | EDA MỘT PHẦN: metadata train/valid và media 40/1.859 valid. CHƯA EDA full-validation. | Đúng VISTA scientific presentations; khác VISTA-400K augmentation. |
| YTSeg | [From Text Segmentation to Smart Chaptering (EACL 2024)](https://aclanthology.org/2024.eacl-long.25/) | CHƯA CÓ EDA notebook hiện hành; đã kiểm source/rights/GT theo ID ở khảo sát lịch sử. | Paper YTSeg. |
| VidChapters | [VidChapters-7M (NeurIPS 2023)](https://arxiv.org/abs/2309.13952) | CHƯA CÓ EDA notebook hiện hành; đã qualification một số source groups lịch sử. | Paper dataset chapter. |
| SSLectures | [Abstractive Summarization of Lectures and Lecture Segments Transcripts with BART](https://link.springer.com/chapter/10.1007/978-981-97-9255-9_4) | EDA MỘT PHẦN: audit package/source 9 bản ghi. CHƯA đủ provenance/EDA toàn tập. | Paper liên quan nhóm tác giả; không tự giải quyết provenance boundary/title. |
| MITFLD | [Towards Key Point Identification for Lecture Videos (2025)](https://doi.org/10.1145/3746640) | EDA MỘT PHẦN: 35-ID pilot/label/media audit. CHƯA EDA toàn corpus đủ gate. | Paper MITFLD; target fragmentation/key-point. |
| MIT001 | [Chưa xác minh paper riêng cho snapshot MIT001](https://ocw.mit.edu/courses/18-01-single-variable-calculus-fall-2006/) | EDA MỘT PHẦN: diagnostic 35 video và rights/media audit; 9 end-time cases cần review. | URL nguồn video chính thức, không phải URL paper. GT AVLectures cần provenance riêng. |
| Yale / Open Yale Courses | [Nguồn Open Yale Courses; chưa paper dataset riêng](https://oyc.yale.edu/) | EDA MỘT PHẦN: source/rights/media screening theo ID; chưa cohort/EDA hoàn chỉnh. | URL publisher, không phải paper. |
| EduViQA (snapshot local) | [Adaptive Chunking for VideoRAG Pipelines (CSICC 2025)](https://doi.org/10.1109/CSICC65765.2025.10967455) | EDA MỘT PHẦN: snapshot inventory 20 video/marker. CHƯA EDA task-qualified RQ3. | Paper EduViQA được tác giả Video-RAC trích; khác EduVidQA. |
| SlideVQA (snapshot local) | [SlideVQA (AAAI 2023)](https://arxiv.org/abs/2301.04883) | EDA MỘT PHẦN: local snapshot inventory lịch sử; CHƯA EDA task-qualified hiện hành. | Paper multi-image document QA; không tự chứng minh lecture-video GT. |

## Display decision

The editable Miro table truncates long cells in its current native view; the available table API does not expose auto-height or wrap settings. Keep the same table and stable records, add separate EDA and paper/source columns. Put an editable canvas grid with wrapped text and content-sized rows above it, in the same dataset overview frame. Each grid cell displays its complete text, and each paper/source URL is clickable. The lower native table remains a filtering/index view, not the full-reading surface. No widgets or records are deleted.

## Local evidence

- benchmark/docs/DATASET_EDA.md, including superseding qualification follow-up and historical source review.
- benchmark/docs/BENCHMARK.md and benchmark/plans/260901-unified-scientific-benchmark/framework/00-master-plan.md.
- docs/rq2-tib-120-results-261013.md and current OCR Miro audit/result records.
- benchmark/plans/reports/rq3-eduvidqa-annotation-preflight-261009-report.md; lvvo-provenance-split-261010-report.md; dataset-qualification-261010-report.md; rq1-sslectures-260929-1432-package-provenance-nine-row-report.md.

## Supporting primary release sources

- TIB author citation card: https://huggingface.co/datasets/gigant/tib/blob/main/README.md (HAL citation; direct HAL was bot-blocked; DOI resolver failed this session).
- LectureVideoDB author project: https://cvit.iiit.ac.in/research/projects/cvit-projects?start=80 . Mirror mapping is not independently established by this search.
- MLP author/fork repository: https://github.com/mlpdataset/mlpdataset ; ICCV final paper: https://openaccess.thecvf.com/content/ICCV2023/papers/Lee_Lecture_Presentations_Multimodal_Dataset_Towards_Understanding_Multimodality_in_Educational_Videos_ICCV_2023_paper.pdf .
- LectureMath author citation/release: https://github.com/kdavila/lecturemath/blob/master/ACCESS2021_release/README.md .
- AccessMath author software page: https://cs.rit.edu/~dprl/software.html ; author PDF: https://www.cs.rit.edu/~rlaz/files/Kenny_ICDAR_2017.pdf .
- EduViQA author project/citation: https://prismaticlab.github.io/Video-RAC/ ; https://github.com/PrismaticLab/Video-RAC .
- EduVidQA author release: https://github.com/sourjyadip/eduvidqa-emnlp25 .

## Board verification

- Existing native table retained: `3458764686983654070`; 19 stable rows, eight columns, paper/source typed as links.
- Read-back matched all 19 EDA descriptions and URLs to the correct dataset names; zero mapping mismatches.
- Full-reading canvas grid: 19 rows × eight columns = 152 text cells. Returned geometry checked against content-sized row boxes; zero cell overflows.
- Existing frame retained: `3458764686983654054`. Native index moved below the full-reading grid; no deletion. Native view may still truncate, so the upper canvas grid is the reading surface.

## Unresolved questions

- Paper identity for internal MIT001 snapshot and standalone Yale dataset: not established; official source URLs are explicitly labeled as sources, not fabricated paper links.
- IIIT-CVID mirror versus LectureVideoDB: related paper/source identified; exact release identity and per-record mapping still need independent evidence.
- EDA missing/partial scopes remain explicit; a paper link does not qualify a dataset or authorize a rerun.

