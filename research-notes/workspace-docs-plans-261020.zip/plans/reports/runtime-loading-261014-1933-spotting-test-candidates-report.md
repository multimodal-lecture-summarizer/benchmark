# Test-bound spotting candidate runtime-loading verification

**Completed:** actual loading and a fresh-process repeat passed for both candidates; the test-bound runtime receipt is sealed.

Date: 2026-10-14, Asia/Bangkok. Scope: actual offline loading and inspection of the two frozen spotting systems, bound to the frozen native test. No image inference, OCR scoring, benchmark comparison, model/configuration change, GT edit, commit or push.

## Findings and resolved gaps

The global Python does not match the candidate lock: its NumPy, OpenCV, Torch/torchvision and setuptools versions differ. The existing dedicated venv at `benchmark/research-data/spotting-candidates-261014/venv` is isolated, uses Python 3.11.1 / Unicode 14.0.0, matches all **64 pinned package versions**, and passes `pip check`. It was reused without package upgrades or changing the shared/global environment.

An old `model-load-verification.json` reported loading under different contract/adapter/verifier hashes and only bound validation. It is historical evidence, not sufficient for the current loader or test endpoint. The current legacy loader was first rechecked successfully for both models; the new authoritative test-bound verifier additionally checks effective native state, consumed model paths, actual imported source origins and native binaries. No source ZIP, original weights, candidate registry, lock, validation/test freeze or executed EDA artifact is rewritten.

## Frozen identities

- Source ZIP: `b5b562580e250ee3336462b7699bc79d0d1149d3b8cc82f1b221a0d0ce4fb489`.
- Candidate registry: `6408aa4d33f7f87ce3bfc028d8e2b6bd4628a21d48c6d70f9f88db0fc41ef80d`.
- Runtime lock: `56706330c3d94a16793999083bb8d796551a4032fa48e095deedb4a8c382cd0d`.
- Test freeze: `9504e34f69b16f4b63893184e5decf2e3d88d7251833b0efbb85f2eb883438dd`.
- Additive candidate test-use binding: `3c8101c36e6fef4b06d5a4efb0a1307757bed3aac742720ecefd034411b55d22`.

The verifier requires exact candidate membership, config/model hashes and original validation binding equality. Test artifacts, verification/replay receipts, GT/policy/scorer and source ZIP are anchored before following their declared hashes. The **1,754 frame / 40,063 object** primary denominator and supplementary **1,751 / 40,023** endpoint remain unchanged.

## Effective runtime inspection

Each candidate is loaded in its own newly launched venv process with the frozen CPU environment applied before engine import. The predictor closure's native reader is inspected without calling the predictor. Installed engine Python sources/dictionaries match pinned wheel/source hashes; actual loaded origins are checked, including Paddle's unqualified `tools.*` and `ppocr.*` aliases. Unexpected origins outside the pinned venv package reject verification.

| Candidate | Actual native state inspected | Configuration binding |
|---|---|---|
| EasyOCR CRAFT + English generation 2 | CPU; intra-op math threads 1; both detector and recognizer in eval; 5 actual dynamic quantized Linear/LSTM layers, 12 modules in quantized family; CRAFT detector has no quantized modules | Correct two checkpoint files traced through actual `torch.load`; model storage, English character list (96), CTC converter and height 64 verified; frozen `readtext` arguments bound to real signature |
| Paddle DB v3 + English recognition v4 | Both native predictors CPU/MKLDNN, math threads 1, IR optimization enabled, no TensorRT/INT8; actual model/parameter paths match; no angle classifier, drop_score=0 | Applied constructor exactly matches registry; DB threshold .3, box threshold .6, unclip 1.5, quad/fast/no dilation/max_candidates 1000; resize max-side 960 and normalization inspected; recognition shape 3×48×320, batch 1, native CTC dictionary (97 entries), no word boxes |

EasyOCR's **12 quantized-family modules** include internal/packed modules; the directly observed dynamic layers are **three Linear and two LSTM**. Do not interpret 12 as 12 independent quantized layers. Intra-op threads are fixed at 1; the native Torch inter-op count is recorded separately (14 on this host), without changing defaults or claiming all runtime scheduling is single-threaded. The native reader's quantize attribute is a one-element tuple due to upstream assignment; actual module classes, not that attribute's truthiness, establish the recognizer quantization outcome.

EasyOCR call-time detector thresholds, normalization, resize and grouping are bound by the exact config, accepted API signature and hashed source. Paddle inspection observes its instantiated resize/normalization/postprocess/recognizer objects directly. Native crop transforms, actual image tensors, CTC outputs and grouping behavior have **not been exercised on an image**. FP32 is the pinned Paddle setting; its native backend configuration and no-INT8 state are checked, not a numerical-output equivalence experiment.

## Native binary and offline evidence

Three OpenCV distributions are present at the same pinned version. Their metadata alone does not identify the binary imported at runtime. Actual `cv2.pyd` is OpenCV **4.6.0**, SHA-256 `6fa4bf7f77e533e3f60ed18f2c8d8412b2e216839b96356ed0c0d8fd501ad8d5`, and matches the **opencv-contrib-python** wheel RECORD; the other two RECORD hashes do not match this effective binary. No distribution was silently removed or substituted. The effective provider, build-info digest and installed native-file fingerprints are included in child receipts.

Native `.pyd`/`.dll` files for the locked backend roots are hashed **before engine import** and checked again after loading. Effective imported roots/binary fingerprints are also recorded. Python version, platform, venv/base interpreter paths and interpreter executable/DLL hashes participate in the candidate identity digest. Repeat loading must match complete candidate identity, not merely config names.

A Python socket/DNS denial guard is installed before engine imports; any attempted network API call fails verification, even if swallowed upstream. No denied calls occurred in successful attempts. This is explicit Python-level download prevention, not OS network isolation or attestation of every DLL that Windows loads. The binary manifest fingerprints installed files in relevant roots; it does not claim to enumerate every loaded native library.

## Execution and verification

Final baseline and repeated loading **passed 2/2 candidates in each run**, using four fresh model-loading processes. Their complete candidate identity digests agree exactly, including interpreter/platform, all 64 pinned versions, effective native state, imported code, consumed weights and binary fingerprints. The parent sealed the final runtime receipt only after this repeat and a final snapshot recheck. It verifies 278 bound source/test/implementation/model input hashes; each worker also snapshots and rechecks 172 backend native files. Effective imported package-root manifests contain 160 binary files for EasyOCR and 150 for Paddle; actual pinned native source origins number 12 and 71 respectively. No Python network calls occurred.

The preliminary structured run remains diagnostic evidence of an earlier implementation; it was not used as the final repeat baseline. Both final runs used the reviewed pre/post-binary and interpreter binding. Focused pytest passed **46/46** (12 runtime tests plus 34 existing candidate/scorer/cohort tests). The known ignored `pyreadline3` destructor OSError occurred after successful exit 0.

Sealed receipt SHA-256: `475a72e185716f05645d35a01ff2964c141370dfae9583b3dccc162a8c304d70`. Candidate identity digests: EasyOCR `00ceda1d246da464744eb8c82fa724deca86b7576289f81a8d2a2ca9636d6206`; Paddle `d3094e1189a45c81124da07e165d7f3d4af35b199f5ba7b88a63e3471c20c8b2`.

Fresh attempt directories preserve stdout/stderr, child receipts, exit status and observed costs. A nonzero exit, timeout, missing/stale receipt, wrong identity, changed input or incomplete candidate coverage cannot be promoted to success. Final registry publication uses exclusive creation only after a matching repeat. Times are validation costs including hashing/import/loading; they are not OCR inference latency or speed comparisons.

Final independent read-only audit confirmed the sealed receipt is byte-identical to the final repeat receipt, all baseline/repeat child/log/pip artifacts match, both candidate identities agree, current script hashes match, and no inference/network attempt was recorded. Root verification rechecked all 278 input hashes, native/interpreter fingerprints and unchanged frozen test bindings; `git diff --check` passed. Source/model data, venv and operational outputs remain ignored. Current indexes link the follow-up runtime receipt separately from historical frozen pending statuses. No commit or push was performed.

## Artifacts and replay

- [Versioned test-bound runtime receipt](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-test-runtime-261014.json).
- [Final-code baseline](../../benchmark/experiments/outputs/spotting-test-runtime-261014/20261014T124913Z-05435fdb/verification.json), [matching repeated attempt](../../benchmark/experiments/outputs/spotting-test-runtime-261014/20261014T125340Z-ec0ff925/verification.json).
- [easyocr_craft_english_g2 child evidence](../../benchmark/experiments/outputs/spotting-test-runtime-261014/20261014T125340Z-ec0ff925/easyocr_craft_english_g2.json); stdout/stderr digests are in the sealed receipt.
- [paddle_db_v3_rec_v4_keep_all child evidence](../../benchmark/experiments/outputs/spotting-test-runtime-261014/20261014T125340Z-ec0ff925/paddle_db_v3_rec_v4_keep_all.json); stdout/stderr digests are in the sealed receipt.
- [Reusable verifier](../../benchmark/experiments/scripts/verify_spotting_test_runtime.py), [runtime binding](../../benchmark/experiments/scripts/spotting_runtime_binding.py), [native inspection](../../benchmark/experiments/scripts/spotting_runtime_inspect.py), [fresh worker](../../benchmark/experiments/scripts/spotting_runtime_worker.py), [binary/interpreter fingerprint](../../benchmark/experiments/scripts/spotting_runtime_fingerprint.py), [network guard](../../benchmark/experiments/scripts/spotting_runtime_guard.py).
- [Frozen candidate registry](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-candidates-261014.json), [runtime lock](../../benchmark/experiments/scripts/requirements-spotting-candidates.lock.txt), [test binding](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-test-261014-candidate-binding.json), [GT/cohort policy and limits](gt-policy-261014-1633-cvid-test-spotting-freeze-report.md).

From `benchmark`, run `python -m experiments.scripts.verify_spotting_test_runtime`. The standard-library parent launches the pinned venv children; do not use the global environment for candidate inference. For a second attempt, pass `--repeat-of <first verification.json>`. The one-time `--seal` option additionally publishes the registry receipt after a matching repeat; once sealed, rerun without `--seal` and compare against the registry receipt. All model data, venv, source ZIP and operational outputs stay ignored/local.

## Limits and unresolved questions

- Loading success does not prove successful end-to-end image processing, accuracy, throughput or numerical equivalence. No image inference occurred.
- Runtime evidence applies to this Windows/CPU environment and exact code/files. Re-run fail-closed preflight and create a new run identity before comparison or after any environment change; never resume validation predictions into test.
- Preserve frozen native precision, thresholds and grouping; no test-score tuning, GT filtering, dictionary assistance or favorable endpoint selection.
- Annotation selectivity, possible semantic errors, test EDA exposure, uncertain video/writer independence and pretraining overlap remain as frozen.
- Next step after verified sealing: actual common-cohort frame inference and comparison with full per-frame failures/predictions and the fixed metrics. No winner has been selected.
