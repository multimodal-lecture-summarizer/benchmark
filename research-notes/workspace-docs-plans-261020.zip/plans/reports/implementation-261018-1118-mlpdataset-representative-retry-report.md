# Representative failed-source retry notebook

Implemented and independently reviewed. User will run real YouTube trials on Colab; no remote source recovery tested or claimed locally.

## Behavior

Standalone notebook33cells/20code. Default RUN_REPRESENTATIVE_RETRY=True, max12videos,10minutes total sampled acquisition,120s percommand plus existingglobal30minute/video/storage caps,3second gaps within remaining budget. No authentication/cookies change. Snapshot pre-existing failed pool before mutation; rank byattemptcount/ID,sourcegroup coverage first,currenterror classes andhistorical403/resource diversity whenroom,balancedgroup fill. Actual saved131pool produces12selected acrossall9failedsourcegroups plusboth historicalcategories. Selectiondescriptive,notstatisticalrecoveryestimate. No fixedsourceIDs. Empty/missinggroups/disabled handling verified.

Samplefirst uses existing numberedattempt/download/probe/SHA flow. Mode intentionally overrides general auto/manual failedretry selection; otherfailedIDs retain state. Disable RUN_REPRESENTATIVE_RETRY torestore generalpolicy. RETRY_FAILED/DOWNLOAD_MEDIA honored. CacheddownloadedIDs still hash/probeverified andneverretried. Selectedbudgetstop/disabled show no-new-attemptdistinctfromactualfailure. Missing/incomplete/unreadable source cannotcountsuccess even ifcommandexit0. Reports separateprevious/currenterrors,newattempts,processstart,reason,status,sourceSHA/bytes/duration. Printfull logs, pool,selection,outcomes,summary inline;CSV/JSON plusreceipt exports. Recovery feedsunchangedpreviewcache/fullcoverage. Acquisitionaudit restoresselectedID order. Config/sourceIDs/hash identity unchanged;333/9021 inventory retained. No annotationrepairs or evidenceZIP.

## Verification

5focusedtests usingactual131states andrenamedIDs, controlledlocalchildren withrealrun_logged,ffprobe,hash/statehistory/logvalidation,nonselectedcachepreservation,disable/mediaquota/sampledeadline/pause/timeoutmin andexit0withoutfilefailure passed. Tester rerun7.367s;independentreviewer rerun7.541s.8previewresumeFFmpegtests,stagebudgettest,full333/9021inventory+receipt replay333historicalstates/strictJSON/allartifacthashes passed.20codecellsparse;priorhelpersASTunchanged;25format/27preview/29coverage sourceunchanged. Tests demonstratelocalorchestration,notYouTubeavailability.

Guide/journal updated. Inputnotebook beforethisedit wasclean; preserved atbenchmark/experiments/outputs/mlpdataset_representative_retry_261018/before-representative-retry.ipynb. PriorColab evidence remains separate historicalauditreceipts/ledgers.

Run:uploadnewnotebook,retainDrive/RUN_NAME,CPU Runall; saveipynbwithoutputs. InspectREPRESENTATIVE RETRY RESULTS andrepresentative_retry receiptsection. No commit/push.

Unresolved: real Colab sample outcomes, remaining source availability/authentication,semantic/timebase/rights qualification.
