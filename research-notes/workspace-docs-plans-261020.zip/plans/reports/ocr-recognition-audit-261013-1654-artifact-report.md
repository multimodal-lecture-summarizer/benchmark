# OCR recognition artifact audit — 2026-10-13

**Decision: PASS for integrity and scoring of the supplied Colab recognition artifacts.** Retain descriptive validation-only conclusions. Full notebook fresh-kernel replay and independent verification of the original inference model binaries remain unverified. No inference rerun was performed or required to recalculate the saved results.

## Evidence inspected

- User-supplied ZIP: `C:\Users\hung\Downloads\ocr-validation-261013-v1-20261013T043709Z-1-001.zip`.
- ZIP size: 2,023,778 bytes; 52 unique members; all member CRC checks passed.
- ZIP SHA-256: `b5d7c0b0b957a7faa1a23e54d35c70a120a51b418daac58790f483dfad3d0203`.
- Local dataset ZIP: `benchmark/research-data/iiit-cvid-source/IIIT-CVid.zip`; SHA-256 independently recomputed as `b5b562580e250ee3336462b7699bc79d0d1149d3b8cc82f1b221a0d0ce4fb489`.
- Dataset receipt identifies `staghado/IIIT-CVid`, revision `8159222f11460bff70bec7990ade19c468755fe4`. This audit checked the local ZIP against its recorded hash; it did not re-fetch that remote revision.
- [Machine-readable audit evidence](ocr-recognition-audit-261013-1654-evidence.json): input hashes, every run member hash, engine identities, recalculated scores, changed historical predictions and verification results.
- [Saved notebook](../../benchmark/experiments/notebooks/iiit_cvid_ocr_comparison_colab.ipynb) and its four embedded source modules.

Drive connector searches returned no matching run/folder. The audit therefore uses the supplied downloaded snapshot; it does not attest to the current contents of the live Drive folder.

## Checks and results

| Check | Result |
|---|---|
| Source archive identity | PASS: independently recomputed SHA-256 matches receipt |
| Extracted source fidelity | PASS: 15,379 crop PNGs and 5 label files match source ZIP size/CRC |
| Image readability | PASS: all 15,379 local crop images decoded |
| Cohort and released GT | PASS: exact image/label ID correspondence; no duplicate label or prediction ID; all references match unchanged local released labels |
| Paired coverage | PASS: both engines cover identical 15,379 IDs, 73,654 normalized reference characters, 5 courses, 140 source-video groups |
| Cohort receipt | PASS: independently reconstructed hash `cb1be5f8bdb6bf8a0fc4942cab65892e6358fb5f57174bb8477d8d388a82ea11` matches both identities |
| Prediction/summary/failure hashes | PASS: all six artifact hashes match their engine manifests |
| Source identity | PASS: all four notebook-embedded sources match source receipt; local source text matches as well |
| Engine identity and environment | PASS for recorded metadata: engine versions, source/normalizer identity and package inventory agree |
| Model hashes | PASS for receipt/config consistency; actual inference weight binaries are absent from supplied ZIP and were not independently rehashed |
| Scores | PASS: independent Levenshtein implementation recomputed every prediction score, totals and exact-word accuracy |
| Failure accounting | PASS: zero row errors; both failure JSONLs empty; empty predictions retained in denominators |
| Course and video CSVs | PASS: every group count, character denominator, edit sum, CER and exact-word rate recomputed |
| Per-crop CSVs | PASS: cohort-features and paired-errors IDs, GT and recorded edit counts match predictions; feature measurements and every feature-stratum plot were not independently regenerated |
| Paired uncertainty | PASS: seed 20261009, 2,000 source-video bootstrap draws; exported draws and interval reproduced |
| Notebook execution evidence | PARTIAL: 12 code cells, one without saved execution count/output (zero-based index 11); zero saved error outputs |

Normalization independently reproduced: Unicode NFKC → casefold → collapse whitespace. Punctuation and digits remain. CER is total normalized Levenshtein distance divided by total normalized reference characters. Exact-word accuracy requires complete normalized-string equality. Empty predictions score as deletions; error rows must have empty prediction. This cohort has no inference-error rows.

## Verified Colab results

| Metric | EasyOCR 1.7.2 | PaddleOCR 2.8.1 |
|---|---:|---:|
| Crops | 15,379 | 15,379 |
| Reference characters | 73,654 | 73,654 |
| Total edit distance | 17,999 | 8,630 |
| Micro CER | 24.4372336% | 11.7169468% |
| Exact-word accuracy | 54.9385526% | 71.6756616% |
| Empty predictions | 8 | 18 |
| Inference failures | 0 | 0 |

PaddleOCR − EasyOCR CER: **−12.7202867 percentage points**. Source-video cluster bootstrap 95% interval: **[−15.5847180; −9.9782700] percentage points**. All five course comparisons have lower CER for PaddleOCR. Course 19 contributes 7,757 crops (50.44%); the aggregate is character-weighted and does not establish equal benefit across courses or unseen videos.

Paired outcomes: PaddleOCR fewer edits in 4,982 crops; EasyOCR fewer in 462; equal edits in 9,935. Exact-word agreement: both exact 8,204; EasyOCR only exact 245; PaddleOCR only exact 2,819; neither exact 4,111. Both exported tables match the raw predictions.

## Findings that require explicit interpretation

1. **Colab and historical CPU runs differ.** EasyOCR has 16 changed prediction strings versus local `ocr_validation_261009`, with net edit distance 18,000 → 17,999. This is more than a single changed crop. Full changed-ID ledger is in the audit JSON. PaddleOCR prediction strings are identical across all 15,379 crops, although JSONL file hashes differ. Cause of EasyOCR variation is not established by this audit; retain separate run identities.
2. **Old preflight failure is retained.** `ocr-preflight-error.log` records missing `setuptools`. Later log `ocr-preflight-1791863130815731651.log` records successful one-crop inference/model-hash preflight for both engines; installed package inventory includes `setuptools==75.8.0`. This setup error is distinct from the zero final inference failures. The empty `failure-ledger.json` must not be described as proof that no setup attempt ever failed.
3. **Analysis and inference environments differ intentionally.** Kernel receipt: Python 3.13.16 / NumPy 2.1.3 / Pandas 2.2.3. Inference identities: Python 3.11.12 / NumPy 1.26.4 / CPU; EasyOCR batch size 1, PaddleOCR 32, one inference thread. Package inventory agrees with identities. No speed ranking is supported by these artifacts.
4. **The notebook does not prove a complete fresh-kernel sequential run.** An intermediate paired-analysis cell has no saved count/output, while later cells have output. This does not invalidate independently verified prediction scoring, but prevents certifying full notebook replay.
5. **Label fidelity is verified; annotation authorship/quality is not.** Released labels were preserved. This audit does not resolve creator/QC provenance or adjudicate suspicious labels. Historical dHash review flags are not proven label errors and do not justify exclusions.

## Required audit bundle and what remains

The supplied ZIP already provides what is needed to audit saved recognition scoring: both full prediction JSONLs; per-engine summaries, identities, artifact hashes and failure ledgers; paired summary; dataset/source-code/environment receipts; package inventory; preflight logs; per-crop/course/video tables; bootstrap exports; figures. Local pinned source data and saved notebook provide the complementary GT/source evidence.

No additional user input is required to close the saved-artifact scoring gate. Preserve this ZIP, the audit JSON, the pinned source archive and saved notebook together.

Open verification items:

- To certify notebook reproducibility: execute its cells in order from a fresh kernel and retain complete output. Use matching receipts to reuse existing prediction checkpoints; this need not trigger another full inference run.
- To independently certify original weight bytes: provide or retain the exact inference model files and rehash them. Current evidence verifies recorded hash agreement and successful preflight logs only.
- Annotation creator/QC provenance remains unresolved; limit claims to performance against released validation labels.

**Next task:** freeze frame-level spotting cohort and protocol, including frame IDs, GT boxes plus transcription, geometry/ignore adjudication, matching, normalization and failure rules. Recognition audit does not establish spotting Hmean, detection precision/recall/F1, or readiness of transition/keyframe GT.
