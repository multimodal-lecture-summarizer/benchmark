# MLPDataset notebook runtime review

Date: 2026-10-18. Scope: recent standalone Colab notebook recovery changes and their setup/cache/preview/receipt consumers. Skill: ck:code-review. Review compared the current notebook with the preserved input notebook because the parent workspace has no Git repository. Root README absent; benchmark/README.md provides workspace context.

## Findings

**P2 — orphan download log overwritten after abrupt runtime termination: fixed.** The old acquisition helper selected the next log from completed checkpoint attempt count. A hard runtime termination could leave a log without the corresponding appended attempt. Resuming the running state selected the same filename and opened it for writing, losing diagnostic history. KeyboardInterrupt handling alone did not cover this path.

The helper now selects the next unused numeric logfile, records `log_name` on completed/interrupted attempts, and acquisition output enumerates existing source attempt logs independently of checkpoint count. Orphan evidence is displayed without inventing an attempt record or process count. Media/frame cache identity and completed files are unchanged. Independent re-review passed; specific real-process/acquisition-cell regression passed independently in0.675seconds. The local red/green check detects overwritten bytes under the previous behavior and preserves/displays both logs under the current behavior.

No other confirmed runtime blocker identified in reviewed paths. Spec compliance passed before code-quality review: full333-video/9021-mark accounting, bounded public-protocol recovery, current checkpoint selection, preserved cache identities, process/source count separation and inline evidence match the authorized scope.

## Verification

- Focused recovery after fix:13/13 tests passed in8.582seconds.
- All-failed retry:6/6 tests passed in4.806seconds. Representative retry:5/5 passed in5.180seconds.
- Stage-budget checks passed, including actual child processes/FFmpeg, free-space/reserve/quota, timeout and identity behavior.
- Red/green orphan-log regression passed; independent narrow re-review passed.

- Preview resume after re-review:8/8 passed in20.136seconds. Total unittest checks after the fix:32/32 across four suites.
- Full333-state/9021-mark receipt replay passed, including unchanged histories, strict JSON and every emitted artifact hash.
- Sequential offline execution passed using the real hash-checked release ZIPs and cached pinned provenance. Executed configuration and every remaining code cell through receipt (19/20 code cells; installer excluded). Preserved333 videos/9021 marks with zero acquired media, zero previews and valid full-coverage/receipt output. Only Drive/download configuration, temporary output path, display capture and explicitly labelled missing local EJS metadata were adapted by the harness; no download transport was invoked. This is not a fresh Colab setup run.
- Final notebook schema/AST passed:33 cells/20 code cells, clean outputs, embedded sources match tested mirrors, protected cache helpers and preview/coverage sources unchanged. Notebook SHA256: `06c1476a374302e3212b32deb0799ebfec0ba5b9266f888e4c5a8223eb138190`.

During harness preparation, a shell quoting error prevented notebook synchronization and correctly triggered mirror-consistency test failures; synchronization was corrected using a saved Python script. The new fixture initially lacked the required `flags` column and was corrected. The first sequential rehearsal encountered Windows sandbox temporary-directory rename/cleanup restrictions; hard-link optimization was also denied. Re-running with ordinary archive copies in a dedicated workspace output folder completed successfully. No Colab production behavior was changed to bypass these local harness/environment failures.

## Limits and runtime expectations

Cache media missing/hash mismatch intentionally stops acquisition rather than silently accepting altered evidence. Source/profile guards constrain new process work; total Run all also includes Drive reads, cache hashing, output rendering and receipt hashing. This is not a hard total-runtime bound.

Setup EDA packages are installed without blanket upgrade. Static syntax/version-pin inspection does not establish pip/npm registry access or fresh-Colab dependency resolution. Local transport fixtures establish retry logic, not YouTube availability or universal recovery. No live YouTube download or local package installation was performed for this review.

Unresolved: actual Colab setup/network success; current Drive state after interruption; remaining remote403/authentication restrictions; full semantic label validity.
