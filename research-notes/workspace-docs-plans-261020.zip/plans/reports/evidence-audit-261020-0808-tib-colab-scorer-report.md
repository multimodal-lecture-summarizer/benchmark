# Actual Colab T4 scorer evidence — scoped PASS

**P4 formal-runtime scorer-ready PASS** for frozen fixtures and21 stored development outputs on three existing pilot IDs. Actual execution is now evidenced; previous preparation/CPU-only HOLD snapshots remain historical. This does not authorize selection300 or certify generation recovery, pilot40 or study budget.

## Evidence and identity

User ZIP `tib-scorer-evidence-20261020T010554Z.zip`:421816bytes, SHA256 `116ecb2ccce3d47689fba85c35f4036f38b03ee2bab84423be2e0e11b4065ad7`. Run `1792458128735048286`. [Audit receipt](../../benchmark/experiments/registry/protocols/tib-scorer-colab-runtime-261020-v1/actual-colab-20261020T010554Z/audit_receipt.json), [actual scorer-ready receipt](../../benchmark/experiments/registry/protocols/tib-scorer-colab-runtime-261020-v1/actual-colab-20261020T010554Z/scorer_ready_receipt.json), [cost evidence](../../benchmark/experiments/registry/protocols/tib-scorer-colab-runtime-261020-v1/actual-colab-20261020T010554Z/cost_evidence.json).

Offline audit verified62 archive members/CRC/safe paths, all19 bundled file hashes against the original locked package manifest, frozen spec/runtime amendment/CPU receipt and code identities, actual runtime binding, artifact hashes and identical per-run/latest copies. All21 checkpoint envelopes, key filenames, input/runtime bindings, results and original costs match the21 metric rows. All105metric values finite;0metric failures/0missing rows; generation statuses8clean+13warning unchanged.

Existing [executed notebook](../../benchmark/experiments/notebooks/tib_p4_scorer_colab_t4_261020_v2.ipynb) corroborates the ZIP:6/6code cells executed in order,0saved errors, all six code cells match the clean v2 template, printed scorer receipt exactly matches exported receipt and printed export SHA matches the ZIP. Executed notebook preserved unchanged; clean template restored alongside it. Private ZIP/source/reference material stays under ignored research-data, without model/scorer rerun.

## Actual scorer runtime and fixtures

Tesla T4, CUDA13.0, Python3.13.15; exact runtime/support package pins verified, including Torch2.11.0+cu130/NumPy2.1.3/Transformers4.57.6. FP32/eval/batch1, TF32/autocast disabled; observed17BERTlayers, fast tokenizer, IDF=false/no fitted dictionary, no baseline rescaling. Colab reports2logicalCPUs,1torch CPU thread and1interop thread; this is the observed runtime, not a CPU-speed comparison.

- Native/window equivalence: BERT maximum absolute error1.1069434e-7, sentence embedding2.2351742e-8; both below1e-5.
- BERT long probe:1800content tokens preserved exactly across4windows, actual maximum512tokens per forward. Sentence long probe:640content tokens preserved exactly with native capacity128.
- Identity E2E: all five metrics1.0. Full-source fixture observes12/12source sentences with batch1.
- Missing/empty source/reference/output fixtures return allNULL. Controlled semantic exception/nonfinite fixtures retain three valid lexical metrics, two semanticNULLs and explicit failures; no zero imputation.
- Both exported asset manifests match actual receipt bindings. All15model/tokenizer/config file hashes and parsed manifest content equal the independently verified local CPU asset manifests. Manifest byte hashes differ with serialization, not file content. The ZIP omits weights; this audit did not independently rehash Colab weight bytes, which the executed loader validates before use.

Tokenizer log warnings about1800>512 and640>128 come from obtaining untruncated content IDs for these probes. Exact forward-hook evidence proves actual model calls obey the512/128 capacities; these warnings are not indexing failures in this run.

## Measured cost

| Phase | Wall seconds |
|---|---:|
| Hash/runtime/assets validation |20.15|
| Model initialization |33.39|
| Fixtures |3.74|
|21stored-output scoring calls |161.70|
| Checkpoint write/readback |0.42|
| Input profiling |0.18|
| Total scorer subprocess |219.61|

Sampled peak processRSS **3.00GiB**; peak VRAM allocated **2.83GiB**, reserved **2.87GiB**. Resource samplerCPU time193.34s; checkpoint storage24436bytes. Fresh E2E scoring throughput0.12987outputs/s; initialization/fixtures/validation are separate. These three-source descriptive timings do not project pilot40,300selection or523test and exclude earlier notebook install/download/Drive overhead. SampledRSS excludes filesystem cache and other processes.

## Status and next boundary

Actual scoped scorer gate PASS.21fresh E2E calls,0reused records,0generation calls; no model quality ranking or admission decision. Warning outputs remain scoreable;350maximum,40/300/523 cohorts, frozen metrics, dataset, acceptance policy and historical receipts unchanged. Bootstrap v2 policy hash matches the notebook helper; installation/identity succeeded. Old `bootstrap_hold.json` is the pre-run marker; current/per-run receipts and execution counts establish the later PASS.

Immediate checkpoint readback and offline exported integrity verified. **Cross-session recovery remains unverified**, for both the separate generation recovery gate and scorer cached replay; this fresh run does not demonstrate either. Next is a separately controlled fresh-session recovery check, then pilot40 after its applicable resource gates. No new generation, metrics computation, selection or test execution was performed during this audit.

## Remaining

Generation fresh-session reuse evidence, applicable scorer replay evidence if claimed, pilot40/resource allocation and measurements, numeric total-study/Drive quotas and conservative projection, admission/config/cap final-lock, then selection300 and final seal/full523 or preoutcome500→400. P4 remains in-progress; these gates are not passed by scorer-ready alone.
