# OCR EDA on Miro

Added dedicated OCR CVID full-split EDA frame adjacent to crop/ASR row in verified empty area. Six plots/summary panels derive from existing EDA exports: raw split frame counts, box/transcription counts, course concentration, full-object box-height/frame-height CDF, raw transcription-length CDF, and KEEP/metadata/HOLD accounting. Raw train3171/82263, val549/15379, test1755/40103; distinguish frozen R5 test1754/40063 after whole-frame geometry HOLD.

Executed EDA notebook hash and summary hash verified against14/10 receipt;16/16 cells,0errors,11PNG+75JPEG. QC limits shown: selective released annotations;72 diagnostic semantic samples do not estimate population error rate; no blind-gold claim. EDA/test exposure and crop-recognition/spotting endpoint distinction retained. No OCR/EDA/scoring rerun.

Miro frame3458764687502489499; dashboard3458764687502489504. Linked from both existing OCR crop and spotting frames. Frame bbox31000,-630,5700,3400; dashboard31100,-530,5376,3024; footer below chart without overlap. Original R5 charts/tables and prior four-note deletion unchanged. Standalone SVG/PNG/PDF/HTML, source receipts and Miro readback saved at benchmark/experiments/outputs/ocr-eda-visual-261016-2354/. PNG visually inspected.

Unresolved questions: none for this EDA presentation; semantic GT certification, source-video independence and unseen-test claims remain unsupported as in audited EDA.
