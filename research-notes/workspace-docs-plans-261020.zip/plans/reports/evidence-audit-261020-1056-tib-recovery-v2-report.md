# TIB P4c returned recovery v2 — PASS

Actual fresh-session recovery passes on Colab Tesla T4. Both the returned ZIP and executed notebook were inspected. P4c can close in its recovery scope; pilot40, admission and study budget remain separate gates. No local generation, model loading, scoring, selection300 or final test was performed during this audit.

## Artifact integrity

- Returned ZIP: `tib-p4-recovery-evidence-20261020T023840Z.zip`, 673,373 bytes, SHA256 `985ecb78106b66123216f7b4ff036b567d575c612d05edceed16f1cf9a2eeb2b`; supplied hash matches. CRC clean; 64 unique members and all51 bound package files verified.
- Returned package files exactly match prepared v2 ZIP, SHA256 `36d08b03c1a4ccefe63556024239d117494e2af02e7827b920921adcaee4f03a`; manifest SHA256 `619f9ce4ad9ae889f6ae1d9ec3479f9af61e934be1b2d07c69fbb3dee400ae1b`.
- Origin witness envelope and original288 generation/21 scorer file hashes match historical exports. Child context and receipt digests match the combined receipt. No original checkpoint identity or metric was amended.
- Origin boot `a6139a79-09e5-4649-bf54-22c887c27f91` differs from recovery boot `66fdf69e-f02d-40cb-bd79-eec3433819a1`; timestamps are ordered. Run `487e800a-5641-47d8-82f7-4c217a5d9d66`; context SHA256 `ba766ad6b8f612f45db23d6c9319f8ef5075236a4e52536984809fb9800f18f2`.

## Recovery results

| Check | Verified result |
|---|---|
| Generation assets | BART, LED, Qwen3 reloaded once each on actual Tesla T4; pinned runtime/assets/configs match historical capacity |
| Cached generation | Seven historical profiles × three source IDs =21 outputs;123 nodes reused |
| Node/output identity | Every node key digest, output and backend telemetry matches original checkpoint; all raw/delivered summary hashes match |
| New generation |0 calls;0 denied attempts;0 new generation wall seconds |
| Scorer |21 checkpoint reuses;105 finite metric values exactly match original scores; unchanged store |
| New metrics |0 calls;0 new scoring seconds; no scorer models or fixtures rerun |
| Combined receipt |PASS; empty reasons; cross_session_recovery_verified=true |

Generation recovery wall214.2764s, CPU120.5697s, sampled peak process RSS4.867GiB; allocated/reserved VRAM7.541/7.684GiB. Model reload wall: BART26.2124s, LED28.1004s, Qwen3149.2875s. Scorer replay wall5.0605s, CPU2.9895s, RSS at end565,784,576 bytes (boundary observation, not peak). Sum of child wall times219.3369s excludes installation, downloads and notebook setup; it is not total session time.

Original generation node cost1146.8398s and scorer cost161.7003s remain separately recorded. Cached recovery memory/time does not estimate generation throughput or prove pilot40/full523 budget. Child receipts intentionally retain `cross_session_survival_verified=false`: the parent combined receipt supplies the independently checked two-session proof; this is not a failed child check.

## Executed notebook

`benchmark/experiments/notebooks/tib_p4_fresh_recovery_colab_261020_v2.ipynb`, SHA256 `7c125af0b4aed258692b421eadc7be37912da56a7703527064ee37b7d163e4e1`.

12 total cells; all7 code-cell sources exactly match v2 sources generated in memory without overwriting the downloaded notebook. Saved execution counts1–7 are contiguous, with zero notebook error outputs. Generation/scorer subprocess exit0 and PASS summaries, final combined PASS and printed export size/hash agree with the supplied ZIP. The executed notebook remains unchanged; its saved outputs corroborate the raw receipts.

Installation logs retain inherited Gradio6.30.0, Gradio-client2.7.2 and Diffusers0.41.0 requirements incompatible with pinned huggingface-hub0.36.2. Installation succeeded and the pinned research path passed its runtime/cache checks; this is not evidence those unrelated libraries work. Do not silently upgrade research dependencies to clear those warnings. Generation logs retain torch_dtype deprecation and whole-source tokenizer length25895>16384 warning. Native chunk/window replay and all node identities passed; there was no generation attempt or traceback. These warnings are retained, not erased.

## Evidence location and next gate

Raw receipts/log, witness, metric replay and machine audit: `benchmark/experiments/registry/protocols/tib-p4-fresh-recovery-261020-v2/actual-colab-20261020T023840Z/`. Original ZIP copied into ignored `benchmark/research-data/tib-p4-fresh-recovery-261020-v2/returned-20261020T023840Z/`. V1 HOLD and v2 preparation HOLD remain historical, unchanged.

Next is pilot40 preparation and applicable resource readiness for BARTcontrol/LEDngram3/Qwenr384/Lead-3/LexRank. This audit does not start or authorize generation. Preserve cap350, cohort40/300, final523→500→400, frozen metrics/windows/IDF=false and acceptance policy. Seven replayed historical profiles are not seven newly admitted pilot candidates.

## Open

Pilot resource gates, remaining pilot IDs and per-stratum measurements; numeric quota/storage/session budget, admission/profile/cap final-lock and conservative projection before selection300. No additional recovery rerun required for the audited caches.
