# P4 — quyết định kết thúc decode development và acceptance policy

User chốt19/10,23:41: chuyển trọng tâm sang đánh giá có kiểm soát, không mở tìm cấu hình vô hạn. Đây là protocol decision trước selection, không model-quality winner hoặc admission cuối cùng.

## Quyết định giữ nguyên

- BART giữ control. `valid:886` exact-clone diagnostic giữ trong evidence; không tự sửa coverage logic hoặc coi đây là technical completion failure.
- LED ngram3 là profile ưu tiên kiểm tra tiếp, không kết luận tốt nhất về semantic quality. Ngram0/ngram4 cùng artifacts giữ lịch sử.
- Qwen r384 ưu tiên; reduce exhaustion vẫn được ghi. Concise256 không là lựa chọn mặc định tiếp theo. R512 duy nhất trong bounded registry có thể được kích hoạt sau resource review; **không bắt buộc**, không tự bật và không cần đạt0exhaustion mới được tiếp tục nghiên cứu.
- Lead-3 fixed control và LexRank giữ nguyên, tổng candidate universe vẫn5; không thay TIB hoặc thêm multimodal study.
- Giữ350words maximum, pilot40/selection300/eligible-test523, fallback523→500→400;40diagnostics nằm trong final. Cap value không đổi; final cap/profile/admission freeze sau evidence gates, trước selection.

## Intermediate acceptance policy v1

Ba trạng thái tách rõ technical execution và chất lượng:

| Trạng thái | Quy tắc | Hệ quả |
|---|---|---|
| completed | Node/record đáp ứng technical contract, delivered summary hợp lệ và không có warning đã định | Giữ trong completed/paired eligible frame theo scorer coverage |
| completed_with_warning | Technical contract hợp lệ; có exhaustion/noEOS, reserve reached/possibleforcedEOS, repetition hoặc ending heuristic | Giữ output, warning fields, denominator và scoring; không tự retry/drop |
| failed | Empty/unusable technical output, invalid native IDs/count/context/hash/lineage, missing required new-stage telemetry, backend error hoặc delivered summary invalid | Giữ attempted ID; chất lượng generation failure làNULL, không impute0; retry chỉ theo rule định trước |

“Usable” ở đây là **technical usability**, không đánh giá ý nghĩa: decoded text có ít nhất một Unicode letter/number; native IDs/count/reserve và required config/EOS metadata hợp lệ; context/hash/lineage contract do validator xác nhận; delivered text nonempty và≤350whitespace words. Formatting artifacts hoặc semantic loss vẫn cần diagnostic/scorer, không âm thầm loại bằng tiêu chí subjective.

Native IDs/config/EOS requirements chỉ áp dụng cho **neural nodes**. Lead-3/LexRank dùng source/hash/algorithm/extractive-lineage/delivered-cap validators, native EOS/reserve=N/A, không phải missing/error. Warning retention và scorer/common-coverage policy áp dụng nhất quán cả5pipelines.

EOS ở cuối không tự chứng minh natural completion; reserve reached và exhaustion-without-EOS ghi riêng. Node khôngEOS dù dưới reserve vẫn warning. EOS đúng tại reserve không gọi exhausted-without-EOS nhưng vẫn warning do reserve reached. Các warning không bị chuyển thành failure chỉ vì ROUGE thấp.

Nếu mọi node hợp lệ và delivered summary hợp lệ, một node warning làm record `completed_with_warning`. Một node technical failure làm record `failed`; giữ raw partial artifacts/cost. Scorer lỗi theo metric là trục riêng, không đổi generation status. BART clone/semantic review giữ diagnostic và không tự gate thành failure.

Mọi stage/report ghi attempted/completed-clean/completed-warning/failed riêng theo pipeline/stratum/stage. Successful generation denominator là clean+warning. Common coverage theo existing two-level selection protocol và successful metric pairs; không tự bỏ warning records, không riêng mỗi model một policy sau scores.

Policy được khóa trước selection; raw P4/P4.1 receipts không viết lại. Reclassification nếu có là derived view bind policy+source audit hashes, không đổi `status=completed` hoặc `formal_intermediate_acceptance_policy_frozen=false` trong receipts lịch sử. Runtime/pilot mới phải bind policy version/hash; old notebook/ZIP giữ nguyên, không tự coi bundle cũ đã thực thi policy mới.

Classifier là pure prospective helper, không phải standalone admission validator: future runner phải chạy source/context/hash/lineage checks và truyền kết quả technical validation rõ ràng; không dùng defaultTrue để thay evidence. Record aggregation chỉ nhận kết quả node vừa tính hoặc saved decisions đã validate schema/hash. CPU controls không được đưa qua neural node helper.

## Artifacts đã khóa và kiểm tra

- [Policy v1](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/development-decision-261019-2341/intermediate_acceptance_policy_v1.json) bind classifier+diagnostic code hashes, giữ warning outputs trong scoring/common coverage.
- [Development decision](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/development-decision-261019-2341/development_decision_v1.json) đóng default search, giữ5candidateIDs và preferred BARTcontrol/LEDngram3/Qwen384;512disabled/optional. Đây không là final admitted set.
- [Derived acceptance view](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/development-decision-261019-2341/derived_p41_acceptance_view_v1.json) trên21 outputs đã native-replay-audit:8completed,13completed_with_warning,0failed. Riêng9outputs của3preferred neural profiles:5completed,4warning,0failed. Không output/record nào bị drop hoặc regenerate; raw statuses giữ nguyên. Đây là offline application của policy mới, không evidence rằng old notebook đã chạy policy mới.
-26 unit tests cho policy helper PASS, gồm valid exhausted output, EOS-at-cap, noEOS-under-cap, inconsistent/missing telemetry, empty/unusable output, output cap và record aggregation. Không model/scorer/benchmark run.
- Final focused acceptance+telemetry+checkpoint regression:39tests PASS,0,41s. Windows pyreadline3 phát nonfatal destructor warning sau test process exit0; không lỗi model/Colab.

## Trình tự còn lại đã chốt

1. **Scorer-ready trên runtime thật.** Giữ ROUGE1/2/L, BERTScore và source similarity theo existing frozen formula/tokenizer/window/IDF=false; bind actual package/code/model/tokenizer/runtime và fixtures/long-input/E2E/cost. CPU-ready receipt đã có, không gọi nó absent. Colab torch2.11.0+cu130/numpy2.1.3 khác CPU proof torch2.6.0+cu124/numpy2.4.6; cần versioned runtime amendment/fixtures trước khi cấp Colab-ready, không chỉ copy boolean hoặc ép thay metric IDs.
2. **Recovery từ fresh Colab runtime.** Dùng unchanged P4.1 bundle+registry+runtime identity và actual Drive checkpoints, không sửa checkpoint keys để ép reuse. Xác minh hashes/source/profile/environment, restored node outputs và delivered hashes khớp, actual backend generation calls0 với những nodes đã hoàn tất. Reused nodes có new-call time0 và original cost riêng; model reload/probe/restore overhead mới vẫn tính một lần. T4 fresh-generation flag sẽfalse trên cached-only replay, đây không là recovery failure. Integrity offline ZIP hiện có không thay evidence cross-session.
3. **Pilot40** trên presealed cohort và profile ưu tiên sau stage resource/recovery/scorer gates. Thu record/stratum/stage latency, calls/tokens, peakRSS/VRAM, clean/warning/failure, checkpoint/retry/init costs. Ba source hiện tại không thay pilot40, không suy p95/upper bound toàn study từ một source/stratum.
4. **Admission và budget freeze.** Bind preferred→admitted profiles, scorer-ready, acceptance policy, trial caps, actual measurements, CPU/GPU/session/storage quotas và conservative projection. Không thêm trial vì thấy selection/test score. User guard dưới12h là per-run bound, không tự thành tổng-study quota.
5. **Selection300** hai tầng: config trong family trên common coverage; rồi fixed representatives+Lead-3 giữa family trên common coverage tính lại. Khi quyết định đã khóa mới final seal và test523 hoặc preoutcome500→400 theo budget. Không fit400 thìblocked, không tự rút mẫu.

## Còn mở

Actual formal-runtime scorer/fixtures/cost, fresh-runtime reuse proof, pilot40 resource allocation và measurements, admission/config/cap final-lock, total-study quotas/projection, final seal. Không chạy thêm model/scorer/benchmark trong lần cập nhật quyết định này.
