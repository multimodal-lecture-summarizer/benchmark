# MLPDataset: final targeted review and EDA decision

Date: 2026-10-19. **Targeted review complete with explicit HOLDs; formal GT/cohort remain unfrozen.**

The completed work covers all **82 selected original marks / 42 sources / 10 source groups**. It does not cover every released mark or every source interval. No raw annotation, media cache, executed notebook or protocol rule was changed. No further Colab run is needed to complete this targeted queue.

## Deliverables

- [Versioned decision ledger](../../benchmark/experiments/registry/datasets/mlpdataset-targeted-adjudication-v2.json): immutable original identities, reviewed events, exact PTS evidence, mappings, reasons, source gates and predecessor/protocol/notebook bindings.
- [Flat 82-row CSV](../../benchmark/experiments/registry/datasets/mlpdataset-targeted-adjudication-v2.csv): convenient row-by-row review; JSON is authoritative for effect intervals and evidence.
- [Manual visual decisions](../../benchmark/experiments/scripts/mlpdataset_final_visual_decisions.py), [builder](../../benchmark/experiments/scripts/build_mlpdataset_final_adjudication.py) and [integrity verifier](../../benchmark/experiments/scripts/verify_mlpdataset_final_adjudication.py).
- [Frozen semantic/scoring rules](../../docs/mlpdataset-slide-transition-protocol.md), unchanged. Earlier [sampled v1 ledger](../../benchmark/experiments/registry/datasets/mlpdataset-sampled-adjudication-v1.json) remains a historical proposal, not overwritten by v2.

`included_local_review` means a resolved event mapping with a locally reviewed PTS observation. It does **not** mean source equivalence, raw native-cache certification, complete event GT or formal scoring eligibility. Every source in the targeted ledger still has `formal_scoring_eligible=false`.

## Final row decisions

| Decision | Original rows | Meaning |
|---|---:|---|
| Included local review | 40 | Clear instructional replacement, explicit mapping and locally reviewed last-old-frame point |
| Excluded non-target | 11 | Four true source starts and seven auxiliary intro/presenter/outro/credit cases |
| HOLD | 31 | Explicit unresolved source, event assignment or timing issue; no point assigned to the row |
| Total | 82 | Every selected original index/time/annotation SHA/source SHA preserved |

The **40 included rows identify 28 unique mapped primary events**. Repeated rows remain separately traceable; scoring must count each canonical event once. These are diagnostic, deliberately selected cases, so the decision ratios are not estimates of dataset label accuracy or event prevalence.

The event inventory has **43 canonical observations: 39 primary candidates and four auxiliary events**. Of the 39 primary candidates, **35 have local PTS points**: 34 hard cuts and one wipe. Seven of these points belong to events whose original-row assignment remains ambiguous, leaving 28 mapped unique points. Four primary effects retain timing HOLDs. Two additional ALRJ observations are explicitly supplemental, not extra GT events.

## What remains HOLD and why

| Cause | Rows | Action recorded |
|---|---:|---|
| Released timestamp beyond measured source end | 18 | Source-edition/timebase mapping not established. Never clamp to EOF, shift globally or exclude merely because a final frame is an end card |
| Multiple primary events, ambiguous original-row assignment | 6 | Three fast-dental rows, two optimization rows and one appliance row retain candidate event lists without nearest-time or ordinal assignment |
| Subtle crossfade/rotation/push timing | 4 | One colon/stool crossfade, two consciousness rotations and one vertical push have no forced last-old point; observed frames/brackets retained |
| No target event in finite inspected window | 2 | Unchanged title/final instructional page does not prove source-wide event absence; annotation mapping remains unresolved |
| Figure replacement versus terminal blank | 1 | ALRJ row remains unresolved; earlier figure change and later blank are recorded separately |
| Total | 31 | Concrete final targeted HOLD decisions, not extraction failures |

For the ALRJ source, the muscle-to-motor-unit figure change is bracketed by native frames at **847.04/847.08 s**, and diagram-to-blank by **848.96/849.00 s**. The remaining 200 presentations through 856.96 s show no incoming slide before the 857-second source end. Neither observation justifies automatically rewriting the released mark as a primary event.

For the wipe, full-size presentation inspection matters: clean-old frame12 at **13.9 s**, first thin transition line frame13 at **13.933333333 s**, last visible transition edge frame35, and clean stable-new frame36 at **14.7 s**. The reviewed endpoint is 13.9 s, not the midpoint or the first clearly recognizable new page. These are source-relative PTS observations from the saved presentation evidence, not requested preview timestamps.

## Repeated rows and protocol

All 14 originally identified repeated groups are accounted for: **11 map multiple rows to one primary event**, two remain ambiguous among multiple events, and one contains auxiliary outro events only. The appliance case adds one non-repeated row with two candidate primary events. No row was sorted away, deleted, epsilon-shifted or silently deduplicated.

The protocol remains: primary internal full instructional replacements; endpoint at the last fully old native frame before replacement begins; separate onset, effect-end and stable-new fields. Same-heading replacement can qualify; within-slide builds, lecturer motion, credits and source boundaries are auxiliary. Primary collar is 0.5 seconds, with predeclared 1/2-second sensitivity; per-video one-to-one matching maximizes cardinality, then minimizes timing error. No predictions or detector scores influenced these decisions.

For a hard cut, onset/end/first stable new can coincide. For the wipe, last effect frame and first stable new are recorded separately, with effect-end defined as completion at the first stable new frame. Uncertain effects keep null point fields and explicit uncertainty/missing-context notes rather than a midpoint.

Independent final review corrected the crossfade uncertainty: native frame0 is fully old, frame6 at 1965.72 s already mixed, and frame35 stable new. The ledger retains conservative onset bracket0..6 and completion bracket22..35. The earlier coarse last-old observation at 1965.76 s is superseded; it must not be promoted to a reviewed point.

## Dataset-wide EDA conclusion

| Scope | Current evidence | Interpretation |
|---|---|---|
| Inventory | 333 sources, 9,021 released marks, approximately 186.634 hours | Preserve the entire inventory; 315 structural candidates are not a qualified evaluation cohort |
| Acquisition | All 333 source media downloaded in the completed run | Earlier bot/403 failures no longer describe current acquisition status |
| Sparse previews | 2,913 frames at 987 marks; 48 outside-source requests; zero pending | The previous 388 pending preview requests are finished; 8,034 marks were not individually previewed |
| Targeted dense run | 48 new contexts / 16 sources / 1,771 frames, all ready; historical evidence also retained | Diagnostic ambiguity review, not random sampling or whole-source completeness |
| Native follow-up | 64/64 jobs across 38 sources; 3,553 frames displayed; zero saved Python/display errors or omissions | Extraction queue complete; seven other selected historical cases explicitly remain coarse |
| Targeted adjudication | All 82 rows assigned final local include/exclude/HOLD decisions | This queue is complete; formal benchmark qualification is separate |

The dataset is usable now as a **diagnostic source for slide-transition research** with an honest released-label track and separately versioned reviewed observations. It is not yet a complete, repaired gold-standard event benchmark. Released slide-end timestamps mix instructional replacements, within-slide changes, boundaries and auxiliary content; some repeated rows map to one event, while other windows contain several events. A uniform timestamp shift cannot repair this mixture.

Empty/missing annotation sources remain **unlabeled**, not known negatives: six empty annotation sources and one missing-folder source must not create automatic zero-event GT. The earlier author-release comparison also remains unresolved: packaged archives contain 333 rows while pinned repository CSVs contain 334. Neither inventory coverage nor successful downloads settles media-use rights or source-edition equivalence.

All ten source groups have appeared in EDA. Source-group names are proxies, not verified independent speakers/courses. These outputs support no blind-test, detector ranking, model-selection, full-source recall or independent confidence-interval claim.

## Verification and evidence limits

The native notebook remains **102,585,725 bytes**, SHA256 `bfa246af81cb2e610d3f3961f889de5db8d7002b22bf012397318ad2c6c3b876`. The executed EDA and targeted notebooks remain unchanged as well. The new ledger binds the unchanged protocol, predecessor ledger, original/native queues, bound notebook bundle, frame ledger, job audit, manual decisions, saved logs and executed native notebook.

Focused verification passes:

- Exact 82-row coverage and original index/time/source/annotation hash preservation; all 18 overshoots HOLD, all four true zero-time starts excluded.
- Every referenced JPEG matches the immutable frame ledger, and all 3,553 local JPEG hashes pass.
- All 64 saved logs match the notebook-log text hashes after documented Windows CRLF restoration, preserving standalone progress carriage returns. Physical saved-log file hashes are separately bound.
- Frame indices/integer PTS/rational time bases match full FFmpeg logs; PTS are strictly increasing and inside bound half-open jobs, allowing 1e-8 seconds only for printed elapsed-time rounding.
- Point/last-old equality, adjacent onset indices, separate effect fields, reciprocal row/event mappings, unique event accounting and JSON/CSV decision consistency pass.

The verifier checks integrity and consistency, not semantic truth. Visual decisions used **scaled, lossy JPEG presentations at native temporal cadence** plus continuous historical clips. Raw source media, native PNG cache and independent ffprobe/checkpoint JSON remain on Drive and were not independently rehashed locally. Runtime readiness reported independent ffprobe PTS checks; matching captions to saved showinfo logs does not replace an independent local audit of those raw artifacts. No raw-native certification is claimed.

Local validation receipt: `benchmark/experiments/outputs/mlpdataset_native_executed_review_261019/final-adjudication-validation.json`. The evidence directory is intentionally ignored/local. Rebuilding requires that retained local evidence; moving JSON/CSV alone does not recreate the images/logs.

Independent scientific review **PASS**: original-row coverage, hashes/logs/PTS, reciprocal mappings, all source-edge decisions, conservative effect brackets and the report's qualification limits were checked. Final ledger SHA256: `ba47a871675375f839c773318e206889c84c7c9dcb4576c8b66e925e215d3483`. [Retained validation summary](../../benchmark/experiments/registry/datasets/mlpdataset-targeted-adjudication-v2-validation.json) also binds the CSV and verifier.

## Before a formal comparison

Do not rerun completed extraction as a substitute for the remaining scientific gates. First establish source/annotation edition and timeline equivalence for the 18 overshoots; resolve ambiguous mappings/effect bounds from raw evidence or retain affected sources as ineligible. Audit full-source annotation completeness for any eventual scoring cohort, including missing events between released marks. Then verify source-use provenance and dependence groups, declare prior EDA exposure, freeze eligible IDs/track/splits and bind all GT/media/protocol/scorer hashes before detector comparison.

Unresolved: raw-source/PNG/probe independent certification; 31 justified targeted HOLDs; whole-source missing-event coverage; archive/CSV inventory discrepancy; rights/dependence grouping and honest cohort/split freeze. None changes the completion status of this targeted review.
