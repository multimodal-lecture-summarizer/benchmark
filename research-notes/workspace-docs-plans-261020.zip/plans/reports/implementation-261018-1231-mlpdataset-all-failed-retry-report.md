# All remaining failed-source retry

Implemented default all-failed retry in standalone notebook; no actual new YouTube downloads performed locally. User runs on Colab. Exact received executed notebook preserved at benchmark/experiments/outputs/mlpdataset_all_failed_retry_261018/received-representative-executed.ipynb.

## Change

RETRY_FAILED_SCOPE=all-failed(default) takes all pre-existing failed checkpoints withinmedia selection,currently119; it doesnot hardcode119orvideoIDs. Wrapper reusesexistinggroup-balancedselector withlimit=len(states),assertsselected_count==failurepool andexcludesdownloaded214. Optionalrepresentative restores12/10minbehavior. LegacyRUN_REPRESENTATIVE_RETRY switch remains masterenable forbothscopes;RETRY_FAILED/DOWNLOAD_MEDIA stillhonored. Empty/disabledpool safe.

All-failed retrywindow300minutes andglobalacquisition300minutes,120s perselectedsource,3s gap;mediacap increased8→16GiB. Original300MiB pervideofolder,1GiBfreefloor,0.5GiBdownloadreserve,1GiBanalysis/logcap preserved. Theseareupperlimits,notexpectedruntime orall-recoveryguarantee.119 worstcasetimeoutcommands+gaps fitwithin nominal300minbeforeoverhead; storage/network canstillblock. Everyselectedsource getsactualnewoutcome orprecisenonattemptreason.

Source/frameidentities andallpriorhelperASTunchanged;cachehash/probevalidated,partialfilesresume,numberedattemptlogs/history retained. Preview/format/fullcoverage sources25/27/29unchanged. Recordorder restored;all333/9021accountingretained. Inlineprogress distinguishes checkpoint-before-attempt fromRetryN/pool andactualoutcome. TableFAILED-SOURCE RETRY RESULTS plusfullpool/selection/summary/logs. ExistingCSV/JSONfilenames+representative_retry receiptkey preservedwithscope/codeversionv2;receiptrevisionv10. No auth/cookies/GT/semanticrepairs/deletion/commit/push.

## Verification

6newfocusedtests passed9.203s:actualcurrent119selected/214cacheexcluded,ignoredsamplecap/representativemode/remap/disabled/empty/group,localchildprocess+realffprobe/hash/cache/history,all/global/storagebudget/corruptcache/exit0nofilesuccessrejected.5existingrepresentative,8realFFmpegpreviewresume,stagebudget,full333/9021inventory+receiptstrictJSON/history/everyartifacthash regressions passed. All20codecellsparse;33cells retained;sourceASTcompareconfirmsoldhelper/preview/coveragecontracts. Independentplan/codereviewfoundnoblockers. Guide/journalupdated;finalizeartifactgatepassed.

Run:newnotebookupload,sameDrive/RUN_NAME,CPU Runall;saveexecutedoutputs. NextColabreceiptmustconfirmselected/started/recovered/pendingcounts forallcurrentfailures.

Unresolved: realall-failedColaboutcomes,remainingmediaavailability/Drivequota,completevisualsemantic/timebase/rightsqualification. Fullselection doesnotmeanall119willrecover.
