# TESTR recovery, PGNet replacement và Colab T4 qualification

Historical preparation snapshot. Current delivery was consolidated into canonical ZIPs; superseded variant files were deleted by user request. See [current guide](../../docs/cvid-joint-spotting-colab-t4-run-guide.md) and [cleanup record](../../docs/pgnet-delivery-cleanup-261015.md); old hashes below describe their dated snapshot.

Ngày nghiên cứu: 15/10/2026, Asia/Bangkok. Trạng thái: TESTR chưa lấy được weights; PGNet artifact/adapter và notebook v2 đã chuẩn bị; CPU train diagnostic hoàn tất. Theo yêu cầu người dùng, demo GPU đã hủy khi đang cài dependencies, xác nhận0 task processes còn chạy; GPU forward chưa được xác minh. Chưa có full test comparison.

## Điều hướng

1. Quyết định và căn cứ
2. Checkpoint/config đã khóa
3. Bằng chứng runtime và giới hạn
4. Notebook, gate và cách chạy
5. Việc còn mở

## 1. Quyết định và căn cứ

Không đưa TESTR vào comparison ở trạng thái hiện tại. Kiểm tra lại 12 URL SharePoint trong README chính thức (gồm model và data links) đều chuyển tới Microsoft authentication. URL R50 Polygon TotalText trả HTTP200 nhưng `Content-Type=text/html`, final endpoint là trang đăng nhập; **không phải checkpoint bytes**. Không vượt authentication, không gán SHA của HTML thành weights. [Repository tác giả](https://github.com/mlpc-ucsd/TESTR).

Colab đã cấp thật **Tesla T4 / 15.360 MiB**, driver580.82.07, Python3.13.15 và nvcc13.0.88. Stack TESTR đã chọn dùng Python3.8/Torch1.10.1/CUDA11.3/Detectron2; current VM không đáp ứng toolkit profile đã seal. Điều này chưa chứng minh TESTR không thể chạy trên T4 nếu có weights và dựng lại toolkit thích hợp; hiện cả acquisition lẫn reproducible build gate chưa đạt.

Chọn **PGNet English, official PGNetA inference export, TotalText polygon/fast postprocess** làm candidate thứ sáu. PGNet chia sẻ CNN features cho các head border/centerline/direction/character và point gathering, bổ sung vai trò joint localization–recognition. Nó không phải Transformer, nên không dùng kết quả để kết luận Transformer joint spotting tốt/xấu hơn pipeline. [Paper PGNet](https://arxiv.org/abs/2104.05458).

PGNet được chọn vì có weights công khai từ chính PaddleOCR, native polygon+text, inference CPU/GPU không cần build Detectron2 custom ops, và giữ được endpoint spotting. Đây là lựa chọn trước điểm test, không theo leaderboard hoặc kết quả accuracy CVID. DeepSolo vẫn có Python3.8/Torch1.9/CUDA11.1/Detectron2v0.6 trong hướng dẫn tác giả, nên chưa giải quyết trực tiếp trở ngại legacy custom-op của TESTR. [DeepSolo installation](https://github.com/ViTAE-Transformer/DeepSolo/blob/main/DeepSolo/README.md).

## 2. Checkpoint/config đã khóa

Weights tải thành công từ [official inference archive](https://paddleocr.bj.bcebos.com/dygraph_v2.0/pgnet/e2e_server_pgnetA_infer.tar), URL do [tài liệu PaddleOCR](https://www.paddleocr.ai/v2.9/algorithm/end_to_end/algorithm_e2e_pgnet.html) cung cấp. Archive195.768.320bytes, SHA256:

```text
archive: 43085149cbc7f370c06679d011fe8818e68dc464fa1998f4ae6fb836d7d6b1e2
inference.pdiparams: 1e662920fa5f01757a9b97402b0080889fb7c2bcd85331df55e710494c1c60cb
inference.pdmodel: 2e1f0e4ac5e3c31b3875086f05f2636a20ce6037f6e2179898a1efa25c2ccf3d
inference.pdiparams.info: da925dcb46daa99968804146121101895786c62b7dfa83c3320085cf44beb986
ic15_dict.txt: 71e9aa833ec424844f3670bb5f1a2851867b9ce963f78df531e45d3a4c77dd72
```

Dictionary nằm trong PaddleOCR2.8.1 wheel có hash đã khóa; 36 symbols `0-9a-z` là giới hạn đáng kể với punctuation/uppercase/diacritics. Không sửa vocab hoặc GT để ưu ái PGNet. Native postprocessor tên `Lexicon_Table` ở source thực chất chứa character dictionary này, không có dataset word lexicon được bổ sung.

Config: score threshold0.5, `e2e_pgnet_valid_set=totaltext`, `mode=fast`, `e2e_limit_side_len=768`, CUDAFP32, TensorRT/ONNX/MKLDNN tắt. Native E2EResizeForTest TotalText dùng factor1.25, cap theo height và làm tròn hai chiều lên stride128; không mô tả nhầm thành generic max-side resize. Normalize1/255, mean[.485,.456,.406]/std[.229,.224,.225], BGR input theo implementation, HWC→CHW. Giữ integer clipping bên trong official TextE2E, không thêm split/merge/repair của adapter. API không trả region confidence nên không bịa score1.0.

Môi trường riêng theo legacy Paddle profile: managedPython3.10.16, PaddleOCR2.8.1, PaddleGPU2.6.2, numpy1.26.4, protobuf3.20.2 và explicit CUDA11.8/cuDNN8 NVIDIA wheels. Loader paths được truyền trước khi chạy worker. Resolved wheel graph, installed bytes và mapped native libraries được seal theo notebook prepare/preflight.

## 3. Bằng chứng runtime và giới hạn

### Local CPU diagnostic

Chạy weights thật bằng official TextE2E trên đúng9 frame train đã chọn score-independent. Tất cả9 forward hoàn tất,199 predictions, trong đó1 native polygon không hợp lệ. Không chấm GT/accuracy; chưa có test inference. [CPU receipt](../../benchmark/research-data/joint-spotting-261015/local-cpu-diagnostic.json).

Polygon lỗi vẫn được giữ nguyên. V2 áp dụng **chung cho cả sáu candidate**: preflight kiểm runtime/schema, ghi invalid geometry, yêu cầu có ít nhất một valid region trong bộ train; không loại candidate chỉ vì có một prediction lỗi. Khi chấm test, invalid polygon vẫn là FP theo scorer đã khóa. Không thay matching, GT hoặc failure denominator. Đây là sửa admission policy để không biến preflight thành lựa chọn theo chất lượng prediction, không phải sửa model output.

### Colab T4

Đã chạy cell kiểm tra phần cứng trên notebook qualification riêng. Không chạy test cohort. Demo upstream-only đã dừng theo yêu cầu mới khi đang cài dependencies, trước model forward; chỉ tải package công khai, không upload code dự án hoặc ảnh CVID. Không sử dụng notebook demo đã hủy như bằng chứng inference.

Gói qualification trên9 ảnh train CVID và code project đã chuẩn bị riêng (~3,9MB,0test images). Bộ duyệt tự động chặn upload vì thiếu chấp thuận cụ thể cho truyền dataset/code sang Colab. Người dùng chọn chỉ chuẩn bị/kiểm tra local và tự chạy code; không upload. Có [hướng dẫn người dùng tự thực hiện](../../docs/cvid-joint-spotting-colab-t4-run-guide.md) và notebook preflight unexecuted.

## 4. Notebook, gate và cách chạy

- [Notebook v2](../../benchmark/experiments/notebooks/iiit-cvid-spotting-colab-t4-v2.ipynb).
- [Bundle v2](../../benchmark/experiments/outputs/iiit-cvid-spotting-colab-t4-inputs-v2.zip).
- [Registry v2](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-colab-t4-candidates-261015-v2.json).
- [Train qualification package](../../benchmark/experiments/outputs/joint-spotting-t4-qualification-261015.zip).
- [Official acquisition audit](../../benchmark/research-data/joint-spotting-261015/official-acquisition-audit.json).

V2 có **sáu required candidates**: giữ nguyên toàn bộ năm candidate đầu, thay TESTR bằng PGNet; TESTR nằm trong exclusion provenance. Cohort1.754frames/40.063GT và scorer không đổi. V1 notebook/bundle/receipt giữ nguyên hash để bảo toàn lịch sử. Mọi candidate phải qua actual train preflight trong đúng run identity trước full test; PGNet chưa đủ gate sẽ chặn bảng sáu candidate, không bị bỏ qua sau khi thấy điểm.

Đặt bundlev2 tại `MyDrive/OCR/iiit-cvid-spotting-colab-t4-inputs-v2.zip`, mở notebookv2, chọn T4, dùng run IDv2 mới. Checkpoints, cache, receipts, sensitivity và sáu plots kế thừa workflow hiện tại. Không nhập CPU predictions hoặc receipt public demo thành full-cohort completion.

Local:80tests passed; v1 hashes giữ nguyên; v2 exact ZIP membership/hash và notebook binding đã xác minh. Không có bằng chứng full comparison, latency superiority hoặc generalization từ các kiểm tra này.

## 5. Việc còn mở

- Người dùng tự chạy notebook preflight, lưu receipt/logs/notebook output; không coi hardware check hoặc CPU diagnostic là GPU pass.
- Không có quyền agent upload/train-forward Colab; người dùng tự quyết định thao tác upload và execution theo hướng dẫn.
- TESTR vẫn cần checkpoint tác giả truy cập hợp lệ và compatible build stack.
- Full six-candidate inference/scoring chưa chạy; CVID selective annotations, exposed-test và bảy course proxy limits giữ nguyên.
