# TIB text reuse and paper attribution evidence

Research: 2026-10-19, Asia/Bangkok. Scope: P1 evidence only; no benchmark, model execution, record permission certification or dataset modification.

## Summary

**Confirmed:** official TIB release identity; paper attribution for Lead-3 and reference-aware Extractive Oracle; separate origins of author-provided abstracts and automatically generated transcripts. **Not established:** one dataset-wide license covering every released transcript and abstract. Missing license or inaccessible HTTP response establishes neither permission nor prohibition.

Recommended order: (1) bind actual text to authoritative field-specific terms; (2) use verified source-record licenses for the intended local text use with conditions recorded; (3) retain unresolved records as unknown for that use. Keep acquisition/provenance audit separate from a sealed permission decision. No requirement to manually review all 9,103 records, download all media, or create new scientific gates.

## Sources and credibility

Three independent authorities consulted: dataset authors, TIB, Creative Commons. Author card/repository/blog are corroborating sources from one author group, not independent legal grants. Primary-source text only; no tutorial-based conclusions.

| Evidence | Authority / strength | Boundary |
|---|---|---|
| [Pinned HF card](https://huggingface.co/datasets/gigant/tib/blob/e6ab9fd7c6acd164f3284b8c4b17eb9d94681eee/README.md) | Official released snapshot; strong schema/source evidence | Local bytes read; no dataset-level license declaration found; row `license` is a record field |
| [Author repository](https://github.com/giganttheo/tib-dataset) | Official author provenance; strong identity linkage | Links HF, paper and blog; publication alone does not grant additional rights |
| [HAL v1 paper](https://hal.science/hal-04168911v1) | Author manuscript; primary method attribution | Genuine local PDF recovered; July 28, 2023 version; HAL cover says HAL Authorization, not a dataset license |
| [Author blog](https://giganttheo.github.io/tib) | Author explanation, September 25, 2023 | Corroborates transcription, variable abstracts and baseline methods |
| [TIB Open Data](https://av.tib.eu/opendata) | Data provider; primary grant and field documentation | Applies to supplied metadata/thumbnails whose reuse is permitted; actual row/text binding still needed |
| [TIB FAQ](https://av.tib.eu/faq) | Provider explanation; strong source-license distinction | Distinguishes open licenses from consent-only media access |
| [TIB Special Conditions](https://av.tib.eu/terms) | Provider terms, effective March 4, 2026 | Portal use terms; §1.1 says film publication/sublicenses involve separate agreement |
| [CC BY 4.0](https://creativecommons.org/licenses/by/4.0/legalcode.en), [CC0](https://creativecommons.org/publicdomain/zero/1.0/legalcode.en) | License publisher; controlling text for those versions | Only rights the licensor/affirmer can grant; does not extend the scope of a TIB grant |
| [CC FAQ](https://creativecommons.org/faq/), [BY-ND 4.0](https://creativecommons.org/licenses/by-nd/4.0/legalcode.en), [BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/legalcode), [BY-NC-SA 3.0](https://creativecommons.org/licenses/by-nc-sa/3.0/legalcode) | License publisher; version-specific terms | Do not silently substitute 4.0 for German-ported or 3.0 terms |

## Official paper: attribution now verified

Citation: Théo Gigant, Frédéric Dufaux, Camille Guinaudeau, Marc Décombas. *TIB: A Dataset for Abstractive Summarization of Long Multimodal Videoconference Records*. CBMI 2023, ACM, Orléans. DOI [10.1145/3617233.3617238](https://doi.org/10.1145/3617233.3617238); HAL-04168911v1, submitted July 28, 2023.

| Claim | Exact evidence | Assessment |
|---|---|---|
| Lead-3 is a TIB paper baseline | §5.2, PDF p5 / printed p4; first three transcript sentences | SUPPORTED attribution; proposed local splitter/output cap is not thereby a reproduction |
| Extractive Oracle is reference-aware | Same section; sentence selection maximizes ROUGE against target; footnote 6 links [extoracle_summarization](https://github.com/pltrdy/extoracle_summarization) | SUPPORTED diagnostic role; not a deployable candidate or independent gold |
| Both were evaluated | Table 2, PDF p7 / printed p6 | SUPPORTED historical paper result; not a local result |
| Metrics and truncation | §5.1–5.2: ROUGE/BERTScore via Evaluate defaults; input-limited models truncated | SUPPORTED description; exact dependency versions, sentence splitter and Oracle settings not independently recovered |
| Text-only target relationship | §4 and §5: copied source abstracts; Whisper-small multilingual transcripts | SUPPORTED source distinction; abstract agreement cannot establish comprehensive lecture-summary quality |

Author blog specifically describes Oracle as a ROUGE-2 extractive upper bound. Paper says ROUGE; keep that distinction rather than inventing a recovered implementation configuration. Algorithmic search ceiling is not certified mathematical optimality without inspecting its search settings.

Local paper: `benchmark/research-data/tib-evidence-261019-1507/sources/hal-paper.pdf`, 2,938,494 bytes; SHA-256 `3b6cdf70eec79f47cc6af461ddbeb458ff659cca800cc9567ce33770d1b3b0be`.

## Text rights: supported scope and remaining conditions

**TIB CC0 route:** the live Open Data schema includes `metadata.abstracts[].value` and `metadata.transcriptions[].vtt`, including ASR/source/version attributes. This is stronger than saying Open Data never contains full transcripts. The grant covers the supplied qualifying export records. It does not establish that every HF abstract appears there unchanged, or that TIB-exported transcripts equal the dataset authors' independently generated Whisper-small output. Match source ID/URL and actual text; preserve discrepancies. The live export date is 2026-10-19; search cache showed an older May export, so prefer downloaded current HTML over cached dates. [TIB Open Data](https://av.tib.eu/opendata).

**Video-license route:** if source-record terms cover the spoken work and relevant reproduction/transformation rights, text derived from that speech can have a supported license route without acquiring video. Preserve author, source, exact license URI/version, and transformation attribution. CC BY 4.0 allows copying and adaptation within granted rights; it does not grant third-party rights absent from the licensor's authority. Whether a transcript is merely a technical format change or an adaptation depends on the actual transformation and applicable law. [CC BY 4.0 §§1–3](https://creativecommons.org/licenses/by/4.0/legalcode.en).

**Separate abstract route:** source video terms cannot automatically prove permission for separately authored reference abstracts. A matching abstract in a qualifying CC0 export offers a direct route; alternatively retain a specific grant covering that abstract. A DOI, public page or row license label alone is insufficient field-scope evidence. CC0 waives the affirmer's rights; it does not clear all other persons' rights. [CC0 §4](https://creativecommons.org/publicdomain/zero/1.0/legalcode.en).

**Consent-only route:** TIB FAQ permits viewing/listening/downloading these media but states users may not redistribute them or publish them themselves. This is evidence about consent-based media terms; it is not a complete answer about every possible private transcript analysis, legal exception, or separately released abstract. [TIB FAQ, licensing section](https://av.tib.eu/faq).

## License-family handling for the actual use

| Observed family | Local transcript/abstract analysis | Sharing source text, normalized text or expressive outputs |
|---|---|---|
| CC0, field scope matched | Supported within identified grant | Retain provenance; no automatic third-party clearance |
| CC BY, source scope matched | Conditional on version and actual rights | Retain attribution, license, source and modification notices |
| CC BY-SA | Conditional; SA does not itself forbid analysis | Determine adaptation versus collection; SA obligations can attach to shared adaptations |
| CC BY-NC / NC-SA | Conditional on actual noncommercial use | Academic label alone does not resolve commercial purpose; preserve NC/SA conditions |
| CC BY-ND / NC-ND | Version-sensitive; do not automatically reject all local analysis | BY-ND 4.0 permits producing/reproducing adaptations privately but not sharing them; older versions differ |
| No Open Access / absent / conflicting prose | UNKNOWN for the specific text use until further evidence | No automatic allow or blanket legal deny |

ND is not a reliable synonym for “no transcript”: CC permits format changes; transformation status and license version matter. Conversely, a generated summary is not automatically cleared for public redistribution merely because inference ran locally. Statutory exceptions may apply independently, but this research does not decide a jurisdiction-specific exception. [CC FAQ](https://creativecommons.org/faq/), [BY-ND 4.0 §2](https://creativecommons.org/licenses/by-nd/4.0/legalcode.en).

Preserve inconsistent raw license prose. Resolve headings such as BY-SA versus a noncommercial sentence using the authoritative linked legal code/source page; do not silently rewrite the release or select whichever interpretation is convenient. [BY-SA 3.0](https://creativecommons.org/licenses/by-sa/3.0/legalcode), [BY-NC-SA 3.0](https://creativecommons.org/licenses/by-nc-sa/3.0/legalcode).

## Ranked evidence strategy and trade-offs

| Rank / route | Evidence benefit | Complexity / cost / maintenance | Adoption risk / architectural fit |
|---|---|---|---|
| 1. Field binding to official terms, grouped by common evidence | Strongest explainable eligibility; separates transcript/reference | Small mapping work; text comparison can be automated; retain date/hash | Fits existing P1 ledger; authoritative mature provider, current exports may change |
| 2. Source-record CC route for specific intended use | Useful when independent transcript differs from Open Data | Version/NC/SA/ND conditions need explicit handling | Fits text-only pipeline; narrower claims, no need to download media |
| 3. Unknown plus targeted evidence follow-up | Honest unresolved status; avoids guessed permission | Low immediate cost; unresolved records cannot support a sealed permitted cohort yet | Fits audit-unsealed state; targeted follow-up only, no universal manual review |
| Reject: blanket allow from public hosting/CC0 title or blanket deny from missing license | No reliable field-specific conclusion | Superficially cheap; expensive later rework | Incompatible with P1 provenance contract |

These are evidence routes, not new datasets, model recommendations or additional study branches. Software community size and breaking-change history are not decision criteria here; source drift, grant scope and versioned license interpretation are the relevant maintenance risks.

## Next steps and limitations

1. Bind root's measured row counts and acquisition receipt separately; this report does not infer observed counts from the card.
2. Record `text_use`, `reference_use` and `redistribution` decisions separately, with source URL/version/hash and supported/conditional/unknown reason. Common policy evidence can be shared across rows; exceptions need row trace.
3. Replace stale Lead-3/Oracle attribution UNVERIFIED with verified paper locations; retain local reproduction/configuration UNVERIFIED.
4. Keep source bytes, raw license strings and old artifacts unchanged. No inference or model acquisition authorized by this report.

Initial research limitation: this subtask did not acquire the Open Data ZIP. The completed root acquisition and full field-binding scan below supersede that initial availability limitation. Remaining limits: no jurisdiction-specific copyright/TDM adjudication, third-party-rights clearance, runtime or local benchmark reproduction. Official paper establishes authors' methods, not permission for every dataset component.

## Completed field binding update

Root acquired the official 2026-10-19 Open Data ZIP: 646,383,491 bytes, SHA-256 `444868bae152872830231c40156bda076b255a8a9b4f1d917ce0229c92b55173`; all 44,254 media records scanned. [Tracked field summary](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/evidence-261019-1507/field_rights_summary.json), [availability](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/evidence-261019-1507/rights_availability_summary.json), [independent review PASS](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/evidence-261019-1507/independent_review_receipt.json).

- 6,521/9,103 source IDs found; 6,520 equivalent DOIs after technical display normalization. Earlier conservative raw-DOI HOLD is superseded; raw identifiers preserved.
- 5,592 abstracts have `SUPPORTED_CC0_FIELD_MATCH`: 2,459 raw exact plus 3,133 NFC/whitespace exact. Remaining 3,511 retain HOLD for missing/unmatched/empty field evidence.
- Zero released Whisper transcripts matched TIB export transcript text. Source text: 6,503 `CONDITIONAL_SOURCE_CC_SCOPE_AND_USE`, 2,600 HOLD; these are evidence classifications, not legal clearance.
- 5,577 combine supported reference with conditional source: train 4,456 / valid 567 / test 554. **These are not qualified cohort counts.**
- One DOI difference: `train:3780`, released `10.14288/1.0398149` versus Open Data `10.14288/1.0398140`, source media 54270. Preserve FLAG: card permits an associated-paper DOI; difference alone does not prove a wrong record.
- G1 remains `HOLD_PENDING_REMAINING_FIELD_SCOPE`; no selected IDs or benchmark outputs. Remaining action targets actual source-use conditions and unresolved text fields, not already matched abstracts.

## Unresolved questions

- For 3,511 unmatched/missing/empty reference fields, what additional source evidence resolves the specific field scope?
- For 6,503 conditionally supported source texts and the remaining 2,600 HOLD, which grants cover intended local use and what sharing conditions apply? Zero CC0 transcript matches currently resolves none through that route.
- Which conflicting raw license labels can be resolved by authoritative URI/version evidence?
- What exact splitter, Oracle search parameters and dependency versions would be needed before claiming paper reproduction?
