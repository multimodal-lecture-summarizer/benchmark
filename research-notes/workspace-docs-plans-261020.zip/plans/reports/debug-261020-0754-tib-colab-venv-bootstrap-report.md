# Colab scorer venv bootstrap correction

User traceback: Python3.13 `/usr/bin/python3 -m venv --system-site-packages .../venv` exits1 before requirements installation or model loading. Actual stderr was not supplied, so the exact Colab cause remains unconfirmed.

Confirmed notebook defects: venv subprocess output was not persisted by `execute`; failure can leave `bin/python` present and rerunning would wrongly skip environment creation. Default venv invokes ensurepip; missing/broken ensurepip is a plausible cause, not a confirmed diagnosis. [Python3.13 documentation](https://docs.python.org/3.13/library/venv.html).

Notebook v2 creates/repairs the same venv with `--system-site-packages --without-pip`, verifies target prefix identity, then uses base `pip --python <target>` to install the unchanged requirements. This pip-less target workflow is [officially supported since pip22.3](https://pip.pypa.io/en/stable/topics/python-option/). No environment deletion, base-environment package installation, dependency relaxation or metric changes.

Use [notebook v2](../../benchmark/experiments/notebooks/tib-p4-scorer-colab-t4-261020-v2.ipynb), with the same existing v1 ZIP. Bootstrap logs are exported as `create-venv.log`, `venv-identity.log`, `install.log`; `bootstrap_policy.json` binds the setup-cell hash. [Versioned bootstrap amendment](../../benchmark/experiments/registry/protocols/tib-scorer-colab-runtime-261020-v1/bootstrap_amendment_v2.json). Original v1 notebook, scorer ZIP, historic receipts, metrics, dataset/cohorts and acceptance policy remain unchanged.

**40 local tests passed**, exit0. Includes controlled missing-ensurepip failure leaving an interpreter, real stdlib venv repair and real offline wheel installation into the target with pip --python, plus failed-create/identity/install log+HOLD guards, runtime/scorer/checkpoint regressions and stale-PASS tests. Windows pyreadline finalizer emitted its existing nonfatal warning after successful exit. No model loading, generation or actual Colab execution. V2 code cells compile; unchanged ZIP and frozen six-file hashes verified.

Remaining: run v2 on the actual Colab T4 runtime. Readiness remainsHOLD. If creation still fails, `create-venv.log` now supplies the missing stderr; do not infer that ensurepip caused that new failure.
