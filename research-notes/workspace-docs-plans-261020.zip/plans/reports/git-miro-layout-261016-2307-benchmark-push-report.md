# Benchmark push and Miro layout

Completed: five commits pushed to origin/main. Remote HEAD equals local `6f79c52586c0ada7592c30e96fbfa9b9ff562a35`. Latest cleanup commit deletes only misplaced unexecuted LVVO draft; canonical executed EDA retained. Scoped diff and credential checks passed; unrelated 70 untracked files retained. No force push.

Miro research layout: moved 12 existing task frames into rows sized to their real footprints, expanded crop/keyframe frames and spaced crop tables and keyframe captions/images. Fixed ASR/slide and spotting/Detection A frame collisions. Seventy existing items updated; zero created/deleted. All 171 original IDs, text, table cells and stable record/field IDs preserved by readback comparison. Dataset and overview text boxes have no pairwise overlap; index remains clear of task tree.

Fresh measured bounds confirm zero frame overlaps and zero table-to-table/text/image overlaps in reviewed research grid. Evidence: benchmark/experiments/outputs/miro-layout-261016-2307/{before.svg,research-before.svg,update.svg,update-result.svg,after.svg,layout-validation.json,completion-receipt.json}. No scientific content change or model rerun. Existing unrelated app notes/legacy diagrams were outside this research-layout edit.

Tool limitation: supplementary tables-format guidance call rejected by connector schema (enum omits tables). Used full current table bodies with original row/column IDs for position-only updates; post-update content equality passed.

Unresolved questions: no remaining detected overlap in reviewed areas. Verification used canvas geometry/readback; no separate screenshot review.
