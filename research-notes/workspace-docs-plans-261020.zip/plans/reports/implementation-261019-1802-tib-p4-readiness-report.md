# P4 technical readiness và Colab launch — 2026-10-19

Đã triển khai scorer, delivered selector, adapters, compute projection và Colab capacity runner. **134 tests PASS**, actual pinned neural scorer probes/E2E PASS. Development40/300 và eligible test523 giữ nguyên; chưa selection hoặc final benchmark. Runtime Colab T4 đã kết nối, first cell chờ Drive OAuth; chưa có T4 model inference evidence.

## Bốn gate

| Gate | Đã có | Còn thiếu |
|---|---|---|
| Scorer-ready | ROUGE1/2/L F1, BERTScore, source similarity; pins/code/IDF/window contract và actual CPU fixtures | Full-corpus throughput/budget; khác runtime cần probe/receipt mới |
| W_global | Eligible train4.213, p95=333→350 từ tối đa; common selector/reporting | Actual candidate output/context feasibility trước final lock |
| Profiles | 5IDs, executable adapters, native planning và CPU smoke; Colab package | T4 pretrained load/generation, peaks, calls/latency/failures và admission |
| Compute/storage | Budget engine/checkpoint logic; user chấp thuận Colab/Drive, runtime<12h | Actual T4/store receipts, total quotas, trial list và conservative projection |

Scorer-ready receipt là **ready_cpu_fixture_scope_only**, không selection_start_authorized, T4 hoặc full_compute_budget_verified. Không nâng readiness này thành full P4 PASS.

## Scorer evidence

[Spec v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/scorer_spec_v2.json) và [ready receipt](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/scorer_ready_receipt.json) bind code/package/asset hashes. XLM-R-large `c23d21b0620b635a76227c604d44e43a9f0ee389`, layer17; multilingual MPNet `4328cf26390c98c5e3c738b4460a05b95f4911f5`. Official pinned assets3.385.337.579bytes, safetensors LFS SHA/bytes verified; stored ignored locally. IDF=false, fit IDs=[]; no selection/test fitting. [Official BERTScore implementation](https://github.com/Tiiiger/bert_score) supports explicit no-IDF/no-rescaling; long-window extension is project-specific, not full-context equivalence.

ROUGE uses0.1.2 official ASCII tokenizer/Porter stemming; rougeL sequence LCS, not rougeLsum. Source metric is mean-summary-sentence max-source-sentence cosine over all source sentences, pinned complete SentenceTransformer pipeline, direct token windows/content-weighted pooling. Diagnostic similarity, not factuality/exact paper replication. Empty/backend/nonfinite failures→NULL with reasons, not quality0.

Actual CPU native/window max errors: BERT1.44754e-7, sentence1.49012e-8; long BERT1.800/1.800 content tokens and sentence640/640 IDs preserved. Probe40.82s wall, sampled process RSS peak2.512.113.664bytes (~2.34GiB), CPU4threads/batch1/FP32; sampled peak is lower-bound observation, not whole-host peak or corpus throughput. Actual controlled identity E2E returned all5 metrics≈1 without failures. BERT512/sentence128 capacities bind to receipt.

## Output cap và adapters

User ratified only eligible native-train reference words, p95 nearest-rank then ceil25. **4.213 references: p95=333; cap350**. Không validation/test references chọn cap. Cap là maximum, không yêu cầu sinh đủ từ; future Ngắn/Trung bình/Chi tiết ngoài study.

[Proxy v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/output_cap_evidence_v2.json) validates frozen qualification/canonical/tokenizer hashes.171/4.213 references exceed cap (~4.06%); this is **reference proxy**, not generation capping rate. Delivered-reference native maxima575 BART/LED,585 Qwen; reserve768 proposal không là runtime guarantee. Final cap lock chờ actual context/output/feasibility; amendment development trước selection, không giảm sau selection/test outcomes.

Common selector giữ longest complete sentence prefix≤cap; nếu first sentence quá dài, explicit forced-word-boundary fallback, không thêm content. Lưu raw/delivered hashes, lengths/capped/forced flags và separate denominators. Native encoder/decoder và causal chat+output reserves độc lập; LED padding/global attention explicit.

Lead3/LexRank CPU real smoke6/6 PASS trên valid:644/341/886, capped0/3 mỗi pipeline ở smoke này. Native source plans: BART0/5/26 map calls; LED0/2/7; Qwen0/2/7. Zero là direct-final fit, không zero generation cost; reduce counts chưa biết trước neural outputs. Tokenizer plans không chứng minh VRAM/latency/T4 feasibility.

Review tìm lỗi decode/re-encode làm mất Unicode ở Qwen source/reducer window boundaries; đã sửa giữ original token IDs/scaffold, có regression trên pinned tokenizer U+1D7D9. Output-proxy tokenizer hash validation thiếu ở v1 được sửa bằng v2, giữ v1. Budget CLI đã bổ sung actual scorer/store/trial/admission file+hash validation; không chỉ kiểm SHA string shape. Old120 source/predictions/scorers không đổi.

## Colab và checkpoint package

[Notebook active](https://colab.research.google.com/drive/1ONVvp8DShLMeu7IprGbuFiJD0IL3NEj-) và [ZIP](https://drive.google.com/file/d/1QXA5FuDFyTPXDA0B0Vz5q5uCtR1YhCEQ/view?usp=drivesdk) đã upload vào private folder `TIB_P4_FEASIBILITY_261019`. Connector readback folder/ZIP/notebook: shared=false, owner-only. ZIP63.206bytes/SHA600fc9734dee141e7881a90812273fb34852d15d88a1d3f8aa6b4570fa7db6b3. Chỉ3 sealed pilot sources + attribution/scripts/profiles; không references, selection/test data hoặc weights. [Runbook](../../docs/tib-p4-colab-feasibility.md).

User cho phép private Colab/Drive technical scope, giữ CC/NC/attribution/no-public-sharing conditions; scope amendment chỉ3 records đang chuyển, không blanket public redistribution. T4/A100 receipts ghi đúng device; A100 không PASS T4. Mỗi model process riêng, weights pinned revisions, actual load/config/packages/VRAM/RAM/calls/timing/raw-delivered/failures lưu Drive. Native map/reduce node checkpoint: input/source/profile/runtime/layer/node bindings, hash/fsync/rename/readback; started/failed/completed attempt records và cache invalidation. Resume hardware/package drift không reuse; fresh-only flag chặn cached-only run tự nhận fresh T4 capacity.

Notebook guard11.5h gồm setup, subprocess deadline trước12h. Không biến user session bound thành giả định tổng multi-stage GPU/CPU quota. Formal budgets/trial counts/storage headroom/restore/session costs còn UNSET; budget engine trả REQUIRED_NO_START, full523→500→400; diagnostics40 nằm trong final cohort, không cộng thêm40.

Browser đã mở bằng đúng account owner, chọn/kết nối T4, bấm Run all. Cell1 drive.mount chờ OAuth client **Google Drive for desktop**. Automatic approval review từ chối Continue vì chưa có specific client/scope authorization; không bypass, không request-access email, không đổi sharing. User approval đang được hỏi. Chưa chạy neural Colab candidate nào, không claim T4 feasible từ connected badge.

Readback tiếp theo: first mount attempt đã hiện trạng thái lỗi khi consent chưa hoàn tất, các cell sau chưa thực thi. Giữ original attempt; sau approval cần rerun mount/notebook. Exact iframe error text chưa extract, không tự gán lỗi model hoặc chẩn đoán timeout thành confirmed.

## Verification và giới hạn

- Final focused/shared-contract regression:134 PASS/16.91s,1 upstream deprecation warning; independent reviewer75 checks PASS (overlap, không cộng vào134).
- Initial bare-Python scorer check thiếu workspace-local rouge-score; declared PYTHONPATH resolves. Initial Windows sandbox temp rename/safetensors failures resolve qua unique workspace basetemp, không nới assertions. Một OAuth screenshot timed out; main Colab T4 screenshot và pending dialog state đã quan sát, không suy consent thành approved.
- Prepared notebook has runnable6cells; currently remote first cell attempted, local prepared copy has no execution outputs. ZIP CRC and all bundled file hashes verified. Code source tests không thay actual Colab load/generation evidence.

Còn mở: client OAuth approval; actual T4 capacity/output feasibility và final cap lock; Drive cross-session survival/storage quota; full-study CPU/GPU/wall/session allowances, all-config trial registry và source-only representative fallback allocation; validation selection/final cohort+diagnostics seal. Không formal benchmark, model winner, commit hoặc push mới.
