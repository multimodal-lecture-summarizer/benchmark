# TIB dataset evidence — snapshot, source binding và quyền theo trường

Ngày19/10/2026, bắt đầu15:07 Asia/Bangkok. Phạm vi: hoàn thiện evidence dataset, không chạy EDA gap-closure/model/benchmark, không đổi quy mô nghiên cứu.

## Kết quả

**Technical dataset evidence PASS. G1 tổng thể vẫn HOLD cho quyền sử dụng còn chưa đủ scope/điều kiện.** Đã thay tình trạng “chỉ có README” bằng actual pinned shards, remote checksums, observed schema/counts và rights field-matching có trace. Không coi việc tải thành công hoặc license label là permission PASS.

| Thành phần | Evidence đã có |
|---|---|
| Snapshot | `gigant/tib`, full SHA `e6ab9fd7c6acd164f3284b8c4b17eb9d94681eee`, xác nhận từ API chính thức |
| File inventory | Đủ4 Parquet shards; SHA-256/bytes khớp LFS metadata; README và `.gitattributes` khớp Git blob hashes |
| Counts thực | Train7.282, valid910, test911; tổng9.103 |
| Schema/IDs | Cả4 shards có15 field names theo pinned card; required string/nested-sidecar checks đạt;9.103 DOI và9.103 source URLs riêng biệt, không rỗng |
| Paper | Official HAL PDF đã tải, SHA-256 lưu trong accounting; Lead-3/Oracle attribution xác minh tại section5.2/Table2 |
| Rights evidence | Per-record ledger9.103 IDs; đối chiếu DOI/source ID/text với official TIB Open Data, tách reference/source/redistribution |

Schema/ID checks không chứng nhận timing/content usability, near-duplicate independence hoặc qualified cohort. P1 còn in-progress; P2–P5 pending.

## Artifact và tái lập

- [Evidence receipt](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/evidence-261019-1507/evidence_receipt.json): hashes của10 metadata files và7 local artifacts; không phải cohort/permission seal.
- [Source binding](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/evidence-261019-1507/source_binding.json), [actual manifest](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/evidence-261019-1507/dataset_manifest.json), [pinned API response](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/evidence-261019-1507/hf_revision_api.json).
- [Field-rights summary](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/evidence-261019-1507/field_rights_summary.json), [availability view](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/evidence-261019-1507/rights_availability_summary.json), [provenance/license inventory](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/evidence-261019-1507/provenance_summary.json).
- [Paper accounting](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/evidence-261019-1507/paper_source_accounting.json) và [phân tích quyền/primary sources](./research-261019-1507-tib-rights-provenance-report.md).
- Dữ liệu nặng, HTML/PDF gốc, OpenData ZIP, complete JSONL ledger và matching script: `benchmark/research-data/tib-evidence-261019-1507/`, đã kiểm Git ignore. Không đưa source text/ZIP vào Git.

Offline audit được chạy với `--snapshot research-data/tib-evidence-261019-1507/e6ab9fd7c6acd164f3284b8c4b17eb9d94681eee --output research-data/tib-evidence-261019-1507/local-audit`. Tool này cố ý không kiểm remote/rights/paper nên vẫn ghi các mục đó pending; supplement source binding và paper accounting là evidence bổ sung, không sửa receipt cũ.

## Đối chiếu quyền reference và source

Đã tải [official Open Data export](https://av.tib.eu/opendata), version2026-10-19:646.383.491 bytes, SHA-256 `444868bae152872830231c40156bda076b255a8a9b4f1d917ce0229c92b55173`. Scan toàn bộ44.254 media rows; đây là nguồn corroboration quyền, không thay dataset/native splits.

| Phép đối chiếu | Kết quả |
|---|---|
| Source media ID có trong export |6.521;2.582 không xuất hiện |
| DOI tương đương trong các mục tìm thấy |6.520;1 khác biệt giữ flag |
| Abstract raw exact |2.459 |
| Abstract exact sau NFC/whitespace, case-sensitive |3.133 |
| Reference có field-specific CC0 evidence |**5.592** |
| Reference còn HOLD |3.511:921 chưa khớp text,2.582 không có mục trong export,8 rỗng |
| Transcript dataset khớp transcript trong export |**0**; không gán blanket CC0 cho author-generated Whisper text |
| Transcript có current source CC URI, scope/use còn có điều kiện |**6.503** |
| Transcript còn HOLD |2.600 |

CC0 được gắn vào đúng trường abstract có source ID/DOI và nội dung khớp, không áp lên toàn dataset. Source CC route chỉ là conditional evidence cho spoken work/transformation/actual use, chưa là legal PASS. Không tự cho phép public redistribution source hoặc generated summaries. [TIB Open Data](https://av.tib.eu/opendata), [TIB licensing FAQ](https://av.tib.eu/faq).

| Split | Reference CC0 supported | Source CC conditional | Có cả hai evidence routes |
|---|---:|---:|---:|
| Train |4.468 |5.210 |4.456 |
| Valid |568 |655 |567 |
| Test |556 |638 |554 |
| Tổng |5.592 |6.503 |5.577 |

Các số này **không phải eligible counts**: chưa xử lý A/B/C,225 reused flags, source groups/exposure hoặc ratify source-use conditions. Không seal567 validation hay554 test, không đổi target40/300/40 hoặc fallback600→500→400.

Release có26 first-line license labels: BY5.722, SA1.265, NC-SA1.221, NC27, ND847, No Open Access17, missing4. Đã đối chiếu26 representative pages với linked license URIs để hiểu label/version; đây không phải exhaustive per-record permission check. Giữ raw prose có mâu thuẫn, ví dụ BY-SA mô tả thêm noncommercial; không tự viết lại. ND cần xử lý theo version/actual private use, không blanket loại847 records.

## Exceptions và amendment

- `train:3780`, source media54270: released DOI `10.14288/1.0398149`; export DOI `10.14288/1.0398140`. Hai DOI đều là external publication forms. Giữ flag/evidence; không kết luận wrong record hoặc tự sửa DOI/loại bản ghi.
- V1 matching bảo thủ so raw DOI, chưa bỏ suffix hiển thị `(DOI)` của release nên giữ toàn bộ HOLD. V2 chỉ chuẩn hóa DOI resolver/suffix/whitespace/case; giữ raw, ghi supersedes, giữ nguyên V1 ledger/summary. Không xem model outputs hoặc thay dataset.
- Lượt tóm tắt license metadata đầu tiên gặp empty-string edge case; đã xử lý label rỗng thành MISSING rồi chạy lại. Không có rights decision/cohort nào dựa trên output lỗi.

## Kiểm chứng và giới hạn

Independent read-only review **PASS** cho snapshot technical evidence và field binding. Reviewer tự kiểm4 LFS checksums,2 Git blob hashes, actual footer/card counts, toàn bộ9.103 provenance rows; scan lại official ZIP44.254 rows, xác minh mọi matched-line hash/DOI flag và5.592 abstract matches. Sáu original Parquet sample rows tái tạo identifiers/raw-normalized hashes.7 focused DOI/text-matching checks PASS.

Không sửa production audit code; không cần rerun34 unit tests đã PASS ở slice10:35. Lượt này có real-data audit/identity checks, không phải benchmark hoặc EDA gap-closure. Chưa chạy normalization/offset artifact cho toàn corpus, A/B/C adjudication, cohort selection, model/scorer/T4 pilot, commit hoặc push. Giữ nguyên old120 và mọi raw source/license bytes.

## Còn cần giải quyết

1. Ratify actual source-text use/obligations theo verified CC URI/version, xử lý record/field scope còn conditional; không yêu cầu manual review toàn9.103 abstracts.
2. Tìm thêm grant/field evidence cho3.511 reference chưa supported và2.600 source chưa đủ evidence, hoặc ghi targeted HOLD ở P3. Vắng mặt ở export hiện tại không chứng minh không được phép dùng.
3. Review một DOI difference và license prose/version exceptions; không outcome-driven exclusion.
4. Hoàn thiện canonical raw/normalized/offset trace và P3 qualification/group/exposure trước cohort seal. Chưa có cơ sở gọi G1/P1 hoàn tất hoặc bắt đầu formal benchmark.
