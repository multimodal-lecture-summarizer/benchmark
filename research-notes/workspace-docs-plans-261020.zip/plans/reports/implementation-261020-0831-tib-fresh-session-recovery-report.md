# P4 fresh-session checkpoint recovery — prepared, execution HOLD

Scorer-ready is **closed PASS** under the [actual T4 audit](./evidence-audit-261020-0808-tib-colab-scorer-report.md). User directed next order: fresh-session generation/scorer recovery → gated remaining pilot40 → admission/profile/cap/storage/quota/projection freeze → selection300. No metric definitions or21-output metrics were recomputed in this work.

## Delivered and procedure

1. Run [A — origin handoff](../../benchmark/experiments/notebooks/tib-p4-handoff-colab-261020-v1.ipynb) in the current Colab session. Upload the new private recovery ZIP. It mounts Drive, verifies the package and hashes existing original checkpoint stores, then writes a new origin witness. No checkpoint extraction/copy into original stores, package installation or models loaded by A.
2. After A succeeds, use **Runtime → Disconnect and delete runtime**. Open [B — fresh recovery](../../benchmark/experiments/notebooks/tib-p4-fresh-recovery-colab-261020-v1.ipynb) with a new T4 runtime; upload the same recovery ZIP. A kernel restart within the same VM fails the freshness gate. Do not run A again in the new runtime.
3. B validates a different actual Linux VM boot ID and unchanged Drive hashes before setup/model loading. Installs the original direct pins plus the same observed accelerate1.15.0, using the tested pip-less venv bootstrap. Both subprocesses bind current boot ID, recovery run ID, package hash and origin witness hash.
4. B replays the generation and scorer caches, writes separate overhead/original costs, combines stage receipts and exports the new private evidence ZIP. Send that ZIP for audit. No automatic pilot, selection or final run.

Local ZIP: `benchmark/research-data/tib-p4-fresh-recovery-261020-v1/tib-p4-fresh-recovery-261020-v1.zip`,490845bytes, SHA256 `53ee5b56a8227d41d0c1b5a651753b11f70dcf45241849c24988b14a548202ad`.51hash-bound files plus manifest, including both original bundles unchanged and four separate recovery tools. [Preparation receipt](../../benchmark/experiments/registry/protocols/tib-p4-fresh-recovery-261020-v1/preparation_receipt.json), [recovery protocol](../../benchmark/experiments/registry/protocols/tib-p4-fresh-recovery-261020-v1/recovery_plan.json). Files contain private source/reference data and attribution; keep private as before.

## Generation guarantees

Expected288source files (281JSON envelopes+7logs) derive directly from the known-hash audited P4.1 returned ZIP, not a possibly modified local extraction. Reuse all123nodes/21outputs across the seven historical profiles; this is integrity replay, not reopened configuration search. Reload the three unique pinned generation models once each to independently measure the old exact runtime fingerprint, including actual assets/weights, tokenizer, dtype, attention backend, device map and dependencies. Original model/generation configs must match.

Original pipeline, native windowing/wrappers, output selector, profile registry, source IDs and checkpoint keys remain unchanged. Read-only wrapper verifies a node file/key before invoking the original checkpoint API; before-call/backend/model.generate guards forbid cache-miss inference and prevent attempt-file writes. Source inventory is verified before/after. Require123reused node events,21identical raw/delivered outputs and native/token/lineage/telemetry identities; new generation calls/time0. Fresh generation isfalse on cached replay, as expected.

New model-load/tokenization/validation/restore wall/CPU/RAM/VRAM costs remain visible. Original per-node generation cost and original seven profile load/record/total costs are recorded separately. This recovery is not a new generation latency/capacity benchmark.

## Scorer guarantees

Uses the unchanged original19-file scorer manifest/bundle and actual-ready receipt. Require original complete runtime hash, input/asset-manifest/code/spec identities and exact21Drive checkpoint hashes. Restore105finite cached metrics with warning/denominator data; new metric calls/time0. Original scoring cost161.700283845s remains separate from new hashing/restore overhead. No scorer model loads, fixtures or metric calculations; archived original asset manifests bind previous proof rather than claiming current weight reload.

The complete runtime fingerprint includes effective distribution inventory, Python/platform and CPU/thread metadata. A fresh Colab image may differ despite matching the main pins: result must HOLD, with no key or metadata rewrite to force reuse.

## Fresh-session and write protection

Origin witness is create-only, checksummed and bound to the recovery package and original Drive file hashes. Same VM boot ID is rejected even with a restarted kernel. Both actual child invocations validate session context **before any output directory/log write**, protecting both original stores, not just their own stage. Stale/copied PASS receipts cannot satisfy a new run’s context; combined receipt independently checks counts, metrics artifact hash and stage receipt hashes. Output/witness paths cannot overlap original stores.

Original generation/scorer checkpoint directories, raw receipts and both original bundles remain unchanged. Combined PASS requires actual different-VM/Drive proof and both actual stage receipts. Local injected/test runs do not certify fresh Colab execution.

## Verification

**74tests PASS**, exit0,12.01s:49recovery/session/notebook tests plus25existing development/scorer-runtime regressions. Covers corrupt/missing cache, untouched source stores, zero new calls, preserved costs, complete native replay, full runtime mismatch, stage-context preflight, origin witness/same-VM refusal, stale PASS and metric tampering, and notebook import-root separation. Existing Windows pyreadline finalizer warning after successful process exit; no failed tests. Both notebooks’9code cells compile, all execution countsNULL/outputs empty; ZIP51-file hashes and original bundle bytes verified. Independent read-only review found no remaining concrete blockers.

No actual Colab execution, models/downloads/generation/scoring/pilot/selection/final run performed locally. Recovery remains **HOLD pending actual execution/audit**, while scorer-ready remains closed PASS.

## Pilot and budget remain gated

After actual recovery and applicable resource gates PASS, complete remaining presealed pilot IDs with BARTcontrol, LEDngram3, Qwenr384, Lead-3 and LexRank. Prior three-source outputs do not automatically certify a complete formal pilot ledger. Preserve stratum/stage failures/warnings and measure resource/latency costs. Freeze actual admission/profile identities,350word maximum, numeric storage/session/study quotas and conservative projection before selection300; full523→500→400 final policy remains unchanged.

## Unresolved

Actual origin seal/new-T4 recovery and evidence audit; compatibility of the new Colab runtime with both original runtime hashes; numeric pilot/full-study quotas and storage allocation; pilot40 measurements, admission/final-lock and selection gates.32GiB free working disk and11.5h session deadline are recovery operational guards, not full-study budget certification.
