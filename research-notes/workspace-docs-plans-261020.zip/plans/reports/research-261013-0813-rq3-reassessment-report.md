# Khảo sát lại RQ3: dữ liệu, endpoint và khả năng thực thi

**Ngày khảo sát:** 2026-10-13, Asia/Bangkok. **Trạng thái:** research complete; chưa có cohort/protocol RQ3 được freeze hoặc model evaluation mới. RQ2 đang chạy theo thông tin người dùng; không truy cập runtime/Drive hoặc sửa frozen RQ2 artifacts.

## Tóm tắt

RQ3 có thể tiến theo **QA agreement với reader cố định**, sau khi phục hồi và kiểm tra source context. Không cần nhãn retrieval relevance để so sánh câu trả lời đầu ra; cần nhãn đó nếu muốn kết luận Recall@k/MRR hoặc chất lượng bằng chứng. Vì vậy, không nên dùng một trạng thái HOLD chung để chặn mọi endpoint.

Ưu tiên giữ EduVidQA nếu muốn nối tiếp nghiên cứu structured lecture-text retrieval. Kiểm tra đường transcript PDF NPTEL, không chỉ lặp lại YouTube subtitle API. Nếu context không phục hồi được trong một đợt acquisition giới hạn, Video-MMLU là ứng viên QA thay thế đáng preflight vì đã có QA và thư mục transcript được liệt kê trong release. SlideQA là ứng viên riêng cho retrieval trên slide; chưa được xác minh đủ để thay benchmark hiện tại.

Ngoài dữ liệu, mã RQ3 cũ có lỗi hợp đồng, chia chương và scoring. **Không chạy benchmark chính thức trực tiếp bằng runner hiện tại.** Đây là đề xuất nghiên cứu, chưa thay đổi mục tiêu RQ3, registry hoặc implementation.

## Mục lục

1. [Phạm vi và phương pháp](#phạm-vi-và-phương-pháp)
2. [RQ3 cần trả lời điều gì](#rq3-cần-trả-lời-điều-gì)
3. [Khảo sát dữ liệu](#khảo-sát-dữ-liệu)
4. [Kiểm tra mã hiện tại](#kiểm-tra-mã-hiện-tại)
5. [Thiết kế đề xuất](#thiết-kế-đề-xuất)
6. [Bước tiếp theo](#bước-tiếp-theo)
7. [Câu hỏi chưa giải quyết](#câu-hỏi-chưa-giải-quyết)

## Phạm vi và phương pháp

- Đọc benchmark README, master plan, task matrix, historical Q0–Q3 matrix, registry, retrieval module, LLM factory, tests và qualification receipts.
- Thực hiện đúng 5 lượt web research; ưu tiên bài báo tác giả, repository tác giả và dataset cards. Nguồn chính trải từ 2025–2026; E-QGen là nguồn nền cũ hơn. Không coi ngày crawler là ngày phát hành dữ liệu.
- Gemini không bật: global `.Codex/.ck.json` không tồn tại. `ck:docs-seeker` detect/fetch đã chạy; Context7 trả `Documentation not found`, chuyển sang đọc repository qua web. Không sửa skill.
- Dùng `ck:project-organization` ở advisory mode: báo cáo đặt trong workspace `plans/reports/`, theo naming phiên hiện tại; không di chuyển tài liệu cũ.
- Chỉ đọc public pages; không tải bộ video, model hoặc gọi paid inference. Directory listing/card là bằng chứng release-level, không phải byte-level qualification. Một số trang con HF/GitHub trả lỗi khi mở; được giữ là unverified.
- Bằng chứng local ngày 2026-10-10 được kiểm lại checksum, không gọi là lần thử mạng mới. Không thực hiện lại YouTube transcript/download probe trong phiên này.

## RQ3 cần trả lời điều gì

Master plan hiện hành cho phép fixed-reader pipeline comparison sau source-context qualification. Ma trận cũ mô tả Q0 flat, Q1 oracle chapters, Q2 predicted hierarchy và Q3 multimodal hierarchy. Bốn arm này chưa mặc nhiên đủ điều kiện chạy: Q1 cần chapter GT riêng; Q3 cần visual evidence gắn đúng nguồn. Không kế thừa hiệu quả chaptering từ kết quả RQ1 đã rút.

| Endpoint | Đầu vào/nhãn tối thiểu | Được kết luận | Không được suy ra |
|---|---|---|---|
| QA agreement | Question, released answer, source context đúng lecture, fixed reader | Pipeline nào khớp released answers hơn trong cohort | Retrieval relevance, factuality, citation correctness |
| Retrieval relevance | Corpus units và query-to-relevant-unit labels có provenance | Recall@k/MRR trên đơn vị được chốt | QA correctness hoặc grounding chỉ từ retrieval score |
| Temporal evidence localization | Source timebase và evidence interval labels phù hợp | Hit/IoU theo định nghĩa frozen | QA timestamp đơn lẻ là full evidence span |
| Multimodal contribution | Cùng QA, source-linked text/visual inputs, controlled ablation | Tác động thêm visual evidence trong điều kiện đo | Benefit multimodal từ thay cả reader và retriever |

TIB có abstracts/transcripts cho RQ2 nhưng chưa có QA/evidence labels phù hợp. Không tự sinh QA từ 120 mẫu RQ2 rồi gọi đó là independent RQ3 ground truth.

## Khảo sát dữ liệu

### EduVidQA — ưu tiên nếu giữ mục tiêu lecture-text QA

[Repo chính thức](https://github.com/sourjyadip/eduvidqa-emnlp25) cung cấp QA CSV và evaluation code; người dùng phải lấy context riêng. [Bài báo EMNLP 2025, Appendix C](https://aclanthology.org/2025.emnlp-main.1760.pdf) mô tả transcript PDF NPTEL có text/keyframes/timestamps, mở thêm đường acquisition ngoài phụ đề YouTube. Đây là đường cần kiểm, chưa phải context đã lấy được.

Receipt local pinned `aab6cc03e43182cc916f14ed2aca495f57a1ed96`: 5.234 QA rows/296 videos; paper nêu 5.252. Có 1.038 synthetic-test timestamps trống và 456 timestamps ba thành phần chưa giải nghĩa. Không thấy independent relevance/evidence-span labels trong audit cũ. Sample transcript probe ngày 10-10 lỗi ParseError; sáu timestamp HH:MM:SS bị duration contradiction. Hash của bốn audit artifacts hiện vẫn khớp receipt.

**Quyết định:** answer-agreement conditional on context recovery; retrieval/temporal claims HOLD. Không cần sửa timestamp nếu endpoint hoàn toàn text-only. NPTEL PDF → đúng course/lecture/video ID phải có ledger, không ghép chỉ theo title. Không lấy đoạn quanh gold answer/timestamp làm đầu vào cho arm retrieval tự do.

### Video-MMLU — ứng viên QA có context được liệt kê sẵn

[Repo tác giả](https://github.com/Espere-1119-Song/Video-MMLU) mô tả benchmark bài giảng toán/lý/hóa và QA. [Release HF](https://huggingface.co/datasets/Enxin/Video-MMLU/tree/main) liệt kê `video_mmlu.jsonl`, QA TSV, `video_sources.jsonl` và `transcript/`. Không cần giả định phải tự ASR toàn bộ video trước khi preflight text-only QA. Tác giả dùng judge Qwen2.5-72B trong evaluation; cấu hình đó không phải chứng cứ chạy vừa T4. [Evaluation docs](https://github.com/Espere-1119-Song/Video-MMLU/blob/main/EVAL.md).

**Quyết định:** ứng viên acquisition ưu tiên nếu EduVidQA bị chặn. Chưa tải/parse transcript, chưa đếm actual joined QA, chưa kiểm human/synthetic label provenance, course leakage hoặc independent relevance labels. Không dùng số video quảng bá làm số qualified. Text-only study đo agreement trong setting bị giới hạn modality; visual-dependent questions cần đánh dấu/stratify, không loại dựa trên model scores. Chưa chọn dataset này thay EduVidQA.

### SlideQA — ứng viên retrieval trên slide, khác video-timeline QA

[Repo công khai](https://github.com/shanayamalik/NLP-slideQA) mô tả 450 QA từ ba khóa NLP, gold evidence slide và retrieval Recall; quy trình có generation/curation QA. Đây là course project; tên thư mục writeup `iclr2026` không chứng minh paper đã được chấp nhận. Trang con chứa dữ liệu chưa mở được trong lượt khảo sát.

**Quyết định:** đáng kiểm release rows, slide IDs, PDFs, license và cách tạo/xác minh nhãn. Supplied synthetic originating-slide labels có thể hỗ trợ metric giới hạn đúng provenance nếu join được; không tự gọi chúng là exhaustive independently judged relevance. Không chạy script sinh QA để thay phần dữ liệu chưa tải được. Nếu qualified, gọi đây là slide retrieval/QA component study, không temporal-video RQ3 hay chapter hierarchy experiment.

### LectQA-Vid — phù hợp về mô tả, access chưa xác minh

[Bài báo tác giả](https://www.techscience.com/cmc/v88n2/67662/html) mô tả 100 micro-lectures 2–5 phút, 3.000 QA và temporal spans do annotators tạo. Nhưng khảo sát chưa xác nhận public downloadable annotation/transcript package hoặc pinned schema. Không có kết quả local. Ngữ cảnh ngắn cũng hạn chế kiểm tra lợi ích hierarchy trên lecture dài.

**Quyết định:** để secondary access candidate; không chờ vô hạn, không ghi đã đủ evidence GT chỉ từ prose paper. Temporal filtering cần xác minh thông tin thời gian nào có tại inference, tránh dùng gold target span làm query input.

### E-QGen và UIAIC/EduViQA — dùng với claim hẹp

- [E-QGen tác giả](https://github.com/NYCU-NLP-Lab/E-QGen): phát hành paragraph–question pairs từ lecture transcripts. Golden pairs dựa trên timestamps, silver dựa trên embedding matching, platinum do GPT-4 sinh. Có thể khảo sát question-to-paragraph association; không mặc nhiên có released answers hoặc exhaustive relevance labels. Không trộn weak/synthetic associations rồi gọi human evidence GT.
- [UIAIC/EduViQA card](https://huggingface.co/datasets/UIAIC/EduViQA): mô tả 20 videos, English/Persian, synthetic QA theo chunk cùng transcript/frame directories. Card tự gọi EduVQA-Alpha và ví dụ loader dùng ID khác. Cần xác minh actual files/schema/QA-to-chunk linkage. Đây là dataset khác EduVidQA EMNLP; chỉ cân nhắc diagnostic synthetic chunk association, không thay thế ngầm benchmark chính.

| Tuyến | Phù hợp gần nhất | Readiness xác nhận trong phiên | Ưu tiên |
|---|---|---|---|
| EduVidQA + NPTEL/author transcript | Long-form lecture-text QA; structured vs flat | QA audit local còn nguyên; context acquisition chưa chạy mới | 1 — giữ câu hỏi nghiên cứu |
| Video-MMLU | Lecture QA, text hoặc multimodal | Author release listing có QA/transcript; byte-level chưa kiểm | 2 — dự phòng thực dụng |
| SlideQA | Slide evidence retrieval/QA | README có target-slide protocol; rows/license chưa kiểm | Track thành phần riêng |
| LectQA-Vid | Micro-lecture temporal QA | Paper mô tả; download/schema chưa xác minh | Secondary access |
| E-QGen | Paragraph–question association | README/provenance categories | Diagnostic hẹp |
| UIAIC/EduViQA | Synthetic chunk QA | Card; actual joins chưa kiểm | Diagnostic hẹp |

Không chọn general-video benchmarks làm thay thế lecture-domain chỉ vì dễ tải. Không dataset nào trong bảng được đánh dấu formal-ready trong phiên này.

## Kiểm tra mã hiện tại

Nguồn trực tiếp: `benchmark/benchmarks/models/retrieval_qa.py`, `benchmark/benchmarks/models/llm_engine.py`, `benchmark/experiments/registry/candidates.yaml`. Không sửa implementation.

| Phát hiện | Bằng chứng | Hệ quả trước formal run |
|---|---|---|
| Registry không khớp module | Registry trỏ `FlatDenseRetrieval`, `OracleHierarchicalRetrieval`, `PredictedHierarchicalRetrieval`, `MultimodalRRFRetrieval`; AST không thấy cả bốn class trong target module | Cần nối adapter/class/kwargs đúng và kiểm instantiate theo registry |
| Predicted hierarchy chưa dùng vị trí boundary để chia text | Q2/Q3 lấy `len(boundaries)+1`, chia đều theo sentence count; `sentence_timestamps` không dùng để partition | Boundary placement chưa quyết định chapter membership; không thể claim đúng C5 hierarchy |
| Context parity chưa được enforce bằng token | Chỉ assert config cap <=1024; `_synthesize_answer` nối toàn bộ retrieved evidence | Cần tokenizer counting/packing thực, prompt/output budgets và receipts |
| Embedding fallback khác phương pháp khai báo | SBERT load lỗi chuyển sang `hash(word)` vector | Phải fail/mark failed nếu frozen embedder không sẵn; hash có thể đổi giữa processes |
| Reader identity có thể đổi | LLM factory fallback HF/Gemini → deterministic engine | Pin revision/config, giữ actual identity; không gộp fallback vào cùng arm |
| Token F1 sai với token lặp | Set intersection thay multiset counts; cô lập hàm bằng AST: identical `alpha alpha beta` → EM=100, F1=66.67 | Sửa scorer và regression test trước scoring thật; đây là test contract, không research score |
| Grounding/visual implementation chưa tương ứng tên claim | Q0 thiếu timestamps tạo `i*10`; Q3 ghép OCR theo chapter index, `visual_captions` chưa dùng và thêm text `Grounding:` vào answer | Không coi thời gian/chuỗi citation là evidence; source-map thật và separate citation scoring cần thiết |

Q0 lấy windows ba câu/stride hai; Q2 lấy sentences trong một chapter. Dùng cùng top-k vẫn khác lượng context và retrieval units. Muốn cô lập hierarchy, dùng chung leaf chunks; hierarchy chỉ đổi routing/search. Nếu đổi cả units, phải gọi là pipeline-composition comparison.

`benchmark/reports/rq3_benchmark_results.json` có số Q0/Q1 nhưng không đủ provenance/cohort receipts trong khảo sát này để phục hồi claim. Không sử dụng làm kết quả RQ3 hiện hành. Tests với demo sentences không chứng nhận scientific readiness.

## Thiết kế đề xuất

**RQ3-A đề xuất:** trên cùng lecture contexts và cùng reader/token budget, source-only predicted structure có cải thiện released-answer agreement so với flat retrieval không?

- Primary comparison: flat dense vs structured dense; dùng chung leaf chunks, encoder, reader và packing policy. BM25 là baseline bổ sung nếu tài nguyên cho phép; không cần mở rộng ngay sang mọi model family.
- Structure được tạo từ source, không question/answer references hoặc gold evidence. Nếu không có chapter GT, bỏ oracle-chapter arm khỏi comparison chính; không tạo oracle từ QA timestamps.
- Giữ reader checkpoint/revision cố định. Có thể reuse Qwen từ RQ2 để giảm engineering, nhưng phải có QA feasibility trên development group; summarization success không chứng minh QA capability.
- Reader trả lời từ retrieved context; references chỉ vào scorer. Closed-book arm chỉ là diagnostic kiểm tra prior knowledge, không được trừ điểm rồi coi đó là retrieval quality.
- Primary scorer cần chốt theo loại answer sau xem development examples: Token F1 đúng multiset là lexical agreement, không correctness. Với long-form answers, secondary semantic agreement riêng; LLM judge chỉ khi có rubric/model revision, calibration và budget cụ thể.
- Không bắt buộc video/timestamps cho text-only endpoint. Muốn thêm OCR/image evidence phải join cùng source, chạy paired ablation và tính đủ resource costs.
- Freeze eligible pool/cohort, video/course groups, missingness, context cap, model identities, outcomes và failure policy trước scores. Grouped splits theo video/course; QA cùng video không độc lập. Báo QA-weighted và macro-by-video khác nhau.
- Chọn sample size từ số source groups, mục tiêu độ chính xác và resource feasibility; không mặc định lấy 120 QA vì RQ2 dùng 120 records. Development cohort là feasibility, không formal evaluation.

**RQ3-B conditional:** Recall@k/MRR chỉ sau evidence relevance labels qualify. Dùng common unit/source interval mapping; nếu nhiều đoạn liên quan, định nghĩa rõ metric là hit@k hay recall của relevant set. Synthetic originating-slide/chunk labels hỗ trợ descriptive association riêng nếu provenance cho phép, không nâng thành human-grounded evidence accuracy.

## Bước tiếp theo

1. **Một đợt context acquisition có giới hạn, không model run:** chọn trước một nhóm development video IDs; kiểm NPTEL/author PDF → video linkage và transcript release. Ghi status từng ID, hash, source URL, extraction method, missingness. Dừng đợt khi đã có đường reproducible hoặc sau một phiên 60–90 phút vẫn thiếu versioned context; giữ failures, không lặp YouTube API vô hạn. Đây là stop rule đề xuất, chưa thực hiện.
2. **Nếu EduVidQA không có context:** preflight Video-MMLU. Pin revision, lấy nhỏ QA/schema/source map/transcript; join theo IDs, kiểm real count/encoding/empty context/course groups. Không tải cả video archive cho text-only feasibility. Quyết định endpoint trước khi dùng test answers để tuning.
3. **Nếu cần evidence retrieval trên visual trước:** preflight SlideQA release riêng; thiếu QA rows/PDF/slide join/license thì HOLD, không tự generate replacement. LectQA-Vid chỉ tiếp tục khi có actual package.
4. **Sau khi chọn data route:** sửa riêng registry/adapters, temporal/text partition, token enforcement, scorer, identity/fallback; focused tests trên contract failures và known metric cases. Đây là work cần được thực hiện ở giai đoạn implementation, chưa nằm trong thay đổi phiên research.
5. **Executed context EDA → freeze → notebook thật → evaluation:** giữ counts, input/prediction/failure receipts và item-level scores; báo partial nếu thiếu mẫu. Chỉ cập nhật trạng thái RQ3 master plan sau actual qualification, không từ README của dataset.

**Đầu ra thực tế của phiên này:** báo cáo này; checksum kiểm lại bốn historical EduVidQA artifacts đều PASS; AST class inspection và scorer counterexample hoàn tất. Không tải model, không benchmark mới, không sửa frozen RQ2, không commit/push.

## Câu hỏi chưa giải quyết

- NPTEL PDF hoặc author transcript nào join chính xác được với EduVidQA video IDs? Chưa acquisition mới.
- QA/transcript Video-MMLU thực tải và join được bao nhiêu video, provenance labels và source course groups ra sao?
- SlideQA có phát hành rows/PDF/slide labels và license đủ rõ không? Nhãn có independent review hay chỉ originating slide?
- LectQA-Vid có package public/versioned không; temporal span là output target hay được cấp cho system tại inference?
- Formal RQ3 tiếp tục long-form answer agreement hay chuyển sang slide evidence study? Báo cáo khuyến nghị tuyến đầu, chưa thay quyết định nghiên cứu.
