# Retire fixed mark diagnostics from general EDA

Removed old fixed-target configuration, hand-entered drafts, dense helpers/runner, selected clip/candidate stages and all dependent coverage/receipt/artifact fields. No placeholders for retired stages. Removed historical IDs from default manual/retry configuration; manual/retry lists empty and retryFalse. MEDIA_SCOPEall and full333video/9021mark inventory remain. Genericpreview uses same automatic anomaly+first/middle/last selection with three offsets for every source. No fixed target overrides. Guide rewritten for currentflow.

Historical source evidence/media/checkpoints/backups retained. Acquisition identity/selector/load/processguard AST unchanged; newpreviewversionhash distinguishes regeneratedimages. No dataset/GT edits. Fullledger still includes unviewedmarks.

Validation: independent review clear; schema/all20codeAST pass. Complete saved ledgers preserve333/9021, originalorder, wordtotals, empty/missingannotations and groupdenominators. Failed/interrupted/unattempted and missingspeaker cases pass. RealFFmpeg genericfixture:6requests,5decoded/1outside; zero-budget rerun excludes staleframes; zero-markvideo remains inmediaaudit. Actualfinalreceiptconstruction and strictJSONserialization passed with333/9021 and no retiredfields. LocalAggdisplay warning expected.

Evidence: experiments/outputs/mlpdataset_remove_targeted_261017/local-validation/validation.json and experiments/outputs/mlpdataset_full_inventory_261017/local-validation/validation.json within benchmark. No live network/Colab acquisition replay.

Unresolved: user execution of newall-source runner, fullmediaavailability and semantic/audio qualification. Budgetlimits remain explicit; no coverage inferred from genericsamples.
