---
status: completed-annotation-research-media-alignment-hold
date: 2026-10-17
timezone: Asia/Bangkok
scope: MLPDataset and updated LPM release; notebook EDA before detector evaluation
---

# MLPDataset research and notebook EDA

Research conducted **2026-10-17, Asia/Bangkok**. No detector inference, cohort freeze, split assignment or original-label edits.

## Navigation

- [Summary](#summary)
- [Method and sources](#method-and-sources)
- [Release comparison](#release-comparison)
- [Annotation findings](#annotation-findings)
- [ASR and timebase](#asr-and-timebase)
- [Media and dependence](#media-and-dependence)
- [Artifacts and reproduction](#artifacts-and-reproduction)
- [Next steps](#next-steps)
- [Unresolved questions](#unresolved-questions)

## Summary

The existing [MLP notebook](../../benchmark/experiments/notebooks/diagnostics/mlpdataset-slide-transition-eda.ipynb) now performs source research, complete annotation accounting, release comparison, all-file ASR/spoken diagnostics, dependence review and bounded media access probes. Final fresh-kernel execution completed 13/13 code cells with zero error outputs; two figures contain eight plot panels. Full tables retain IDs and original timestamp order; plots and CSV exports accompany the saved outputs. This is dataset analysis before model comparison.

Both author ZIPs were acquired and inspected. The updated LPM archive fixes the malformed dental JSON, but every shared transition, transcript, spoken and raw-metadata member is byte-identical. Consequently the annotation anomalies remain. Public video metadata succeeds for two predeclared source IDs; both clip requests return HTTP 403, with zero decoded frames. Source-video alignment remains unverified.

## Method and sources

Research scope: exact release identity, annotation target, coverage, invalid data, ASR offsets, source dependence and actual media availability. Historical 2022/2023 material defines the release; availability and pinned source bytes were checked on the research date. Used author sources, not third-party dataset counts.

Twelve pinned source files were saved with URL, commit, status, retrieval timestamp, byte count and SHA-256. The `ck:docs-seeker` Context7 lookup returned “Documentation not found”; direct author repository analysis was used. Web access to the CVF paper page/PDF returned 403, although the search index exposed its abstract. No claim of a complete PDF review is made; label semantics were independently checked in downloaded author instructions and preprocessing documentation.

Primary sources:

1. [MLP author fork, pinned revision](https://github.com/mlpdataset/MLPDataset/tree/0e5ceabc29e381f52b70383c23a2c32a2dd47962).
2. [LPM upstream, observed revision](https://github.com/dondongwon/LPMDataset/tree/e1addf4f4e2ddb3457dc18f94117cafa8d063e90).
3. [MTurk slide instructions](https://github.com/mlpdataset/MLPDataset/blob/0e5ceabc29e381f52b70383c23a2c32a2dd47962/preprocessing/mturk_slide_seg.html#L657-L687).
4. [Author preprocessing documentation](https://github.com/mlpdataset/MLPDataset/blob/0e5ceabc29e381f52b70383c23a2c32a2dd47962/preprocessing/README.md).
5. [ICCV 2023 paper](https://openaccess.thecvf.com/content/ICCV2023/papers/Lee_Lecture_Presentations_Multimodal_Dataset_Towards_Understanding_Multimodality_in_Educational_Videos_ICCV_2023_paper.pdf).

Search topics: MLP/LPM identity, slide-segmentation annotation, updated archive, paper/repository release counts. Four web research calls; additional deterministic downloads acquired the identified primary-source artifacts.

## Release comparison

| Artifact | Legacy MLP ZIP | Updated LPM ZIP |
|---|---|---|
| Author download ID | `1amyxxy4reuHGQ3FaKLE5bYzVxD7DOl7K` | `1yoilKif2bBb8Z9j8D5yqQKmjzG0uS7IB` |
| File | `mlp_anon.zip` | `lpmdata_102023.zip` |
| Bytes | 138,163,175 | 148,633,724 |
| SHA-256 | `dbd07ef37de603a22abb7be7d81245034b3c487f4878227cbef36ae3d451cfa7` | `9d85728e0fdf27999f7ca2794ab49b24da4b5f8fa42a7defcb122223a763447d` |
| Metadata video rows | 333 | 333 |
| Segment files | 332 | 332 |
| Source images/video | 0 | 0 |
| Dental JSON | Malformed | Parsed, 2,588 records |

CRC and unique/safe member paths passed for both ZIPs. After normalizing only the root directory (`data/` versus `data_oct/`), 27,811 file paths are shared: 27,810 identical and one changed, `dental/dental.json`. Seventeen legacy-only files are `.DS_Store` artifacts; the updated-only file is `lecture_vids.csv`. All 30 updated JSON members parse successfully. The notebooks contained inside the ZIPs were not executed.

The pinned repository CSVs each contain **334** rows, with one extra ID, `dEh_Zk9d0sE`, absent from both ZIP metadata tables. Timestamp lists for the 333 common IDs match. This is a release coverage discrepancy, not permission to invent an annotation folder or substitute a paper's advertised count for observed coverage.

Recommendation: retain the updated author ZIP as the preferred future source because its JSON parses; keep both hashes and the comparison ledger. This recommendation does not freeze an evaluation release/cohort.

## Annotation findings

The annotation target is the end of a slide, immediately before a whole-slide change. Same-slide animation/text reveal is excluded by the author instructions. A transition to an inserted video is treated as one change. These labels do not establish generic camera-cut, chapter-boundary or board-state ground truth.

| Check | Observed |
|---|---:|
| Accounted source-video IDs | 333/333 |
| Metadata duration total | 186.634 hours |
| Matched annotation folders | 332 |
| Released timestamp rows, original order | 9,021 |
| Structurally acceptable video annotations | 315/333 |
| Empty segment files | 6 |
| Non-increasing marks | 15, across 11 videos |
| Missing annotation folder | 1, `aXxRSrIcGjU` |
| Negative marks | 0 |
| Marks beyond metadata duration +0.05 s | 0 |
| CSV/segments timestamp mismatches among matched videos | 0 |

The 18 structurally flagged videos are enumerated in the notebook. No sorting, deduplication, deletion or timestamp clipping was applied. Structural acceptance is not semantic label qualification.

Final marks lie within 0.05/0.5/1/2 seconds of metadata duration for 18/24/26/27 videos. These are diagnostic sensitivity counts, not a terminal-boundary exclusion rule. Whether a final mark closes a segment rather than denotes an internal transition requires frame review before scoring. Do not describe all 9,021 rows as independently verified internal transitions.

Plots cover source concentration, duration, mark counts, original-order gaps, duration versus marks, final-mark distance and ASR-offset residuals. The 5th/50th/95th percentiles of marks per video are 5/18/68.4.

## ASR and timebase

All **332 transcript CSVs** and **9,021 spoken CSVs** were read. Transcript files contain **1,652,828 word rows**; spoken files contain **1,613,709 word rows**, with **337 empty spoken files**. ASR is machine-generated, not a human reference for transcription quality. Transcript checks found no nonfinite times, negative starts, end-before-start rows or start-time regressions; 27 word fields are missing.

For all **8,684 nonempty spoken files**, retained row IDs support a timing-offset comparison against the full transcript. Maximum start-offset residuals are within 1e-6 s of the previous slide-end mark (or zero for the first segment); no file fails that internal consistency check. **3,223 spoken files** contain negative relative starts, consistent with words crossing a segment boundary. These offsets must not be confused with negative absolute video timestamps.

The notebook finds 41,766 raw word differences and zero differences after casefolding, with deterministic examples and per-file counts. These observed differences are letter casing, not changed wording under that normalization. Matching timestamps alone cannot establish transcript wording identity, human accuracy or agreement with the current video edit. The receipt contains the final raw/casefold diagnostic counts.

## Media and dependence

The predeclared probe chooses the lexicographically first source ID and the first ID with a non-increasing mark: `-8QB3Rbeqoc`, `-a5-EHnZ_XA`. Both return public metadata. Observed durations are 819/487 s, differing from release metadata by −0.46/+0.29 s. License fields are absent. One two-second clip around the first positive mark was attempted per source; both media-server requests return HTTP 403. Zero frames were decoded, and zero boundaries were semantically verified.

Raw probe logs remain local/ignored. Saved notebook replay reuses these explicitly dated observations instead of repeatedly retrying failed downloads. Metadata success does not certify video availability, edit equivalence, rights or boundary correctness for either source, much less all 333 sources.

Ten speaker/domain labels and 28 series path proxies are inventoried. They are dependence signals, not independently verified people/courses. Exact annotation hashes are checked, including empty files; identical timestamp files are not proof of identical video pixels. No pixel near-duplicate analysis or split leakage clearance is possible from the annotation ZIPs alone. Retrieval-task splits from author training code are not adopted as source-disjoint transition splits.

Author README separates the repository-data license declaration from the original videos' YouTube license. No video redistribution permission is inferred. Downloaded author code was inspected as text, not executed; ZIP members were read without extraction.

## Artifacts and reproduction

- [Executed notebook](../../benchmark/experiments/notebooks/diagnostics/mlpdataset-slide-transition-eda.ipynb): full ledgers, examples, figures, version comparison and access failures.
- [Research receipt](../../benchmark/experiments/outputs/mlpdataset_research_261017/research-eda-receipt.json): denominators, source pins, SHA-256 manifests and limitations.
- [Execution/registry receipt](../../benchmark/experiments/registry/datasets/mlpdataset-research-eda-261017.json): saved notebook hash and execution validation.
- [Local exports](../../benchmark/experiments/outputs/mlpdataset_research_261017/): source snapshots, both-release comparison CSV, all video/mark/ASR/spoken ledgers, JSON audit, figures and access logs.

Run from the `benchmark` repository using a Python environment with `nbformat`, `nbclient`, `ipykernel`, `numpy`, `pandas`, `matplotlib`, `requests`, `gdown`; media probes additionally require `yt-dlp`, FFmpeg and optionally OpenCV for decoded previews.

```powershell
python -m jupyter nbconvert --execute --to notebook --inplace experiments/notebooks/diagnostics/mlpdataset-slide-transition-eda.ipynb --ExecutePreprocessor.timeout=300
```

First acquisition verifies known archive/source hashes; replay reuses downloaded sources and the dated media-probe table. Remove or archive `media-probes.csv` only when deliberately refreshing access observations. Source/video data, logs and historical notebook backup remain ignored. No commit/push performed.

## Next steps

1. Retain the updated ZIP and release comparison; explicitly choose the future evaluation release. Resolve the extra repository-only video separately.
2. Recover exact source media for a score-independent subset, review duration/FPS/edit correspondence, before/after frames and terminal marks. Include every anomaly affecting that subset; do not repair labels from detector predictions.
3. After media/label qualification, freeze a source-grouped cohort, dependence handling, boundary matching/collar and failure policy. Only then create the detector comparison notebook.

## Unresolved questions

- Which terminal marks only close the last segment?
- Are recovered source videos the same edit/timebase as the annotation release?
- Can the source clips be acquired through ordinary authorized access, and what use rights apply per source?
- What do speaker/series proxies mean for source/course independence?
- Where are annotations for repository-only ID `dEh_Zk9d0sE`?
