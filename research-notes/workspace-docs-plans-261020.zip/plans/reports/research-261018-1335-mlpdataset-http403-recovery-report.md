# Research: MLPDataset HTTP403 recovery and interrupted resume

Research timestamp:2026-10-18 Asia/Bangkok. Scope: diagnose five observed source download failures from partial Colab log and design bounded public-source recovery preserving existing cache. No credential, account or proxy automation. Gemini toggle config absent:used official web sources. Docs-seeker detect/fetch ran; Context7 returned Documentation not found, so official GitHub README/wiki/pinnedsource used. Research budget:fourwebcalls plusone docs-discoverycall, no furthersearchneeded.

## Summary and local evidence

Pasted log completes86of119retries:81downloaded,5failed,87thstarted. Lastfailedattempts areHTTP403during video data transfer, following successful metadata/format extraction; not currentLOGIN_REQUIRED. SourcesjE9FnEq3k0U,uNrB2uG_9gs,hgk8-2Fweb8,mdE7H8maXcY,pfFrVkgguvo. Selectedformats134/396 shown. This doesnotestablishserver-side403cause orfinalDrivecountsafteruserstop. Notebookcurrentlycleansource; partialstates archivedseparately. No fixedIDruntimepolicy.

Currentselector prefersdirectHTTPSMP4. Its slashfallback is an availability selector, not a retry after403fromselectedformat. Application invokes one command then marksfailed; no controlled alternateprotocol/clientattempts. Base runner prints structuredmetadata beforepopulatingits errorfield, producing misleadingerror-emptylogs. Interrupted/running states excluded fromexplicitfailed pool even though resumable.

## Findings and comparison

[Official extractor wiki](https://github.com/yt-dlp/yt-dlp/wiki/Extractors) recommends modest request spacing and notesclient/session restrictions. Addboundedpacing,notunlimitedretries. [CLI reference](https://github.com/yt-dlp/yt-dlp#usage-and-options) supports formatfilters,clientarguments,requestsleep,abort-on-unavailablefragments andpartialresume.

[PO Token Guide](https://github.com/yt-dlp/yt-dlp/wiki/PO-Token-Guide) explains someclient/protocol403s caninvolvetokenrequirements; itdoesnotprovethesefiveerrorshave thatcause. Tokens canbepervideo,providerpluginsareexternal. Do notinstall unreviewedproviderorrequireaccountcookieshere.

Crucialversioncheck:[2026.08.19 client source](https://raw.githubusercontent.com/yt-dlp/yt-dlp/2026.08.19/yt_dlp/extractor/youtube/_base.py) warnsandroid_vr formats403since2026-08-17. Reject that fallback despite moregeneralwiki table. Pinnedsource confirmsweb_safari existsbutHLSformats mayrequiretrusted/logged-insessions. ThereforepublicHLS fallback is an experiment,notguaranteedfix. Do notupgrade yt-dlp blindly:existingcacheidentitybinds version. [Pinned README](https://raw.githubusercontent.com/yt-dlp/yt-dlp/2026.08.19/README.md) usedforCLIcompatibility.

## Recommended implementation

1. Preserveexistingdefaultprimarydownload andall media/frameidentities;recordactualprofile/selector/clientmethodineachnewattemptanddownloadedstate.
2. AfterobservedHTTP403orformat-unavailable only, trydefault-clientHLS thenweb_safariHLS,atmost3totalcommandsper source insideexisting120s total sourcewindow/global/storagelimits. Stoponbotconfirmation,private/unavailable,timeout,storage orlocalvalidationerrors. Noauthbypassclaim.
3. Isolatealternateprofileoutputs inper-source recovery subdirectories;neverresume directstream.partial intoadifferentformat. Noexistingfilesdeleted;per-videoquota countsallpartials. Requireuniquecompletedfile,ffprobe/readablepositive duration,SHA;store nestedrelativefile_name soexistingpreviewworks.
4. Preserveandappendstate/logaftereachcommand;interruptionstoredimmediately;include failed/interrupted/running inresumablepool,retainingactualpreviousstatus. Sourceleveloutcomes separatefromnumberofcommandattempts;noinfiniteautoloop. Emitcheckpointpoolcounts,cachehits,newdownloadresults directlyinline.
5. Populate runner.error beforedisplayingstructuredlog. Pace source retries7s plusboundedrequestsleep;defaultskipfreshformatdiagnostics toavoidredundantmetadataquerieswhiledebuggingdownloads. Previewbehavior andfull333/9021 EDA unchanged.

## Verification strategy

Saved86partialstatesreplay;403→HLSsuccess,403→noformats→Safari success,botstop,strictfragments,corrupt/nofile nofalse-success;distinctpartialfiles/logs;interruptionafterfirstprofilethenresume;per-source/global/storagetimeoutcaps;existingcache+framehashpreserved;nestedpathpreview actualFFmpeg;allfailed119selectionandrepresentativecompatibility;full333/9021receipt. Controlledlocalprocess/networkfixtures proveorchestration only;actualYouTube recovery requiresnewColaboutput.

Nextactions:reviewplan,implementboundedprofiles,runnewfocused+priorregressions,independentreview,updateguide. NoGTtimestampsrepaired.

Unresolved: actual403servercause; whetherHLSavailableforremainingpublicsources;finalDrivecountsbeyondpasted86;Colabrecoveryoutcomes.
