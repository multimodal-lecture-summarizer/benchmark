# Completed MLPDataset Colab output audit

Input: `benchmark/experiments/notebooks/diagnostics/mlpdataset_slide_transition_eda_colab.ipynb`. Read-only review of code and saved outputs; no notebook edits, source downloads or inference reruns.

Input SHA256: `e5c34b2313acba4b07da3f72a1d19c340e005e20016e67b8fd4a88685b4afe49`. Size246,605,704bytes. Saved receipt timestamp2026-10-18T17:26:45.831740Z =2026-10-19 00:26:45 Asia/Bangkok.

## Execution and accounting

- Notebook schema valid;33cells/20code cells. Execution counts1–20 sequential, outputs present where expected, no saved Python error output.
- Complete inventory333videos/9021parsed slide-end marks/10source groups retained, zero excluded rows and zero numeric parse errors.332transcripts and9021spoken files.315sources pass structural checks only.
- All333source checkpoints report downloaded. Acquisition was disabled in this run; zero new download processes, zero failures in the current pool. Five earlier transfer403 IDs are now downloaded with effective primary acquisition: hgk8-2Fweb8, jE9FnEq3k0U, mdE7H8maXcY, pfFrVkgguvo, uNrB2uG_9gs. This does not demonstrate HLS fallback success; saved effective profiles are primary or legacy.
- Preview1310validated cache hits +1215new decodes =2525images.2961requests at987marks:2525decoded,388not attempted due preview time budget,48outside video. No current failed/timeout preview rows. Prior partial1215process logs all exited0.
-858marks have some visual evidence across326videos/all10source groups;828marks have complete before/at/after triplets. Seven downloaded sources have no released marks (six empty annotation files, one missing annotation folder). Remaining8163/9021marks have no sparse preview; visual mark coverage9.51%. Completing388pending requests completes this requested queue, not all9021marks.
- Full coverage tables, final receipt and5946-entry artifact inventory are present. Independently reconciled333unique source IDs,9021unique mark IDs, preview counts,858visual marks and receipt counts. Artifact paths unique;5946entries have valid SHA256 syntax and nonnegative sizes. Inventory contains33CSV/2527JSON/3386PNG. Actual Drive bytes and all artifact hashes were not independently fetched/recomputed locally.

## Annotation concerns

18sources carry structural flags;15nonincreasing mark rows remain, six sources have empty annotation files and one lacks annotation folder. Do not treat315structural candidates as a frozen scientific cohort.

18annotation marks are at/after ffprobe-reported source end, all terminal marks. Observed excess is roughly0.03–0.15seconds. These need an explicit terminal-mark/timebase policy, not automatic shifting of every annotation. The48outside-video frame requests are a different denominator and also include offset requests near the end.

No semantic certification, annotation repair, model inference, split assignment or cohort freeze. Successful decoding does not prove source edit equivalence, exact frame PTS, independent speaker identity or boundary-label correctness. Audio signal/ASR semantic accuracy uninspected.

## Visual inspection

Directly inspected five of858embedded grids at fixed output positions1,215,430,644,858. Diagnostic sample only, not a prevalence estimate. The first four show an old slide before/at the released mark and changed content at+0.5s. The last grid shows an end-card transition still in progress at+0.5s, illustrating why a sparse triplet does not establish effect onset/end or an exact timestamp correction. Labels remain unreviewed; no automated semantic verdict inferred.

## Runtime and next actions

This run completed extraction and later rendering/reporting: final receipt is present, so it is no longer necessary to wait for the earlier output-render phase. The246.6MB notebook and858embedded grids explain substantial output/display volume; no claim that every delay is a renderer defect. Resource receipt: media6,410,638,442bytes and analysis/log734,510,860bytes, below16GiB/1GiB limits.

Keep all downloaded media and existing frame checkpoints. If finishing the current preview queue, resume only388missing requests. Avoid regenerating/re-saving unchanged grids when optimizing a future runner while preserving full tables/coverage. Before a transition comparison, qualify event semantics/timebase/terminal/anomaly policy, then freeze eligible units, grouping and collar/one-to-one scorer. No detector comparison is yet established.

Unresolved: remaining388requested previews; semantic/timebase qualification; exact terminal policy; source/dependence and rights; independent Drive artifact audit.
