# MLPDataset EDA and completed preview review

## Decision

Keep the dataset conditionally for lecture slide-transition research. Acquisition and the requested sparse preview queue are complete. EDA inventory is complete for the pinned release, but exact event semantics/timebase qualification is not complete; this is not a frozen clean GT cohort or a completed detector benchmark. No annotation, cache or notebook was edited in this review.

Input: `benchmark/experiments/notebooks/diagnostics/mlpdataset_slide_transition_eda_colab.ipynb`, saved2026-10-19 10:57:58 local,130654549bytes, SHA256 `5a1b0622cd046c42df3e12b8347fb07864056f6bbe0301be6b9824f4c55c9c64`. Receipt observed2026-10-19T03:52:42.353071Z. All20code cells executed sequentially with no saved Python error output. Review uses saved outputs and pinned local source files, without rerunning acquisition/inference or fetching Drive artifacts.

## Complete EDA findings

-333release video rows,9021parsed marks,10source-group proxies,28nonmissing course/series proxies,186.634hours reported duration. Inventory excludes zero video/mark rows. The29row dependency table includes one missing-series row, not29distinct courses.
-333/333sources downloaded with333distinct saved media SHA256 values. No exact downloaded-file byte duplicate appears in saved states; near duplicates, shared slides and same-speaker dependence remain untested. Valid download/hash is not independent proof of historical source edit equivalence.
-332Google-ASR transcript files parsed,1652828word rows;9021spoken CSVs parsed,1613709word rows.337spoken CSVs empty.27missing Word cells across4transcripts; no nonfinite, reversed, negative or regressing full-transcript timestamps. Spoken negative local starts appear in3223files; all8684nonempty files with checkable offsets agree with their parent transcript offset within1e-6s.41766raw word differences disappear after casefold. Local negative starts should be interpreted with the released offset convention, not blindly clamped or called ASR errors. ASR semantic accuracy/audio quality was not inspected; Google-ASR output is not independent transcription GT.
-326videos contain marks,6have empty segment files,1lacks the annotation folder.315structural candidates are only a structural screen; they are not315certified usable videos.15nonincreasing rows across11videos:9exact zero previous gaps and6gaps of-0.0001s. These indicate repeated/near-repeated event times or export ordering; they do not prove the associated visible transition is absent.
-18marks at/after measured media end are all the final released row in their source. Excess0.028333–0.1499s. They need a source-end/timebase policy, not global timestamp shifting. The last released row (`terminal=True`) is not automatically EOF:326last rows exist, and many still correspond to a visible content/outro transition. Do not remove all326terminal rows indiscriminately.
-2961preview requests at987marks/326videos:2525cache hits+388new successful processes=2913decoded frames. All388new runner records have returncode0, no stop reason/error. Gallery embeds2913JPEG display derivatives with0render errors.48outside-source requests comprise4before-zero requests,18at-mark beyond-end requests and26after-end requests.957complete triplets,12two-image sets,18one-image sets. No requested item remains pending or failed.
-987/9021marks(10.94%) have sparse visual evidence;8034do not. All333/9021remain in FULL COVERAGE. Seven videos have no released marks and hence no transition preview; they must not silently become zero-transition negative examples for evaluation.
-Dental contributes190/333videos(57.06%) and2607/9021marks(28.90%). Proxy names do not certify distinct human speakers. Pooling by frame/mark alone can hide source imbalance and leak shared material across splits.
-Legacy versus updated release: slide-transition/ASR/spoken member bytes are identical; the one changed substantive JSON is dental/dental.json. Repository metadata lists334IDs, while the pinned archives contain333; repository-only dEh_Zk9d0sE stays separately accounted. Metadata version counts should not be mixed.

## What the labels mean

Pinned annotation instructions explicitly define the point as the END of the current slide, the last frame before the next slide. They exclude animations/new text on the same slide and treat an inserted video as one transition. Source files were locally SHA-checked against receipt source pins. See `benchmark/experiments/outputs/mlpdataset_research_261017/sources/mlpdataset__preprocessing__mturk_slide_seg.html`, lines675–687; preprocessing README lines15–16 corroborate slide-end segments.

Therefore old slide before AND at the annotation, new slide at+0.5s is qualitatively consistent with the released convention. It is not evidence that every timestamp is0.5s early. Three requested timestamps do not establish exact decoded PTS, the last old frame or precise effect onset/end. Matching source hashes ensures consistency within this run, not equivalence to the original video edition used by annotators.

## Visual review and limits

Manually viewed24contact sheets covering all987existing triplets, with25targeted marks also viewed at larger resolution. Contact-sheet scanning screens visible behavior; it is not987individual semantic certifications. The25detailed cases cover all10source groups. Selection is diagnostic, including anomalies/first/middle/last and deliberately ambiguous examples, not random. No correctness percentage for the whole dataset is inferred.25case observations and image evidence are in `benchmark/experiments/outputs/mlpdataset_eda_review_261019/`.

Detailed cases:13show a clear content replacement,2show blend/ongoing effects,7show no clear slide replacement within the sparse window,1has a blank after-frame and2only support source-end context. These counts describe the selected25only and are not prevalence estimates. Every observation remains uncertified GT.

| Example | Direct observation | Consequence |
|---|---|---|
| -8QB3Rbeqoc mark0,18.7466s | Oral Medicine before/at; ASA Classification at+0.5 | Qualitatively supports slide-end convention |
| rw7gzh25h9o mark0,5.4399s | Oral Pathology logo before/at; contents after | Visible transition; no global shift warranted |
| 077X0x07S0c mark32,1966s | Colon slide blends atmark, different slide after | Need explicit effect onset/end policy |
| aLK_nkgx8wo mark0,13.9937s | Vertical shutter effect still visible at+0.5 | Sparse window cannot locate completed transition |
| 18SixEz5GDE marks0/13,17.4132/1015.913s | Same title/sleep slide throughout each triplet | Wider context and source alignment check; not automatically wrong |
| 2xr4P0WGKSA marks0/26,4.267/2190.7665s | Slide stays same, lecturer moves | Full-image change is not slide change; unresolved timing |
| 9GmySN5P408 mark24,884.656s | One Optimal Force graph stays same | Revisit in cached video, no repair based on triplet |
| Ybv_JU0IoEM mark7,382.1287s | Same endocrine title but1of2changes to2of2 | Same title alone cannot identify animation/nontransition |
| DZSEErNZ1d4 marks9/21 | Different content after despite repeated/near-repeated timestamps | Review event deduplication separately from visual validity |
| KDVP_WAIUXs mark4,208.5586s; _yre2uKcj7A mark17,1570.5s | Clear next slide despite structural flag | Do not discard entire flagged source automatically |
| lBI8DXevsDk mark41,3744.2097s | Lecturer only across triplet | Source/segment end or delayed change unresolved |
| b118qvD927M mark0,538.866s; pUH2_SGnm9g mark44,3053.146s | Only pre-end image; at/after are outside | Source-end marker is not evidence of internal transition |

Contact sheets also show title cards, credits, black/blank frames, slides with lecturer panels, graphic replacements and text/layout updates. A sparse same-title update cannot reliably distinguish a new slide from a build animation. Lecturer/cursor motion is a potential detector confound. No ROI cropping policy or automatic animation verdict has been applied.

## Before the next step

1. **Target definition first.** Declare whether evaluating internal slide changes, slide segment ends, or all visual scene changes. For this dataset preserve the released slide-end convention. Specify title/outro/video insertion/blank intervals; define effect onset/last-old-frame/first-stable-new-frame separately. Do not mix them in a single unlabeled timestamp.
2. **Resolve ambiguous timing using cached media.** Review no-visible-change, ongoing effect, blank-frame, source-end and repeated-time cases. A targeted dense/continuous window around each suspect mark(e.g.±5s) can locate the event; widen only when still unresolved. Check slide region separately from lecturer motion. Record event type, old-frame end, effect start/end, confidence and evidence. Do not hardcode timestamp repairs from these sparse images; original annotations remain immutable and any proposed corrections require a versioned mapping.
3. **Create an explicit eligibility and GT policy.** Retain all333/9021in EDA inventory. Mark missing/empty annotation sources as unlabeled, not negative GT. Decide source-end treatment and repeated/near-equal-time event mapping with original slide/spoken indices preserved. Keep raw released and any reviewed-derived labels separate.315structural candidates are not an approved cohort.
4. **Freeze protocol before detector comparison.** Bind chosen media/source hashes, selected units, label version, exclusions-with-reasons and source/series grouping. Avoid random frame/mark splits from the same source. Predeclare one-to-one event matching, time tolerance relative to video frame resolution/annotation convention and reporting of pooled plus per-source/group outcomes. Do not tune time tolerance or repairs using final test predictions. Since previews have already been seen across all groups, do not describe this EDA review as a blind untouched test evaluation.
5. **Input/rights scope.** If later consuming text, preserve offset coordinates, document empty spoken segments and missing words; do not certify ASR accuracy from offset checks. Pinned repository license file says CC BY-NC-SA4.0; separate raw-video redistribution/use provenance remains unqualified here. No source license inference is made from download success.

These are qualification decisions, not a need to rerun downloads or all388previews. Current cache is complete for the chosen queue. Whole-video missing-event recall cannot be established by looking only around existing annotations; that requires an annotation-completeness audit over video intervals, beyond this sparse review.

## Readiness

- Complete: pinned-release inventory/version comparison, structural/text-file checks,333source acquisition, requested preview extraction/display and full coverage accounting.
- Partial: visual semantic/timebase review, source independence/near-duplicate audit, source rights and audio/ASR correctness.
- Not completed: reviewed GT policy, frozen eligible cohort/split/scorer, detector comparison or model selection.

Unresolved: exact events for no-change/blank/effect cases; terminal/repeated-time policy; original-source timebase equivalence; near-duplicate/speaker groups; raw-video use provenance. Keep/no-selection qualification remains conditional.
