# Research: giả thuyết, EDA và bằng chứng chất lượng cho RQ2

Thời điểm bắt đầu: **2026-10-18 22:25, Asia/Bangkok (UTC+7)**. Phạm vi: nghiên cứu và phản biện phương pháp; không triển khai, annotation, tải model, chấm lại hay generation. Báo cáo này đề xuất điều chỉnh, **không thay protocol hoặc quyết định nghiên cứu đã chốt**.

## Mục lục

1. [Kết luận](#1-kết-luận)
2. [Phương pháp và nguồn](#2-phương-pháp-và-nguồn)
3. [Thẩm định nội dung được gửi](#3-thẩm-định-nội-dung-được-gửi)
4. [Giả thuyết và đại lượng đo](#4-giả-thuyết-và-đại-lượng-đo)
5. [Bằng chứng theo nguồn](#5-bằng-chứng-theo-nguồn)
6. [Phân tích mất thông tin](#6-phân-tích-mất-thông-tin)
7. [Dữ liệu, thống kê và ngân sách](#7-dữ-liệu-thống-kê-và-ngân-sách)
8. [Điều chỉnh kế hoạch được đề xuất](#8-điều-chỉnh-kế-hoạch-được-đề-xuất)
9. [Nguồn tham khảo](#9-nguồn-tham-khảo)
10. [Bước tiếp theo và câu hỏi mở](#10-bước-tiếp-theo-và-câu-hỏi-mở)

## 1. Kết luận

**Phản biện được gửi đúng ở điểm trọng tâm: một phép so sánh hợp lệ về abstract agreement chưa tự trả lời được giả thuyết bảo toàn ý quan trọng.** Nhận xét trước của assistant đã nhấn mạnh tính an toàn của kết luận hẹp nhưng chưa làm rõ khoảng cách này. EDA cấu trúc tốt, protocol chặt và `no_selection` trung thực không thay thế được việc đo đúng mục tiêu.

Kế hoạch lúc 21:18 đã cải thiện đối chứng, provenance và giới hạn T4, nhưng primary endpoint vẫn là ROUGE-L với creator abstract. Nếu mục tiêu thực sự là bảo toàn ý và tính trung thực với nguồn, cần bổ sung hợp đồng đánh giá theo nguồn trước khi ưu tiên chạy ba nhánh hoặc tăng N. Nếu tiếp tục mục tiêu abstract agreement, thiết kế hẹp vẫn có giá trị và không bắt buộc thêm human scoring. Đây là **hai phạm vi khác nhau**, chưa được coi là một quyết định mới đã phê duyệt.

Ưu tiên nghiên cứu đề xuất: giữ toàn bộ kết quả 120 mẫu, audit/thu hồi receipt và intermediate summaries, định nghĩa mục đích summary, rồi kiểm khả thi của cách đo key-idea retention/faithfulness. Chỉ sau đó quyết định có cần generation mới hay đối chứng count-matched. Không có lý do khoa học để rerun chỉ vì S3 chưa thắng.

## 2. Phương pháp và nguồn

- Đầu vào: toàn bộ file phản biện 9 mục do người dùng gửi; code frozen/pair/scorer, báo cáo kết quả RQ2, kế hoạch 21:18 và audit EDA trước trong cuộc trao đổi.
- Tra cứu web có mục tiêu: **5 lượt gọi**, ưu tiên nguồn gốc: ACL Anthology, bài arXiv của tác giả, dataset card của nhà phát hành và nguồn thống kê của tác giả/nhà xuất bản.
- 7 nguồn ngoài được sử dụng: TIB card; Maynez 2020; Gigant 2024; Gigant 2025; HighRES 2019; RoSE/ACU 2023; Lakens 2017. Mốc 2017–2025; không phải systematic review hoặc chứng nhận tính mới đến mọi bài năm 2026.
- Từ khóa: reference quality, TIB multimodal structure, source-based salience, atomic content units, faithfulness, equivalence testing.
- Cấu hình `~/.Codex/.ck.json` không có: theo mặc định skill, dùng web; không gọi Gemini.
- Giới hạn truy cập: endpoint README TIB ở revision pinned trả lỗi; dùng dataset card hiện được truy cập. Không đồng nhất card hiện tại với bằng chứng qualification của snapshot local. PMC Lakens có challenge; bibliographic claim kiểm thêm qua DOI/nhà xuất bản và PubMed.
- Không dựa vào nội dung kết quả tìm kiếm từ blog tổng hợp để kết luận phương pháp. Bài 2025 được đọc ở **arXiv v1, 14/04/2025**; không suy trạng thái xuất bản chính thức chỉ từ field `Journal: TOMM`.

## 3. Thẩm định nội dung được gửi

| Nhận định trong phản biện | Kết quả đối chiếu | Hệ quả cho RQ2 |
|---|---|---|
| Chốt giả thuyết trước phán xét EDA đủ | Đồng ý; phù hợp targeted evaluation của RoSE [R6] | Định nghĩa target summary và outcome, không chỉ thêm biểu đồ |
| Abstract có chất lượng/mục đích khác nhau | Dataset card xác nhận tính không đồng nhất [R1] | Cần kiểm task–reference fit; không mặc định abstract gây kết quả bất lợi |
| ROUGE/BERTScore không đủ cho chất lượng toàn diện | Hướng lập luận phù hợp nghiên cứu faithfulness [R2] | Không chuyển metric agreement thành coverage/factuality |
| Gigant 2024 bổ sung reference-free metric | Xác minh đúng bài và tác giả [R3] | Metric đề xuất dùng trọng số n-gram nguồn; **không phải source SBERTScore đang có** |
| Đã có nghiên cứu TIB về modalities/structure năm 2025 | Xác minh bản arXiv [R4] | Structure của bài là tổ chức slide–transcript theo thời gian; khác S3 lexical chunking |
| Cần tách pipeline comparison và tác dụng riêng của boundary | Đúng với code thực tế | Count control là lựa chọn khi hỏi cơ chế; không bắt buộc cho mọi nghiên cứu pipeline |
| 120 mẫu hay 24–36 mẫu không tự bảo đảm đủ | Đồng ý | Tách số mẫu diagnostic, độ tin cậy annotation, precision và chi phí |
| Theo dõi source → map → reduce | Khả thi theo thiết kế receipt frozen, chưa thu hồi raw artifact | Kiểm receipt trước khi nghĩ đến generation mới |
| `no_selection` không đồng nghĩa tương đương | Phù hợp lý luận equivalence [R7] | Báo estimate/interval và giới hạn thực dụng; không thêm TOST hậu nghiệm để tìm kết luận |
| Đề cương gốc nói video ngắn nhiều đối tượng | **Chưa xác minh tài liệu gốc trong task này** | Không lấy câu trong phản biện làm quyết định đổi domain/RQ hiện hành |

Điều cần chỉnh trong cách hiểu phản biện: S3 hiện tại không có tầng tổng hợp hierarchy riêng. Nó dự đoán lexical boundaries, chia token-limited chunks rồi dùng cùng map/reduce phẳng với S1. Do đó không được đặt tên giả thuyết như đã có một cơ chế topic hierarchy đầy đủ.

## 4. Giả thuyết và đại lượng đo

### 4.1 Giữ nguyên câu hỏi đã có

**H-agreement:** trên 120 creator-valid records đã chọn, S3 lexical-boundary pipeline có khác S1 fixed-chunk pipeline về agreement với creator abstracts và nguồn transcript hay không, dưới cấu hình đã chạy?

Kết quả hiện có: 240 final summaries; 120 cặp cho ba metrics sau semantic amendment v2; mean S3−S1 nhỏ, mọi exploratory grouped interval qua 0. Chưa có bằng chứng chọn winner. Đây là kết quả cũ, không đổi tên thành kiểm định giả thuyết mới.

### 4.2 Câu hỏi mới đáng nghiên cứu — đề xuất, chưa chốt

**H-retention:** với mục đích summary đã xác định, cùng ordered source, generator/prompt và chính sách ngân sách đầu ra, lexical-boundary map/reduce có bảo toàn các ý nguồn quan trọng tốt hơn fixed-chunk map/reduce, đồng thời không làm xấu mức hỗ trợ của phát biểu bởi nguồn?

- Viết rõ đây là mở rộng **sau khi đã xem kết quả cũ**. Diagnostic trên old120 là post-hoc/exploratory; protocol mới chỉ prospective cho dữ liệu/đầu ra chưa dùng để điều chỉnh tiếp.
- Primary candidate: chênh lệch key-idea retention theo video/record; faithfulness là outcome/guardrail riêng, không trộn thành điểm tổng hợp tùy ý.
- Abstract ROUGE/BERTScore chuyển thành secondary **nếu** mục tiêu này được chọn. Không sửa vai trò endpoint của run cũ.
- “Không làm xấu” chỉ là mục tiêu thiết kế cho tới khi có non-inferiority margin và phân tích được định trước; không mặc định đã chứng minh.
- Cùng output cap không bằng cùng realized length. Ghi length/cap-hit và quan hệ với outcome; không trim hai summaries hậu nghiệm cho bằng độ dài rồi coi đó là kết quả gốc. Một strict length-matched control là protocol khác nếu cần.

### 4.3 Câu hỏi cơ chế — bổ sung có điều kiện

**H-control:** source lexical partitioning khác count-matched uniform partitioning như thế nào? Nhánh B trong kế hoạch hiện có phù hợp câu hỏi này, nhưng chưa cô lập toàn bộ length/compression effects. Nếu đóng góp chính là hiệu quả hai pipeline, chưa cần đặt C−B/ROUGE thành primary chỉ vì có thể xây đối chứng.

## 5. Bằng chứng theo nguồn

### 5.1 Những gì đã có và còn thiếu

Source SBERTScore hiện tại **đã là một phép đo reference-free theo transcript**. Code lấy mỗi summary sentence, tìm max cosine với source sentences rồi lấy trung bình. Nó không trực tiếp cho biết summary đã giữ đủ các ý quan trọng nào, hoặc kiểm được entailment/contradiction. Vì vậy yêu cầu mới không nên diễn đạt đơn giản là “thêm một metric theo nguồn”.

HighRES cung cấp tiền lệ đánh giá với nội dung nổi bật được đánh dấu từ input [R5]. ACU trong RoSE lại được viết từ **reference summaries**, không phải mặc nhiên từ transcript [R6]. Một source-derived idea ledger cho TIB là adaptation phải mô tả/kiểm rubric riêng; không gọi là áp dụng nguyên bản RoSE hoặc gold sẵn có.

### 5.2 Hợp đồng đánh giá đề xuất

1. **Đích summary:** chốt người đọc, mục đích (overview hay ôn tập), độ dài/ngân sách và phạm vi source. Không yêu cầu mọi chi tiết/công thức/ví dụ nếu output không đủ dung lượng cho đích đó.
2. **Source idea ledger:** người/nguồn annotation đủ năng lực xác định đơn vị ý quan trọng, evidence spans hoặc segment timestamps và mức chắc chắn **trước khi xem S1/S3 hoặc điểm abstract**. Số ý không cố định máy móc; đảm bảo phù hợp độ dài đích. Nếu dùng trọng số, freeze trước outputs.
3. **Matching outputs:** mã hóa arm, đổi thứ tự trình bày; mỗi ý được đánh dấu covered/not-covered/partial/uncertain, có citations. Chốt trước cách partial ảnh hưởng điểm; không tự gán 0,5 sau khi xem outcome. Có thể báo lower/upper coverage bounds cho uncertain thay vì ép thành nhãn chắc chắn.
4. **Claim support riêng:** tách supported, contradicted, not-supported-after-defined-search, not-located-in-inspected-scope và uncertain/source-corrupted. Không coi “chưa tìm thấy trong excerpt” là false. Ghi coverage của việc kiểm source và unresolved denominator.
5. **Relations/coherence:** nếu claim nghiên cứu đề cập quan hệ ý, chọn trước các quan hệ cần giữ và evidence; đánh giá sai quan hệ riêng. Mạch lạc/lặp không thay thế salience hoặc faithfulness.
6. **Reliability:** rubric pilot trên development; một phần đánh giá độc lập bởi hai người đủ năng lực nếu route annotation được chọn. Báo agreement trước adjudication, bất đồng/uncertainty và độ nhạy; không đặt threshold 0,8 hay cỡ double-review như chuẩn mặc định không có lý do. Agreement cao vẫn không bảo đảm nhãn đúng.
7. **LLM support:** có thể gợi ý đoạn nguồn/claim để người kiểm tra, nhưng giữ version/prompt/provenance và false-negative retrieval. Không dùng cùng generator tự xác nhận summary rồi gọi đó là independent validation.

Phép đo minh họa: `retention_i = số source ideas được xác nhận covered / số ideas đủ điều kiện của record i`. Lấy paired difference S3−S1 theo record rồi tổng hợp; không coi mỗi idea là một video độc lập. Case không có ledger đáng tin giữ ở trạng thái không đánh giá được và báo denominator, không gán quality0. Empty summary là failure/không bao phủ ý, không được nhận faithfulness hoàn hảo do không có claim.

### 5.3 Chi phí và lựa chọn route

| Route | Giá trị | Giới hạn/quyết định |
|---|---|---|
| Giữ abstract agreement | Tận dụng toàn bộ kết quả hiện có, không generation mới | Không trả lời đầy đủ H-retention |
| Source-grounded diagnostic trên old120 | Kiểm task/metric mismatch và failure modes | Post-hoc; subset purposive không cho prevalence hay superiority toàn cohort |
| Source-grounded study được freeze mới | Trực tiếp hơn với H-retention | Cần nguồn annotation/validation đủ tin cậy, chi phí người và precision planning |
| Thêm weighted-source metric Gigant 2024 | Ứng viên proxy relevance có cơ sở [R3] | Chưa được implement/validate trên cohort; không là automatic key-idea/faithfulness gold |

Không tự áp human-scoring gate vào nghiên cứu hẹp đã được chấp nhận. Nếu không có nguồn lực đánh giá theo nguồn hoặc nhãn có sẵn được qualification, phải giữ giới hạn H-agreement; không tuyên bố H-retention đã được kiểm chỉ bằng tăng metric count.

## 6. Phân tích mất thông tin

**Phát hiện code quan trọng:** `_summarize` trong `rq2_tib_benchmark_pair.py` lưu `section_summaries` cùng final summary vào arm receipt. Frozen runtime checkpoint/final update giữ `arms`, không lọc field này. Source pair nhúng trong notebook có hash `ff6168e9073a6b3f9d86223a243667fa1ef7bdf32c7e9009f2c4296607c6fb92`, khớp protocol. Embedded runtime cũng khớp frozen hash; bản local runtime hiện khác newline bytes nhưng normalized source đã được đối chiếu giống nhau.

Tuy nhiên saved notebook chỉ render/export abstracts và **final** S1/S3; generation logs không hiển thị text map. Local hiện chưa có real receipt ngoài fixtures. Kết luận đúng là **frozen implementation có lưu intermediates, cần lấy và audit receipt gốc**, chưa phải đã thu hồi đủ 240 bộ map summaries.

Đề xuất truy vết, không generation:

`source idea/evidence → source chunk IDs/hash → map summaries chứa ý → final summary → support/contradiction ledger`.

| Quan sát có evidence | Kết luận giới hạn |
|---|---|
| Ý có trong source chunk nhưng vắng ở mọi map output tương ứng | Không được bảo toàn trong map outputs đã lưu |
| Ý còn trong maps nhưng vắng ở final | Không được bảo toàn qua reduce trong run đó |
| Final nêu quan hệ khác source/maps | Có lỗi kết hợp cần adjudication, chưa tự chỉ ra nguyên nhân sâu |
| Final đúng nguồn nhưng abstract agreement thấp | Một case metric/reference disagreement; không tự chứng minh S3 tốt hơn |
| Không có map artifact hoặc uncertainty chưa giải quyết | Chưa định vị được stage mất ý; không tái tạo map bằng run mới rồi gọi là trace cũ |

Giữ đầy đủ source order và phân biệt không được nhắc với bị biến dạng. Association qua hai stage không tự chứng minh ranh giới là nguyên nhân. Missing intermediates ở run cũ không cản source→final diagnostic nhưng làm hẹp kết luận quá trình.

## 7. Dữ liệu, thống kê và ngân sách

### EDA đủ cho điều gì?

EDA đã quét full pool, missingness, lexical flags và phân bố; cohort cũ có chọn mẫu/hashes/group screening. Đó là nền tảng tốt cho nguồn văn bản và H-agreement. Kiểm kê dữ liệu không tự qualification được key-idea ground truth, annotation rubric hoặc claim về factuality. Reference/source suitability, pipeline instrumentation và model validation là các lớp khác EDA, cần đặt đúng tên.

Cohort120 đã kiểm: 109 Conference/Talk, 7 Lecture thuần; 97 Computer Science thuần; language metadata120/120 en. Dùng các số này để mô tả đối tượng nghiên cứu, không khẳng định metadata chứng nhận nội dung. Không cần loại Conference/Talk chỉ vì tên genre. Một đoạn giới thiệu hoặc bản ôn tập có thể phù hợp với các labels khác nhau, tùy target.

### Statistical unit và mức đủ

- Primary unit: released video/presentation record; nếu media identity chưa xác minh thì không gọi120 video độc lập tuyệt đối. Ideas, claims và map chunks lồng trong record; nguồn/series liên quan cần cluster sensitivity.
- Giữ source-author/title flags theo evidence, không tự equate cùng tác giả với leakage.
- Mọi sửa rubric/prompt sau khi xem outputs phải có development/history ledger; tên split không tự chứng minh unseen. Old120 phù hợp khám phá và kiểm đo lường, không được biến thành independent confirmation của giả thuyết mới.
- 30 diagnostic hay 60/120 evaluation chỉ là mốc lập ngân sách, không chứng nhận saturation/power. Nếu lấy extreme metric deltas để chẩn đoán, báo riêng khỏi score-independent sample.
- `no_selection` hiện tại: chưa đủ bằng chứng chọn phương pháp từ outcome đã đo. Không có source-retention scores để nói S3 giữ ý hơn/kém; không kết luận equivalence từ intervals qua0. Route equivalence/non-inferiority tương lai cần margin và thiết kế riêng [R7].

### T4 và chi phí con người

Giữ Qwen1.5B FP16, cùng serialized prompt và profile giữa arms là hướng tiết kiệm đề xuất đã có; không có model/GPU measurement mới. Chấm annotation offline và đọc map receipt không cần generation T4. Nút thắt H-retention có thể là đọc/annotation transcript dài, không phải VRAM.

Do đó lập hai ngân sách độc lập: (a) giờ người cho source ledger/matching/review, (b) GPU/CPU/load/scorer/export. Đo throughput annotation trên development trước chốt số mẫu; không hứa30 mẫu “đủ” hay dùng độ lớn cohort thay cho reliability. Thời gian chấm ACU trên news references trong bài gốc không chuyển trực tiếp thành thời gian đọc transcript TIB.

Nếu có thí nghiệm mới, giữ pre-freeze context/capacity checks của kế hoạch hiện có, sequential generator/scorers và failure accounting. Same allocated budget không phải same actual tokens, output length hoặc padded compute. Không chạy factorial model/prompt/arms/budgets chỉ để bao phủ mọi yếu tố.

## 8. Điều chỉnh kế hoạch được đề xuất

Đây là delta cần cân nhắc cho [kế hoạch 21:18](../261018-2118-rq2-scientific-improvement/plan.md); báo cáo này **chưa sửa năm file kế hoạch**.

| Vị trí | Hiện tại | Delta đề xuất trước triển khai |
|---|---|---|
| Trước P1 | Mặc định narrow agreement | Thêm decision record về target summary, H-agreement/H-retention, contribution và ngày giả thuyết mới |
| P1 audit/error analysis | Diagnostic 30, có grounding/map-loss | Ưu tiên thu receipt/intermediates; source ideas viết trước outputs; phân biệt diagnostic với validated endpoint |
| P2 qualification | Frame60/120 mới | Xác định source/task/reference fit và khả năng làm ledger trước; không vội bỏ old120 hoặc hứa cohort mới đủ |
| P3 đối chứng/metric | C−B ROUGE primary | Nếu chọn H-retention: primary S3−S1 source idea retention, faithfulness riêng; C−B là secondary cơ chế nếu nguồn lực cho phép |
| P4 T4 | Development GPU và sizing | Thêm annotation throughput/reliability gate độc lập; generation mới chỉ khi câu hỏi chưa trả lời được bằng artifact cũ |
| Reporting | `no_selection` + intervals | Thêm measurement validity, source/abstract disagreement và stage-loss evidence; giữ null/uncertain/failed denominators |

Không cần phủ định các gate budget/context/identity đã có. Điểm đổi thứ tự là **question → measurement feasibility → artifact analysis → controlled experiment**, không chọn arm/sample size trước rồi mới quyết định chất lượng cần đo.

## 9. Nguồn tham khảo

### Nguồn ngoài đã kiểm

- **[R1] TIB dataset card**, nhà phát hành: [gigant/tib](https://huggingface.co/datasets/gigant/tib). Nêu transcript tự động, abstract làm target và mục đích/độ dài/chất lượng không đồng nhất. Card là tài liệu nguồn, không chứng nhận từng reference local.
- **[R2] Maynez et al., ACL2020:** [On Faithfulness and Factuality in Abstractive Summarization](https://aclanthology.org/2020.acl-main.173/). Hỗ trợ phân biệt lexical/semantic similarity với faithfulness; kết quả nguồn khác không thay evidence trên TIB.
- **[R3] Gigant et al., EMNLP2024:** [Mitigating the Impact of Reference Quality on Evaluation of Summarization Systems with Reference-Free Metrics](https://aclanthology.org/2024.emnlp-main.1078/). Đọc PDF mục1–4; đề xuất relevance metric weighted source n-grams và kết hợp reference-based scores. Không đồng nhất với SBERTScore trong repo.
- **[R4] Gigant et al., arXiv2025 v1:** [Summarization of Multimodal Presentations with Vision-Language Models](https://arxiv.org/html/2504.10049v1). Đọc methodology và §5.1–5.3: structure là temporal interleaving slide/transcript, có input-budget analysis. Không chuyển ranking/Pareto của VLM paper thành T4/Qwen1.5B guarantee; tính mới của pipeline hiện tại chưa được xác lập chỉ từ khác biệt này.
- **[R5] Hardy et al., ACL2019:** [HighRES](https://aclanthology.org/P19-1330/). Tiền lệ highlights salient source và đánh giá summary theo input; adaptation sang long transcripts vẫn cần qualification.
- **[R6] Liu et al., ACL2023:** [Revisiting the Gold Standard / RoSE](https://aclanthology.org/2023.acl-long.228/). Đọc ACU protocol và targeted evaluation; original ACUs từ references, có cảnh báo về độ dài, subjectivity và task alignment.
- **[R7] Lakens2017:** [Equivalence Tests: A Practical Primer](https://doi.org/10.1177/1948550617697177). Nền tảng distinction no-difference evidence/equivalence; không tự áp một test vào cohort này.

### Bằng chứng local

- [Kết quả 120](../../benchmark/docs/results/rq2-tib-120-results-261013.md), [semantic amendment](../../benchmark/docs/results/rq2-tib-semantic-rescore-v2.md).
- [EDA](../../benchmark/experiments/notebooks/diagnostics/rq2-tib-all-splits-eda-colab.ipynb), [cohort](../../benchmark/experiments/registry/datasets/tib-rq2-rq4-120-cohort-261012.json), [protocol](../../benchmark/experiments/registry/datasets/tib-rq2-rq4-120-protocol-261012.json).
- [Pair generation/receipt](../../benchmark/experiments/scripts/rq2_tib_benchmark_pair.py), [frozen runtime](../../benchmark/experiments/scripts/rq2_tib_frozen_runtime.py), [semantic scorer](../../benchmark/experiments/scripts/rq2_tib_benchmark_metrics.py), [saved generation notebook](../../benchmark/experiments/notebooks/rq2-tib-120-evaluation-colab.ipynb).
- [Master evidence map](../../benchmark/plans/260901-unified-scientific-benchmark/framework/00-master-plan.md): active RQ2 không human scoring; nghiên cứu mới có source-based annotation là đề xuất thay phạm vi cần ghi rõ, không hành vi đã phê duyệt.

Security/rights liên quan: transcript/annotation theo nguồn và điều kiện dữ liệu; không gửi private receipt/source sang API judge khác khi chưa có phạm vi cho phép. Không có security/deployment change trong nghiên cứu này.

## 10. Bước tiếp theo và câu hỏi mở

### Bước tiếp theo đề xuất, chưa thực hiện

1. Ghi decision record về mục đích summary và giả thuyết ưu tiên; giữ hypothesis history thay vì viết lại run cũ.
2. Thu hồi/audit receipt gốc và kiểm `section_summaries`, source partitions, 240 arm coverage; không regenerate intermediates của run cũ.
3. Thử rubric nguồn trên development độc lập, đo thời gian/reliability; xác định route annotation khả thi hoặc giữ narrow agreement.
4. Diagnostic old120 theo sampling rule và scope rõ; ghi cả case ủng hộ/không ủng hộ, đối chiếu source–map–final–abstract. Chỉ sửa kế hoạch/protocol mới sau decision record.
5. Chốt primary outcome, annotation/GPU budget và precision trước N/arms; chỉ chuẩn bị run mới nếu cần và sau một yêu cầu triển khai riêng.

### Câu hỏi chưa giải quyết

- Target summary là overview hay bản ôn tập, độ dài và người đọc cụ thể?
- Ưu tiên H-agreement hiện hành hay mở H-retention; nguồn annotation/validation và người có năng lực hiện có?
- Receipt Drive thực có đầy đủ intermediate summaries/chunk identities không; hash discrepancy có giải thích được không?
- Key-idea rubric nào đáng tin trên transcript TIB, xử lý ASR/source uncertainty và relation labels thế nào?
- Practical retention/faithfulness margins, precision và tổng giờ người/GPU chấp nhận là bao nhiêu?
- Đề cương gốc có thật sự mang phạm vi như file phản biện mô tả không; contribution cuối cùng của task và toàn hệ thống là gì?
