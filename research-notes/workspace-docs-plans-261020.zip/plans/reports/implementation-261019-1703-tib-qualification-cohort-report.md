# TIB qualification, P2 evidence và development seal — 2026-10-19

Đã hoàn tất bốn đầu việc đến development-ID seal: policy quyền theo record, CPU EDA trên toàn pinned snapshot, qualification/exposure accounting và khóa **40 pilot / 300 selection**. Chưa chạy generation, model selection, final benchmark hoặc T4 feasibility pilot. Final test chưa seal. Không commit/push; dữ liệu lớn và text excerpts giữ local, ignored.

## Kết quả và mẫu số

| Native split | Snapshot | Source + reference rights/content eligible | Sau exposure/group filtering |
|---|---:|---:|---:|
| Train | 7.282 | 4.215 | 4.213 |
| Validation | 910 | 532 | 464 |
| Test | 911 | 523 | 523 |
| Tổng | 9.103 | 5.270 | 5.200 |

70 eligible records bị loại do old120/9-pilot exposure: 2 train, 68 validation. Ledger vẫn ghi mọi historical ID, kể cả những ID đã fail quyền/reference trước đó; không suy chỉ có70 exposed records trong corpus. Các known-group protection rules đều được áp dụng; ở frame đủ điều kiện này không phát sinh thêm loại linked-group/test-priority ngoài70. EDA-only exposure không tự loại test.

523 là **eligible native-test frame**, không phải final IDs/N đã khóa và không bảo đảm fit T4. Giữ full-test-first; nếu cần, P4 áp fallback600→500→400 với N nhỏ hơn frame và budget đã khóa trước test outcomes. Với frame523, không chọn600; ưu tiên full523, rồi500, rồi400 nếu cần và khả thi. Không loại source dài/OOM sau outcomes để làm giảm mẫu số.

## Source-use policy

[Policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/source_use_policy.json) phân biệt `allow / conditional / hold`. Thực tế **allow0 / conditional6.171 / hold2.932** ở source; không nâng conditional thành blanket permission. Có5.592 reference khớp field CC0; giao source/reference cho phép5.270 records trước exposure. Quyền của reference không tự cấp quyền source.

Scope frozen: local private noncommercial research, giữ attribution; không external generation APIs, không public redistribution source/reference/expressive outputs. NC/SA/ND4 routes chỉ eligible trong các điều kiện cụ thể của policy; older-ND, thiếu current grant, thiếu attribution hoặc non-open giữ HOLD. 165 license-prose/URI conflicts giữ flags/evidence; URI được phân giải theo rule, không tùy ý xóa exceptions. Hold reasons:2.582 thiếu current grant,328 older-ND,5 attribution,17 non-open. Chi tiết [rights report](research-261019-1703-tib-source-use-policy-report.md).

Đổi sang môi trường cloud/T4 phải xác minh điều kiện truy cập/lưu trữ/chia sẻ trong execution profile; development seal hiện tại không cấp quyền tự động upload dữ liệu.

## Reference và source groups

[Reference policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/reference_policy.json) calibrated train trước model outcomes: **A0 / B9.095 / C8**. C là empty-reference evidence; generic/short/reused/unreviewed chưa đủ bằng chứng usable hoặc unusable giữ B. Primary A+B hiện thực chất là B-only; A-only sensitivity **không ước lượng được**, phải báo unavailable. Không có factuality/gold certification.

225 historical flags thuộc18 reuse groups đã được review theo rubric; casefold toàn frame tìm226 members vì thêm một legacy structurally-excluded row. Các targeted cases đều giữ uncertain B dựa trên abstract/title/limited source spans đã lưu hash; không khẳng định episode-level coverage hay review toàn transcript. Historical9.103→9.002→8.769 được tái lập để truy dấu, không ép thành eligibility mới. [Reference report](qualification-261019-1703-tib-reference-usability-report.md).

Group audit đã xử lý9.103 nguồn,2.854.654 candidate pairs và toàn2.658 historical queued pairs: **22 confirmed near-source edges / 9.082 components**,16 nonsingleton components với37 records,7 cross-split components. Ba quan hệ train:2341 / valid:433 / test:782 được tái lập. Author/title/reused abstract riêng lẻ không tạo group; numeric overlap thresholds và string-shingle confirmation đã frozen trước outcomes. Bottom-256 retrieval là approximate, recall unknown; đây là known-dependency control, không chứng minh corpus độc lập hoàn toàn.

Runtime provenance limitation: completed group process dùng module đã load trước một disk edit; hash runner trong original summary là observed file hash, không phải sealed executed-code identity. Sau sửa missing `digest` import, additive receipt đã replay mọi9.103 raw/canonical hashes,22 accepted pairs và toàn graph forward/reversed, giữ nguyên original artifacts/core. Không rerun2.854.654 candidate comparisons; giới hạn đó ghi rõ trong [additive receipt](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/group_validation_review_fix_receipt.json).

## P2 thực chạy và development seal

Canonical source là released transcript; NFC/whitespace, giữ raw/normalized hashes và offset runs. Segment anomalies giữ sidecar flags, không tự tái dựng source. CPU scan toàn9.103 với pinned BART/LED/Qwen tokenizers; không tải model weights. Có split-wise source/reference/compression quantiles, genre/subject/language, technical/segment flags và4 figures. [Executed notebook](../../benchmark/experiments/notebooks/diagnostics/tib-summarization-gap-closure-261019.ipynb) kiểm receipt và render các saved CLI artifacts; không giả là một full-snapshot rescan mới trong notebook.

Ví dụ toàn raw train: source median4.702 words, p95≈10.518, max30.044; reference median110 words, p95=346. Native source BART/LED median5.596 tokens, p95≈12.591, max37.558; Qwen median5.584,5, max37.455. Đây là distribution trước rights/exposure, không phải selected-cohort hoặc T4 capacity statistics. Native counts không special tokens; illustrative windows không wrappers/overlap/reduction. W_global vẫn UNSET; actual profiles, sentence CPU tails và measured map/reduce calls còn P4-dependent. [Gap matrix](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/eda_gap_matrix.json).

[Development cohort](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/development_cohort.json) đã seal trên native validation, không fallback:

| Role | N | Short / medium / long |
|---|---:|---|
| Pilot | 40 | 13 / 12 / 15 |
| Selection | 300 | 100 / 90 / 110 |

Eligible-train source-word cutpoints3.447/5.891; stable SHA order, constrained largest remainder, pilot includes per-bin extremes, reserve toàn pilot groups trước selection. Staged pilot IDs: valid:644 / valid:341 / valid:886; **chưa chạy**. Verified replay và reversed-input order cùng IDs; overlap ID/group giữa hai roles, với historical tuning và eligible test bằng0 theo known ledger. Đủ340 records trong464 validation, size là operational choice, không statistical-power guarantee.

## Verification và phần chưa chạy

- 101 focused tests PASS, gồm rights fail-closed, reference span validation, group runtime wiring, canonical offsets, deterministic sampling/fallback, test-priority và overwrite guard;34 contract/snapshot/legacy dataset regression tests PASS. Exit0; môi trường phát nonfatal pyreadline3 shutdown warning.
- Independent scoped review PASS trước seal; receipts hash-bind rights/reference/EDA/groups và group additive replay. [Execution receipt](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/execution_receipt.json) lưu các hash, replay và notebook status.
- Notebook có6 executed cells/0 errors/4 PNG;32 execution-receipt file hashes và manifest receipt/notebook hashes đã readback PASS. Strict plan validation PASS/0 issues; Git whitespace check PASS. Publication từng bị chặn local kernel startup trong sandbox, sau đó fresh kernel chạy xong; receipt-export resume thiếu biến được sửa bằng đọc lại notebook đã lưu, không chạy lại scan/inference. [Attempt history](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/publication_attempts.json) ghi rõ các lần này.
- Hướng dẫn vận hành: [qualification guide](../../docs/tib-summarization-qualification.md). Dữ liệu text/canonical/pairs/ledgers đầy đủ ở ignored `benchmark/research-data/tib-qualification-261019-1703/`; registry chỉ giữ policies, IDs, aggregates và compact receipts.

**T4 pilot chưa thể bắt đầu**: local GPU thực là RTX4050 Laptop6.141MiB, driver610.88, không phải T4. Scorer-ready receipt, candidate runtime profiles, W_global, measured T4 capacity và compute/storage/retry budgets chưa có. Tokenizer revisions không thay thế model/scorer-ready evidence. Không có model winner mới; old120/no_selection không đổi.

Còn mở: ratify W_global từ eligible train/development evidence và product constraint; khóa scorer/model revisions/config profiles; có T4 session và numeric budgets/store conditions; chạy staged feasibility rồi mới mở pilot40/selection300; khóa final test và diagnostic spec sau validation decisions. A-only hiện unavailable và group recall unknown phải giữ trong final reporting, không bổ sung labels/claims để che hai giới hạn này.
