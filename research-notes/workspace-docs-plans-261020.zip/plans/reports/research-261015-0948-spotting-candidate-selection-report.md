# Nghiên cứu mở rộng candidate spotting trên CVID

Ngày đối chiếu nguồn: 15/10/2026. Trạng thái: lựa chọn nghiên cứu, chưa bổ sung candidate vào registry/notebook và chưa xác minh runtime của candidate mới.

## Quyết định đề xuất

Mở rộng từ hai thành **năm pipeline chính và một candidate có điều kiện**. Ba pipeline bổ sung chính là Tesseract LSTM, docTR FAST + PARSeq và PaddleOCR PP-OCRv6 medium. TESTR là nhánh bổ sung để khảo sát mô hình học chung định vị–nhận dạng, phụ thuộc khả năng dựng runtime Linux/CUDA.

Số lượng này xuất phát từ các vai trò đối chứng cần phủ; không có căn cứ thống kê rằng sáu là số lượng tối ưu. Hai candidate hiện tại đủ cho một phép so sánh hai hệ thống, nhưng chưa đại diện cho các hướng OCR/spotting khác nhau.

| Candidate cụ thể | Vai trò trong thiết kế | Quyết định và trạng thái |
|---|---|---|
| EasyOCR 1.7.2, CRAFT + English G2 | Mốc detector CRAFT + recognizer CTC | Giữ nguyên candidate đã khóa; runtime đã có receipt |
| PaddleOCR 2.8.1, English PP-OCRv3 det + English PP-OCRv4 rec | Mốc DB + SVTR_LCNet | Giữ nguyên candidate đã khóa; runtime đã có receipt |
| Tesseract 5, tessdata_best/eng, OEM 1, PSM 11 | Layout truyền thống kết hợp recognizer LSTM | Bổ sung chính; phiên bản binary/hash cần khóa |
| docTR 0.12.0, fast_base + parseq, pretrained | Detector FAST + recognizer Transformer tự hồi quy | Bổ sung chính; weights và forward pass cần xác minh |
| PaddleOCR 3.7.0, PP-OCRv6_medium_det + PP-OCRv6_medium_rec | Đối chứng thế hệ mới trong cùng họ PaddleOCR | Bổ sung chính; môi trường riêng, weights/runtime cần xác minh |
| TESTR R50 Polygon, Total-Text, không lexicon | Mô hình Transformer học chung định vị–nhận dạng | Bổ sung có điều kiện; cần checkpoint và runtime Linux/CUDA khả dụng |

“Bổ sung chính” là ưu tiên triển khai, không đồng nghĩa đã chạy được. Hiện chỉ hai candidate cũ có bằng chứng runtime local. Không gọi danh sách này là sáu candidate sẵn sàng.

## Cơ sở chọn lọc

Đây là rà soát có phạm vi phục vụ benchmark hiện tại, không phải systematic review toàn bộ literature. Các điều kiện bắt buộc trước khi nhận candidate:

1. Nhận frame đầy đủ và xuất vùng chữ cùng transcription; recognizer chỉ đọc crop chưa đáp ứng spotting.
2. Có code, cấu hình và checkpoint truy nguyên được từ nguồn chính thức; kiểm tra quyền sử dụng code và weights riêng.
3. Có thể cố định phiên bản, hash, preprocessing, decoder, threshold, grouping và thiết bị; không dùng GT/lexicon của CVID để sửa đầu ra.
4. Có adapter ánh xạ đầu ra sang protocol hiện tại mà không cắt/gộp vùng theo GT.
5. Qua technical preflight bằng ảnh train chọn trước, không dùng điểm test để quyết định ứng viên được giữ.

Sau điều kiện bắt buộc, ưu tiên độ phủ phương pháp, khả năng tái lập và chi phí triển khai. Chọn một đại diện cụ thể cho mỗi vai trò thay vì cộng nhiều wrapper dùng chung weights. PP-OCRv6 là đối chứng thế hệ có chủ ý; không tính thành một họ kiến trúc độc lập với Paddle cũ. Điểm công bố trên Total-Text, ICDAR hoặc benchmark của nhà cung cấp không được dùng để dự báo thứ hạng CVID.

## Căn cứ từng ứng viên mới

### Tesseract: baseline layout + LSTM

Tesseract cung cấp TSV có các hàng cấp từ và tọa độ. `tessdata_best` tương thích chế độ LSTM OEM 1. PSM 11 phục vụ sparse text, phù hợp làm giả thuyết cấu hình cho frame có nhiều vùng chữ rời nhau. Đây là lựa chọn theo đặc tính tác vụ, chưa phải cấu hình đã chứng minh tốt nhất trên CVID. [TSV và chế độ chạy](https://tesseract-ocr.github.io/tessdoc/Command-Line-Usage.html), [page segmentation](https://tesseract-ocr.github.io/tessdoc/ImproveQuality.html), [traineddata](https://tesseract-ocr.github.io/tessdoc/Data-Files.html).

Đề xuất khóa: Tesseract 5 với binary version cụ thể; `eng.traineddata` từ `tessdata_best` với commit/hash; OEM 1; PSM 11; không thêm binarization, upscale hoặc dictionary CVID bên ngoài. Adapter chỉ nhận hàng TSV level 5; loại level 1–4 vì đó là cấu trúc trang/block/line, không phải prediction từ. Không thêm confidence cutoff; giữ hàng từ có chuỗi rỗng để scorer xử lý thất bại đọc chữ. PSM 3 nếu khảo sát phải là sensitivity được khai báo trước, không tính thêm một mô hình độc lập. [Weights chính thức](https://github.com/tesseract-ocr/tessdata_best).

### docTR: FAST + PARSeq

API docTR 0.12.0 có `fast_base`, `parseq` và OCR predictor pretrained. FAST nghiên cứu phát hiện chữ bằng biểu diễn kernel; PARSeq nghiên cứu nhận dạng bằng permuted autoregressive Transformer. Cặp này bổ sung cả hướng detector và recognizer khác hai mốc hiện tại. [API docTR](https://mindee.github.io/doctr/v0.12.0/modules/models.html), [FAST](https://arxiv.org/abs/2111.02394), [PARSeq](https://arxiv.org/abs/2207.06966).

Đề xuất dùng weights pretrained do docTR phân phối, PyTorch, giữ đầu ra Word và hình học native; chuyển tọa độ chuẩn hóa về pixel bằng kích thước frame. Xét `assume_straight_pages=False`, `export_as_straight_boxes=False` để bảo toàn vùng xoay; xác minh API của đúng phiên bản khi khóa config. Không thêm page unwarping/orientation/layout model ngoài cặp đã chọn. Kiểm tra vocab thực tế, không mặc định checkpoint là English-only. [Hướng dẫn model/vocab](https://mindee.github.io/doctr/v0.12.0/using_doctr/using_models.html), [repository và cấu trúc đầu ra](https://github.com/mindee/doctr).

Weights docTR là một implementation/training cụ thể; không gán điểm hoặc checkpoint của paper FAST/PARSeq gốc cho pipeline này. Khả năng chạy CPU và native operator còn cần forward pass thực tế.

### PP-OCRv6 medium: đối chứng thế hệ

Release chính thức PaddleOCR 3.7.0 ngày 11/06/2026 đã giới thiệu PP-OCRv6. Vì vậy lựa chọn bản mới không dừng ở PP-OCRv5. Chọn cố định cặp medium để có một đại diện, chưa có bằng chứng CVID rằng medium tốt hơn tiny/small. [Release 3.7.0](https://github.com/PaddlePaddle/PaddleOCR/releases/tag/v3.7.0).

Đề xuất cặp `PP-OCRv6_medium_det` + `PP-OCRv6_medium_rec`, backend Paddle, CPU FP32 cho thử nghiệm kỹ thuật ban đầu, tắt document orientation, unwarping và textline orientation; khai báo rõ recognition score threshold 0 để giữ đầu ra nhận dạng. Preprocessing, detector thresholds, dictionary và decoder phải lấy từ đúng artifact/config rồi khóa toàn bộ; chưa coi các trường đó đã được xác minh. [Pipeline chính thức](https://github.com/PaddlePaddle/PaddleOCR/blob/main/docs/version3.x/pipeline_usage/OCR.en.md), [quick start và đầu ra polygon/text](https://github.com/PaddlePaddle/PaddleOCR/blob/main/docs/quick_start.en.md), [detector weights](https://huggingface.co/PaddlePaddle/PP-OCRv6_medium_det), [recognizer weights](https://huggingface.co/PaddlePaddle/PP-OCRv6_medium_rec).

Tạo môi trường riêng cho PaddleOCR 3.x; không nâng cấp môi trường PaddleOCR 2.8.1 đã seal. Chưa tải/hash weights hoặc xác nhận native dependencies trên Windows. Khóa commit tài liệu/config vì liên kết nhánh `main` có thể thay đổi.

### TESTR: joint spotting có điều kiện

TESTR cung cấp mô hình Transformer học chung localization và recognition, cùng pretrained R50 polygon trên Total-Text không lexicon. Chọn polygon checkpoint để giảm thêm lựa chọn chuyển đổi đường cong; chọn dữ liệu word-level thay vì checkpoint CTW1500 line-level. Đây là đối chứng thiết kế học chung, không phải tuyên bố TESTR tốt nhất. [Paper CVPR 2022](https://openaccess.thecvf.com/content/CVPR2022/papers/Zhang_Text_Spotting_Transformers_CVPR_2022_paper.pdf), [code/checkpoint chính thức](https://github.com/mlpc-ucsd/TESTR).

Stack tác giả gồm Python 3.8, CUDA 11.3, Torch 1.10.1, Detectron2/AdelaiDet. Cần môi trường Linux/CUDA riêng và xác minh checkpoint truy cập được, hash, vocab, license và inference không lexicon. Không hứa chạy TESTR trong môi trường Windows CPU đang khóa. Nếu không đạt gate kỹ thuật, báo năm pipeline chính và một candidate không đủ điều kiện runtime; không thay ứng viên dựa trên điểm test.

DeepSolo là phương án dự phòng thuộc hướng joint Transformer, có paper và repository chính thức. Chưa cần thêm cả hai khi mục tiêu hiện tại là phủ vai trò phương pháp; checkpoint/runtime DeepSolo chưa được xác minh trong đợt này. [DeepSolo](https://github.com/ViTAE-Transformer/DeepSolo), [paper](https://arxiv.org/abs/2211.10772).

## Các lựa chọn chưa đưa vào bảng chính

| Nhóm | Lý do và điều kiện xem xét lại |
|---|---|
| TrOCR, PARSeq, ABINet hoặc SVTR đứng riêng | Chỉ recognition; phải ghép detector và khóa pipeline hoàn chỉnh. PARSeq đã xuất hiện trong cặp docTR |
| CRAFT, DBNet hoặc EAST đứng riêng | Chỉ detection; chưa có transcription |
| RapidOCR/ONNX dùng cùng Paddle weights | Chủ yếu là biến thể runtime; phù hợp nghiên cứu triển khai hơn là tăng độ phủ mô hình |
| Thêm nhiều bản PP-OCR liên tiếp | Dễ làm bảng nghiêng về một họ; dùng làm ablation nếu câu hỏi là tiến bộ qua các thế hệ |
| VLM xuất plain text/Markdown | Chưa đáp ứng contract vùng chữ + transcription. Có thể mở track riêng nếu cung cấp hình học và failure rules kiểm chứng được |
| Cloud OCR | Chưa có hợp đồng version/weights và điều kiện tái lập tương đương; không suy ra chất lượng thấp hơn |

## Thiết kế so sánh sau khi mở rộng

Giữ nguyên cohort **1.754 frame, 40.063 đối tượng XML được chấm** và protocol đã khóa. Detection dùng hình học; spotting yêu cầu cả match hình học và exact text sau normalization. Matching độc lập max-cardinality một-một, polygon IoU > 0,5; NFKC/casefold/collapsed whitespace, giữ dấu câu/chữ số/dấu tiếng Việt/ký tự đơn và literal `*`. Failure vẫn ở mẫu số; không loại frame lỗi để tăng điểm.

Giữ nguyên các sensitivity đã khai báo: IoU > 0,75; case-sensitive; loại cố định ba frame bị flag theo policy sẵn có. Không thêm sensitivity theo hướng thuận lợi cho một model sau khi thấy kết quả.

Tạo **registry, analysis contract và run root phiên bản mới**. Hai candidate cũ giữ nguyên weights/config/thresholds/grouping và môi trường đã seal. Candidate mới cần receipt gồm package/backend/device, model source/hash, dictionary, config hiệu lực, preprocessing, thresholds, grouping và output adapter. Không sửa âm thầm binding của run hai candidate hiện tại.

Không ép mọi model dùng cùng con số confidence threshold: các score chưa được calibration chung. Chọn config công bố hoặc lựa chọn theo tác vụ trước khi xem điểm; ghi rõ lựa chọn nào là mặc định, lựa chọn nào do người nghiên cứu đặt. Nếu tune trên val, phải là track riêng với ngân sách/quy trình khai báo trước; không gọi so sánh model mới đã tune với mốc cũ untuned là đối chứng kiến trúc thuần túy.

Giữ grouping native, không dùng GT để split/merge box. Khác biệt word/line granularity ảnh hưởng IoU và Hmean trên GT hiện tại; kết luận là hiệu quả **pipeline với cấu hình cụ thể**, chưa xác định riêng tác động kiến trúc recognizer/detector.

Chỉ số chính Hmean end-to-end; kèm detection P/R/F1, số frame failure/missing, sensitivity, theo course và chi phí quan sát. Khai báo trước đối chứng mới so với Paddle cũ cố định; giữ phép EasyOCR–Paddle ban đầu. Paired cluster bootstrap theo course/folder phù hợp hơn coi từng box độc lập. Với nhiều so sánh, báo CI exploratory và nêu chưa hiệu chỉnh multiplicity; không dùng bảng nhiều CI để tuyên bố một winner có ý nghĩa xác nhận. Chỉ có bảy course, thêm model không tăng số đơn vị dữ liệu độc lập.

Năm pipeline chính ưu tiên profile CPU để kiểm tra khả thi. TESTR nếu dùng GPU phải ghi profile riêng; không xếp hạng tốc độ chung từ các thiết bị khác nhau. Muốn so sánh tốc độ chung cần một thí nghiệm phần cứng/runtime riêng được khóa lại, kể cả các anchor.

## Bằng chứng hiện tại và giới hạn

Registry hiện có: `benchmark/experiments/registry/datasets/iiit-cvid-spotting-candidates-261014.json`. Runtime receipt hiện có: `iiit-cvid-spotting-test-runtime-261014.json`; đây là bằng chứng cho hai candidate cũ, không bao phủ danh sách đề xuất.

Snapshot local đã kiểm tra ngày 15/10: run v2 có 738/1.754 frame EasyOCR thành công, chưa có Paddle predictions; không còn worker liên quan ở thời điểm kiểm tra. Chưa có kết quả so sánh hoàn tất. Không sử dụng điểm từ partial run để chọn danh sách mới. Receipt/checkpoint có giá trị xác định trạng thái hơn câu “No frame inference run” còn cũ trong README.

Không gộp 738 prediction vào một candidate hoàn tất. Chỉ tái sử dụng đầu ra sau khi xác minh run identity, config/weights/environment, prediction hash và coverage đầy đủ; việc resume hay replay phải được ghi nhận rõ. Không trộn các attempt để giữ prediction tốt nhất.

CVID có annotation chọn lọc: chữ nhìn thấy nhưng không gán nhãn có thể bị tính FP. Cohort đã EDA và có partial inference, vì vậy không gọi đây là blind preregistration hoặc benchmark gold/exhaustive. Kết quả chỉ mô tả khả năng khớp released annotations trên cohort này; chưa chứng minh tổng quát cho lecture video khác, chữ viết tay khác hoặc production. Audit crop recognition trước đó vẫn là bằng chứng riêng.

## Bước tiếp theo và đầu ra bắt buộc

1. Tạo candidate extension registry mới theo bảng trên; ghi TESTR ở trạng thái conditional.
2. Tải từ nguồn chính thức, khóa weights/config/dictionary/license và môi trường riêng của ba candidate mới chính.
3. Chạy forward pass trên các frame train được chọn theo quy tắc cố định trước khi chấm; kiểm tra tọa độ, chuỗi rỗng, grouping, lỗi và receipt.
4. Khóa technical eligibility và analysis contract mở rộng; chỉ sau đó chạy cùng cohort test. Không công bố model mới là ready trước bước 3.

Đợt này chỉ tạo báo cáo nghiên cứu. Chưa cài model, sửa registry/notebook, chạy test inference hoặc cập nhật Miro.

## Ghi nhận công cụ và độ chắc chắn

Đã đối chiếu nguồn chính thức: tài liệu dự án, repository tác giả, paper và model cards. Script docs-seeker `fetch-docs.js` cho docTR trả `Documentation not found on context7.com` (exit 1); đã dùng tài liệu docTR/GitHub chính thức làm fallback. Không sửa skill hoặc cài dependency để né lỗi tra cứu. Các kiến trúc và public artifact có căn cứ nguồn; tính tương thích local, exact artifact hash và hiệu quả CVID của candidate mới vẫn chưa được kiểm chứng.

## Câu hỏi còn mở

- Có Linux/CUDA phù hợp để đủ điều kiện TESTR hay chỉ triển khai năm pipeline chính? Không ảnh hưởng việc khóa ba candidate bổ sung chính.
- Phiên bản binary Tesseract, commit/checksum các weights và cấu hình inference hiệu lực của docTR/PP-OCRv6 sẽ được chốt bằng receipt nào sau technical preflight?
- Có yêu cầu nghiên cứu tốc độ trên cùng phần cứng hay chỉ accuracy cùng cohort? Báo cáo hiện không giả định tốc độ CPU/GPU có thể so trực tiếp.
