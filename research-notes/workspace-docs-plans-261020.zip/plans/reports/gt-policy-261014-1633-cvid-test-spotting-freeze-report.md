# CVID test spotting: released GT policy and frozen cohort

Date: 2026-10-14, Asia/Bangkok. Scope: study-specific end-to-end localization/transcription against released XML. The policy and implementation passed advisory review before generating the freeze. **Freeze complete:** all test PNG/XMLs re-decoded and matched to EDA, full-cohort scorer verification passed, and deterministic replay preserved all frozen bytes. No OCR model inference occurred.

## Policy and scientific basis

**Primary reference is the released XML, unchanged.** Retain original box coordinates, object ordinals and object/name transcriptions, including apparent semantic disagreements, uncertain text, short words, digits, punctuation, literal asterisks and selectively included math/logo/interface labels. No GT imputation, spelling correction, crop-index substitution, splitting or merging. Normalization inherits the existing frozen scorer: Unicode NFKC, casefold, collapsed whitespace, exact normalized equality. Raw labels remain available.

The [dataset paper, Section III and V-B](https://cdn.iiit.ac.in/cdn/cvit.iiit.ac.in/images/ConferencePapers/2018/localizing-recognizing-text.pdf) describes word annotations seeded by TextSpotter and edited in LabelImg, exclusion of equations/symbols, course-based partitions and localization credit at IoU > 0.5. Local EDA establishes the released archive's actual counts, coordinate/crop correspondence and annotation anomalies. The paper does not certify every current XML label, nor our study-specific scorer. Its Section V-D “word spotting” is QBS/QBE retrieval mAP; this study's joint detection/transcription Hmean is a different endpoint.

Test-label noise can change benchmark comparisons, as shown by [Northcutt et al., NeurIPS Datasets and Benchmarks 2021](https://datasets-benchmarks-proceedings.neurips.cc/paper/2021/hash/f2217062e9a397a1dca429e7d70bc6ca-Abstract-round1.html). This motivates transparent raw-reference results and a diagnostic influence analysis, rather than treating model-assisted review as replacement gold. The EDA's 72 examples are a diagnostic course/box-height sample: no population label-error estimate follows from seven apparent disagreements and five uncertain observations.

The [Nosek et al. 2018 preregistration framework](https://doi.org/10.1073/pnas.1708274114) motivates fixing analysis choices before outcomes and distinguishing later exploration. This freeze is a local, outcome-predeclared version after EDA exposure, not external registration, blind preregistration or evidence of complete historical test-use provenance. [ICDAR2015](https://imlab.jp/publication_data/1469/C02.pdf) provides joint-localization/transcription evaluation background; official short-word, punctuation or ignore policies are not silently imported.

## Mechanical KEEP / REPAIR / HOLD rules

Start with all **1,755 native test PNG/XML pairs / 40,103 XML objects** in source ZIP SHA-256 `b5b562580e250ee3336462b7699bc79d0d1149d3b8cc82f1b221a0d0ce4fb489`, release revision `8159222f11460bff70bec7990ade19c468755fe4`.

- **KEEP:** source PNG decodes, paired XML parses, every box satisfies `0 <= xmin < xmax <= PNG width` and `0 <= ymin < ymax <= PNG height`, every normalized transcription is nonblank, and each difficult flag is exactly `0`.
- **REPAIR_METADATA_DERIVED:** same criteria, with decoded PNG dimensions overriding incorrect XML size only in derived evaluation metadata. Preserve XML bytes, text and coordinates. No box scaling, clipping or inclusive-coordinate conversion.
- **HOLD entire frame:** any invalid/out-of-bounds/nonpositive box, normalized blank label, unresolved difficult flag or unreadable/unpaired input. A known bad object is not dropped while keeping predictions on its frame: doing so would introduce an unlabelled region without a validated ignore mask.
- **Integrity stop:** unexpected source hashes, counts, pairing, EDA discrepancies or new read failures abort this version's freeze. They cannot silently reduce the denominator.
- No primary exclusion for scores, model failures, legibility opinions, apparent semantic error, word/category choice, or dHash flags. Failed selected frames remain in the scoring denominator.

| Decision | Frames | Effect |
|---|---:|---|
| KEEP | 1,657 | Selected unchanged |
| REPAIR_METADATA_DERIVED | 97 | Selected; decoded dimensions only |
| HOLD | 1 | Excluded with all 40 objects |
| **Primary selected** | **1,754** | **40,063 released objects; 7 courses / 276 folder groups** |

The sole excluded frame is **`Frames/test/24/25/00_31_56_00006.png`**. Object `#object-0036`, raw label `jle`, has box **[-2, 4, 28, 19]**, outside decoded PNG **1920×1090**. XML size **2×1** is also incorrect. Correcting dimensions alone does not repair its negative coordinate. The other 39 objects are excluded with the frame; no clipping or replacement geometry was invented.

| Course | Selected frames | GT objects | Derived size repairs |
|---|---:|---:|---:|
| 3 | 140 | 1,261 | 1 |
| 7 | 252 | 2,242 | 0 |
| 10 | 224 | 2,976 | 2 |
| 14 | 245 | 4,910 | 0 |
| 18 | 282 | 5,671 | 2 |
| 20 | 368 | 17,097 | 25 |
| 24 | 243 | 5,906 | 67 |
| **Total** | **1,754** | **40,063** | **97** |

## Selective annotation: estimand and prediction handling

Released labels are the primary reference for a **descriptive annotation-agreement endpoint**. The paper excludes equations/symbols; EDA observes inconsistent inclusion of symbolic, logo and interface regions. Exhaustive word coverage is unverified. Therefore:

- Keep every released geometry-valid labelled instance. Do not invent category exclusions from reviewer impressions.
- Apply no inferred ignore regions, GT-driven ROI mask, dictionary, label-based prediction filter or forgiveness for unmatched predictions. Models receive full PNG pixels only; review flags and GT cannot guide inference.
- Each unmatched prediction is FP **relative to the release**, even when it could be correct visible text that the release did not annotate. Report raw prediction records so this behavior remains auditable.
- Recall measures recovery of **annotated instances**. Precision measures agreement with **released annotations**; it is not certified precision over all visible text. A model finding real unannotated text can receive worse released-label precision. Candidate ranking can reflect coverage and word/line granularity as well as OCR quality.
- Detection P/R/F1 diagnoses localization agreement; independent optimal detection and spotting matchings do not provide an additive decomposition of recognition errors or remove annotation bias.

This deliberately restricts the claim rather than pretending annotation omissions have been resolved. An exhaustive OCR endpoint would require separately specified scope, independent missing-region review/adjudication and a new GT version.

## Predeclared observed-flag frame influence analysis

Primary GT and denominator remain unchanged. The supplementary analysis removes entire primary frames containing an `uncertain` or `apparent_disagreement` object from the already completed EDA sample, with exact membership frozen before spotting outcomes:

| Canonical frame ID | EDA sample / object ordinal | Flag | Entire-frame GT removed |
|---|---|---|---:|
| `Frames/test/10/1/00_13_09_00002.png` | sem-004 / 0005 (`e.g`); sem-005 / 0006 (`designed`) | uncertain punctuation / obscured suffix | 15 |
| `Frames/test/18/15/00_01_40_00001.png` | sem-027 / 0010 (`kgp`) | uncertain blurred logo | 11 |
| `Frames/test/7/12/00_42_00_00005.png` | sem-064 / 0002 (`te`) | apparent disagreement | 14 |

Sensitivity denominator: **1,751 frames / 40,023 objects**, removing three frames and 40 objects; only four sampled objects are flagged. Validate and score the full primary set first, then aggregate unchanged per-frame counts on retained frames. Equivalent whole-frame GT/prediction subsetting gives the same result. Never drop only flagged objects or use an object-level ignore rule. Failure records on retained frames still count.

Always report primary and sensitivity together, including both candidate scores/differences and changed denominators. This assesses the influence of these observed frames, including their other content; it is not corrected GT, a bound on annotation noise, a random sample analysis or proof of clean remaining labels. Do not choose whichever endpoint favors a model. New flags after freeze are separately dated exploratory evidence; changing primary labels/membership requires a new version and independent author/human adjudication.

## Scoring, uncertainty and model gate

Primary: pooled micro end-to-end Hmean `2TP/(2TP+FP+FN)`, polygon IoU **> 0.5**, maximum-cardinality one-to-one matching within each frame with exact normalized text for spotting. Detection uses its own maximum-cardinality geometry matching. Preserve the pinned scorer's normalization, invalid-prediction FP, no one-to-many credit, failed/missing-frame FN and malformed/extra/duplicate-record rejection rules. Additional fixed analyses: IoU > 0.75 and case-sensitive normalization, using the same predictions. Report selected/completed/failed counts, error ledger, TP/FP/FN, detection/spotting P/R/F1, every course and folder group, plus unweighted mean course scores alongside the pooled primary.

Primary uncertainty: paired course-cluster bootstrap, **2,000 replicates**, seed **20261014**, Python `random.Random(seed).choice` over lexicographically sorted seven IDs `[10,14,18,20,24,3,7]`; draw seven clusters with replacement per replicate and recompute pooled counts. Statistic: candidate B minus A spotting Hmean. Sort differences; use zero-based indices `floor(.025*N)` and `floor(.975*N)-1`, no interpolation. Secondary: the same procedure over 276 sorted folder groups. Start a fresh RNG for each endpoint/grouping. These settings fix reproducibility; they are not power justification. Seven course proxies and uncertain dependence permit exploratory conditional intervals only. No population or generalized-winner conclusion follows.

An explicit additive test-use binding references the unchanged candidate registry, all test inputs and model/config hashes. Its original validation binding is preserved. Candidate runtime-loading verification remains pending and must pass before inference. This task neither loads models nor evaluates OCR accuracy.

## Artifacts and replay

- [Versioned machine-readable GT policy](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-test-261014-gt-policy.json).
- [All 1,755 source frame decisions, IDs, reasons, image/XML hashes and per-course counts](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-test-261014-cohort.json).
- [All 1,754 selected frame IDs](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-test-261014-selected-frame-ids.txt). Canonical IDs follow existing `Frames/test/...`; each manifest row retains EDA alias `test/...`.
- [Full local GT JSONL: boxes, raw text, ordinals and aliases](../../benchmark/experiments/outputs/iiit-cvid-spotting-test-261014/ground-truth.jsonl).
- [Excluded-frame issues](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-test-261014-annotation-holds.json), [fixed influence membership](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-test-261014-influence.json), [scoring protocol](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-test-261014-protocol.json).
- [Candidate test-use binding](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-test-261014-candidate-binding.json), [freeze receipt](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-test-261014-freeze.json), [verification receipt](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-test-261014-verified.json), [byte-identical replay proof](../../benchmark/experiments/registry/datasets/iiit-cvid-spotting-test-261014-replay-verified.json).

From `benchmark`: `python -m experiments.scripts.freeze_cvid_test_spotting` and `python -m experiments.scripts.verify_cvid_test_freeze`. The first re-decodes all test PNG/XMLs, checks every object against the hash-bound executed EDA and verifies review artifacts. It preflights all output paths/existing bytes before writes, refuses a changed frozen version and writes the receipt last. Receipt-last ordering supports interrupted-write recovery, not a multi-file transaction. Source ZIP, full GT and EDA evidence remain local; there is no publication or commit in this task.

## Execution and verification

Freeze and verification completed. All 1,755 native test PNG/XMLs were re-read against executed EDA; all 40,103 source objects were accounted for. Verification independently compared all 40,063 selected GT rows to the hash-bound EDA ledger, checked eight artifact hashes, 83 preserved/input hashes and 12 implementation-module hashes.

Full-cohort oracle achieved TP=40,063, FP=FN=0, Hmean=1 for both detection and spotting. Influence oracle achieved TP=40,023 with no FP/FN. All-missing records retained 1,754 failed frames and 40,063 FN (influence: 1,751 / 40,023). Successful empty predictions gave the same FN and zero engine failures. Paired identical-oracle bootstrap gave difference zero and interval [0,0] across seven clusters for both endpoints. These are scorer contract checks using synthetic predictions from GT, not model results.

Deterministic builder replay re-decoded source test again, refused any differing output, and preserved byte-identical hashes for all nine checked files (eight freeze artifacts including the predeclared policy, plus freeze receipt). Focused default pytest passed **34/34**, including seven new policy/freeze tests and existing scorer/candidate contracts. An ignored pyreadline3 console destructor OSError appeared after successful exit 0; it did not fail the tests.

Freeze receipt SHA-256: `9504e34f69b16f4b63893184e5decf2e3d88d7251833b0efbb85f2eb883438dd`. Cohort manifest SHA-256: `116ccd271dfc95b3bdd1190e75635eac064b49c076ab030ea6f27cf3ea3d5e18`. GT policy SHA-256: `d1f14217d5e6f3273e5d4ad894af65b822ad04e51df2cfffc631a3e8cf6cb463`. Protocol SHA-256: `884aba8bb19a8e7e20734e2fa2f9dee851e78d96417462947b4b2e8c3bf6aa3a`.

Reviewer identified and then confirmed fixes for two implementation issues before freeze: consumed policy/candidate bytes now bind to captured hashes with pre/post dependency and EDA checks; default temporary-path tests are portable and out-of-root outputs reject before writing. No validation/protocol/candidate source artifact or executed EDA output was modified.

Final independent read-only review rechecked every selected GT row, all freeze/replay/input/module identities and saved verification counts, with no remaining blocker. The 155 local links across the report/plan/current indexes resolved, `git diff --check` passed, and source ZIP/full derived GT remain ignored. Seven dataset EDA entries and the empty on-demand execution queue are preserved; the notebook manifest records the subsequent test freeze separately from historical EDA execution status. No commit or push was performed.

## Limits and unresolved questions

- Native course-held-out released-label comparison is supported; test GT was EDA-exposed, not blind or untouched.
- Semantic correctness and annotation completeness remain uncertified. Human/author adjudication and exhaustive scope review have not occurred.
- No authenticated per-video identity map or universal writer-independent proof; train/val metadata explicitly repeats an instructor. Test has no explicit named overlap, but ambiguous groups remain unresolved.
- dHash visual review closes its declared queue only; transformation screening recall is unknown.
- Historical model test-use completeness and pretraining overlap are unknown. No production winner or broad generalization claim is supported.
- **Next gate:** candidate runtime-loading verification against the frozen test-use binding, followed by common-cohort inference without tuning test thresholds/grouping.
- The generic notebook runner/manifest incompatibility documented in the EDA report remains pre-existing and out of scope. No new evaluation notebook or model run is claimed.
- No unresolved policy question blocks this restricted released-label test freeze.
