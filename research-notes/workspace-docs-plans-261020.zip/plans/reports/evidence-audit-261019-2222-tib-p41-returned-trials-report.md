# P4.1 — kiểm tra actual trial evidence

**7/7 trials,21/21 outputs hoàn tất trên Tesla T4. Integrity/native-lineage/telemetry PASS; generation quality chưa được giải quyết đầy đủ. Chưa có cơ sở khóa một cấu hình thắng hoặc mở selection300.**

Audit dùng stored artifacts và local pinned tokenizer replay, không model/scorer inference mới. Chỉ3 presealed pilot IDs, không phải21unique records hoặc completed pilot40. User request là kiểm tra; không thay configs, registry, cap, dataset hoặc cohort.

## Evidence đã xác minh

- ZIP835.310bytes, SHA256 `db97d6b9093af58572a79c403c06e2d5fcfe24bc59268930958759f5987193ed`.
-308/308 manifest file sizes/SHA và CRC PASS;281/281 JSON envelope hashes PASS;20 exported bundle files khớp nguyên package đã khóa, gồm actual runner/adapter code. File paths/duplicate members đã kiểm.
-7 capacity receipts khớp đúng7 default trial IDs, model/profile/registry/runtime/source hashes và7 logs. Không có trial512, failed call hoặc reused call trong tập này;123 fresh completed nodes.
- Offline replay21 outputs khớp native wrappers/windows/padding/reserves, ordered source intervals, checkpoint keys, attempts, decoded generated IDs, delivery selector/hashes và reduction diagnostics.123 backend telemetry records được recompute từ recorded base config+overrides+generated IDs, khớp EOS/reserve/repetition/ending rules. Không chạy code lạ từ ZIP: exported code đã đối chiếu với package/local code đã review.
- [Returned trial audit](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/development-trials-261019-2122/returned_trial_audit_v1.json), [development output review](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/development-trials-261019-2122/returned_output_review_v1.json). Raw ZIP/extracted artifacts/script/result giữ trong ignored `benchmark/research-data/tib-p41-261019-2122/returned-evidence-20261019T151425Z/`.

Original baseline ZIPs, implementation/package receipts và frozen registry giữ nguyên. Prepared notebook file vẫn không chứa saved cell outputs; actual execution được xác nhận từ returned logs/checkpoints/code.

## Những gì thay đổi trong development

Reserve exhaustion ở đây là chạm max_new_tokens mà terminal token không phải valid EOS.

| Trial | Delivered words644/341/886 | Map exhausted | Reduce exhausted | Repetition flags mọi node | Ending flags mọi node |
|---|---:|---:|---:|---:|---:|
| bart-control |61/44/63 |0/31 |0/5 |0 |0 |
| led-ngram0 |234/211/126 |4/9 |0/2 |9 |10 |
| led-ngram3 |150/67/53 |0/9 |0/2 |0 |3 |
| led-ngram4 |207/103/193 |0/9 |0/2 |0 |8 |
| qwen-r256 |102/113/159 |7/9 |2/2 |0 |9 |
| qwen-r384 |102/160/206 |0/9 |2/2 |0 |2 |
| qwen-concise-r256 |102/124/168 |8/9 |2/2 |0 |9 |

Cả21 final nodes kết thúc EOS dưới reserve768;0 delivered-word cuts bởi cap350;0 possible-forced-EOS-at-reserve candidates trên123 calls. EOS không chứng minh natural completion. Giữ cap350maximum, không ép model sinh đủ350 hoặc giảm cap từ các output này.

### BART — baseline được tái hiện, vấn đề còn nguyên

Cả39 node outputs và3 delivered outputs khớp nguyên baseline trước. Mẫu dài `valid:886` vẫn final=first map, qua exact clone ở `reduce:1:0`, `reduce:2:0`, singleton final. Lineage xử lý toàn nguồn là đúng; chưa có bằng chứng lỗi coverage code. Đây là descriptive semantic-attrition flag; không tự biến thành semantic completeness score.

### LED — hết lặp theo rule, chưa bảo đảm nội dung tốt

Control ngram0 tái hiện nguyên14 nodes/3 delivered outputs baseline. Trial3/4 đều loại các repeated4gram flags và map reserve exhaustion quan sát được. Tuy nhiên rule4gram bị decode no-repeat3/4 chặn một phần theo cấu trúc;0 repetition flags không là independent quality proof.

- Ngram3, mẫu dài: map1 kết thúc “closed traject”; map5 sinh hash/number markers dạng `#1#2#3#4#1 ...`.
- Ngram4, mẫu dài: các map kết thúc “on the boundary of”, “in the asympt”, “asymptotic expansion as”; xuất hiện `[ multiblock footnote omitted ]`, và reducer/final giữ `* abstract *`.
- Những formatting markers cụ thể trên không có trong source-only inputs. Đây là model-generated formatting artifacts, chưa phải một đánh giá factuality đầy đủ.
- Mẫu medium: ngram3 tập trung phần outreach; ngram4 tập trung active listening. Hai cấu hình phân bố nội dung khác nhau dù final đều có punctuation/EOS. Chưa có cơ sở chọn3 hay4 chỉ từ0flags, summary length hoặc tốc độ.

### Qwen —384 giúp map, reducer vẫn bị cắt

- Current256control:9 exhausted intermediate calls (7map+2reduce).
-384: còn2 exhausted calls, cả hai đều reduce384. Tất cả9 map calls kết thúc EOS. Long reducer vẫn kết thúc giữa cụm “dividing the”.
- Concise256:10 exhausted intermediate calls (8map+2reduce), nên **không được evidence này hỗ trợ như một giải pháp giảm truncation**. Long reducer kết thúc “forming a spectral network (”.
- Current256long reducer dừng tại heading `**Spectral Networks`; final thiếu substantive discussion của phần này.384/concise outputs có nhắc quadratic differentials/spectral networks, nhưng quan sát topic này không là full-source semantic coverage score.
- Short644 final giống hệt102words ở cả3Qwen trials, phù hợp direct-final path/prompt/seed không đổi. Qwen baseline ZIP cũ dùng seed mapping khác: so sánh384/concise với **current256control**, không quy khác biệt oldZIP thành hiệu ứng causal của reserve.

Tên lỗi như “Google Thumbnail Code”, “Shikodi and Bafa”, “software conservatory” đã có trong noisy source transcripts. Không tự gọi chúng là hallucinations của model khi chưa đối chiếu source.

## Tài nguyên và giới hạn suy rộng

| Trial | Snapshot/load seconds | Sum record wall seconds | Total receipt seconds | Peak reserved GiB |
|---|---:|---:|---:|---:|
| bart-control |23,14 |57,33 |90,94 |1,078 |
| led-ngram0 |24,81 |78,62 |106,68 |2,166 |
| led-ngram3 |11,13 |52,57 |67,27 |2,164 |
| led-ngram4 |11,26 |66,50 |81,00 |2,164 |
| qwen-r256 |304,87 |276,58 |584,86 |13,230 |
| qwen-r384 |78,85 |335,19 |419,53 |12,881 |
| qwen-concise-r256 |68,62 |287,43 |362,06 |13,229 |

Tổng7 capacity receipts1712,34s≈28,54min, **không** full session time/GPU kernel time hoặc full-study budget. Record wall gồm generation/checkpoint/diagnostic overhead; load riêng gồm download/cache effects.384 total nhỏ hơn256 vì load khác nhau, nhưng sum record wall **lớn hơn**335,19vs276,58s; không gọi384 nhanh hơn.

Actual device memory15.637.086.208bytes≈14,56GiB; host memory13.605.830.656bytes. Float16/eager, CUDA13.0; torch2.11.0+cu130, transformers4.57.6, hub0.36.2, numpy2.1.3, accelerate1.15.0, tokenizers0.22.2, safetensors0.8.0, psutil5.9.5. Runtime identities/asset hashes đã bind; audit không độc lập tải lại model weights.

Qwen384 measured total-minus-reserved≈1,68GiB, vượt guard1GiB đã định cho deferred512. Read-only prerequisite check PASS đúng384 receipt/profile/registry/source IDs. Điều này **không** chứng minh512 sẽ fit, không thay explicit resource review và không tự bật/chạy512. Qwen reserve đổi cả input-window capacity: chỉ diễn giải whole-pipeline configuration trial.

Một record mỗi stratum không hỗ trợ conservative p95/upper-bound projection toàn40/300/523. `measured_profiles.json` projection-ready không được điền bằng pseudo-p95; raw observations được giữ riêng.

## Quyết định sau audit

- PASS scoped execution/integrity/native budgets/telemetry cho7trials trên3sources.
- Không coi P4.1 generation issues đã được giải quyết. Không chọn model/config winner hoặc đổi formal admission từ3samples.
- Có thể tiếp tục công việc scorer formal-runtime và cross-session resume theo plan; CPU scorer-ready cũ không bị mất hiệu lực. Không cần mọi model đạt0automatic flags mới làm nghiên cứu.
- Trước mở rộng pilot40, chốt rõ intermediate acceptance/development trial policy và stage-specific resource budget. Nếu chấp nhận bounded incomplete notes thì giữ flags/failure denominators nhất quán; nếu xem là failure thì predeclare rule/retry trên development, không xử lý riêng theo selection scores.
-512 là trial đã định trước có hardware prerequisites quan sát được; nếu tiếp tục nhánh này cần resource review riêng. Không tự thêm reserve/prompt/model hoặc benchmark khác từ audit.
- Sau fullpilot/scorer/resume/resource evidence mới profile/cap/trial/budget freeze và selection300 hai tầng theo common coverage. Full523→500→400,40diagnostics trong final giữ nguyên; final unsealed.

## Còn mở

Qwen reducer truncation; LED malformed endings/format artifacts/topic retention; BART semantic attrition; formal intermediate acceptance/config admission; formal-runtime scorer/cost; fresh-runtime resume (123calls đều fresh, không phải reuse test); fullpilot40 và conservative quotas/storage/projection. Chưa formal quality metrics/reference scoring, chưa pilot40/selection300/final523 mới.
