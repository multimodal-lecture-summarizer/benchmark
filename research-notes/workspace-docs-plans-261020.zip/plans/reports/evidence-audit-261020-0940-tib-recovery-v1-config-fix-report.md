# Returned recovery audit and v2 correction

Overall **HOLD**. The returned ZIP verifies a different Colab VM and successful scorer checkpoint replay, but generation recovery stopped before its first node. Pilot40 remains gated. No generation, scoring, selection or final benchmark was run locally.

## Actual v1 evidence

Archive `tib-p4-recovery-evidence-20261020T021235Z.zip`: 543,837 bytes, SHA256 `9fe7936ff078e4c556e2155314f8f9b17e1f0a1a93328e5d44ab455cead4fa9c`. CRC, 64 unique members and all 51 package file hashes verified against the original v1 manifest. The origin envelope, 288 generation/21 scorer source hashes, different boot IDs and both stage context bindings verify. Saved executed notebook has seven executed code cells and no cell exceptions; this does not override its HOLD receipt.

- Scorer replay: PASS, 21 reused checkpoints, 105 finite cached values exactly matching original metrics, `new_metric_calls=0`. Original scoring cost remains 161.7003 seconds; new replay wall time 5.6422 seconds. No metric recomputation or fixture/model execution.
- Generation: HOLD, zero replayed records/nodes and `new_generation_calls=0`; original store unchanged. BART loaded on Tesla T4, then `Original loaded configuration differs: resolved_model_config`. Wall49.5641s, CPU28.0060s, sampled RSS2,514,276,352 bytes; peak allocated/reserved VRAM821,321,728/836,763,648 bytes. These are failed-attempt overhead, not complete recovery capacity.
- Original boot `d51e0a61-f44d-4fa3-8f17-2ee6aa60e72e`; recovery boot `9d3bfc45-1fd7-4e67-96b0-d9567a0b7d99`. Freshness proof passes; complete generation survival is still unverified.

Raw receipts, witness, metrics and machine audit are retained under `benchmark/experiments/registry/protocols/tib-p4-fresh-recovery-261020-v1/actual-colab-20261020T021235Z/`; private original ZIP copied under the matching ignored research-data directory. Historical receipts remain unchanged.

## Confirmed implementation defect

Live Transformers `BartConfig.to_dict()` restores `id2label` integer keys; persisted JSON has string keys. A config-only local reproduction confirmed direct inequality and equality after JSON roundtrip. Independently, both newly exported BART model and generation configs equal their historical persisted counterparts. The failure is in the new validator, not evidence of a changed model configuration.

V2 compares the complete loaded and saved configurations in persisted JSON form, rejecting nonfinite values. Every field remains checked. Genuine nested config changes still HOLD. Original bundles, runtime hashes, cache keys, metrics, cohorts, cap350 and acceptance policy remain untouched. Across the 51-file recovery package, only `tools/tib_p4_generation_recovery.py` changed.

## Verification and retry

51 recovery tests PASS, including full injected seven-profile/21-output/123-node replay with integer-versus-string keys and genuine model/generation config mismatch rejection. Local default temporary directory initially caused Windows atomic-rename access failures; rerun using a new workspace-local temporary directory passed. Tests use injected dependencies; they cannot certify actual Colab PASS.

V2 ZIP: `benchmark/research-data/tib-p4-fresh-recovery-261020-v2/tib-p4-fresh-recovery-261020-v2.zip`, SHA256 `36d08b03c1a4ccefe63556024239d117494e2af02e7827b920921adcaee4f03a`, 490,971 bytes. Its versioned amendment and preparation receipt remain HOLD.

1. Run `tib-p4-handoff-colab-261020-v2.ipynb` in the current VM with the v2 ZIP. This seals the unchanged source stores against the corrected package in a separate `TIB_P4_RECOVERY_261020_V2` folder.
2. Disconnect and delete runtime, connect a new T4 VM, then run `tib-p4-fresh-recovery-colab-261020-v2.ipynb` with that same ZIP. Do not rerun handoff in the new VM.
3. Return the new evidence ZIP. No cache miss may trigger generation or scoring. V2 must independently prove 123 nodes/21 outputs plus 21 scorer checkpoint reuses with zero new calls before P4c closes.

## Open

Actual corrected generation recovery and combined PASS; pilot resource gates and pilot40; admission, storage/quota and conservative study budget before selection300. Final target523 with predefined500→400 fallback unchanged.
