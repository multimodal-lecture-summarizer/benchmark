# Executed representative retry Colab audit

Saved receipt2026-10-18T05:26:03Z =12:26:03 UTC+7.20code cells executed1–20, no saved exception. Read-only audit; notebook outputs retained.

## Source recovery

All12selected representative sources recovered in135.49s (~2min15s), spanning9failed source groups.12actualnewattempts/processes,12returncode0, no stopreason. Everyresult reconciles downloadedcheckpoint,status,SHA/bytes,positiveffprobe duration andlatestattempt. Allnewstates retainolderattempts andclear currentlast_error. Successfulsources:e4M0xyYtL-s,dC93OcrNX6c,gsDGPyBzrQM,ejGQ2YGT2-8,cqoOAz8i6nI,fBYu8I52nVM,fiWf6gpuXek,hOT3-eQ78ug,eghZJJg0gP0,FFyGM625F4c,cqcTD1HBOfY,crA3cOwKXmc. FFyGM625F4c hadhistorical403;cqcTD1HBOfY historicalresource stop. Authentication remainedpublic-no-cookies perreceipt. This proves recovery ofthese12inthisrun; doesnotestablishwhybotblocksdisappeared orpredictremaining119.

Media202→214downloaded,131→119historicalfailed. Exactly12sourcesattempted;321notattempted(reused214minus12cached202+outside119). Outside119records skippedoutside_representative_sample,notnewfailures.12downloadedfiles sum432,484,861bytes. Existingbudgetnotexhausted:media~4.01GiB of8,analysis/log~0.386GiB of1.

## Preview and complete inventory

1172decodedframes across399unique marks and170videos,all10sourcegroups. Currentpass reused941validatedcachedframes anddecoded231newframes from232startedprocesses.941cachehits exceeds675frames ofpreviousauditednotebook,indicating266additionalcachedframes existedbeforethislatestpass; intermediatecreationhistorynotindependentlyauditedhere. All675previouslyauditedrequestkeys/framehashes arepreservedandmarkedcachehits.

Ledger1905totalrequests=1172decoded+703preview_time_budgetnotattempted+29outside_video+1preview_timeout. TimeoutQhvpsBma4ac mark0 at14.7048s elapsed2.65s; no automaticsemanticclaim. Generic diagnosticqueue635marks,notall9021.12recoveredvideos contribute72decodedframesin10ofthem;37requestsremainpendingand2outside_video. Recoveredfilesneednotallhavepreviewyet.

Full333videos/9021uniquemarks retained,excluded0,numericparseerrors0. Reportedduration6033marks,6023within,10at/afterend,2988unknown.399/9021=4.42%marks haveanyframe;8622have none.0annotationrepairs/semanticcertifications. Visualsemanticreviewnotperformedinthisaudit.

Formatdiagnostics39commandscompleted,294notattemptedaftertimebudget. Formatcommand success remainsseparatefromdownloadrecovery.

## Next action and limits

No codechange neededto repeatcurrentboundedrepresentative-retry/previewworkflow. KeepDrive/RUN_NAME; nextpoolisremaining119historicalfailedsources andpreviouslyrecovered12areverifiedcache,notretried. Saveoutputsfornextaudit. No guaranteeall119recover;sourceaccessconditionsmayvary. Completeinventory isnotcompletevisual/semanticqualification. Allchecksuse savednotebookledgers/states/receiptevidence,withoutindependentDrivebinaryrehash.

Unresolved:119source availability,703pendingframe requests,8622markswithoutimages,remainingsemantic/timebase/rightschecks.
