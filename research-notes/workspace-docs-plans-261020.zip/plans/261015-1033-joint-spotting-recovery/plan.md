# Official TESTR recovery and joint spotting qualification

Date: 2026-10-15. Scope authorized: recover official TESTR checkpoint and verify Colab T4 feasibility; if unavailable choose a scientifically justified joint spotter and update notebook.

## Acceptance and decision rule

1. Inspect author-released TESTR links, distinguishing checkpoint bytes from authentication HTML. Never accept HTTP200 alone as weight acquisition or bypass login/access restrictions.
2. Prefer the selected R50 TotalText polygon model if public authentic bytes and reproducible runtime are available. Otherwise record source/access/toolkit blockers; do not claim the architecture cannot run on T4 in principle.
3. Substitute PGNet English TotalText native polygon spotting only if official artifact can be acquired and locked. Its shared backbone/joint prediction addresses the joint-spotting role; it is not a Transformer architecture substitute. DeepSolo shares legacy custom-op dependencies and is lower priority for a practical T4 replacement.
4. Attempt actual Colab T4 qualification on fixed train images with isolated runtime. No test inference or metric-based selection. Preserve both failures and final passed receipt; actual GPU forward pass is required for a verified status.
5. New registry/notebook/bundle version preserves original five candidate configs and cohort/scorer. TESTR remains in exclusion provenance; no silent modification of previous prepared artifacts or checkpoints.
6. Deliver source/access audit, replacement weights/config/dictionary hashes, runnable updated notebook and live qualification evidence if available. Explicitly distinguish artifact-locked, package-load verified and T4 train-forward verified.

## Implementation boundaries

- Add separate PGNet adapter and versioned registry; extend shared CLI registry selection without changing old defaults.
- Build v2 notebook/bundle using explicit parameters; original v1 notebook/bundle/receipt retained.
- Add a train-only qualification helper and package; use existing isolated environment/worker/preflight contracts.
- Test configuration inheritance, dictionary identity, native output/failure schema, required-candidate admission and legacy regression behavior. Verify portable bundle and saved notebook evidence.
- Reports only under root plans/reports; ignored weights/source/audits under benchmark/research-data. No commit/push/Miro, no fine-tuning, no broad benchmark run.

## Review

User-authorized cleanup: consolidate verified driver-fix bytes into the two canonical current ZIP filenames; bind both current notebooks to those hashes. Remove four reviewed bootstrap-fix/driver-fix intermediate ZIPs only after member/hash validation and canonical readback; retain the v1 bundle still referenced by the historical notebook. Keep all evidence and record deleted/replaced identities in docs. Integrate upload recovery and failed-log preservation into preflight notebook; no external patch cell required and no model execution.

Presentation follow-up: extend only the user-run preflight notebook and manual guide. Show hardware/package checks, nine input previews, live log, receipt gates, per-frame region counts, full native transcription tables and polygon overlays; export displays with raw receipts even on failure. Keep package SHA, model/config, nine train inputs and worker unchanged. Review against existing receipt schema; locally check notebook JSON and Python syntax without executing cells or model code.

Latest user scope: local preparation and feasibility checks only; user executes all further code. Colab background installation was cancelled before model forward, with no task child processes remaining. No project code or CVID images were uploaded. A clean unexecuted train-only preflight notebook and manual run guide are delivered; actual T4 model inference remains unverified.

Reviewed against existing modules before implementation: default registry and five-primary workflow must remain backward compatible; replacement becomes a sixth required candidate in v2, never optional after observing accuracy. Actual Colab runtime is available to attempt qualification, but GPU allocation and dependency resolution can still fail.
