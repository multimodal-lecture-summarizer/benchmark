---
title: Representative failed-source download retries
status: completed
priority: P1
effort: medium
branch: untracked-notebook
tags: [colab, eda, retry]
created: 2026-10-18
---

# Representative retry implementation

User authorizes editing standalone Colab notebook to try a small representative subset of131 historical failures and show real results inline. Scope public-no-cookies acquisition only; no new credentials/auth mechanism, fixed IDs, semantic timestamp edits, media deletion, commit/push or remote execution here.

Scout: Python/pandas/NumPy/Jupyter/FFmpeg/yt-dlp standalone notebook33cells; cell22 acquisition helpers+cache;23 download/resume;25 format diagnostics;27 preview resume;29 full333/9021 coverage;31 receipt. Existing all333 selection and media identityv3 preserved. Latest received source is clean/no outputs; audit receipts/ledgers from prior user run remain separate evidence. Existing source resume has202 cached +131 failed, last errors botconfirmation; retry policy skips them.

Acceptance: RUN_REPRESENTATIVE_RETRY=True selects at most12 pre-existing failed records from selected IDs; group first coverage plus historical403/budget diversity when capacity permits, deterministic least-attempted ordering; display whole failure pool and reason for each selection. Default total retry10min, percommand120s plus existing30min acquisition/perfolder/storage limits; gap3s. Other failed records retained unattempted in sample-only mode; downloadsdisabled/globalretrydisabled honored; empty pool safe. Samples processed before existing cache checks; full333 media_audit restored originalselected order afterward. Disabling sample mode restores old automatic/manual retry behavior. Existing downloaded caches verified and never retried.

Reuse current download loop instead of a second downloader. Explicit sample IDs bypass failed bot eligibility guard but no cap bypass. Preserve full stateattempt history and numbered logfiles. Successful subprocess still requires unique completed file, ffprobe andSHA256. Failed,budget,timeout,disabled/unselected get truthful rows; no success inferred from format discovery. Inline sample config/pool/selection/new attempts/outcomes/status summary and complete logs. Export CSVs + bind config/selected IDs/outcomes in final receipt. Recovery feeds existingpreview/coverage. Stablepreview/media identities unchanged.

- [x] Scout and requirements; plan written.
- [x] Independent plan review; no blockers, sample deadline/cache/history safeguards confirmed.
- [x] Implement selection helpers/config/download loop/reporting+receipt; save priornotebook.
- [x] Tests:actual saved131 failurepool deterministic<=12/diversity; sample-only orchestration/cache/history/disabled/budgets/realprobehash; no real YouTube request locally. Existing8resume tests,stagebudgets,full333/9021 receipt regression andschema.
- [x] Independent code review; updateguide/report, artifacts andplan sync.

Unresolved: real Colab source availability remains to be observed; a representative sample does not certify all131 failures.

Finalize:5focusedtests,8previewresumeFFmpegtests,stagebudgetand333/9021receiptregressions passed; independentreview passed;workflowartifactfinalizePASS. Guide/journal synced. ActualYouTubetrial awaitsColaboutputs.
