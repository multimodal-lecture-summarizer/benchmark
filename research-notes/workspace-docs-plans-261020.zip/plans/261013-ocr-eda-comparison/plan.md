# OCR EDA and comparison preparation

Scope: IIIT-CVID released validation word crops; preserve original labels and historical outputs. Produce executed additional EDA and a standalone Colab notebook for sequential CPU EasyOCR 1.7.2 versus PaddleOCR 2.8.1 recognition. Frame detection and model selection for the application are out of scope.

Acceptance: pinned ZIP hash and extraction verification; same 15,379 crop IDs; resumable predictions with identity checks; failures retained; CER, exact word accuracy, per-course/video diagnostics, video-cluster bootstrap, paired error galleries and flagged-label sensitivity. No claim of an unseen test set or reliable historical timing comparison.

Touchpoints: existing OCR runner and summary modules are reused, new notebook builder/runtime helpers and focused tests; existing executed EDA notebook gains analyses while preserving its saved outputs. No RQ2 changes.

Steps:
1. Review this plan and inspect source contracts.
2. Extend EDA with verified historical paired predictions and execute added analyses.
3. Build portable Colab comparison notebook with acquisition, isolated environment, model receipts and persistent outputs.
4. Validate notebooks, run focused tests and review the implementation. Report actual execution limits.

Status: completed preparation. Reviewed before implementation and after fixes. Extended EDA executed with real historical predictions (17 executed code cells, 16 PNG, zero errors); comparison notebook built with embedded sources and verified analysis cells; 10 focused tests passed. Fresh Colab installation/model acquisition/full inference is pending the user's run, not claimed complete. Report: `docs/ocr-eda-comparison-261013.md`.
