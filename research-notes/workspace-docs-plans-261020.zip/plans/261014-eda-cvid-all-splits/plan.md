# CVID all-split EDA

Status: complete. Authorized scope: complete and execute EDA for train/val/test before test cohort freeze. No OCR inference or source-GT edits. [Completion report](../reports/dataset-eda-261014-1526-cvid-all-splits-report.md).

## Acceptance

- Fresh-kernel executed all-split notebook with no errors; visible accounting, distributions, stratification, anomalies, source and duplicate review, galleries and conclusions.
- All 5,475 frames and 137,745 XML objects accounted for; all 137,745 crops decoded and linked to source pixels/labels or explicit unmatched/ambiguous ledgers.
- Preserve XML transcriptions; measure crop-index slash rewriting explicitly.
- Review all 469 cross-split perceptual candidates with persisted evidence and honest uncertainty; no dHash-only exclusions.
- Explicit semantic-GT sample protocol, adjudication evidence, residual quality/provenance limits and test-readiness gate.
- Hash-bound exports, notebook/runtime receipts, synchronized manifest/docs; existing validation protocol/cohort unchanged.

## Phases

1. [complete] Full source/crop feature and correspondence scan; all 469 candidate pairs and 72 predeclared semantic samples reviewed.
2. [complete] Fresh-kernel notebook executed: 16/16 code cells, zero saved errors, 11 PNG + 75 JPEG; standalone HTML and full ledgers exported.
3. [complete] Independent scientific/code/artifact review passed, hash/identity tamper probes passed; docs/manifest synchronized. Test-GT policy and stronger source/gold claims remain explicit limits, not uncompleted EDA computation.

## Files and ownership

Root: new `benchmark/experiments/scripts/cvid_eda_*.py`, notebook `benchmark/experiments/notebooks/diagnostics/iiit-cvid-all-splits-eda.ipynb`, local `benchmark/experiments/outputs/cvid-all-split-eda-261014/`, registry receipt and documentation.

Source-provenance adviser: read-only source/history inspection, optional dedicated root plans/reports report. Visual reviewer: will own only a separate candidate-pair adjudication ledger after contact sheets exist. Final reviewer: advisory code/artifact review only. Preserve all unrelated dirty work.

## Validation

Execute the actual notebook through nbclient from a fresh Python kernel. Verify source hash, complete row accounting, one-to-one/multiplicity correspondence, output errors/plots, all artifact hashes and local links. Focused tests only for nontrivial new matching/review contract logic. No scientific test qualification based solely on technical assertions.

Final verification: fresh-kernel execution and independent artifact review passed; generic notebook on-demand check has one pre-existing manifest-schema failure and one pass. HEAD/current top-level keys and validator failures match; no generic runner code or test was modified. See the completion report for scope and evidence.

## Remaining uncertainties

Human annotation semantic quality, transformed source reuse, per-video source linkage, previous model test use and unknown pretrained-model overlap. Record unsupported conclusions as unresolved, not repaired or approved by inference.
