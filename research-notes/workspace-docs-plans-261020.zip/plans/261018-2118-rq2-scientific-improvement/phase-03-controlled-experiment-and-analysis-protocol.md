---
phase: 3
title: "Controlled experiment and analysis protocol"
status: pending
priority: P1
dependencies: [2]
effort: "10-14h; giả định CPU control khả thi, chưa thực hiện"
---

# Phase 3: Controlled experiment and analysis protocol

## Overview

Thiết kế nghiên cứu **mới**, ba nhánh cùng prompt/model, tách thêm nhiễu chunk count và khóa estimand trước điểm evaluation mới. **Pending.** Owner: experiment designer; blocker: P2 target/frame/qualification. Missing old Drive receipts không ngăn thiết kế này; new study phải có provenance riêng.

## Requirements và deliverables

- Một model Qwen2.5-1.5B-Instruct pinned revision, FP16, greedy; không fine-tune, model sweep hoặc factorial đắt tiền làm core design.
- Đầu ra tương lai P3 sở hữu: `reports/controlled-study-design.md`, `reports/count-control-feasibility.md`, `reports/statistical-analysis-plan.md`; protocol/candidate schema/helper/tests **mới**, chỉ tạo khi được phép triển khai.
- Prompt, chunking, budgets, metrics, sample size và analysis rules freeze trước evaluation; development sửa thiết kế thì tạo version mới.

## Architecture và ba nhánh đề xuất

`source-only adapter → A/B/C partitions + coverage receipts → common serialized chat prompts → shared map/reduce generator → arm summaries + cost receipts → reference/source scorers → C−B/C−A item deltas → whole-group intervals + failure accounting`.

| Nhánh | Can thiệp | Những gì chung |
|---|---|---|
| A | Fixed contiguous chunks ≤512 content tokens, original-style baseline | Full identical source, model, prompt, greedy, final cap |
| B | Lexical-agnostic gần đều token; `n_B = n_C` chính xác từng item | Như A, không abstract/chapter GT trong partitioning |
| C | Source-only lexical novelty boundaries rồi token-limited chunks | Cùng map/reduce phẳng; không learned/hierarchy synthesis |

Primary **C−B** kiểm source lexical partitioning so với count-matched uniform control. Secondary **C−A** kiểm recipe đầy đủ mới. Count control loại nhiễu số map chunks; vẫn còn length distribution/content/compression và actual output use, nên không gọi pure semantic placement effect.

Common allocated map budget từng item `M = 96 × max(n_A,n_B,n_C)`; phân phối `divmod(M,n_arm)` với remainder gán chunks đầu theo source order, tổng đúng M. Final cap384. Per-chunk A có thể >96 khi A ít chunks; kiểm reduce-context và mọi dispatch sau chat serialization, không âm thầm truncate input/budget.

## Count-control contract — CPU gate trước GPU

1. Chỉ lấy `n_C` từ C partitions của source, không từ summary/model output/abstract hoặc evaluation metrics.
2. B chia **cùng normalized word sequence** thành đúng `n_C` contiguous nonempty chunks, giữ thứ tự/mỗi word đúng một lần, mỗi chunk tokenizer-count≤512. Word sequence/hash là source identity; token counts được tính đúng tokenizer trên từng realized chunk, không giả định token counts cộng được qua word boundaries.
3. Đề xuất objective deterministic: tối thiểu `Σ(length_i − L_source/n_C)²`, với `L_source` là token count của toàn normalized source, cố định trước tìm cuts; tie bằng lexicographically smallest tuple word-cut indices. Vì token counts không cộng được, không đồng nhất tổng realized chunk lengths với `L_source`. Freeze objective/tie, solver và CPU budget trước eval; không dùng C boundary locations ngoài số lượng. Không cam kết global optimizer đủ nhanh: đo development và kiểm toàn frame trước freeze; nếu cần bounded candidate grid thì phải là design amendment lexical-agnostic định trước, kiểm lại feasibility, không fallback sau score.
4. Kiểm exact feasibility bằng constrained search/optimization; C partition chứng minh có ít nhất một feasible count nhưng không được dùng semantic C cuts làm B fallback. Nếu implementation không tìm/xác minh được solution exact trong CPU budget → **HOLD design**, sửa trước freeze; không drop item/approximate count/fallback âm thầm.
5. Báo manipulation strength toàn frame/selection: n=1, tỷ lệ B/C partitions trùng, boundary displacement, chunk-length distributions, CPU cost. Identical partitions vẫn ở primary denominator; informative-subset sensitivity nếu có phải định nghĩa trước generation, không chọn theo outcome.

## Prompt contract và development gate

- [Backend cũ:53](../../benchmark/experiments/scripts/rq2_local_hf_backend.py) tokenize raw prompt; [Qwen quickstart](https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct) dùng chat template. Đó là lý do kiểm formatting, chưa là bằng chứng nguyên nhân điểm cũ.
- Development **6 train IDs mới, 2/stratum** từ P2: kiểm raw-vs-chat nhỏ trên nhánh A, cùng instruction body/source/budget, chỉ khác wrapper; tối đa 12 final summaries cho phép so sánh này, hạch toán riêng. Không chọn prompt theo evaluation points. Freeze rule chọn chat mặc định khi serialization/instruction compliance hợp lệ; sự cố phải ghi và sửa trước freeze, không tuning liên tục theo ROUGE.
- Instruction chung dự kiến: source-only, faithful compression, giữ ngôn ngữ nguồn; quyết định language preservation phải kiểm trên dev cùng source/reference alignment. Language detector chỉ heuristic, không truth label.
- Count tokens và generation phải dùng đúng **cùng serialized chat token IDs**, generation prompt và special-token policy; tránh đếm raw rồi generate chat hoặc double special tokens. Lưu prompt/template/tokenizer revisions, rendered hash, content/prompt/padding/output tokens riêng.
- Mọi nhánh mới dùng một prompt; không tái dùng old raw outputs làm A và không gộp S1/S3 cũ với study mới. New 6×3=18 profile summaries P4 là phần chat profile; raw/chat diagnostic có chi phí bổ sung riêng.

## Statistical analysis plan đề xuất

- Primary endpoint: Unicode-word ROUGE-L F1 **creator-abstract agreement**. BERTScore reference similarity và source SBERTScore là secondary riêng; không chọn metric để công bố winner.
- Primary estimand: record-weighted mean C−B trên successful paired intersection, **không đòi A thành công**; secondary C−A trên intersection tương ứng. Luôn báo tất cả N selected, arm/scorer failures, stratum counts và triple-complete sensitivity riêng; missing≠0. Không dùng intersection cả ba nhánh thay denominator primary âm thầm.
- Whole-component paired bootstrap5.000, seed20261009, giữ mọi arms của item cùng nhau; record weighting, percentile95%; repeat author-group sensitivity. New groups do P2 xác định, không sao chép giả định old120 độc lập.
- Chỉ finite-cohort exploratory intervals; zero-crossing không chứng minh equivalence. Secondary/subgroup/length correlations exploratory, không pooled cross-study means và không diễn giải confirmatory multiple testing.
- Practical minimum delta và precision target phải có lý do development/domain, preregister trước điểm mới; **chưa chốt số**. Old C−A paired diffs chỉ giúp sensitivity planning C−A; C−B variance chưa biết. Không guarantee power, không chọn N từ điểm mới.
- Proposed N60 (20/stratum); N120 chỉ nếu precision/resource scenario trước eval hỗ trợ. Nếu N60 không fit resource target → HOLD/redesign trước freeze. Không optional stopping/resizing sau điểm.
- Một greedy repetition, cố định seed/config; không nhiều seeds mang tính hình thức. Counterbalance sáu permutations ABC/ACB/BAC/BCA/CAB/CBA theo deterministic rank, cân bằng toàn cohort và chênh≤1/stratum.
- Mỗi selected ID giữ denominator; no replacement, no unlogged retries. Interrupted in-flight attempt có unknown usage; retry riêng chỉ sau quyết định logged, không xóa lỗi hay đổi cohort.

## Context và token gate trước freeze

Cap512 áp dụng cho source content count, không phải toàn serialized prompt. Kiểm actual map prompt + allocated output cap và conservative worst-case reduce envelope (mọi map caps, separators, instruction/chat tokens, final384) theo context model pinned. Không dùng số token tối đa của old120 làm giới hạn ngầm cho long tail mới. Bind bounds/serialization policy vào protocol; kiểm lại realized reduce token IDs trước từng dispatch. Unexpected overflow → fail arm, giữ summary trung gian/usage/ID, không truncate hoặc tự đổi pipeline. Context feasibility, host RAM và storage phải đủ trước chọn/freeze IDs; technical exclusions pre-selection có ledger P2, không loại dựa outcome.

## Related Code Files và ownership tương lai

- Read-only: `run_source_pair` [pair:160](../../benchmark/experiments/scripts/rq2_tib_benchmark_pair.py), `_summarize` [pair:68](../../benchmark/experiments/scripts/rq2_tib_benchmark_pair.py), `_hierarchy_chunks` [validation:184](../../benchmark/experiments/scripts/rq2_controlled_validation.py), `grouped_interval` [analysis:17](../../benchmark/experiments/scripts/rq2_tib_frozen_analysis.py).
- Proposed `[NOT CREATED]`: `benchmark/experiments/scripts/rq2_count_control_v1_partitions.py`, `rq2_count_control_v1_design.py`, `benchmark/tests/test_rq2_count_control_v1_design.py`, `benchmark/experiments/registry/datasets/tib-rq2-count-control-v1-protocol.json`. P3 duy nhất sở hữu; P4 chỉ tiêu thụ contract. Đường dẫn import cụ thể phải kiểm convention khi triển khai; không sửa frozen modules.
- Không thêm fields/state vào shared backend cũ. Nếu new runtime cần state, cấu trúc mới scoped theo run/item; kiểm instantiation/callers/lifetime trước implementation. Hiện chưa có new symbols/callers để migrate.

## Implementation Steps và test matrix tương lai

1. Review P2 frame/claims; viết control/serialization/statistical contracts trước code.
2. Khi được phép, implement versioned CPU partitions và test trước GPU; không thay legacy generation.
3. Unit: word coverage/order, Unicode/pathological words, exact n/cap, objective/tie, n1/identical arms, budget remainder, chat-token parity/context limits và malformed input failures.
4. Integration: source-only leakage barrier, three-arm counterbalance, missing/scorer failure joins, group bootstrap synthetic fixtures, immutable source/reference identity.
5. End-to-end trên fixtures: receipt→resume→analysis, interrupted dispatch/unknown duration, no silent retry, same identity reuse only; các fixture không là benchmark outcome.
6. Chuẩn bị protocol draft và dev checks; P4 đo tài nguyên, quay lại P3 freeze identity cuối trước evaluation. Không xem điểm mới để điều chỉnh.

## Success Criteria

- [ ] Count control exact trên mọi selected item; fail gate cho infeasible/không xác minh được, không drop.
- [ ] Manipulation-strength/identical partitions được báo pre-generation, không loại post-score.
- [ ] Một prompt serialization/model profile chung; allocated/actual/padding đo riêng.
- [ ] Primary C−B, secondary C−A, sample/metrics/missingness/bootstrap frozen trước điểm mới.
- [ ] Test matrix đạt trong triển khai tương lai; raw legacy results không trộn study mới.

## Risk, compatibility và rollback

| Failure mode | Khả năng × tác động | Mitigation |
|---|---|---|
| Uniform optimizer tốn CPU/không exact | Vừa × cao | Full feasibility gate trước GPU; HOLD redesign, không fallback |
| Đếm raw token nhưng generate chat | Vừa × cao | Serialized-token parity và dispatch/context tests |
| Tuning/evaluation contamination | Vừa × cao | Train-only dev, pre-score freeze, new identity khi thay contract |
| Count match bị diễn giải causal quá mức | Cao × cao | Báo residual length/content/compression, narrow comparison |

Rollback: ngừng new design version, giữ audit/failures; không patch frozen old helpers. Chưa chốt: practical delta/precision, cuối cùng60/120, exact optimization cost và prompt suitability trên dev. Optional mạnh-model/full-context/multimodal/hierarchy thật để route sau, không core factorial.

