---
phase: 1
title: "Evidence audit and error analysis"
status: pending
priority: P1
dependencies: []
effort: "4-6h; giả định có đủ evidence local, chưa thực hiện"
---

# Phase 1: Evidence audit and error analysis

## Overview

Audit bằng chứng hiện có, giữ kết luận `no_selection`; tìm failure modes từ output cũ trước khi thiết kế nghiên cứu mới. **Mọi bước/checklist dưới đây pending; không generation mới.** Owner: evidence reviewer; blocker: không có cho audit local, receipt Drive cần được cung cấp/cho phép riêng.

## Requirements

- Tách mức chứng cứ: code/protocol identity; saved notebook outputs; receipts/dispatch ledger đã audit độc lập; không coi ba mức tương đương.
- Giữ nguyên predictions, source, abstracts, notebooks và protocol cũ; không rerun để tìm kết quả thuận lợi.
- Deliverables tương lai trong `reports/`: `evidence-audit.md`, `artifact-identity-ledger.csv`, `prior-output-diagnostic-ledger.csv`, `error-analysis.md` (P1 sở hữu, phase sau chỉ đọc).

## Architecture và bằng chứng hiện tại

Dòng audit: `notebook bytes + saved cells + protocol hashes + report → identity/coverage matrix → deterministic diagnostic sample → coded observations → giới hạn claim và giả thuyết cần kiểm`. Reference dùng trong audit tách khỏi generator tương lai.

1. [Results:5](../../benchmark/docs/results/rq2-tib-120-results-261013.md): 240 summaries hoàn chỉnh; semantic v2 cho 120 cặp cả ba metrics; notebooks gốc/rescore lần lượt 10/10 và 6/6 code cells theo review trước, sẽ kiểm lại bằng saved outputs.
2. [Results:21](../../benchmark/docs/results/rq2-tib-120-results-261013.md): means S3−S1 ROUGE-L +0,003269; BERTScore +0,002108; source SBERTScore +0,003572; mọi grouped interval đi qua 0. Chỉ exploratory finite-cohort evidence.
3. [Results:52](../../benchmark/docs/results/rq2-tib-120-results-261013.md): receipt/ledger Drive gốc chưa được audit độc lập local. Không lấy nội dung notebook báo “verified” thay cho kiểm artifact gốc.
4. Hash rescore local được review trước: `9d8cb366ec6c1810c7f92b7cb1b13c1ce18cedb3567ce5c0c3f34e6987cb879d`; report ghi `ce6c3cc09255e67dd79843122193d5bc3091e7b03d5e59e9fdabcb45edb758a4`. Đây là discrepancy cần tái xác minh, không kết luận giả mạo hay chỉ đổi line endings.

## Related Code Files — chỉ đọc

- [Results report](../../benchmark/docs/results/rq2-tib-120-results-261013.md), [rescore amendment](../../benchmark/docs/results/rq2-tib-semantic-rescore-v2.md), [freeze report](../../benchmark/plans/reports/tib-120-cohort-and-protocol-freeze-261012-report.md).
- [Generation notebook](../../benchmark/experiments/notebooks/rq2-tib-120-evaluation-colab.ipynb), [rescore notebook](../../benchmark/experiments/notebooks/rq2-tib-120-semantic-rescore-colab.ipynb).
- Source trace: `run_source_pair` [pair:160](../../benchmark/experiments/scripts/rq2_tib_benchmark_pair.py) lấy source → S1/S3 chunks → coverage check → common map budget [pair:191](../../benchmark/experiments/scripts/rq2_tib_benchmark_pair.py) → `_summarize` [pair:68](../../benchmark/experiments/scripts/rq2_tib_benchmark_pair.py), map outputs nối phẳng → cùng reduce prompt [pair:111](../../benchmark/experiments/scripts/rq2_tib_benchmark_pair.py).
- `predict_source_boundaries` [validation:201](../../benchmark/experiments/scripts/rq2_controlled_validation.py): novelty `1−Jaccard`, tối đa 5 boundaries, khoảng cách thời gian; `_hierarchy_chunks` [validation:184](../../benchmark/experiments/scripts/rq2_controlled_validation.py) nhóm rồi flatten token-limited chunks. Tên helper không chứng minh hierarchy synthesis.
- `LocalHfUsageBackend.generate` [backend:53](../../benchmark/experiments/scripts/rq2_local_hf_backend.py) và `generate_batch` [backend:84](../../benchmark/experiments/scripts/rq2_local_hf_backend.py) tokenize raw prompt, không chat template. Không sửa module frozen.

## Implementation Steps

1. Inventory local artifact IDs, bytes, SHA-256, saved outputs/cells/errors, thời điểm và provenance; ghi missing paths/null, không fetch Drive trong phạm vi kế hoạch.
2. So raw code hashes với protocol và transcript/reference/prediction text giữa notebooks; đối chiếu metric table, denominators, failure states và timing scope. Identity mismatch phải ghi nguyên trạng.
3. Với hash lệch: giữ hai identity, so byte/cell source/output/metadata khi có artifact tương ứng; phân loại `explained`, `unexplained` hoặc `original unavailable`. Không overwrite notebook/report chỉ để hash khớp.
4. Audit chi phí: generation và semantic-only rescore tách riêng; actual allocation/token/padding/failed unknown không đồng nhất. Đánh dấu thông tin chưa có.
5. Freeze diagnostic sample **30 item cũ**, 10/stratum: 5 theo SHA-256 `rq2-old-output-audit-v1|ID` độc lập score; 5 có `abs(ROUGE-L Cũ S3−S1)` lớn nhất trong phần còn lại, tie theo ID tăng dần. Không trùng item. Nhóm extreme là purposive, không ước lượng tỷ lệ lỗi population.
6. Tạo phiếu source/abstract/output: transcript grounding, topic coverage, repetition, language mismatch, unsupported detail, contradiction apparent, output truncation/endcap, map-to-reduce loss. Giữ trích đoạn source supporting/counterevidence và mức uncertain.
7. Ẩn nhãn arm/metric khi khả thi, shuffle bằng seed đã ghi; độ dài/style có thể làm lộ arm nên ghi giới hạn blinding. Một reviewer + review lại ca ambiguous là mức diagnostic tối thiểu, không tạo gold labels hoặc human quality endpoint mới.
8. Heuristic chỉ gợi ý kiểm tra: language detector/overlap/repetition/endcap không là ground truth; không dùng metric thấp làm bằng chứng hallucination. Ghi cả lỗi reference và source alignment.
9. Tổng hợp error taxonomy và các giả thuyết: prompt formatting, information compression, boundary/count, reference suitability; ghi rõ giả thuyết chưa được kiểm nhân quả. Raw prompt không được mặc định là nguyên nhân điểm thấp.
10. Bàn giao P2 identity ledger, 30 ID, codebook, observations và unresolved evidence; giữ old study `no_selection`. Nếu thiếu receipt gốc, xuất ledger partial và cho phép qualification/protocol design tiếp tục; không xác nhận audit hoàn tất hoặc tái tạo receipt thay bản gốc. Việc cung cấp/truy cập receipt riêng là bước tương lai, không thực hiện trong phiên lập kế hoạch.

## Validation matrix tương lai

| Cấp | Kiểm chứng | Pass |
|---|---|---|
| Unit/read-only | Hash và extraction đúng byte/cell, không double-count | Hai lần đọc cùng artifact cho cùng identity |
| Integration | Join source/reference/summary/score theo ID | 120 ID và 240 outputs, hoặc discrepancy có ledger |
| Diagnostic review | 30 mẫu, rule sampling, citations, uncertain labels | 10/stratum; random/extreme tách; không population rate |
| End-to-end audit | Evidence matrix → report conclusions | Mỗi claim có nguồn và mức verification |

## Success Criteria

- [ ] Mọi artifact được phân loại available/missing/identity mismatch; receipt Drive chưa có vẫn được ghi unverified.
- [ ] Hash mismatch có lời giải có bằng chứng hoặc unresolved rõ; không sửa artifact gốc.
- [ ] 30 diagnostic items đủ nguồn và rubric; không gọi observations là gold annotation.
- [ ] Tách count/length confound, prompt hypothesis và factuality/abstract limits trong kết luận.
- [ ] P2 nhận evidence và issue ledger; không đổi kết quả lịch sử.

## Risk Assessment

| Failure mode | Khả năng × tác động | Mitigation/gate |
|---|---|---|
| Tin notebook self-report là độc lập receipt audit | Cao × cao | Hai cột riêng; missing receipt không được pass identity audit |
| Cherry-pick extreme outputs rồi suy rộng | Cao × cao | Hai sampling strata diagnostic; purposive caveat và không error prevalence |
| Làm sạch hash bằng overwrite | Vừa × cao | Immutable inputs, ledger version mới, dừng provenance claim khi unexplained |
| Reviewer đoán arm/metric bias | Vừa × vừa | Blinding khi khả thi, uncertainty, source citations |

## Compatibility, rollback và quyết định còn mở

Không migration hay thay đổi consumers. Rollback: ngừng dùng diagnostic draft, giữ raw ledger; study cũ vẫn authoritative trong phạm vi evidence hiện có. Chưa chốt: artifact gốc cho discrepancy và receipt Drive khi được cung cấp; vấn đề này hạn chế provenance claim, không bắt buộc rerun model.

