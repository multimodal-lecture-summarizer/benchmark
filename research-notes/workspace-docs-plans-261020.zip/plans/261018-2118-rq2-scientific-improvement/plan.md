---
title: "RQ2 scientific research improvement on T4"
description: "Kế hoạch nâng độ chặt khoa học RQ2: audit, giới hạn dữ liệu, đối chứng ba nhánh và khả thi T4."
status: cancelled
priority: P1
effort: "28-40h công việc tương lai; GPU dự kiến riêng, chưa đo"
branch: "N/A - workspace ngoài không phải Git repository"
tags: [rq2, research, text-summarization, t4, planning-only]
blockedBy: []
blocks: []
created: "2026-10-18T14:19:46.539Z"
createdBy: "ck:plan"
source: skill
---

# RQ2: cải thiện thiết kế nghiên cứu trong giới hạn T4

## Thiết kế tương lai được thay thế — 2026-10-19

Theo yêu cầu mới của người dùng, [kế hoạch năm giai đoạn](../261019-0035-summarization-model-benchmark/plan.md) là kế hoạch hiện hành: Paper & Dataset → EDA → Qualification → tuyển chọn pipeline/T4 benchmark → evaluation. Shortlist LexRank/BART/LED/Qwen3 thay hướng primary count-control ba nhánh bên dưới. Quy mô hiện hành đã tăng: EDA toàn bộ 9.103 records, qualification mọi split; pilot 30–50 và model selection 200–400 mẫu validation tách nhau; final toàn bộ test hợp lệ tối đa 911, hoặc fallback 400–600 theo nguồn lực/quy tắc khóa trước test; error analysis 30–50 trường hợp. Đây là dự toán chưa chọn IDs/chạy/freeze, không bảo đảm thống kê. S1/S3 chỉ còn nghiên cứu phụ. Trạng thái `cancelled` nghĩa là đề xuất chưa thực hiện này đã được thay thế, không phải benchmark thất bại. Nội dung còn lại và các phase files giữ làm lịch sử thiết kế; không còn là chỉ dẫn triển khai hiện hành. Không thay đổi kết quả/frozen artifacts của cohort 120 đã chạy.

## Overview

**PLANNING ONLY.** Bốn phase dưới đây đều là việc tương lai, chưa được thực hiện. Phiên lập kế hoạch chỉ đọc bằng chứng và viết Markdown; không sửa code/dữ liệu, không chạy model, test hay benchmark, không truy cập Drive riêng. Kế hoạch không cấp quyền chạy mới.

Đích mặc định đề xuất: nghiên cứu text-only trên một cohort hữu hạn TIB, đo mức đồng thuận với creator abstract. Ưu tiên tách nhiễu thiết kế và báo cáo trung thực; không bắt buộc đổi model lớn hoặc làm human-scoring mới.

Kết quả cũ vẫn **`no_selection`**: đủ 240 summaries, 120 cặp cho ba metrics, mọi exploratory interval đi qua 0. Không suy ra tương đương hay thiếu hiệu quả. Audit receipt/ledger Drive độc lập còn thiếu; SHA notebook rescore có chênh lệch cần giải thích, không sửa artifact cho khớp báo cáo. [Bằng chứng hiện tại](../../benchmark/docs/results/rq2-tib-120-results-261013.md).

Các mặc định 60 mẫu, ba nhánh, prompt chat và mục tiêu T4 bên dưới là **đề xuất cần qua gate**, chưa phải protocol đã freeze.

## Phases

| Phase | Name | Status |
|-------|------|--------|
| 1 | [Evidence audit and error analysis](./phase-01-evidence-audit-and-error-analysis.md) | Pending |
| 2 | [Data qualification and claim scope](./phase-02-data-qualification-and-claim-scope.md) | Pending |
| 3 | [Controlled experiment and analysis protocol](./phase-03-controlled-experiment-and-analysis-protocol.md) | Pending |
| 4 | [T4 feasibility and execution handoff](./phase-04-t4-feasibility-and-execution-handoff.md) | Pending |

## Dependencies

`P1 → P2 → P3 → P4`. P3 chốt thiết kế; P4 chỉ kiểm khả thi development và đóng gói bàn giao sau khi có quyền triển khai riêng. Nếu P4 cần đổi batch/prompt/budget/cohort, quay lại P3 và freeze lại trước điểm evaluation mới.

P1 bàn giao issue ledger từ evidence local là đủ để P2/P3 làm việc độc lập; thiếu receipt Drive chỉ giữ chứng nhận study cũ ở mức chưa audit, không khóa qualification hoặc thiết kế mới. P2 tạo frame/proposed IDs; P3/P4 chỉ freeze IDs và N cuối cùng sau kiểm context và resource gate, trước generation evaluation.

[Freeze 120 trước đây](../261012-2249-tib-120-frozen-evaluation/plan.md) và [semantic amendment](../261013-1123-rq2-semantic-rescore/plan.md) là predecessor/evidence, không phải yêu cầu chạy lại hoặc đảo trạng thái lịch sử. Chưa có blocker thực thi chéo plan được xác lập; `blockedBy`/`blocks` để trống.

| Phase | Đầu ra và gate | Owner duy nhất | Ước lượng giả định |
|---|---|---|---|
| P1 | Evidence matrix + phân tích lỗi output cũ; phân biệt verified/unverified | Evidence reviewer | 4-6h |
| P2 | Target, suitability ledger, frame và proposed cohort; không leakage nhóm đã biết | Data steward | 6-8h |
| P3 | Protocol ba nhánh, count control khả thi, estimand và test matrix | Experiment designer | 10-14h |
| P4 | Development T4, resource gate, runbook/receipt contract; chưa tự chạy evaluation | Runtime owner | 8-12h |

Ước lượng là giờ công tương lai, không cam kết lịch; chờ dữ liệu/Drive/quyền thực thi không tính. Không có phase viết song song cùng file; artifact P1/P2/P3 đã chốt chỉ đọc ở phase sau, amendment cần owner và version mới.

## Thiết kế đề xuất và dòng dữ liệu

`Pinned source + metadata → suitability/group ledger → source-only A/B/C chunking → cùng chat model và map/reduce → summaries/dispatch ledger → scorer đọc reference riêng → paired intervals + failures + claim ledger`.

- A: fixed chunks ≤512 tokens theo kiểu cũ, nhưng dùng prompt chung của nghiên cứu mới.
- B: lexical-agnostic, chia gần đều theo token; số chunks bằng C từng item, đủ source đúng thứ tự.
- C: source-only lexical boundaries; không phải learned segmentation hay hierarchical synthesis.
- Primary contrast **C−B**; secondary **C−A**. Common map allocation `96 × max(n_A,n_B,n_C)`, final cap 384; actual token/padding/time báo riêng. Count matching không loại hết khác biệt độ dài/compression.
- Prompt chat kiểm tra trên train-only development trước evaluation; dữ liệu cũ raw-prompt không được gộp thành kết quả cùng nghiên cứu mới.
- Frame mới loại 120 cũ, 9 pilot, development mới và nhóm phụ thuộc đã biết. Đề xuất 60 (20/stratum), 120 chỉ nếu feasibility/precision được quyết định trước điểm mới. Toàn pool đã EDA-exposed; không gọi unseen.

## Validation, compatibility và rollback

Ma trận kiểm chứng tương lai: P1 đối chiếu notebook/artifact hashes và diagnostic coding; P2 full accounting/group leakage; P3 unit chunk coverage/count/budgets, integration isolation/scoring/bootstrap; P4 end-to-end development interruption/resume và profiling T4. Chi tiết ở từng phase; hiện chưa chạy các kiểm chứng này.

Giữ nguyên toàn bộ frozen runtime/protocol, notebooks, nguồn, reference và kết quả cũ. Nếu triển khai được cho phép sau này, dùng helper/schema/run root có version mới; không sửa các module có hash trong [protocol cũ](../../benchmark/experiments/registry/datasets/tib-rq2-rq4-120-protocol-261012.json). Không migration dữ liệu cũ; liên kết bằng source/reference hashes và study ID. Rollback từng phase: bỏ bản nháp/version mới khỏi đường thực thi, giữ ledger, trả lại evidence cũ; không ghi đè/chấm lại artifact lịch sử.

| Rủi ro chính | Khả năng × tác động | Gate giảm thiểu |
|---|---|---|
| Claim vượt chất lượng abstract/genre | Cao × cao | P2 khóa finite abstract-agreement claim; route factual/lecture riêng |
| Count control không khả thi hoặc còn confound | Vừa × cao | P3 coverage/count exact trước freeze; fail gate nếu không thỏa, ghi residual effects |
| Prompt tuning/evaluation leakage | Vừa × cao | Development train-only, nhóm tách, freeze trước điểm mới |
| OOM/timeout T4 | Vừa × cao | P4 profile length extremes, unload tuần tự, checkpoint; không tự giảm chất lượng |

## Tiêu chí hoàn tất công việc tương lai

- [ ] P1-P4 có artifact versioned, đủ acceptance của từng phase và provenance rõ.
- [ ] Source chỉ vào generator; abstracts chỉ vào scorer/audit; mọi selected ID được accounting.
- [ ] Protocol mới chốt trước evaluation, common budget và count control có kiểm chứng.
- [ ] T4 gate đạt bằng measurement development hoặc báo không khả thi; không có cam kết power/capacity giả.
- [ ] Bàn giao dừng ở phạm vi được cấp quyền; kết luận cũ giữ `no_selection`.

## Cơ sở phương pháp

[Qwen model card/quickstart](https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct) hỗ trợ kiểm tra chat template; [SummEval](https://aclanthology.org/2021.tacl-1.24/) nhắc giới hạn automatic metrics; [SummN](https://aclanthology.org/2022.acl-long.112/) là tham chiếu kiến trúc nhiều giai đoạn, không chứng minh S3 hiện tại có hierarchy; [resampling cho NLP](https://aclanthology.org/2021.tacl-1.67/) làm nền cho báo cáo bất định, không bảo đảm power của cohort này.

## Kiểm tra bản kế hoạch — 2026-10-18

- `ck plan validate --strict`: PASS, không warnings/errors; cả bốn phase `pending`.
- 48 local Markdown links trong bộ năm file resolve được; không còn generated stubs.
- Independent scientific review đọc đủ năm file: PASS sau bổ sung pair-specific denominator, counterbalance, context bound và nonblocking partial audit.
- Whole-plan consistency sweep: không còn mâu thuẫn được phát hiện giữa năm file. Chưa kiểm chứng optimizer, code mới, dữ liệu mới hoặc T4 bằng thực thi; đây là acceptance của tài liệu kế hoạch.

## Quyết định chưa chốt

Ngưỡng practical delta và precision mục tiêu; 60 hay 120 sau development; suitability rules/nhóm còn thiếu; cách xử lý hash lệch khi có byte/receipt gốc. Không có câu hỏi nào buộc phải trả lời để hoàn tất bản kế hoạch này.
