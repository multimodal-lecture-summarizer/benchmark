---
phase: 4
title: "T4 feasibility and execution handoff"
status: pending
priority: P1
dependencies: [3]
effort: "8-12h công việc; GPU development và evaluation dự toán riêng, chưa thực hiện"
---

# Phase 4: T4 feasibility and execution handoff

## Overview

Đo khả thi trên **T4 thật** bằng development và bàn giao protocol/runbook mới có checkpoint/receipt. **Pending.** Owner: runtime owner; blocker: P3 design/CPU gate và quyền thực thi riêng trong tương lai. Hoàn tất kế hoạch hiện tại không cho phép chạy development hoặc evaluation.

## Requirements và deliverables

- Proposed shared profile: Qwen2.5-1.5B-Instruct pinned, FP16, map batch2, greedy; nếu dev OOM thì batch1 **mọi nhánh**, đo lại và freeze trước eval.
- Không fine-tune/quantization/auto GPU/CPU fallback; không đổi model để cứu item sau evaluation.
- P4 sở hữu artifact tương lai: `reports/t4-development-profile.md`, `reports/t4-capacity-decision.md`, `reports/execution-handoff.md`; versioned new runtime/notebook/bundle builder khi được phép. Không phát lệnh thực thi trong bàn giao kế hoạch này.

## Architecture và vòng đời tài nguyên

`Frozen new source/protocol + complete local model assets → identity/CPU preflight → load generator → source-only A/B/C generation + dispatch checkpoints → unload generator/verify memory release → sequential pinned scorers → aggregate/figures → artifact seal/readback`.

- [T4 official spec](https://www.nvidia.com/en-us/data-center/tesla-t4/) có16GB; usable memory thực đo, không giả định đủ cho cả generator/scorers cùng lúc.
- Engineering targets đề xuất **peak≤12GiB, free≥2GiB** trên T4 thật; ghi peak allocated/reserved và device/process memory/free ở mốc đồng bộ. Đây là mục tiêu, chưa phải số đo hay bảo đảm không OOM.
- Generator và scorer load tuần tự; scorer1 unload trước scorer2. Ghi initialization/load/download/segmentation/scoring/export riêng; chỉ tensor reserved không thay thế total device usage.
- New state scoped run/item/dispatch; `in_progress` ghi bền trước GPU call, attempt result append-only sau call. Không dùng field shared process state để giữ current record/arm.

## Cost baseline và scenario — không phải cam kết

[Chi phí cũ](../../benchmark/docs/results/rq2-tib-120-results-261013.md): S1 generation4.892,003137s + S3 generation4.775,379347s = **9.667,382484s/240 summaries ≈40,28s/arm**. Đây là một run raw-prompt cũ, không dự đoán chắc chat/ba nhánh mới.

| Scenario | Phép chiếu generation-only | +30% dự phòng generation-only |
|---|---|---|
| 60×3=180 summaries | ≈2,01h | ≈2,62h |
| 120×3=360 summaries | ≈4,03h | ≈5,24h |

Chưa gồm segmentation/control optimizer, model init/load/download, prompt validation raw-vs-chat, scoring, export, interrupted/failed/unknown attempts. Cộng30% không là upper bound hay total-session estimate. Các nguồn chi phí chưa biết phải hiện `unknown`, không gán0.

Planning targets đề xuất generation soft6h / session soft8h; dự toán toàn session là `1,30 × (init + load/download + CPU partitioning/segmentation + generation + scoring + export + known failure costs)`, với unknown costs giữ riêng và capacity decision chưa pass nếu chưa có cách đánh giá. Không nhân thêm 30% lên cột generation đã có margin để tránh cộng dự phòng hai lần. Check giữa dispatch, không force-kill call đang chạy. Phải ghi riêng lịch used/remaining cho session/resume; nhiều session không reset giả tổng chi phí.

## Development profile trước evaluation

1. Sau quyền triển khai riêng: xác minh CPU tests P3 và full source/model/tokenizer/scorer hashes; nếu thiếu tài sản pinned, HOLD, không tự cài/chuyển version lặng lẽ.
   Trước generation, kiểm map/reduce context envelope toàn candidate frame, longest-source/map-count extremes, host RAM và storage. Sau generation map, kiểm actual reduce prompt IDs; overflow giữ failure/usage, không tự truncate. Case ngoài envelope quay về protocol review cho run mới, không bỏ selected ID trong run đang diễn ra.
2. Dùng6 train IDs P2,2/stratum, gồm source length/map-count extremes; **18 summaries cho chat profile A/B/C**. Raw-vs-chat gate P3 có lượt bổ sung, hạch toán riêng; không gọi18 là toàn bộ development cost nếu đã chạy thêm.
3. Thu per-dispatch/per-arm: source/content/chat prompt/output/padding tokens, EOS/cap-hit status, n_chunks/lengths, segmentation/CPU control time, init/generation/scoring/export/session wall time, GPU peaks/free, errors và unknown usage.
4. Kiểm output/source language preservation và map/reduce/source coverage trên dev bằng source evidence; detector là heuristic. Không chọn pipeline thắng bằng dev ROUGE hoặc thay prompt dựa evaluation.
5. Profile hai scorers sau generator unload; long-sentence/window coverage không truncation. So sánh sequential resource usage, không báo inherited generation trong semantic-rescore cost lần hai.
6. Tạo per-stratum duration/resource scenarios dùng measured dev và toàn selected source-token/map-count distributions; báo median/range/worst observed, đặc biệt long stratum. Cỡ6 không cho runtime upperbound hay độ tin cậy population.
7. Quyết định60/120 trước eval bằng scenario + reserve30% + mục tiêu precision P3. Nếu60 vẫn không đạt memory/time gate → **HOLD**, redesign trước freeze; không bắt đầu rồi giảm N sau score.
8. OOM development: release/diagnose, đổi batch1 chung cả A/B/C, đo lại cùng dev và ghi revision. Context overflow/empty outputs: sửa thiết kế trước freeze; không silently truncate hay bỏ source.
9. Freeze config/code/data/model/scorer/hardware identity và xuất capacity decision. Mọi thay đổi làm invalid profile liên quan thì đo lại dev cần thiết; không chạm legacy run.

## Execution handoff contract cho tương lai

- Proposed runtime/notebook `[NOT CREATED]`: `benchmark/experiments/scripts/rq2_count_control_v1_runtime.py`, `benchmark/experiments/notebooks/rq2-tib-count-control-v1-colab.ipynb`; output root mới `benchmark/experiments/outputs/rq2-tib-count-control-v1/` (local/ignored, verify ignore trước staging). P4 duy nhất sở hữu; P3 modules read-only.
- Bàn giao nêu prerequisites/IDs/hashes/order/budgets/stop rules; **không tự thực thi evaluation**, không chỉ dẫn chạy lệnh như bước tiếp theo được cấp quyền hiện tại.
- Resume key: study+cohort/source/reference+protocol+code/model/tokenizer/scorer/hardware/config identities; mismatch → root mới, không reuse outputs. Một writer/lock; stale lock chỉ xử lý sau xác minh session cũ dừng.
- Dispatch state: `not_attempted → in_progress → completed/failed/interrupted`; persisted pre-call seal. Lost in-flight có unknown usage/duration, không zero; completed unchanged receipt chỉ reuse nếu exact identity match.
- Partial reporting giữ toàn selected N, mọi selected IDs/arms/metric statuses; no silent retry/replacement, successful intersection và conditional estimand ghi rõ. Incomplete study không tự tuyên bố winner.
- Primary C−B không phụ thuộc A success; secondary C−A và common-three-arm tables có denominators riêng. GPU timing dùng cùng synchronized boundaries, ghi warm-up và thứ tự sáu permutations theo stratum; generation/segmentation/session overhead tách rõ.
- Retries nếu được quyết định riêng phải append attempt và reason, giữ chi phí/error trước; seed/batch/model/prompt không đổi âm thầm. Không parallel sessions cùng output.
- Export predictions, item/group/stratum metrics, failures, known/unknown costs, environment, artifact hashes/seal/readback. Giữ reference trong scorer-side bundle; source-only interface chặn reference trong generation.
- Old Drive receipt audit còn pending không cấm new-study CPU planning; new run phải audit **receipt riêng**, không kế thừa certification cũ chưa có.

## Related Code Files — frozen read-only

- `_summarize` [pair:68](../../benchmark/experiments/scripts/rq2_tib_benchmark_pair.py) và GPU meter [pair:24](../../benchmark/experiments/scripts/rq2_tib_benchmark_pair.py): tham chiếu receipt/memory scope, không sửa.
- [Frozen runtime](../../benchmark/experiments/scripts/rq2_tib_frozen_runtime.py), [frozen protocol](../../benchmark/experiments/registry/datasets/tib-rq2-rq4-120-protocol-261012.json), [rescore amendment](../../benchmark/docs/results/rq2-tib-semantic-rescore-v2.md): tham chiếu immutability/recovery, không dùng để hợp thức hóa new run.

## Validation matrix tương lai

| Cấp | Failure cases | Acceptance |
|---|---|---|
| Unit | Identity mismatch, incomplete usage, state transitions | Fail closed, null giữ nguyên, không retry mặc định |
| Integration | 3-arm budget/order, generator unload→scorers, hash export | Prompt/source identities đúng, costs tách scope |
| End-to-end development | Interrupt trước/sau dispatch, resume/lock, scorer failure | Không double-charge/reuse sai; mọi failure còn ledger |
| T4 thật | Long sources, memory/free, batch2→1 dev, soft budget | Measured capacity decision hoặc explicit HOLD |

## Success Criteria

- [ ] Có measured development profile18 chat summaries và additional prompt-check costs riêng, hoặc HOLD có lý do.
- [ ] Memory/free targets và6h/8h scenarios được đánh giá; không claim bảo đảm T4 capacity.
- [ ] N60/120 và shared batch chốt trước evaluation; source đầy đủ, không quality downgrade để fit.
- [ ] Resume/identity/failure tests và sealed new bundle pass trong triển khai được phép.
- [ ] Bàn giao rõ cần quyền chạy riêng; toàn bộ phase vẫn pending khi chỉ viết kế hoạch.

## Risk, compatibility và rollback

| Failure mode | Khả năng × tác động | Mitigation |
|---|---|---|
| Mean old runtime đánh giá thấp long-source cost | Cao × cao | Per-stratum measured scenarios + reserve; HOLD nếu60 không fit |
| OOM hoặc session expiry | Vừa × cao | Tuần tự model, shared batch freeze, checkpoint/unknown usage |
| Resume nhầm identity/duplicate writer | Vừa × cao | Key hashes + lock + append-only dispatch seal |
| Full study thiếu arm/scorer nhưng báo winner | Vừa × cao | All-selected accounting, conditional estimand, no selection khi thiếu chứng cứ |

Backward compatibility: output schema/run root mới; current readers/old results không thay. Rollback new runtime bằng dừng writer, seal partial, giữ log; resume cùng identity nếu được phép hoặc version root mới. Không xóa lỗi, ghi đè old artifacts hay tự rerun. Chưa chốt: T4 availability, measured capacity, N và practical precision gate; không có GPU evidence mới trong kế hoạch này.

