---
phase: 2
title: "Data qualification and claim scope"
status: pending
priority: P1
dependencies: [1]
effort: "6-8h; giả định có pinned text bundle/metadata local, chưa thực hiện"
---

# Phase 2: Data qualification and claim scope

## Overview

Khóa target hữu hạn, kiểm suitability source/reference và frame mới trước generation. **Pending.** Owner: data steward; đầu vào: evidence/issue ledger local P1, có thể partial. Thiếu receipt Drive không khóa phase này. Không cần video-media gate cho route text-only mặc định.

## Requirements và deliverables

- Target mặc định: finite TIB creator-abstract agreement, không khẳng định factual lecture/video summary quality hoặc unseen generalization.
- Đầu ra tương lai P2 sở hữu: `reports/data-qualification.md`, `reports/claim-scope.md`, `reports/candidate-frame-ledger.csv`; manifest/group ledger mới versioned dưới `benchmark/experiments/registry/datasets/` chỉ tạo khi triển khai được cho phép.
- Source/reference không được chỉnh cho điểm tốt hơn; rules trước score. Abstract issue flags giữ trong cohort và sensitivity theo rule, không loại sau khi thấy điểm.

## Architecture và existing evidence

`Pinned full-pool rows → identity/suitability/genre/language/accounting → dependence graph → exclude exposed evaluation/pilot/dev groups → remaining valid frame → deterministic stratified proposed selection → cohort freeze input P3`.

- [Freeze report:11](../../benchmark/plans/reports/tib-120-cohort-and-protocol-freeze-261012-report.md): full pool 9.103, mechanically eligible 8.769; [report:13](../../benchmark/plans/reports/tib-120-cohort-and-protocol-freeze-261012-report.md): eligible `valid` 887, strata 296/289/302. Đây là số historical, phải tái accounting frame mới.
- [EDA hiện tại](../../benchmark/docs/DATASET_EDA.md) ghi genre 7.966 Conference/Talk và 827 Lecture trên toàn 9.103, **không phải** phân bố 120. P2 phải kiểm genre thực của frame mới; metadata genre không tự chứng minh hoặc bác bỏ educational relevance.
- Source/reference trace: `prepare_record` [dataset:41](../../benchmark/experiments/scripts/rq2_tib_benchmark_dataset.py) lấy transcript/abstract → flags → source/reference hash [dataset:116](../../benchmark/experiments/scripts/rq2_tib_benchmark_dataset.py) → `abstract_agreement_candidate` [dataset:122](../../benchmark/experiments/scripts/rq2_tib_benchmark_dataset.py). Đây là mechanical eligibility, không chứng nhận reference đúng sự thật.
- [Freeze report:15](../../benchmark/plans/reports/tib-120-cohort-and-protocol-freeze-261012-report.md): nhóm source/content và author cũ chưa exhaustive, thiếu identity course/video authoritative. Không coi author name là course ID.

## Related Code Files — chỉ đọc trong kế hoạch

- [Dataset adapter](../../benchmark/experiments/scripts/rq2_tib_benchmark_dataset.py); [original cohort](../../benchmark/experiments/registry/datasets/tib-rq2-rq4-120-cohort-261012.json); [protocol](../../benchmark/experiments/registry/datasets/tib-rq2-rq4-120-protocol-261012.json).
- [All-split EDA notebook](../../benchmark/experiments/notebooks/diagnostics/rq2-tib-all-splits-eda-colab.ipynb), [valid-detail EDA](../../benchmark/experiments/scripts/rq2_tib_valid_detail_eda.py), [pilot cohort helper](../../benchmark/experiments/scripts/rq2_tib_pilot_cohort.py).
- Proposed new files `[NOT CREATED]`: `benchmark/experiments/registry/datasets/tib-rq2-count-control-v1-cohort.json`, `tib-rq2-count-control-v1-qualification.json` cùng thư mục. Không sửa manifests cũ.

## Implementation Steps

1. Đọc P1 issue ledger; bind dataset revision và đầy đủ input hashes. Missing bundle thì báo gate blocked, không thay nguồn bằng bản download không rõ revision.
2. Accounting toàn pool/split: selected, eligible, excluded và reason counts phải cộng về đúng frame; kiểm source language, genre, source length, abstract length/language, overlap, source/transcript-segment alignment.
3. Freeze suitability rubric trước generation: reference có nội dung tóm lược hay chỉ promotional metadata; thiếu/không đọc được source; language mismatch; truncation/alignment; single vs shared abstract. Ghi `suitable/flagged/unusable/uncertain` theo evidence, không dùng điểm model.
4. Phân biệt exclusion kỹ thuật trước selection với quality flag. Empty/corrupt source/reference và unsupported input định nghĩa trước; abstract ngắn/mơ hồ hoặc flag chỉ giữ và sensitivity. Những ca mới phát hiện sau freeze không được quietly drop.
5. Xây lại graph: exact DOI/URL/source hash, reviewed duplicates/series/content ties; rà trong-valid còn lại và cross-split với 120 cũ, 9 pilot, development. Chỉ loại theo quan hệ source/content có bằng chứng theo rule đã định. Author/title-only là flag và sensitivity, không tự chứng minh cùng source hoặc tự động loại. Lưu evidence edges, uncertain ties và author sensitivity riêng; không tuyên bố leakage-free tuyệt đối.
6. Chọn development train-only mới đề xuất 6 IDs, 2/stratum, không trùng/không cùng nhóm đã biết với 120 cũ, 9 pilot hoặc frame evaluation mới. Bao phủ length extremes để prompt/resource check; 9 pilot chỉ technical-cost anchors, không chọn prompt/arm winner.
7. Frame evaluation mới: eligible `valid` còn lại sau loại 120 cũ, 9 pilot, 6 dev mới và known dependence groups của chúng. Một số loại thuộc train nên không trừ số học 887−120−9−6; ghi actual counts theo split/stratum/nhóm.
8. Proposed default **60, 20/stratum**; optional **120, 40/stratum** chỉ khi P3 precision planning/P4 measured feasibility đủ và chốt trước điểm mới. Frame shortage → fail gate/review thiết kế trước freeze; không thay/rescale tự động sau điểm.
9. Đề xuất ranking SHA-256 `tib-rq2-count-control-v1|split/ID`, tie theo ID, giữ cutpoints cũ 4.271/7.142 source tokens chỉ sau tokenizer identity audit. Freeze salt, rules, cutpoints, selected IDs, reserve **không dùng làm replacement** và group membership trước evaluation.
10. Mọi TIB pool đã qua EDA; gọi cohort “newly selected, EDA-exposed”, không gọi unseen/held-out sạch. Không gộp old120 vào endpoint mới.

Trước chọn IDs cuối cùng: rà source-only technical eligibility bằng actual tokenizer/chat serialization cho mọi candidate. Giới hạn source chunk 512 không đủ chứng minh reduce prompt vừa context. P3/P4 phải kiểm envelope tổng map-output caps + separators/instructions/chat wrappers + final384 với context model pinned, RAM host và dung lượng artifact. Nếu long tail không khả thi: ghi exclusion kỹ thuật theo rule pre-selection và đủ reason counts, hoặc HOLD để thiết kế protocol mới; không truncate transcript, bỏ item đã chọn hoặc thêm tầng reduce âm thầm. Sau freeze, realized context overflow được ghi arm failure trong denominator, không tạo eligibility mới.
11. Claim ledger: primary abstract agreement; BERTScore reference similarity và source SBERT transcript similarity riêng. Không gọi factuality %, hierarchy efficacy, multimodal gain hoặc pure semantic-boundary effect.
12. Route rộng lecture/factuality là **conditional separate study**: cần lecture-specific nguồn/rights và validated summary labels hoặc annotation/validation riêng. Không ép human scoring mới/video download vào narrow route và không suy từ genre pool sang claim lecture120.

## Validation matrix tương lai

| Cấp | Nội dung | Acceptance |
|---|---|---|
| Unit | Identity joins, exclusion reasons, stratum boundaries, hash ranking | Không trùng ID; tất cả row có reason/status |
| Integration | Dataset + qualification + graph + split selection | Excluded groups không lọt selected/dev; accounting khớp |
| Full frame audit | Suitability/language/genre/alignment trước scores | Ledger mọi candidate, uncertainty không mất |
| End-to-end freeze | Manifest/source/reference hashes + claim ledger | Exact selected denominator; không score-driven replacement |

## Success Criteria

- [ ] Có actual remaining counts theo split/stratum, không suy đơn giản từ 887.
- [ ] 120 cũ, 9 pilot, dev và known groups được loại khỏi frame mới có traceability.
- [ ] Suitability rules và sensitivity flags frozen trước scores; selected source/reference immutable.
- [ ] 60/120 còn là quyết định pre-evaluation; shortage làm fail gate.
- [ ] Claim narrow text-only và pool EDA exposure hiện rõ trong manifest/report.

## Risk Assessment

| Failure mode | Khả năng × tác động | Mitigation |
|---|---|---|
| Abstract sai target nhưng dùng như factual GT | Cao × cao | Suitability ledger + narrow claim; route rộng độc lập |
| Leakage nhóm/EDA exposure bị giấu | Cao × cao | Known-group exclusions, graph evidence, không unseen claim |
| Không đủ stratum sau exclusions | Vừa × cao | Đếm frame trước freeze; dừng và sửa thiết kế, không replace sau score |
| Post-score loại reference yếu | Vừa × cao | Rule pre-score, giữ flag/sensitivity, denominator ledger |

## Compatibility, rollback và quyết định còn mở

Existing dataset/users/integrations không migration; adapter cũ chỉ đọc, manifest mới có study ID/schema version. Rollback qualification mới bằng ngừng dùng manifest mới; không khôi phục bằng ghi đè nguồn. Chưa chốt: actual remaining frame, completeness nhóm/suitability, practical target rộng có cần route riêng hay không.

