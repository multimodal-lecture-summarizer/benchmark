---
title: Bounded HTTP403 protocol recovery and interrupted resume
status: completed
priority: P1
effort: medium
branch: untracked-notebook
tags: [research, colab, retry]
created: 2026-10-18
---

# HTTP403 recovery

UserstoppedColab andauthorizesresearch,fixes,thoroughlocaltests beforetheirnextColabrun. Researchreport plans/reports/research-261018-1335-mlpdataset-http403-recovery-report.md. Partiallog86completed81success5dataHTTP403;notallremainingcountsconfirmed. Sourcealreadyclean;input+partialstatesbackedup. No remoteYouTubeexecutionhere,credentials,plugininstall,upgrade,GTedits,media/cachedeletion,commit/push.

- [x] Research officialwiki/README+pinned2026.08.19clientcode;rejectandroid_vrfallback,preserveexistingversions.
- [x] Independentplanreview:no blockers;deadline/isolatedpartials/checkpoint/effectiveprofile evidence required.
- [x] Addboundedprofiles(primaryunchanged→defaultHLS→SafariHLS),only403/noformats triggers,stopauth/permission/timeout/resource/validation;120s total/source inclboundedpauses/globalguards,max3newcommands,isolatedprofilepartials,actualeffectiveprofilemetadata/checkpoints/logs;successonlyfile+probe+hash.
- [x] Includeinterrupted/running inresumablepoolwithoutchangingstoredstateuntilattempt;cachedownloadedbranchescontinuehash/probe;preserveall333/9021/source/frameidentityandpreviewcode. Addcommandcountseparatesourcecounts inreceipt/results.
- [x] Fixrunnerstructuredlogemptyerrorbeforeprint;pace7sec/requestsleep0.75;defaultfreshformatdiagnosticsoff (historicaloutputretained);previewunchanged.
- [x] Testfocusedsavedpartialstates,classifiers/profileordering/fallback+isolatedpartials+strictfragments+unsupported/authstop;actuallocalprocess/probehash/nestedpreview,interruptafterprofiles,source/global/storagebounds,old214cachereuse;existingallfailed6/representative5/resume8/stage/full3339021receiptregressions.
- [x] Pin setup to observedcacheversions(yt-dlp2026.8.19,EJS0.8.0,Deno2.9.6);removeblindupgrade,checkagainst savedidentities.
- [x] Independentcodereview;guide/report/journal/artifacts/plancomplete.

Acceptance:controlledlocal403commandfailsfirst,nextprofilevalidmediarecovers,allhistories/hashcachekept,wrong/missingmediaremainsfailed;blockedresourcesnevercalled;interruptedprofilecheckpointssurvive. Nonselectedrecordsandfullinventorynotdropped. NewColabsuccessnotclaimedbeforeuserexecution.

Final verification:12 focused tests; representative5/all-failed6/resume8; stage budgets and full333/9021 receipt replay PASS. Independent review and workflow finalize gate PASS. Remote YouTube and Colab dependency resolution pending user execution. Implementation report: plans/reports/implementation-261018-1335-mlpdataset-http403-recovery-report.md.
