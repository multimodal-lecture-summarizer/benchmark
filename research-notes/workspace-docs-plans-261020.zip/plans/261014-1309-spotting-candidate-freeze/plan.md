---
title: "Freeze spotting candidate weights and operating configurations"
description: ""
status: pending
priority: P2
branch: ""
tags: []
blockedBy: []
blocks: []
created: "2026-10-14T06:11:45.845Z"
createdBy: "ck:plan"
source: skill
---

# Freeze spotting candidate weights and operating configurations

## Overview

Freeze two preselected official families: EasyOCR1.7.2 CRAFT+english_g2 and PaddleOCR2.8.1 English DB(v3)+recognizer(v4). Deliver candidate registry, verified model/source hashes, explicit preprocessing/grouping, adapters, identity guard, focused tests and report. Same cohort/scorer untouched; no evaluation inference.

Independent scientific review approved native defaults except a declared Paddle drop_score=0.0 variant to preserve detector outputs. Set thread env before imports; distinguish configured/runtime verified. Actual weight files must be hashed; no fabricated detector identity.

## Phases

| Phase | Name | Status |
|-------|------|--------|
| 1 | [Verify upstream evidence](./phase-01-verify-upstream-evidence.md) | Pending |
| 2 | [Freeze candidate artifacts](./phase-02-freeze-candidate-artifacts.md) | Pending |
| 3 | [Validate adapters and identities](./phase-03-validate-adapters-and-identities.md) | Pending |

## Dependencies

Requires completed spotting data/scoring freeze at ../261013-2321-iiit-cvid-spotting-freeze. No active upstream blocker. No candidate thresholds selected on frozen validation data.
