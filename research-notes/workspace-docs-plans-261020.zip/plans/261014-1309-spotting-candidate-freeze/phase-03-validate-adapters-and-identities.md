---
phase: 3
title: "Validate adapters and identities"
status: pending
effort: ""
---

# Phase 3: Validate adapters and identities

## Overview

Deliver the named phase under the reviewed scope in plan.md.

## Implementation Steps

Use pinned upstream package releases and locally verified model bytes. Preserve existing cohort/scorer and recognition code. Capture artifact identity and any unverified runtime readiness separately.

## Success Criteria

- [ ] Phase evidence verified; report distinguishes completed configuration freeze from remaining runtime gates.
