---
title: Targeted cached-media review and frozen slide-end protocol
status: completed
delivery_status: preparation_complete
runtime_status: pending_external_colab_and_manual_qualification
priority: P1
effort: medium
created: 2026-10-19
---

# Scope

User authorizes targeted ambiguity review and protocol finalization. Preserve current executed130MB notebook and source annotations. Deliver a versioned protocol JSON+Markdown, provenance-bound review queue/observations, and a separate CPU Colab notebook using existing Drive media/cache only if full source media are not local. No download, global timestamp shift, detector inference, split assignment or clean-GT claim.

## Evidence and design

Current executed333/9021 inventory and2913sparse frames complete;987marks previewed. Saved older dense evidence includes14hash-bound ±5s clips/475PTS rows locally. Reuse only after original sourceSHA/annotation/clipSHA match current ledgers; generated test fixtures are never research media. Inspect real saved dense evidence for overlapping cases now. Missing contexts remain pending Colab rather than invented verdicts.

Queue includes detailed25review ambiguous/no-change/blend/blank cases, all15nonincreasing rows and adjacent original-index context, all18beyond-end and4start-zero rows. Add prior14dense cases as controls. Deduplicate by video+original index; no arbitrary sample cap. Preserve full inventory and every reason. Bind queue+protocol+source hashes, current executed notebookSHA and raw-mark tableSHA.

Protocol-v1 freezes scientific rules, not unverified GT/cohort: slide-end endpoint; separate content/intro/outro/video-insert/animation/EOF/start/unresolved; no treating lecturer motion as slide change. Original labels immutable. Reviewed decisions require evidence source/PTS and no autoacceptance from motion scores. Scorer maximum-cardinality one-to-one then minimum absolute timing error, deterministic ties; primary0.5s collar, secondary1/2s, no tuning on predictions; matching per video. Reviewed event interval/point conventions explicit; raw and reviewed tracks never mixed. Source-disjoint grouping policy and macro-per-source plus pooled accounting. All sources already EDA-exposed; no blind holdout claim. Eligibility/cohort freeze remains blocked on review/timebase; exact cohort counts only after bound decisions.

New notebook reads existing run analysis exports, receipt/state/sourceSHA, verifies each selected media before extraction (once/source), lazy bounded runtime staging, sequential FFmpeg10s windows, integerPTS/timebase, sparse dense selection0.25s, inline MP4+contact images with measured times and no Matplotlib. Separate review output directory/version; never overwrite old source/frame/checkpoint caches. Hash validated extraction checkpoints resume by window/source/config. Deadline-aware work/time/storage/clip-embed caps; no stale-success claims. Clip data embedded HTML avoids IPython Video(None) issue. All statuses/fullqueue/receipt direct output. Manual review remains UNREVIEWED by default; no fake input widget auto-label. Reviewed decisions immutable artifacts with explicit evidence/reviewer and point/effect brackets.

## Acceptance

- Current executed notebook remains byte-identical and untouched.
- Reviewqueue has all required strata and honest pending states; reuse old evidence only with matching identities.
- Protocol status rules_frozen/gt_pending, never evaluation-ready while missing qualification.
- Standalone notebook parses/schema-valid and real FFmpeg fixtures exercise known cut/nonzero origin/EOF/resume/corruption/deadline/interruption; no network requested.
- Scorer tested on greedy trap/many-to-one/ties/invalid/nonfinite/source partition, holds/ignores/exclusions denominators explicit.
- Independent plan/code review and tests before handoff; docs/manifest updated to actual current evidence.

## Ownership

Parent: queue/provenance/local dense inspection/notebook assembly/report. Worker after plan review: bounded dense-review helpers with tests. Protocol worker after review: scorer/protocol policy+tests. Reviewer: read-only final acceptance checks. Distinct files; no overwrites of other work.

## Steps

- [x] Scout saved outputs, cached-source availability, old dense helpers and project rules.
- [x] Independent plan review; required scientific/resource/provenance gates incorporated.
- [x] Source-bound inspection of all 14 historical coarse clips/475 PTS rows; 82-mark/42-video/10-group queue prepared, preserving 20 additional edge-policy HOLDs and 48 missing contexts.
- [x] Protocol v1 and scorer implemented; rules frozen, GT/cohort pending. Original labels unchanged.
- [x] Separate CPU review notebook prepared: 18 cells/11 code cells, all unexecuted; original executed notebook unchanged.
- [x] Focused real-FFmpeg fixture tests and fresh independent suites passed; final independent review PASS with no blockers after all-82-status interruption persistence repair.
- [x] Colab guide, DATASET_EDA, master plan and manifest synchronized; owned Markdown links resolve and YAML parses.
- [x] Parent final handoff gate: implementation report written; five workflow artifacts validated; finalize gate PASS (exit0); preparation delivery complete.

All implementation tasks above are complete for **preparation delivery**. No phase files exist in this plan directory; all plan tasks are synchronized here. Artifact/report finalization is complete. External execution and scientific qualification remain pending below.

## Current delivery evidence — 2026-10-19

| Artifact | Verified state |
|---|---|
| [Current executed EDA notebook](../../benchmark/experiments/notebooks/diagnostics/mlpdataset_slide_transition_eda_colab.ipynb) | Unchanged130,654,549bytes; SHA256 `5a1b0622cd046c42df3e12b8347fb07864056f6bbe0301be6b9824f4c55c9c64`; 20/20code cells executed, no saved Python errors;333sources/9,021marks,2,913frames,0pending sparse requests |
| [Protocol JSON](../../benchmark/experiments/registry/datasets/mlpdataset-slide-transition-protocol-v1.json) and [policy](../../docs/mlpdataset-slide-transition-protocol.md) | rules_frozen / gt_pending / cohort_pending; JSON SHA256 `c213748c2ca733dae518e8629f7f0c86a1bd64231575d96ca460e4a1c03d0dc2` |
| [Targeted queue](../../benchmark/experiments/registry/datasets/mlpdataset-targeted-review-queue-v1.json) | 82marks/42videos/10groups;14historical coarse clips,20additional policy-edge HOLDs,48new contexts; no annotation repairs/native endpoint certification |
| [Standalone review notebook](../../benchmark/experiments/notebooks/diagnostics/mlpdataset-targeted-review-colab.ipynb) | prepared_not_executed;1,860,877bytes/18cells/11code cells; CPU, existing Drive sources read-only, no downloads, separate sibling review output |
| [Local test receipt](../../benchmark/experiments/outputs/mlpdataset_targeted_review_261019/local-validation/targeted-review-test-receipt.json) and [JUnit](../../benchmark/experiments/outputs/mlpdataset_targeted_review_261019/local-validation/targeted-review-tests.xml) | Fresh combined run exit0:50passed +4subtests in21.07s; independent notebook8/helper13/scorer29tests also exit0. Local Windows/real FFmpeg synthetic fixtures, no network/Drive/research-media execution; coverage not measured |
| [Run guide](../../docs/mlpdataset-colab-guide.md) | CPU Run all, default48contexts, embedded14historical clips,20policy HOLDs,60minute/.75GiBoutput/1GiBfree/2GiBstaging defaults; all82statuses persisted on interrupted extraction |

[Implementation report](../reports/implementation-261019-1107-mlpdataset-targeted-review-protocol-report.md) finalized; five harness artifacts validated and finalize gate PASS (exit0). Final hash/AST checks passed. No new Colab execution receipt is claimed.

## External follow-up — not completed by preparation

- [ ] User runs the standalone CPU notebook against existing Drive `RUN_NAME=mlpdataset-eda-261017-v3`, saves outputs, and supplies actual results for the48missing dense contexts; budgets may leave explicit pending/failure states.
- [ ] Manual review resolves event classes, native endpoint PTS/effect brackets, repeated-row mappings and source-end/timebase/source-edition questions; extraction never autoaccepts GT.
- [ ] Full-scope annotation completeness, source/near-duplicate grouping and source-use provenance qualified before eligible cohort/split/GT freeze and detector comparison.

Unresolved: all333full sources remain on Drive rather than local;48contexts need external execution; historical clips remain coarse; native GT, completeness, grouping/rights and frozen cohort/split remain pending. No clarification needed for the authorized preparation work.
