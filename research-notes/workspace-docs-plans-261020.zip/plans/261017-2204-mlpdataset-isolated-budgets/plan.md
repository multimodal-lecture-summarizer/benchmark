# Isolate acquisition and analysis budgets

Authorized fix from executed fullrun:333/9021 inventory complete,202downloaded/117unattempted/13HTTP403/1sessiondiskstop; shared4GiBguard then killed248formatcommands and400FFmpegrequests. Preserve executed notebook and media/checkpoint identities; no source/GT deletion.

- Replace combinedBASE cap with separate configurable media8GiB and analysis1GiB caps. Media cap measures videos including partials; analysis cap measures analysisoutputs and processlogs. Media scheduling/processes reserve0.5GiB above1GiB freefloor for later analysis. Diagnostics/preview ignore media cap but honor own cap, freefloor, process/time limits.
- Stage-aware resource helper and run_logged(stage=download/format/preview) perform preflight before spawn, retain processgroup cleanup and emit runner returncode/stopreason metadata even for empty programlogs. Successful quick exits still obey output checks. Bound globalstages, no unboundedprocesses.
- Keep all selection333 and identityv3. Enable data-driven once-per-run retries for HTTP403 and prior budgetstops, plus optionalmanualallowlist; no hardcodedID list. Alreadydownloaded202 remainhash/probeverified. Preserve all attemptlogs. Report current scheduling skipreason and previousattemptreason separately.
- Genericpreview keeps automatic3offsetrule, no retired14target logic. Record returncode/stopreason/error/elapsed/processstarted per frame; budgetstop distinct from realdecodefailure, no stale image success. Preserve all9021coverage rows and add reasons to videofullcoverage/receipt.
- Keep media time30min, give preview30min; formats retain separate5min. Add storage snapshot/config to receipt and inline tables; show no-space/budget recoverability. Clean notebook outputs only after backup; update guide.
- Validate actual localFFmpeg with media cap already exceeded succeeds forpreview/format while downloadpreflightblocks; separateanalysiscap/free-reserve/timeout/exit/error cases; legacybudget+403retry policy/cacheidentity, stale exclusion and full333/9021conservation/receipt. No live remote downloads. Independent plan/code review.


## Completion

Implemented and independently reviewed. Local real-FFmpeg stage isolation, storage floor/reserve, timeout/process failures, post-exit quota check, retry eligibility, unchanged cache identity and stale/empty-grid checks passed. Full333-video/9021-mark coverage regression and actual receipt-cell replay with333 historical checkpoints passed; all emitted artifact hashes verified. Guide updated. New remote Colab execution remains pending.
