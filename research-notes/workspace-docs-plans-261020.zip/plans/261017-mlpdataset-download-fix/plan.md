---
status: completed
---
# MLPDataset video acquisition fix

Root cause proven by supplied Colab logs: all ten sources expose <=360p video-only streams, while `best` requires combined audio/video. JS runtimes are not configured; Node20 exists but Deno is absent. Retry is off and old failures are retained.

- Back up exact supplied outputs and preserve unchanged EDA cells.
- Install a supported Deno through official npm distribution; upgrade yt-dlp default dependencies and print actual versions. Explicit JS runtime argument in both acquisition and diagnostics.
- Select video streams <=360p, prefer MP4, no audio requirement for frame EDA. Prefer HTTPS to HLS within selector; do not raise resolution cap or change GT.
- New run name and helper identity, default manual first released sorted ID for one-video qualification; user can expand later. Preserve old run.
- All log/receipt/frame outputs remain inline; no result ZIP.
- Verify selector against actual saved format rows via yt-dlp selection logic, helper/process checks and AST. Verify cached-data notebook with network off; live Colab re-execution remains user-run.
