# TIB P4: scorer, cap và Colab feasibility

## Decision2341 — next work

[Frozen acceptance và development close](../plans/reports/protocol-decision-261019-2341-tib-development-close-acceptance-report.md): BARTcontrol/LEDngram3/Qwen384 ưu tiên, Lead-3/LexRank giữ nguyên;512optional/disabled. Completed_with_warning giữ outputs/scoring/coverage; technical invalid vẫnfailed. Derived view preferred9outputs=5completed+4warning,0failed; raw receipts giữ nguyên. Decode search mặc định đã đóng.

Tiếp theo scorer-ready trên actual Colab runtime và **fresh-runtime recovery với unchanged P4.1 bundle**. Không đưa helper/policy mới vào old bundle rồi đổi key để ép reuse. Actual reuse có backend calls0/new generation time0, original costs riêng; reload/restore overhead mới vẫn tính. Fresh-generationT4flagfalse trên replay là expected, không phủ định recovery. Next pilot runner phải include/bind policy mới và actual source/context/hash validators trước pilot40; package cũ là historical evidence, không tự thành runtime implementation của policy mới. Scorer cần amendment cho torch/numpy khác CPU-ready profile; không chỉ copy ready boolean.

## P4.1 actual returned trials — đã audit

[Audit21 outputs/123nodes](../plans/reports/evidence-audit-261019-2222-tib-p41-returned-trials-report.md):7/7 profiles×3sources completed/fresh trên T4;308 files/281 JSON envelopes và20 returned code/input bundle files khớp hashes. EOS/config/reserve/native coverage được kiểm offline, không inference/scorer mới. BART/LED0 control khớp baseline. LED3/4 giảm lặp nhưng còn malformed endings/format artifacts; Qwen384 hết map truncation nhưng2/2reducers vẫn chạm384, concise256 không cải thiện exhaustion.21finalEOS dưới768,0cap350cuts. Chưa profile/config winner, pilot40/selection300/final523, cross-session reuse hoặc formal-runtime scorer mới. Registry/cap350/cohort40/300/523 giữ nguyên;512 vẫn chưa chạy dù observed384 headroom vượt predeclared1GiB guard. Current evidence: [returned trial audit](../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/development-trials-261019-2122/returned_trial_audit_v1.json).

## P4.1 controlled development — historical preparation snapshot

[Notebook P4.1](../benchmark/experiments/notebooks/tib-p41-development-colab-261019.ipynb) và [ZIP tương ứng](../benchmark/research-data/tib-p41-261019-2122/tib-p41-development-261019.zip) đã chuẩn bị để tự chạy. Upload ZIP vào private `MyDrive/TIB_P41_DEVELOPMENT_261019/`, mở notebook trên T4 rồi chạy tuần tự. Default7 trials (BART1/LED3/Qwen3), cùng3 staged sources/cap350; không selection300/final523. Qwen512 deferred và không chạy mặc định. Checkpoints/logs tách baseline; cell cuối xuất evidence ZIP gồm cả runner code/registry, source-only inputs và outputs. Nên dùng runtime T4 mới, giữ guard11.5h.

Trials thêm effective-config/EOS/reserve/possible-forcedEOS/repetition/ending flags, full native window planning và ordered reduction diagnostics. Flags không tự retry/exclude, không chứng minh quality/factuality. Baseline/current actual T4 evidence phía dưới giữ nguyên; P4.1 **chưa có actual T4 trial outcomes**. [Implementation và trial matrix](../plans/reports/implementation-261019-2122-tib-p41-development-trials-report.md), [P4.1 amendment](../plans/261019-0035-summarization-model-benchmark/phase-04a-generation-development-trials.md).

## Evidence đã audit từ ZIP người dùng — 2026-10-19

[Audit P4](../plans/reports/evidence-audit-261019-2013-tib-p4-returned-capacity-report.md) và [technical execution receipt v2](../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/technical_execution_receipt_v2.json) là trạng thái hiện hành.159 files/155 JSON envelopes PASS;9 neural outputs và12 CPU smoke outputs replay offline từ saved outputs, không model inference mới. BART/LED/Qwen3 actual Tesla T4 FP16 fresh3/3 trên `valid:644/341/886`; bundlev2 cho BART/Qwen, bundlev3 cho LED. Receipt lỗi LED đầu giữ lịch sử. Prepared notebooks local vẫn không có saved cell outputs; xác nhận thực thi dựa trên logs/checkpoints trả về.

Scoped T4 capacity PASS không là profile admission: LED có repetition/incomplete endings, BART long final bằng first map output; LED4/9 map và Qwen6/9 map+2/2 reduce exhaust256tokens trước EOS. Cả9 final EOS dưới768,0/9 cap350 cuts; giữ350maximum nhưng final-lock chờ development review. Không đổi config/cap/cohort từ audit. Mount/readback đã xác minh; cross-session reuse và quota chưa có. Pilot40 chưa hoàn tất; selection300/final523 chưa chạy. Không suy p95 hoặc full-study runtime từ một mẫu mỗi stratum. [Output review](../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/development_output_review_v1.json).

Các mục preparation/download dưới đây là snapshot lịch sử, không phủ định evidence thực thi mới. Current remaining gates: output/reserve/effective runtime review, expanded pilot/cost, formal-runtime scorer, cross-session store, full-study quotas/projection, cap/profile freeze trước selection và final seal sau lựa chọn.

## LED download correction — 2026-10-19

User-run Colab log reports BART exit0 and LED exit1. BART exit0 alone does not verify its actual GPU/profile receipt. LED failed before model loading: the original downloader excluded `.bin` weights. The official pinned LED revision `0f8b26971c44af9d4e21edd17ccb5e000f22dac1` contains `pytorch_model.bin` and no safetensors weights; its file inventory was verified through the public Hugging Face API. This is not a measured VRAM failure. TensorFlow CUDA warnings and the `torch_dtype` deprecation did not cause this exception.

The corrected downloader prefers safetensors where available and otherwise downloads PyTorch `.bin` weights, including supported sharded layouts. [Notebook v3](../benchmark/experiments/notebooks/tib-p4-feasibility-colab-261019-v3.ipynb) pairs with [ZIP v3](../benchmark/research-data/tib-p4-261019-1802/colab-package-v3/tib-p4-feasibility-261019-1802-v3.zip); it runs **LED only** on the same three staged sources and existing private checkpoint folder. Both are prepared locally, not uploaded or executed by the agent. Wait for the original neural loop to finish before starting recovery. Upload both v3 files if using this recovery route; do not mix notebook/ZIP versions. Keep previous BART outputs and failed LED receipts intact. No revision/profile/cap/cohort changed. The original technical receipts and v2 bundles remain historical evidence; the v3 bundle receipt binds corrected source hashes.

For the existing v2 Colab runtime, a smaller recovery is to download `pytorch_model.bin` with `hf_hub_download` at that exact revision, then change the neural cell candidate list to `['led']` and rerun only that cell. The existing downloader retains already-cached weights; it does not delete the manually downloaded file. Keep its session deadline checks. No T4 PASS is claimed until a new actual LED capacity receipt completes on T4. [Correction report](../plans/reports/debug-261019-2004-tib-led-checkpoint-download-report.md).

2026-10-19. Tiếp tục [qualification guide](tib-summarization-qualification.md), giữ development40/300 và eligible native test523. Chưa model selection/final seal; diagnostics40 nằm trong final cohort.

## Evidence hiện tại

- Scorer: [CPU-ready receipt](../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/scorer_ready_receipt.json), [spec v2](../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/scorer_spec_v2.json). ROUGE-1/2/L F1, XLM-R-large layer17 BERTScore, project-specific source-sentence similarity. IDF=false/no fit; CPU4threads/batch1/FP32, sentence128/BERT512 tokens.
- Actual pinned pretrained native/window probe PASS; controlled identity fixture đủ5metrics PASS. Đây là CPU fixture capacity, chưa full-corpus scorer throughput/budget hoặc portable Colab scorer-ready receipt.
- [Output policy](../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/output_policy.json): eligible native train4.213, nearest-rank p95=333, ceil25→350 whitespace words maximum. Không dùng validation/test reference chọn cap. Giá trị đã được user duyệt; final-lock sau profile feasibility, trước selection.
- [Candidate profiles](../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/candidate_profiles.json): lead3/lexrank/bart/led/qwen3. Native output768/map-reduce256 là proposals, không admission. Local CPU controls6/6 và native planning9/9 trên3 staged sources PASS.

## Colab và Drive

[Notebook đã upload](https://colab.research.google.com/drive/1ONVvp8DShLMeu7IprGbuFiJD0IL3NEj-) và [ZIP riêng tư](https://drive.google.com/file/d/1QXA5FuDFyTPXDA0B0Vz5q5uCtR1YhCEQ/view?usp=drivesdk) nằm trong [folder](https://drive.google.com/drive/folders/1gQc-iHsdjTCCCrNDiR340sgfTX8mswIn). Readback: folder/ZIP/notebook `shared=false`, owner-only. Không public-share.

ZIP63.206bytes, SHA256 `600fc9734dee141e7881a90812273fb34852d15d88a1d3f8aa6b4570fa7db6b3`; chỉ scripts/profiles và valid:644, valid:341, valid:886 source-only với attribution/license. Không abstract, selection/test data hoặc model weights. [Bundle receipt](../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/colab_bundle_receipt_v2.json), [scope amendment](../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/colab_authorization.json).

1. Mở notebook bằng account owner của folder; runtime GPU T4. A100 chỉ tạo evidence riêng, không PASS T4 gate.
2. First cell mount Drive; OAuth client hiển thị **Google Drive for desktop**. Runtime T4 đã được cấp, nhưng consent đang chờ user; auto-review từ chối Continue khi chưa có approval cụ thể client/scope. Không bypass, không mở public sharing để tránh consent.
3. Notebook kiểm ZIP/file SHA, thử mounted-store write/fsync/rename/readback, chạy CPU controls rồi từng neural model trong process riêng. Model downloads đúng revisions; code không dùng abstract làm prompt.
4. Checkpoint/logs ở `MyDrive/TIB_P4_FEASIBILITY_261019/checkpoints`. Completed node atomic records có input/profile/runtime/source hashes, layer/node, output, timing và backend token counts. Attempt markers giữ status started/failed/completed; partial không được reuse.
5. Deadline11.5h gồm setup; subprocess timeout giữ dưới12h. Nếu hết thời gian, giữ partial evidence. Resume chỉ khớp identity/hardware/packages; cached-only/resumed run không tự trở thành fresh T4 capacity proof.
6. Sau chạy, kiểm từng `capacity-*.json` envelope bằng helper restore; xem actual GPU, load/VRAM allocated+reserved/RAM, calls/tokens/latency/failures/raw-delivered lengths/capping. Không dùng A100 thay T4, không suy toàn cohort từ3 records.

Notebook local [prepared version](../benchmark/experiments/notebooks/tib-p4-feasibility-colab-261019-v2.ipynb) chưa có saved runtime outputs. Remote notebook đã bắt đầu first cell và chờ consent; chưa neural generation. Prepared v1/bundle v1 giữ lịch sử draft, v2 là bản active đã upload.

First mount attempt sau đó đã báo lỗi trong khi consent chưa hoàn tất. Sau approval phải rerun mount/notebook; không coi đây là model failure hoặc một capacity run hoàn tất. Exact iframe error chưa extract; [launch status](../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/colab_launch_status.json) giữ giới hạn đó.

## Local verification và dependencies

Chạy từ `benchmark/`. `rouge-score==0.1.2` được cài trong ignored `research-data/tib-p4-261019-1802/python-deps`, không global Python. Phải thêm đường dẫn đó và benchmark root vào PYTHONPATH khi chạy scorer/tests. Các package pins khác ghi trong spec; khác runtime cần explicit preselection amendment và probe riêng.

```powershell
$env:PYTHONPATH = "$PWD/research-data/tib-p4-261019-1802/python-deps;$PWD"
python -m pytest tests/test_tib_benchmark_output.py tests/test_tib_benchmark_scorer.py tests/test_tib_benchmark_budget.py tests/test_tib_benchmark_checkpoint.py --basetemp research-data/tib-p4-local-tests-new -q
```

Không rerun readiness writer vào existing receipt. New technical evidence dùng version mới; cap/code/metric amendment trước selection, bảo toàn artifact cũ. Không chạy old120 lại.

## Budget và điều kiện tiếp theo

[Budget](../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/compute_budget.json) và [projection status](../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/projection_status.json) giữ REQUIRED_NO_START. User limit dưới12h được chuyển thành technical guard11.5h; không tự suy tổng GPU/CPU-hours, số phiên formal hoặc storage quota.

Projection kiểm actual scorer/store/trial/admission receipt files+hashes, measured model profiles, mọi config trials/map/reduce/final calls, init/scoring/retries, per-node checkpoints/attempt ledgers, reload/transfer/storage/session reserve. Full523 →500 →400; không fit400 thì blocked. Native counts và six CPU outputs không cấp phép formal run.

Còn mở: OAuth consent; actual T4 pretrained load/generation/capacity receipts; cross-session Drive survival; representative timing/tail measurements; config admission/trials; final cap feasibility lock; numeric full-study quotas/projection và final cohort/diagnostics seal. Không winner mới.
