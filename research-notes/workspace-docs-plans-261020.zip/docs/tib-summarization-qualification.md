# TIB summarization qualification: local operations

Operational guide, 2026-10-19. Windows/PowerShell, 16 GB RAM; CPU qualification complete. Local GPU is RTX 4050 Laptop, 6,141 MiB, driver 610.88; no T4 measurements in this slice.
Read the [benchmark overview](../benchmark/README.md), [P2 contract](../plans/261019-0035-summarization-model-benchmark/phase-02-eda-and-visualization-gap-closure.md) and [P3 contract](../plans/261019-0035-summarization-model-benchmark/phase-03-dataset-qualification-and-cohort-freeze.md).
This continues the [historical P1 audit guide](./tib-summarization-local-audit.md); its earlier pending statuses are historical.

## Scope and evidence

Use is bounded to local, private, noncommercial analysis with attribution retained. Do not send source/reference text to external generation APIs or publicly share source, reference or expressive outputs under this policy.
The pinned snapshot is `e6ab9fd7c6acd164f3284b8c4b17eb9d94681eee`: train 7,282, valid 910, test 911; total 9,103.
Canonical input is released `transcript`; `transcript_segments` is a diagnostic sidecar. No timestamp prompt or transcript reconstruction occurs.

| Gate | Verified evidence and limit |
|---|---|
| Rights | 6,171 sources conditionally allowed for this local use; 5,270 pass both source/reference rights: train 4,215, valid 532, test 523. These counts precede content/exposure qualification. |
| Reference usability | A=0, B=9,095, C=8 empty references. A+B is primary, subject to independent gates; A-only sensitivity currently has no records. |
| Targeted reuse review | All 225 historical flags across 18 groups reviewed conservatively as uncertain B. AI-assisted review used abstracts, titles and limited source spans; it is neither gold annotation nor full-transcript certification. |
| Historical pool | 9,103 → 9,002 legacy structural rows → 8 empty + 225 reused flags → 8,769 historical candidates. New qualification need not reproduce 8,769. |
| EDA | All 9,103 canonical records and BART/LED/Qwen3 native-token counts completed on CPU, with completion receipt. |
| Source groups | 22 accepted edges; 37 records in nonsingleton groups; 9,082 components, including seven cross-split components. Approximate retrieval, unknown recall. |
| Qualification | Data-eligible train/valid/test: 4,215/532/523; after exposure protection: 4,213/464/523. Eligible historical exposures remove two train and 68 valid rows; known-linked tuning/test overlap is zero. |
| Development seal | Pilot40 + selection300 validation IDs sealed without fallback; `final_test_sealed=false`, `generation_executed=false`. |

See the [rights report](../plans/reports/research-261019-1703-tib-source-use-policy-report.md) and [reference report](../plans/reports/qualification-261019-1703-tib-reference-usability-report.md) for decisions, hashes and review limits.
The old 120-record cohort, nine-record pilot and their predictions remain unchanged.

The [execution report](../plans/reports/implementation-261019-1703-tib-qualification-cohort-report.md), [executed notebook](../benchmark/experiments/notebooks/diagnostics/tib-summarization-gap-closure-261019.ipynb) and [compact receipt](../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/execution_receipt.json) bind the completed CLI audit and six fresh-kernel verification/render cells, zero errors; the notebook does not rerun the full canonical scan.
Original paper Lead-3/Oracle attribution is verified; current candidate profiles are not paper reproductions.

## Paths and prerequisites

Run commands below from `benchmark/` using a Python environment with the required installed packages: `pyarrow`, `numpy`, `pandas`, `numba`, `transformers` and `matplotlib` for the complete workflow.
The tokenizer directory must already contain BART, LED and Qwen3 tokenizer assets plus their hash receipt; these operations do not download model weights.

```powershell
$Snapshot = 'research-data/tib-evidence-261019-1507/e6ab9fd7c6acd164f3284b8c4b17eb9d94681eee'
$Local = 'research-data/tib-qualification-261019-1703'
$Registry = 'experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703'
```

Keep raw/canonical text, review excerpts and large ledgers in ignored `research-data/`. Registry policies and compact receipts contain provenance, decisions and hashes.
Do not change frozen policies in place. Amend version/root, regenerate affected evidence, and revalidate downstream bindings before outcomes.
Rights/base-reference/EDA exporters reject existing destinations. Reference `--apply-reviews` deliberately updates an existing base ledger and summaries; use only its matching frozen review packet.
`--validate-reviews` checks actual source spans and hashes, preserves ledgers and exclusively creates `reference_review_validation_v2.json`; an existing receipt is rejected.
Grouping uses hardwired paths and can overwrite outputs; never rerun it against completed evidence. Its policy comparison rejects changed policy values; a rerun/amendment needs separately versioned paths in the implementation.
Qualification rejects an existing `qualified_cohort/` and exclusively creates its policy. An interrupted attempt is evidence to inspect, not a destination to overwrite.

## Inspect or reproduce each stage

These help commands were checked without executing qualification or generation:

```powershell
python -m experiments.scripts.tib_model_benchmark_rights --help
python -m experiments.scripts.tib_model_benchmark_references --help
python -m experiments.scripts.tib_model_benchmark_eda --help
python -m experiments.scripts.tib_model_benchmark_qualification --help
```

The following rights/reference example uses a **new unused** local replay destination and compact-summary directory. It reads the existing frozen policies; choose a fresh suffix per attempt.

```powershell
$Replay = 'research-data/tib-qualification-replay-new'
$Compact = 'research-data/tib-qualification-replay-new/compact'
python -m experiments.scripts.tib_model_benchmark_rights --policy "$Registry/source_use_policy.json" --fields research-data/tib-evidence-261019-1507/field-rights-ledger-v2.jsonl --raw-rights research-data/tib-evidence-261019-1507/local-audit/rights_ledger.json --output $Replay
python -m experiments.scripts.tib_model_benchmark_references --data "$Snapshot/data" --policy "$Registry/reference_policy.json" --output $Replay --compact $Compact
python -m experiments.scripts.tib_model_benchmark_references --data "$Snapshot/data" --policy "$Registry/reference_policy.json" --output $Replay --compact $Compact --apply-reviews "$Registry/historical_reuse_group_reviews.json"
python -m experiments.scripts.tib_model_benchmark_references --data "$Snapshot/data" --policy "$Registry/reference_policy.json" --output $Replay --compact $Compact --validate-reviews "$Registry/historical_reuse_group_reviews.json"
```

For EDA, the output must be new and outside the immutable snapshot:

```powershell
python -m experiments.scripts.tib_model_benchmark_eda --snapshot $Snapshot --tokenizers "$Local/tokenizers" --output "$Replay/eda"
```

The [canonical helper](../benchmark/experiments/scripts/tib_model_benchmark_canonical.py) retains raw/normalized text SHA-256 and raw-character offset runs using NFC plus whitespace normalization only.
EDA writes compressed canonical records, text-free record metadata, split distributions, figures and a final file-hash receipt.
Native counts omit special tokens. Illustrative window lower bounds omit wrappers, overlap and reduction: they are metadata diagnostics, not measured calls, safe context capacity, runtime or T4 feasibility.
`W_global` remains unset; ratify it from train/development reference evidence and product constraints before selection, never from each test reference.

The [group module](../benchmark/experiments/scripts/tib_model_benchmark_groups.py) has no CLI arguments. This command targets its hardwired original slice; run only as its initial controlled audit:

```powershell
python -m experiments.scripts.tib_model_benchmark_groups
```

It retrieves source candidates via bottom-256 fivegram sketches, identity metadata, author/title flags and the historical pair queue. Near edges require ≥100 shared fivegrams and Jaccard ≥0.30 or shorter-source containment ≥0.80, then string-shingle confirmation.
Author/title matches alone never group records; repeated abstracts are not source-duplicate evidence. Retrieval is approximate, recall unknown; groups represent known dependencies only.
Require all 2,658 historical queued pairs checked and the known train:2341 / valid:433 / test:782 three edges reproduced. A progress line is not a completion receipt.
The additive `group_validation_review_fix_receipt.json` validates all 9,103 source hashes, all 22 accepted pairs and identical graph reconstruction after restoring the runner's missing `digest` import. Original artifacts are preserved; the full rejected/candidate scan was not rerun.

## Development seal and generation blockers

After upstream completion and hash validation, the [qualification CLI](../benchmark/experiments/scripts/tib_model_benchmark_qualification.py) joins all 9,103 IDs and checks raw text-hash agreement:

```powershell
python -m experiments.scripts.tib_model_benchmark_qualification --root $Local --registry $Registry --old-manifest experiments/registry/datasets/tib-rq2-rq4-120-cohort-261012.json
```

This command mutates evidence: invoke once only after receipts pass. Replay directories above do not automatically contain every prerequisite needed for this seal.
Required inputs include EDA receipt, completed source-group summary, targeted-reference validation, rights replay-validation and `group_validation_review_fix_receipt.json`. Their bound evidence must still match.
Group replay requires `status=pass` and exact booleans `all_9103_hashes_revalidated`, `accepted_pairs_revalidated`, `graph_reconstruction_identical` all true. It binds summary/ledger/pair/policy hashes and current runner/core implementation hashes; missing, false or changed bindings block the seal.
Nonempty canonical source, English metadata, A/B reference and explicit rights permission determine data eligibility; rights HOLD cannot be bypassed by B.
Exposure then excludes old120/9 IDs and linked known tuning groups. Eligible native test groups are protected before validation allocation; eligible validation groups are protected from train development.
EDA exposure alone does not exclude native test; it also does not justify pristine/unseen/pretraining-clean claims.
Source-length cutpoints come from eligible training records. Deterministic constrained largest-remainder allocation selects pilot40 validation records and reserves every pilot-linked group before selection300.
Only availability below300 after pilot group reservation permits selection200, before outputs. Below200 stops; no test borrowing. Pilot and selection IDs and known groups must be disjoint.
The completed [development seal](../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/development_cohort.json) records IDs, groups, quotas, no fallback and policy hashes with `final_test_sealed=false` and `generation_executed=false`.
It does not authorize generation: scorer readiness, candidate profiles, `W_global`, measured T4 capacity and compute/storage/retry budgets remain runtime gates. The detected local RTX 4050 is not T4 capacity evidence.
Final native-test N/IDs and diagnostics require subsequent P4 selection/budget decisions and a separate seal. Do not replace failed test records or filter membership after model outcomes.

## Troubleshooting and unresolved gates

On missing receipts, input hashes, frame mismatch, incomplete historical replication or existing outputs: stop, inspect the recorded failure and amend to a new version where needed. Never rename a partial run as completed.
Current unresolved gates: global output cap, runtime profiles/scorer, measured T4 capacity, compute/storage/retry budgets and final-test seal. EDA, group audit and development-ID seal are complete; no new model result or winner is established by this workflow.
