# RQ2 → RQ4: tiếp nhận kết quả và bước nghiên cứu tiếp theo

Ngày chuẩn bị: 2026-10-13. Người dùng báo RQ2 đang chạy; chưa kiểm tra runtime/Drive hay nhận receipt của lượt chạy đó. Tài liệu này chuẩn bị phân tích, không thay đổi notebook, protocol, cohort, checkpoints hoặc khởi động GPU khác.

**Chuẩn bị đã kiểm tra offline (2026-10-13):** import bundle loader/runtime thành công; `validate_frozen_inputs` PASS trên bundle 120 mẫu cục bộ, manifest và protocol hiện tại. Kiểm tra này xác nhận đúng 120 IDs, 40/40/40, content/token hashes, scorer metadata và frozen code hashes. Không tải model hoặc chấm điểm. Lệnh audit receipt bên dưới chỉ có thể kiểm tra đầy đủ sau khi nhận kết quả thật.

## 1. Gói kết quả cần giữ

Notebook chính thức: `benchmark/experiments/notebooks/rq2-tib-120-evaluation-colab.ipynb`. Thư mục mặc định trên Drive: `MyDrive/RQ2_TIB_120_20261012/formal-run-v1/`.

| Tệp | Vai trò |
|---|---|
| `frozen-receipt.json` | Bằng chứng chính: identity, 120 IDs, dự đoán, trạng thái/lỗi, scores, dispatches, tài nguyên và sessions |
| `dispatches.jsonl` | Đối chiếu lịch sử lời gọi với sealed receipt; giữ cả unknown usage |
| `aggregate-report.json` | Kết quả tổng hợp; phải tái tính từ receipt trước khi dùng |
| `per-item-results.csv` | 120 dòng, hai summaries, references, ba metric và tài nguyên; dùng kiểm tra từng mẫu |
| `paired-coverage.png` | Độ phủ từng metric trên 120 IDs |
| `paired-stratum-deltas.png` | S3−S1 theo short / medium / long |
| `primary-paired-distribution.png` | Phân bố paired ROUGE-L differences |
| `measured-arm-resources.png` | Tài nguyên được ghi nhận, không thay cho raw receipt |

Giữ notebook đã chạy có outputs và thư mục `data/` cùng phiên bản. Không có `parent_index.json` hoặc failure ledger riêng trong runner này: lỗi nằm trong từng row của receipt. Nếu dừng sớm, receipt/log vẫn có giá trị; thiếu CSV/plots chưa chứng minh generation thất bại. Sao chép khi writer đã dừng để tránh receipt/log thuộc hai thời điểm khác nhau. Lưu raw copy bất biến vào thư mục ignored riêng, ví dụ `benchmark/experiments/outputs/rq2_tib_120_received_261013/`; không chép đè pilot hoặc run đang hoạt động.

## 2. Kiểm tra identity trước khi đọc kết luận

Các tệp chuẩn:

- `benchmark/experiments/registry/datasets/tib-rq2-rq4-120-cohort-261012.json`
- `benchmark/experiments/registry/datasets/tib-rq2-rq4-120-protocol-261012.json`
- `benchmark/experiments/outputs/rq2_tib_120_261012/data/tib-evaluation-120.jsonl.gz`

Chạy từ workspace bằng PowerShell sau khi đã đặt bản sao kết quả tại đường dẫn ví dụ. Đổi duy nhất `run` nếu thư mục nhận khác. Đoạn dưới chỉ đọc dữ liệu và in kết quả; không gọi generator/scorer, không tải model, không ghi checkpoints. Dùng Python môi trường benchmark nếu Python mặc định thiếu dependency.

```powershell
Set-Location C:\Users\hung\Documents\GitHub\multimodal-lecture-summarizer\benchmark
@'
import json
from collections import Counter
from pathlib import Path
from experiments.scripts.rq2_tib_benchmark_bundle import load_benchmark_bundle
from experiments.scripts.rq2_tib_frozen_runtime import _validate_receipt
from experiments.scripts.rq2_tib_frozen_analysis import summarize_frozen

run = Path('experiments/outputs/rq2_tib_120_received_261013')
registry = Path('experiments/registry/datasets')
manifest = json.loads((registry/'tib-rq2-rq4-120-cohort-261012.json').read_text(encoding='utf-8'))
protocol = json.loads((registry/'tib-rq2-rq4-120-protocol-261012.json').read_text(encoding='utf-8'))
bundle = load_benchmark_bundle('experiments/outputs/rq2_tib_120_261012/data/tib-evaluation-120.jsonl.gz')
receipt = json.loads((run/'frozen-receipt.json').read_text(encoding='utf-8'))
assert receipt['manifest'] == manifest and receipt['protocol'] == protocol
_validate_receipt(receipt, bundle)
dispatches = [json.loads(line) for line in (run/'dispatches.jsonl').read_text(encoding='utf-8').splitlines()]
assert dispatches == receipt['dispatches'], 'Receipt/log differ: preserve both; audit snapshot timing'
assert Counter(row['length_stratum'] for row in receipt['rows']) == {'short':40,'medium':40,'long':40}
summary = summarize_frozen(receipt, manifest, protocol)
saved = run/'aggregate-report.json'
if saved.exists():
    assert json.loads(saved.read_text(encoding='utf-8')) == summary, 'Stale or changed aggregate'
print(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False))
print('Hardware:', receipt['identity']['profile'])
print('Generation sessions:', receipt.get('sessions', []))
print('Metric sessions:', receipt.get('metric_sessions', []))
'@ | python -
```

Đây là kiểm tra integrity/identity, không chứng nhận tự động mọi claim hoặc hardware. Đối chiếu profile thực tế: Tesla T4, FP16, map batch 2, pinned Qwen revision và package versions; kiểm tra scorer identity nếu có secondary scores. Checksum chứng minh tính nhất quán, không chứng minh chất lượng khoa học. Code khác frozen hashes phải dừng để đối chiếu phiên bản; không sửa protocol để làm receipt hợp lệ.

## 3. Bảng kết quả RQ2 cần hoàn thành

| Nội dung | Quy tắc đã chốt |
|---|---|
| Mẫu số | Selected luôn 120, mỗi stratum 40; không thay IDs chậm/lỗi |
| Coverage | S1/S3 success riêng; paired_scored và missing IDs riêng cho mỗi metric |
| Primary | ROUGE-L F1 theo `unicode_word_lcs_rouge_l_f1_v1`; mean S1, S3 và S3−S1 trên paired successful intersection |
| Secondary | BERTScore theo abstract; source SBERTScore riêng, không gộp thành factuality score |
| Missingness | Missing khác zero; lỗi semantic scoring không xóa summaries/ROUGE |
| Strata | short / medium / long; balanced-strata delta là bổ sung, không thay primary record-weighted mean |
| Sensitivity | 5.000 whole-component resamples, seed 20261009, dependence_group và author_group; exploratory only |
| Claim | Finite exposed-reference cohort, text-only creator-abstract agreement; không unseen generalization, factuality hay multimodal benefit |

Nếu metric dùng các intersections khác nhau, không diễn giải khác biệt giữa metrics như đo trên cùng tập hoàn chỉnh. Khi thiếu mẫu, effect conditional on successful scoring; báo rõ số lượng và ID, không gọi full-120 effect. S3 thay cả boundary và chunk count/length nên không tách riêng tác động boundary placement.

## 4. Phân tích RQ4 ngay từ lượt chạy này

Không cần thêm GPU run để lập bảng chi phí mô tả cho S1/S3. Giữ hai bảng riêng:

1. **Tổng tài nguyên thực thi:** mọi attempt đã ghi nhận, kể cả lỗi; prompt/output tokens, segmentation seconds, generation seconds, incomplete usage và số dispatch unknown. Tổng hiện có không phải paired latency effect.
2. **So sánh cùng record:** trên intersection hai arm hoàn tất và có đủ trường chi phí, tính S3−S1 của `segmentation_seconds + generation_seconds`, cùng prompt/output tokens; báo mẫu số, breakdown theo stratum. Đây là phân tích tài nguyên bổ sung, không primary quality endpoint hay significance test mới. Tách overhead chung và thời gian metrics khỏi arm generation.

VRAM: lấy maximum measured attempt của allocated/reserved bytes theo arm; không cộng peaks, không gọi đây là VRAM tăng thêm riêng của pipeline. `aggregate-report.json` không chứa VRAM peaks/session totals: phải giữ receipt và CSV. Không so timing OCR lịch sử với timing T4 này.

Giữ generation sessions, initialization, stop reasons, metric initialization và per-row semantic seconds để giải thích resumes. Soft limit 10h generation / 12h session được kiểm giữa dispatches; không đảm bảo tổng nhiều phiên dưới 12h. Không cộng overlapping/nested timers để tuyên bố wall time thực tế. One repetition không ước lượng độ biến thiên timing. Chưa có đơn giá/billing nên USD cost là **unmeasured**, không suy từ token pricing API.

Biểu đồ quality-versus-measured-time cho hai cấu hình chỉ hỗ trợ mô tả trade-off. Chưa có quality gate hoặc thử nghiệm toàn hệ thống đã chốt; không tuyên bố Pareto tối ưu của hệ thống multimodal. Actual tokens có thể khác dù allocated output caps bằng nhau.

## 5. Quyết định sau audit

| Tình trạng | Bước tiếp |
|---|---|
| Identity sai hoặc receipt/log lệch | Giữ raw evidence; kiểm tra phiên bản/snapshot; chưa tổng hợp claim |
| Generation còn not_attempted | Báo partial trên 120; kiểm tra stop_reason và khả năng resume theo identity, không tự khởi chạy phiên thứ hai |
| Có failed/interrupted/evaluation_failed | Liệt kê ID và unknown usage; không chỉnh status hoặc tự retry để làm đẹp coverage |
| Generation đủ, secondary thiếu | Giữ primary result; kiểm tra scorer metadata/lỗi; không regenerate summaries để chữa scorer |
| Receipt hợp lệ và coverage đã đối chiếu | Viết báo cáo RQ2/RQ4 với các mẫu số, missingness, sensitivity, tài nguyên và limitations |
| S3 kém hơn hoặc inconclusive | Giữ negative/no-selection result; không tuning trên cohort này rồi gọi confirmatory |

### Mẫu báo cáo sau khi nhận kết quả

Lưu báo cáo vào `benchmark/docs/results/rq2-rq4-tib-120-<ngày-audit>.md`. Các ô PENDING phải được điền từ raw receipt đã qua audit; không sao chép số của pilot. Ghi run root, SHA-256 các raw artifacts, dataset/model revision, protocol hash và thời điểm snapshot ở đầu báo cáo.

| Kết quả chất lượng | Paired / selected | S1 mean | S3 mean | S3−S1 | Missing IDs / lý do |
|---|---|---|---|---|---|
| ROUGE-L — primary | PENDING / 120 | PENDING | PENDING | PENDING | PENDING |
| BERTScore — secondary | PENDING / 120 | PENDING | PENDING | PENDING | PENDING |
| Source SBERTScore — secondary | PENDING / 120 | PENDING | PENDING | PENDING | PENDING |

Thêm cùng bảng cho từng stratum (selected 40); ghi grouped sensitivity cho cả `dependence_group` và `author_group`. `generated` là cặp có primary scores; `completed` còn yêu cầu semantic scoring hoàn tất, nên hai count có thể khác nhau.

| Kết quả tài nguyên | S1 | S3 | Mẫu số / giới hạn |
|---|---|---|---|
| Tổng segmentation / generation seconds | PENDING | PENDING | Mọi attempt, kể cả lỗi; chưa là paired effect |
| Tổng prompt / output tokens đã biết | PENDING | PENDING | Ghi unknown dispatches và incomplete attempts riêng |
| Mean paired segmentation + generation seconds | PENDING | PENDING | Cùng intersection đủ hai arm và cost fields; kèm delta và strata |
| Peak allocated / reserved VRAM bytes | PENDING | PENDING | Maximum measured attempt; không cộng peaks |
| Initialization, generation sessions, metric sessions | PENDING | PENDING | Ghi riêng overhead và resumes, tránh cộng nested timers |
| Monetary cost | unmeasured | unmeasured | Không có billing evidence |

Kết luận phải nêu coverage và missingness trước effect; sau đó mô tả trade-off chất lượng/tài nguyên trong đúng cohort/profile. Nếu bằng chứng chưa đủ, giữ `no_selection`. Cập nhật evaluated counts trong README và owning RQ2/master plan chỉ sau audit này.

## 6. Giai đoạn độc lập tiếp theo: RQ3 và visual components

Quyết định 13/10: chuẩn bị RQ3 bằng **EduVidQA**. **EduViQA và SSLectures không sử dụng trong thực nghiệm hiện tại**, chỉ giữ hồ sơ khảo sát lịch sử; không lên lịch như fallback hoặc extension. Lý do là vai trò nghiên cứu và qualification, không phải thiếu PDF paper. Xem [phạm vi dataset hiện hành](dataset-use-scope-261013.md).

RQ3 chưa sẵn sàng chạy retrieval: review ngày 2026-10-10 ghi **0 QA rows có source context qualified**, sampled transcript ParseError và sáu timebase contradictions. Annotation EDA có 5.234 released rows/296 video groups nhưng không có relevance/evidence-span GT độc lập. Đây là trạng thái trong tài liệu hiện tại, chưa phải một lần kiểm tra mạng mới.

Chuẩn bị RQ3 theo thứ tự: chọn endpoint → khai báo cohort/split và access ledger → phục hồi transcript gắn đúng video ID → EDA context/duplicate/missingness → freeze reader, candidates, chunking, normalization, metric và budget → tạo notebook đánh giá thật. Answer-only QA cần source context và released answers; không bắt buộc video/timestamps nếu không dùng chúng. Recall@k/evidence quality vẫn HOLD nếu không có relevance GT độc lập. Không tự tạo GT hoặc chọn context quanh đáp án như retrieval evidence.

Nếu ưu tiên kết quả thành phần trước RQ3, scope hiện tại ưu tiên OCR crop recognition; LVVO released-image detection là hướng phụ. OCR đã có provisional CPU comparison: tái sử dụng evidence, xử lý label-conflict review, không chạy lại mù hoặc đổi nhãn theo OCR predictions. Không mở thêm mô hình/dataset hoặc notebook placeholder trong lúc chờ RQ2.

## Câu hỏi còn mở

- Receipt thực tế có đủ generation, ba metrics và resource fields không? Chưa nhận để kiểm tra.
- Transcript cohort nào của EduVidQA có thể phục hồi/version được? Retrieval relevance GT vẫn chưa có.
- Sau báo cáo RQ2/RQ4, ưu tiên tháo blocker RQ3 hay adjudication OCR? Chưa khởi động benchmark mới.
