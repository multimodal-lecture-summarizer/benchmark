"""Restore one audited empty R5 checkpoint from its sealed aggregate; no model runs."""
import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import uuid

ANCHORS = {'candidate': 'doctr_fast_base_parseq_t4', 'frame_id': 'Frames/test/14/18/00_02_05_00001.png', 'checkpoint_relative': 'doctr_fast_base_parseq_t4/records/Frames/test/14/18/00_02_05_00001.png.json', 'expected_checkpoint_sha256': 'ce3e6fddb2e6d7ed09cca3196eaba7c21b90795c74ccfff27779999cbfba8222', 'prediction_sha256': 'a0c67b6c66cebfd402facaadd81c706f1b856de28ce237849989a639f1999efe', 'anchors': {'prepared-data.json': '67d326871aa629e5336ec9a8c74b70d6940c121e023d00a5d70af6968d924554', 'doctr_fast_base_parseq_t4/candidate-complete.json': '37064410812e9c4bcf930122d590c8a61de4772c468176f5279852ac1606587f', 'doctr_fast_base_parseq_t4/preflight.json': '9d9e4e85321fdc9e10989711a1657b707f050555debaed460177bbd2f9edb3c6', 'doctr_fast_base_parseq_t4/train-replay.json': 'f7abba3afa9a046243e76f5429ef64b1d54367c6d175c6503fbceba616f693a4', 'doctr_fast_base_parseq_t4/run-identity.json': '00239de332b2b115ac7724bcf0d276635ade64f5e5b632846dacc1fac5e1091c'}, 'evidence_sha256': 'fadb656015d797af4d8a383082c0a45bf19be334b6b6b2ea334b62df54bf6de3'}
DEFAULT_ROOT = Path('/content/drive/MyDrive/OCR/cvid-spotting-t4-261015-v2-r5')


def sha(data):
    return hashlib.sha256(data).hexdigest()


def encode(value):
    return (json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False)+'\n').encode('utf-8')


def require(condition, message):
    if not condition:
        raise ValueError(message)


def require_idle():
    proc = Path('/proc')
    if not proc.exists():
        return
    for entry in proc.iterdir():
        if not entry.name.isdigit():
            continue
        try:
            args = (entry/'cmdline').read_bytes().split(b'\0')
        except (FileNotFoundError, PermissionError, ProcessLookupError):
            continue
        require(not any(b'experiments.scripts.run_spotting_colab' in arg or
                        b'experiments.scripts.spotting_colab_worker' in arg for arg in args),
                'Benchmark runner/worker still active; stop and confirm before recovery')


def recover(root=DEFAULT_ROOT):
    require_idle()
    root = Path(root).resolve()
    require(not (root/'.execution.lock').exists(), 'Execution lock remains; inspect it before recovery')
    parsed = {}
    for name, expected in ANCHORS['anchors'].items():
        data = (root/name).read_bytes()
        require(sha(data) == expected, 'Audited receipt changed: '+name)
        parsed[name] = json.loads(data)
    cid = ANCHORS['candidate']
    complete = parsed[cid+'/candidate-complete.json']
    aggregate = (root/cid/'predictions.jsonl').read_bytes()
    require(sha(aggregate) == ANCHORS['prediction_sha256'] == complete['prediction_sha256'],
            'Aggregate hash differs from audited evidence')
    rows = [json.loads(line) for line in aggregate.splitlines()]
    frames = parsed['prepared-data.json']['frames']
    require(len(rows) == len(frames) == complete['frames'] == 1754 and
            [r['frame_id'] for r in rows] == [r['frame_id'] for r in frames], 'Aggregate cohort differs')
    record = next(r for r in rows if r['frame_id'] == ANCHORS['frame_id'])
    frame = next(f for f in frames if f['frame_id'] == ANCHORS['frame_id'])
    payload = encode(dict(binding=complete['binding'], image_sha256=frame['image_sha256'],
                          record_sha256=sha(encode(record)), record=record))
    require(sha(payload) == ANCHORS['expected_checkpoint_sha256'], 'Reconstructed checkpoint hash differs')
    path = root/ANCHORS['checkpoint_relative']
    require(path.resolve().is_relative_to(root) and not path.is_symlink(), 'Unsafe checkpoint target')
    before = path.read_bytes()
    if before == payload:
        print('ALREADY VERIFIED: checkpoint is intact; no write needed.')
        return path
    require(before == b'', 'Checkpoint is nonempty and differs; refuse to overwrite')
    journal = root/'recovery-audit'/('doctr-empty-checkpoint-'+uuid.uuid4().hex)
    journal.mkdir(parents=True)
    (journal/'original-checkpoint.bin').write_bytes(before)
    receipt = dict(schema='cvid_checkpoint_recovery_v1', timestamp_utc=datetime.now(timezone.utc).isoformat(),
                   source_evidence_sha256=ANCHORS['evidence_sha256'], checkpoint=ANCHORS['checkpoint_relative'],
                   original_bytes=0, original_sha256=sha(before), restored_bytes=len(payload),
                   restored_sha256=sha(payload), aggregate_sha256=sha(aggregate),
                   model_inference_executed=False, status='prepared')
    (journal/'prepared.json').write_bytes(encode(receipt))
    temporary = path.with_name(path.name+'.recovery-'+uuid.uuid4().hex)
    with temporary.open('xb') as stream:
        stream.write(payload); stream.flush(); os.fsync(stream.fileno())
    require(path.read_bytes() == before, 'Target changed during recovery; refuse overwrite')
    os.replace(temporary, path)
    require(path.read_bytes() == payload, 'Checkpoint readback differs; preserve recovery journal')
    receipt['status'] = 'recovered_and_readback_verified'
    (journal/'complete.json').write_bytes(encode(receipt))
    print('RECOVERY PASS:', path)
    print('SHA256:', sha(payload))
    print('Audit journal:', journal)
    print('Do not rerun model inference. Continue with the existing notebook scoring cell, then export evidence.')
    return path


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-root', type=Path, default=DEFAULT_ROOT)
    args = parser.parse_args()
    recover(args.output_root)
