# MLPDataset slide-transition protocol v1

Status: **rules_frozen / gt_pending / cohort_pending**. Version `mlpdataset-slide-transition-protocol-v1`, dated 2026-10-19. This document and `benchmark/experiments/registry/datasets/mlpdataset-slide-transition-protocol-v1.json` freeze rules before detector comparison. They do not certify reviewed labels, source equivalence, annotation completeness, rights, splits or an evaluation-ready cohort. Changes require a new version and rationale before inspecting comparison predictions.

## Evidence and endpoint

Pinned original instructions: `benchmark/experiments/outputs/mlpdataset_research_261017/sources/mlpdataset__preprocessing__mturk_slide_seg.html`, lines 675–687. They specify the current slide's end, full-slide changes, exclusion of animations/new text on the same slide, and one transition for an inserted video. The release remains immutable. The policy below operationalizes ambiguous cases; its collar and reporting rules are study design choices, not author-supplied official metrics.

Primary endpoint: **internal changes between full instructional slides**, timed at the last fully old decoded frame before any replacement effect begins. For a hard cut this is the frame immediately preceding the first new frame. For a dissolve/wipe, retain separately the last fully old frame, effect onset, effect end and first stable new frame. Never substitute effect midpoint/end or a sparse requested timestamp for the endpoint. An instructional title/agenda slide can qualify; a noninstructional logo/intro or credit/outro does not.

| Event class | Primary treatment |
|---|---|
| Distinct full instructional slide, including same title but distinct slide identity/content | Include after evidence review; same title does not imply same slide |
| Incremental reveal, bullet/text build, cursor/lecturer motion on the same slide | Non-target; do not create a transition |
| Intro/logo, outro/credits, noninstructional title card | Auxiliary class; exclude from primary event list, retain original mapping |
| Inserted video | One auxiliary insertion episode at entry; do not count its internal shots or return as additional insertion events; excluded from primary |
| Blank/black interstitial | Do not invent a separate slide; a resolved slide-to-slide effect has one event at last old frame; ambiguous relation remains HOLD |
| Source start, time zero, true EOF/segment-end marker | Auxiliary source boundary; not an internal slide transition |
| Unclear event identity, source edit, timing, animation versus same-title slide | HOLD with explicit bracket/reason |

Primary full-slide replacement does not require every pixel to change: a new page in a common template can qualify. Review content identity and temporal context, not whole-frame difference scores. Crop/ROI definitions, label repairs and scoring cannot depend on detector output. Any separate all-scene or inserted-video endpoint needs its own named protocol and report.

## Timebase and review decisions

Use decoded presentation order and exact integer PTS plus rational time base. Record source-file SHA256, stream identity, video timestamp origin and the mapping to source-relative seconds; do not assume origin zero or constant frame rate. Retain frame indices, PTS and duplicate-frame relationships. Consecutive identical decoded frames remain distinct temporal frames: the endpoint is the last native frame in the old-content run, not the first unique bitmap. A source may contain duplicate content at nonadjacent times without being the same event. Missing/duplicate/nonmonotonic PTS or unexplained media edition differences require HOLD until an explicit timeline mapping is verified.

Dense 0.25-second sampling and continuous ±5-second clips are triage aids. A reviewed point requires inspection of native frames bracketing the transition and their strict PTS. Incomplete native evidence must retain a closed uncertainty bracket `[last_observed_old, first_observed_changed]`, not a midpoint; status remains HOLD and it cannot enter point GT. Missing old context, effect end or stable new context is recorded explicitly. Store onset/effect-end/first-stable timestamps separately, allowing equality for a cut when supported by native frames. A ±5-second window that misses the event is unresolved, not evidence that no event exists; widen using already cached media if needed.

Each immutable reviewed decision must bind protocol version/hash, video ID, source SHA256, annotation-file SHA256, original zero-based row index/time, evidence paths/hashes, decoded PTS/time base and reviewer/time. Store event class, disposition (`included`, `excluded_non_target`, `hold`), reason, confidence, native evidence status, endpoint point or bracket, effect fields, and original-row-to-reviewed-event mapping. A high confidence coarse observation does not certify a native endpoint. Revisions create a new decision version with predecessor hash. Existing historical clips can support observations only after source/annotation/clip hash checks; passing those checks does not establish native-frame endpoint evidence.

## Inventory, repeats and source boundaries

Keep **all 333 sources / 9,021 released marks** in the inventory. Six empty annotation sources and one missing-folder source are **unlabeled**, not known negatives. The 315 structurally screened sources are candidates only. Original slide/spoken indices and released ordering must survive every mapping. Raw released and reviewed event arrays are separate tracks and may never be combined, silently replaced or compared as if identical GT.

The 15 nonincreasing rows across 11 sources (nine zero gaps, six −0.0001-second gaps) require manual event mapping with adjacent original-row context. Determine whether multiple original indices identify one event, distinct events, export rounding or unresolved ordering. No automatic sort, epsilon shift, timestamp rewrite or deduplication of the release. The scorer's private sorted view preserves original indices and is solely a matching operation on already qualified arrays. Unresolved repeat mappings block the source.

The 18 final released marks overshoot measured media end by approximately 0.028–0.150 seconds. Check exact native first/last PTS and stream duration semantics, original edition equivalence and event identity. Keep outside-source raw labels in inventory with HOLD/timebase status until resolved. Four zero-start rows also need boundary/content classification. The `terminal` flag means final released row only: **do not discard all 326 final rows**. An internal instructional change can occur at the final released row; only verified true source-end/non-target marks are excluded. No global timestamp shift or clamping.

## Eligibility, held intervals and denominator

An eligible scoring unit is a source with a verified media/timestamp mapping, resolved original-row mapping, explicit label track and **fully annotated declared scope**. Version 1 scorer accepts full-source scope `[0, duration)` only. Whole-video recall needs a completeness audit covering intervals between released marks; targeted review around existing labels alone cannot establish missing-event recall. A seven-source unlabeled set cannot be admitted as zero-transition negative GT.

Record held/ignore intervals for provenance, but **any unresolved interval blocks the entire source** in v1. Do not drop uncertain GT inside a window while counting predictions in the same window as false positives. Blocked sources contribute no TP/FP/FN; report blocked reference/prediction counts, reasons, ignored annotation counts and retained/scored source counts explicitly. A later partial-scope policy must be separately versioned before comparison.

Resolved non-target original marks are counted in `ignored_event_count` and mapped to their class; they are not reference events. Their intervals are not free prediction zones: within a fully annotated primary scope, a prediction on an animation/intro/video shot is FP unless matched to an actual primary event. This differs from unresolved ignore intervals, which block the source. No caller may use ignored counts to conceal uncertain events. Input predictions must cover the declared full scope. Detector failures, timeouts and missing outputs require a separate failure ledger and block formal comparison; never encode a failed/timeout run as a successful empty prediction array. Missing prediction keys are recorded by the scorer and treated as empty only for diagnostic FN accounting; formal aggregation refuses them. A genuinely successful detector returning no events is an explicit empty array with a successful run receipt.

Freeze eligible IDs, media/annotation/review SHA256 values, all exclusion reasons, track, duration/timebase, grouping, annotation scope, split manifest and protocol/scorer hashes only **after** review/completeness gates. The candidate cohort version/hash is pending. The scorer refuses a formal aggregate unless the caller supplies frozen GT/cohort status, matching label track and a manifest hash, and every supplied source is eligible without holds. This mechanical assertion is necessary, not independent scientific certification. Pending-state calls are diagnostic only.

## Matching and metrics

For each video independently, match reference points `g_i` and predictions `p_j` one-to-one where `abs(g_i - p_j) <= c`. First maximize matched count; among those matchings minimize summed absolute error. Deterministic final tie break uses ordered original-index pairs in timestamp-sorted noncrossing order. Duplicate prediction times remain separate predictions and can create FP; reviewed duplicate GT events must be resolved before scoring. Never match across videos.

Primary collar **c = 0.5 seconds**, inclusive. This is a pre-prediction pragmatic tolerance for human/source timing and decoder resolution differences while preserving subsecond localization pressure. Native frame timing is still required for reviewed labels; the collar does not certify a 0.25-second sample as last-old-frame evidence. It is not empirically validated as an author metric. Predeclare **1 and 2 seconds** as secondary sensitivity analyses; report all and do not select a winner, retune thresholds or repair GT according to the favorable collar.

Let `TP = matched_count`, `FP = prediction_count − TP`, `FN = reference_count − TP`. Precision `P = TP/(TP+FP)`, recall `R = TP/(TP+FN)`, F1 `= 2TP/(2TP+FP+FN)`. Undefined denominators produce null, not a free perfect score; report the number of defined units/groups. Empty annotated sources can produce FP; unlabeled sources are blocked. Report matched timing errors separately from detection F1 and show their matched-event denominator.

Report pooled counts/metrics, per-video counts/metrics and per-source-group pooled metrics plus their unweighted macro mean. Preserve course/series breakdowns and group counts to expose imbalance. Planned primary uncertainty rule: **2,000 bootstrap draws, seed 261019, 95% percentile confidence intervals** (2.5th/97.5th percentiles). Sample verified whole source-dependence connected components with replacement, carrying every source/event/prediction in each sampled component and recomputing pooled and macro metrics. Use identical sampled components for paired candidate differences. Never resample frames or events independently. Freeze verified component membership and metric-defined denominators with the cohort before execution; component identities and actual cohort remain pending. This is a planned rule, not an executed uncertainty analysis. Scorer v1 returns counts and groups; bootstrap implementation and uncertainty estimates remain pending, and no CI is claimed here.

## Dependence and evaluation boundary

Build source, course/series and near-duplicate connected groups before assigning splits; shared video editions/slides/near duplicates cannot cross a split. Proxy source names do not prove independent speakers. Keep all connected dependencies together, document missing course/group metadata, and review the dominant dental share. Actual duplicate grouping and split assignment are pending; no split is created by this protocol.

All ten source groups have already appeared in EDA previews. Do not claim a blind unseen test set from this review. A later held-out evaluation needs an honest exposure ledger and a predeclared separation strategy. Selected ambiguity cases and historical controls are diagnostic queues; their label/class counts are not dataset prevalence or accuracy estimates. No detector comparison/model selection or source-rights certification is performed here.

Unresolved: native endpoints and ambiguous classes; repeated-row event mappings; EOF/source timebase equivalence; whole-scope annotation completeness; near-duplicate/source grouping; candidate cohort hashes/splits; source-use provenance.
