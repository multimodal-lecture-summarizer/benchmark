# Chạy trên runtime đang lỗi; không reset, không cài lại package.
from pathlib import Path
from datetime import datetime, timezone
import hashlib, io, json, zipfile, shutil
from google.colab import files
ROOT = Path('/content/joint-qualification/runner')
WORK = Path('/content/joint-qualification/work')
OUT = Path('/content/joint-qualification/evidence')
assert not (OUT/'pgnet_totaltext_joint_t4/preflight.json').exists(), 'Đã có preflight seal: dùng output root mới, không sửa run đã khóa.'
assert (ROOT/'qualification-manifest.json').is_file(), 'Chạy các cell đầu để chuẩn bị ROOT trước.'
uploaded = files.upload()
assert len(uploaded)==1, 'Chọn đúng một ZIP driver-fix.'
filename, raw = next(iter(uploaded.items()))
assert hashlib.sha256(raw).hexdigest() == 'ee6c45d306f9684299cc0eb0492ffe962b1f3ac03cc0b31c2d3019456e01eb0a', 'ZIP khác bản driver-fix đã khóa.'
with zipfile.ZipFile(io.BytesIO(raw)) as archive:
    manifest = json.loads(archive.read('qualification-manifest.json'))
    old_manifest = json.loads((ROOT/'qualification-manifest.json').read_text())
    assert manifest['test_inputs']==0 and len(manifest['train_inputs'])==9
    assert manifest['train_inputs']==old_manifest['train_inputs'], 'Không được thay train cohort.'
    names = archive.namelist()
    assert len(names)==len(set(names)) and set(names)==set(manifest['files'])|{'qualification-manifest.json'}
    for name,expected in manifest['files'].items():
        relative = Path(name)
        assert not relative.is_absolute() and '..' not in relative.parts and chr(92) not in name and ':' not in name
        assert hashlib.sha256(archive.read(name)).hexdigest()==expected
    history = OUT/'failure-history'/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    history.mkdir(parents=True,exist_ok=False)
    for name in ['qualification.log','process-status.json','cuda-diagnostics.json','qualification-manifest.json']:
        if (OUT/name).is_file():
            shutil.copy2(OUT/name,history/name)
    archive.extractall(ROOT)
(OUT/'qualification-manifest.json').write_text(json.dumps(manifest,indent=2))
(history/'driver-fix-applied.json').write_text(json.dumps({'zip':filename,'sha256':hashlib.sha256(raw).hexdigest(),'model_executed':False,'packages_changed':False,'failed_evidence_preserved':True},indent=2))
print('Đã kiểm hash và áp dụng driver-fix; giữ package/weights và evidence lỗi. Chạy lại Bước4, sau đó receipt → predictions → export.')
