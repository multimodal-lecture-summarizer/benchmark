# Chạy riêng cell này sau lỗi GPU, trước khi reset runtime hoặc cài lại.
# Chỉ kiểm runtime/driver; không load PGNet, không đọc frame, không sửa seal.
import os, subprocess, json, textwrap
from pathlib import Path
OUT = Path('/content/joint-qualification/evidence')
OUT.mkdir(parents=True, exist_ok=True)
prepared_path = OUT/'pgnet_totaltext_joint_t4/prepared.json'
assert prepared_path.is_file(), 'Thiếu prepared.json; giữ log và export evidence trước.'
prepared_diag = json.loads(prepared_path.read_text())
parent_ld = os.environ.get('LD_LIBRARY_PATH','')
import sys
sys.path.insert(0, '/content/joint-qualification/runner')
from experiments.scripts.spotting_colab_environments import worker_library_path
worker_ld = worker_library_path(prepared_diag)
probe_source = textwrap.dedent(r"""
import ctypes, json, os
print('ENV',json.dumps({k:os.environ.get(k) for k in ['CUDA_VISIBLE_DEVICES','NVIDIA_VISIBLE_DEVICES','LD_LIBRARY_PATH']}),flush=True)
for name in ['libcuda.so.1','libcuda.so','libcudart.so.11.0']:
    try:
        lib=ctypes.CDLL(name)
        print('LOAD',name,'OK',flush=True)
        if name=='libcuda.so.1':
            lib.cuInit.argtypes=[ctypes.c_uint]
            lib.cuInit.restype=ctypes.c_int
            code=lib.cuInit(0)
            count=ctypes.c_int()
            count_code=lib.cuDeviceGetCount(ctypes.byref(count))
            print('DRIVER',json.dumps({'cuInit':code,'cuDeviceGetCount':count_code,'devices':count.value}),flush=True)
        elif name=='libcudart.so.11.0':
            count=ctypes.c_int()
            code=lib.cudaGetDeviceCount(ctypes.byref(count))
            lib.cudaGetErrorString.restype=ctypes.c_char_p
            message=lib.cudaGetErrorString(code)
            print('CUDA_RUNTIME',json.dumps({'code':code,'devices':count.value,'error':message.decode() if message else None}),flush=True)
    except Exception as exc:
        print('LOAD',name,type(exc).__name__,str(exc),flush=True)
import paddle
print('PADDLE',json.dumps({'version':paddle.__version__,'cuda_build':paddle.is_compiled_with_cuda(),'cuda':paddle.version.cuda(),'cudnn':paddle.version.cudnn(),'device_count':paddle.device.cuda.device_count()}),flush=True)
""")
diagnostic_results = {}
def capture_diag(name, command, environment=None):
    try:
        result = subprocess.run(command, env=environment, capture_output=True, text=True, timeout=60)
        diagnostic_results[name] = {'returncode':result.returncode, 'stdout':result.stdout, 'stderr':result.stderr}
    except Exception as exc:
        diagnostic_results[name] = {'error':str(exc)}
    print('\n===',name,'===\n',json.dumps(diagnostic_results[name],ensure_ascii=False,indent=2))
capture_diag('current_nvidia_smi',['nvidia-smi'])
for name, loader in [('exact_worker_environment',worker_ld), ('diagnostic_with_inherited_loader',':'.join(x for x in [worker_ld,parent_ld] if x))]:
    probe_env = dict(os.environ, LD_LIBRARY_PATH=loader, PYTHONNOUSERSITE='1', OMP_NUM_THREADS='1', MKL_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1')
    capture_diag(name,[prepared_diag['python'],'-s','-c',probe_source],probe_env)
diagnostic_results['note'] = 'Driver/runtime probes only; inherited-loader comparison is diagnostic, not a changed passed model runtime.'
diagnostic_path = OUT/'cuda-diagnostics.json'
diagnostic_path.write_text(json.dumps(diagnostic_results,ensure_ascii=False,indent=2),encoding='utf-8')
print('\nSaved:',diagnostic_path,'— chạy cell export cuối để tải cùng evidence.')
