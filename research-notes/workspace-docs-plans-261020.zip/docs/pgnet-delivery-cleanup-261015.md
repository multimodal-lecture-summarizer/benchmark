# PGNet current delivery and ZIP cleanup

User explicitly requested direct notebook correction and deletion of unused ZIP variants. No model cells executed. Archive CRC, exact manifest/member hashes and allowed source-only differences checked before deletion. Evidence, weights, environment caches and frame inputs retained.

Current delivery: notebook preflight and comparison v2 bind canonical filenames and exact hashes. Bootstrap and driver loader corrections are already included; no external repair cell required. Failed-run logs are preserved by the notebook upload cell before a retry.

| Retained ZIP | Bytes | SHA256 |
|---|---:|---|
| joint-spotting-t4-qualification-261015.zip | 3906098 | `ee6c45d306f9684299cc0eb0492ffe962b1f3ac03cc0b31c2d3019456e01eb0a` |
| iiit-cvid-spotting-colab-t4-inputs-v2.zip | 1795038 | `d0b1d32d6a5cc3df2202e275494db5d94d9e0cba3939b5d06a8b35cbec31e555` |

Original v1 bundle retained because its historical notebook/README still references it.

| Deleted intermediate ZIP | Bytes | SHA256 |
|---|---:|---|
| joint-spotting-t4-qualification-261015-bootstrap-fix.zip | 3905914 | `231918bcb11629c8fcf4b438d57f1120ad0023cf09124ac8413672dc926d1d62` |
| joint-spotting-t4-qualification-261015-driver-fix.zip | 3906098 | `ee6c45d306f9684299cc0eb0492ffe962b1f3ac03cc0b31c2d3019456e01eb0a` |
| iiit-cvid-spotting-colab-t4-inputs-v2-bootstrap-fix.zip | 1794857 | `c4192236f0e9d688c82790836650cd97c4e6452207fad5ca3f286194c050b7be` |
| iiit-cvid-spotting-colab-t4-inputs-v2-driver-fix.zip | 1795038 | `d0b1d32d6a5cc3df2202e275494db5d94d9e0cba3939b5d06a8b35cbec31e555` |

Removed 4 intermediate ZIPs, 11401907 bytes. Canonical files were replaced with validated driver-fix bytes; former canonical hashes remain in pgnet-delivery-cleanup.json and dated reports.

Actual T4 PGNet train-forward and passed receipt remain pending user execution.
