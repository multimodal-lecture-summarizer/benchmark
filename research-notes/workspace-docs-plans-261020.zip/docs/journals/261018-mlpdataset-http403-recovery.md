---
date: 2026-10-18
type: technical-journal
status: local-verified-remote-pending
---

# MLPDataset: bounded HTTP403 recovery

## Context

User stopped the all-failed Colab run and requested research, targeted recovery and thorough local verification before rerunning. The pasted log completed86 retries:81 downloads and5 transferHTTP403 failures; retry87 had started. This is partial evidence, not the final Drive checkpoint inventory.

## What happened

The primary format selector could choose a direct stream successfully, then fail during transfer. Its slash alternatives only choose among available formats; they do not rerun a failed transfer through another protocol. Existing interrupted/running checkpoints also needed explicit inclusion in the resumable pool. Structured runner output was emitted before its extracted error was populated.

## Decisions

Keep the primary selector and existing media/frame identities. After HTTP403 or recognized no-format errors only, allow default-client HLS then `web_safari` HLS. At most three commands share the selected source's120-second window, including pauses and deadline-aware probe/hash work. Access/login, HTTP429, unavailable sources, resource stops, timeouts and invalid media terminate the sequence. Final filesystem/checkpoint I/O can exceed the checked wall-clock deadline.

Isolate alternate profile/format partial files, preserve previous files/history, and record each command plus the successful effective profile separately from baseline identity. Valid completed downloads remain hash/probe checked and reusable, including nested recovery paths. Include failed/interrupted/running states dynamically; do not assume the original119 or the observed5 failures are the current pool size. Add7-second source/profile pacing and0.75-second request pacing. Disable fresh format diagnostics by default, retaining previous history. Pin yt-dlp2026.8.19, EJS0.8.0 and Deno2.9.6 to observed checkpoint identities instead of blindly upgrading the runtime. Full333-video/9021-mark EDA and preview scheduling remain unchanged.

## Reflection and evidence

Official guidance can differ from a pinned release: the pinned2026.08.19 client source explicitly warns about `android_vr`403 behavior, so that fallback is excluded. Public HLS is an experiment, not a proven remote remedy. No cookies, plugins or version upgrades were introduced. Twelve focused tests passed in7.610seconds, including actual acquisition-cell recovery/reuse and static installer-pin checks across86 identities. Fresh representative-retry5, all-failed6, preview-resume8, stage-budget and full333/9021 receipt/hash regressions passed. Controlled fixtures validate orchestration and media checks without establishing YouTube recovery. No actual package installation was run locally.

## Next

Upload the revised notebook, keep the same Drive and `RUN_NAME`, and Run all on CPU. Save outputs showing actual checkpoint pool, profile attempts, source outcomes and receipt. Do not infer semantic label validity from a successful download.

References: [research report](../../plans/reports/research-261018-1335-mlpdataset-http403-recovery-report.md), [Colab guide](../mlpdataset-colab-guide.md), [implementation plan](../../plans/261018-1335-mlpdataset-http403-recovery/plan.md).

Unresolved: server-side403 cause; public HLS availability; final Drive counts after interruption; actual remote results; package resolution/install on a fresh Colab runtime.
