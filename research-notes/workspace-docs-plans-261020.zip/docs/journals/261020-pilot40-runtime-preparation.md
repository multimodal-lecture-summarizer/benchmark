# 2026-10-20 — pilot40 runtime preparation

Scorer-ready and fresh-session generation/scorer recovery are audited PASS. The next task is the unchanged40-ID/five-profile technical pilot; [P4d contract](../../plans/261019-0035-summarization-model-benchmark/phase-04d-pilot40-runtime.md) and [preparation report](../../plans/reports/implementation-261020-1107-tib-pilot40-preparation-report.md) separate preparation from actual execution.

The user approved11.5GPU-hours,23CPU-hours and11.5cumulative active wall-hours across at most2sessions, each≤11.5h with15%headroom. Drive2GiB, local free≥32GiB, working cap24GiB and transfer16GiB are ceilings. Scoring1.5GPUh/3CPUh and restore0.5wallh are inside totals. Internal scheduling partitions are conservative operational defaults. None is measured demand, and a second session does not add budget.

The pilot retains Lead-3/LexRank/BARTcontrol/LEDngram3/Qwen384 and cap350. Intended200cells comprise9 strictly verified historical neural imports,111 fresh neural outputs and80 fresh CPU outputs. Fresh latency excludes inherited generation. No new metrics, decode trials, model selection or final test run in this source-only bundle.

Actual T4, package, memory, local/Drive storage, persistent write/readback and cumulative budget checks still need to pass before inference. Every committed node must flush. No automatic retries or long-tail removal; exhausted/interrupted work preserves the original40 per candidate and explicit partial/failure receipts. Session2 may resume only matching identities with remaining cumulative budget.

The risk is treating approved ceilings or local tests as evidence that all40records fit. Actual Colab artifacts and the executed notebook must establish completion and costs. Pilot generation coverage also does not certify fresh scoring coverage or formal study admission.

Unresolved: actual preflight and pilot execution, later pilot scoring, measured projection and full-study budget/admission/profile/cap freeze before selection300. Final523→500→400 unchanged.
