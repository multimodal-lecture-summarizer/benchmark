# Cached previews do not establish slide-end ground truth

**Date**: 2026-10-19 11:27 Asia/Bangkok
**Severity**: Medium
**Component**: MLPDataset targeted review and transition scoring
**Status**: Ongoing

## What Happened

The executed ~130 MB EDA stays immutable. Fourteen historical ±5-second clips were matched against current source, annotation and clip SHA256 values, then reviewed locally. They expose delayed replacement effects and source-edge semantics; they do not certify native-frame endpoints. The queue contains 82 marks from 42 sources across ten groups: 14 historical controls, 20 policy holds and 48 contexts requiring extraction.

## The Brutal Truth

The frustrating part is that successful downloads and convincing previews still leave the scientific question open. Treating a polished gallery as corrected GT would hide uncertainty exactly where timing matters. Repeating the EDA would cost time without resolving that mistake.

## Technical Details

Protocol JSON states `status=rules_frozen`, `gt_status=pending`, `cohort_status=pending`, `evaluation_ready=false`. The inventory retains 333 sources and 9,021 raw marks, including 15 nonincreasing rows and 18 final marks beyond measured media duration. Sampling every 0.25 seconds cannot identify the last fully old native frame.

## What We Tried

Reused hash-bound historical clips before requesting new contexts. Added a standalone CPU notebook preserving `RUN_NAME=mlpdataset-eda-261017-v3`, reading existing cache and writing a sibling review directory. Deadline, storage, checkpoint and receipt controls account for all 82 statuses. Helper/scorer checks reported 13/29 passes at this checkpoint; notebook integration remains in progress. No Colab execution is claimed.

## Root Cause Analysis

Released timestamps mix unresolved event identity, ordering and source-boundary questions. Sparse inspection cannot settle those questions or detect every missing transition between labels. A global shift, clamping and automatic deduplication would destroy evidence rather than repair it; all were rejected.

## Lessons Learned

Preserve raw labels and original indices. Bind observations to exact media and PTS. Matching maximizes one-to-one cardinality, then minimizes timing error: primary collar 0.5 seconds; sensitivity collars 1/2 seconds. The 2,000-draw bootstrap with seed 261019 is planned, not implemented or executed.

## Next Steps

Implementation owner: finish notebook integration before delivery. Research reviewer: inspect pending contexts, native endpoints, repeated-row mappings and whole-source completeness before freezing any cohort or reporting formal metrics.

Unresolved: native timing, ambiguous classes, source equivalence, completeness, dependence groups/splits and source-use provenance.
