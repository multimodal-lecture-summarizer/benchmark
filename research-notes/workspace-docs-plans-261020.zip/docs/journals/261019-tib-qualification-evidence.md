# TIB qualification: usable evidence, limited claims

**Date**: 2026-10-19 17:29
**Severity**: Medium
**Component**: TIB summarization dataset qualification
**Status**: Ongoing — development IDs sealed; generation blocked

## What Happened

The pinned 9,103-record snapshot now has per-record rights, reference, canonical-text and known-source-group evidence. Scoped private, noncommercial use conditionally permits 6,171 sources; 5,270 records pass both source and reference rights. After qualification/exposure filtering, train/valid/test counts are **4,213/464/523**. We sealed **40 pilot + 300 selection** validation IDs without fallback. Final test remains unsealed; no new model generation, benchmark, deployment or commit occurred.

## The Brutal Truth

The frustrating part is how easily tidy counts can imply certainty we have not earned. **A=0/B=9,095/C=8** is honest uncertainty, not a failed attempt to manufacture clean gold. Reviewing the 225 historical reused-abstract flags does not certify 225 episode summaries. The local RTX 4050 Laptop also cannot provide T4 feasibility evidence.

## Technical Details

All 225 historical flags across 18 groups remain uncertain B after AI-assisted abstract/title/limited-source-span review. Eight empty references are C; A-only sensitivity has no records. Approximate source retrieval found 22 accepted edges and 37 records in nonsingleton groups; recall remains unknown.

The grouping runner lost its `digest` import during on-disk edits after the running process had loaded an earlier version. Its final file hash therefore was not sealed executed-code identity. `group_validation_review_fix_receipt.json` preserves that limitation, revalidates all 9,103 source hashes, all 22 accepted pairs and identical graph reconstruction. The 2,854,654 candidate comparisons were not rerun.

## What We Tried

We restored the missing import and added a runtime-wiring regression. Additive replay preserved original artifacts instead of silently replacing their provenance. Canonical EDA and native-token counts completed on CPU; token windows remain diagnostics rather than measured capacity.

## Root Cause Analysis

We changed a runner while it was executing, then observed the later file hash at receipt creation. That broke the connection between executed code and recorded identity. Separately, creator abstracts and incomplete rights evidence never justified blanket eligibility.

## Lessons Learned

Freeze executable identity before starting long audits. Record amendments explicitly. Keep uncertain references eligible only under a locked rubric; reject score-driven relabeling and blanket exclusion of reused abstracts. Keep unknown rights on HOLD. Known group separation cannot establish exhaustive independence.

## Next Steps

The benchmark owner must ratify `W_global`, scorer readiness, candidate profiles and compute/storage/retry budgets before generation. The runtime operator must measure actual T4 capacity before the feasibility pilot. Final-test membership needs its later independent seal; preserve historical outputs and the current development seal.

Unresolved questions: Which output cap and runtime profiles pass the scorer and T4 gates? What budget supports the final eligible test frame?
