# Summarization benchmark scale amendment

**Date**: 2026-10-19 01:02 Asia/Bangkok
**Severity**: Medium
**Component**: TIB summarization benchmark planning
**Status**: Resolved — planning decision only; execution pending

## What Happened
The user requested a larger benchmark with explicit development and final evaluation roles. The [five-phase plan](../../plans/261019-0035-summarization-model-benchmark/plan.md) now budgets separate pilot, validation selection and final-test cohorts. This journal records the amendment; it does not authorize execution.

## Limits
Sample sizes are planning estimates. Eligibility, exposure and actual T4 capacity still require verification; statistical sufficiency and runtime are not guaranteed.

## Technical Details
Reuse existing EDA across all 9,103 records; qualify every train/validation/test split. Budget 30–50 validation records for pilot and 200–400 different validation records for selection, disjoint by group. Prefer all eligible native test records, at most 911, across multiple T4 sessions. Plan 30–50 post-final error-analysis cases; these are diagnostics, not population rates or new gold labels.

## What We Tried
Only the plan was amended. No implementation, EDA, model or benchmark run occurred; no IDs were selected and no new cohort/protocol was frozen. The historical 120-record study retains `no_selection`.

## Root Cause Analysis
The amendment replaces the earlier scale with separate validation development and native-test evaluation roles. Qualification and measured pilot evidence determine the final resource commitment.

## Decisions and Lessons Learned
Prefer the entire eligible test frame. Permit a 400–600 fallback only when a predeclared resource rule makes the full run infeasible, sealed before test predictions; use the entire frame if fewer than 400 qualify. Never substitute whichever IDs finish first. These are planning targets, without statistical guarantees.

## Next Steps
Before execution, the data steward must qualify splits/groups/exposure; the runtime designer must measure pilot costs, choose validation configurations and seal final N/resource rules before test outputs. Keep prior evidence intact.

## Contract revision — 2026-10-19 09:23 Asia/Bangkok
The user authorized a documentation-only revision across all six plan files; all eight contracts were clarified. Root document checks passed: strict CLI validation, 39 local links and 12 anchors; independent consistency review passed after ownership fixes. These checks do not certify runtime capacity.
Specify scorer readiness before selection, with rescoring and reselection after scorer changes; declare the common evaluation population, failure handling and bounded validation tuning.
Require native-context limits and contracting reduction; mark T4 profiles provisional until measured. The host has 16 GB RAM; T4 capacity remains unmeasured.
Define the budget/fallback algorithm before test outputs, durable node/RNG checkpoints, duplicate record versus group handling, and a structured error-analysis form.
The gap was underspecified execution contracts: cohort scale alone cannot make selection reproducible. Resolve these rules before execution instead of deciding from completed test outputs; this avoids costly ambiguity during interrupted sessions.
Retain EDA for all 9,103 records and qualification of every split; pilot 30–50 validation records, selection 200–400 disjoint validation records, qualified native test at most 911 with predeclared 400–600 fallback, and 30–50 error-analysis cases.
No runtime certificate, ID selection, new freeze or model run results from this revision. P4 owns pre-selection scorer spec/readiness; P3 owns the pretest diagnostic sampling spec; P5 consumes both after final generation. Data steward and runtime designer must qualify resources and measure pilots before execution.

## Verification-report follow-up — 2026-10-19 09:57 Asia/Bangkok

The plan now separates configuration selection within each family from comparison between fixed family representatives. Family means are recomputed on a representative-only common set; sibling configs do not compete under the family delta threshold. All trials and both levels of coverage remain accounted for, without new cohorts or a larger N.
The verification report is retained unchanged. Snapshot/rights, reused-reference decisions, metric provenance/pins, actual T4/backend capacity, numeric quotas and checkpoint-store durability remain pending evidence. This update changes planning documents only; no selected IDs, frozen protocol or benchmark run is produced.

## Attachment-led revision — 2026-10-19 10:22 Asia/Bangkok
The user authorized another documentation-only revision: planner owns six plan files, root owns three benchmark crosslinks; edits are complete and current root document checks passed.
Defaults become 40 pilot and 300 selection validation records, disjoint; selection may fall back to 200 for availability before outputs. Final evaluation remains full-first, all qualified test records at most 911, with resource fallback 600 → 500 → 400; 40 unique diagnostic cases come from that same final cohort.
Keep one primary TIB benchmark, without an independent genre benchmark or new gold labels. Preserve canonical raw plus technical-normalized transcripts; segments remain a sidecar, with no prompt timestamps.
Declare research reference-usability classes A/B/C: primary eligibility A+B, C excluded from reference-based scoring with a reason/evidence ledger and retained in the audit. Derive one global output cap from development evidence instead of fixing 250; retain four models, fixed CPU Lead3 control, and two-stage configuration selection.
Reference-quality and genre sensitivity reuse the same predictions. Oracle and reference-free metrics remain optional diagnostics outside ranking; paper-claim verification remains pending.
The decision closes ambiguity before outputs exist; leaving these choices until results arrive would undermine comparison and waste reruns. The historical 120-record `no_selection` record remains immutable.
Planner completed the revision; root strict CLI checks passed with five pending phases, 45 local links and 17 anchors valid; independent P1–P5 consistency review passed. Required resource qualification and pilot measurements remain future work: host RAM is 16 GB, T4 capacity unverified. No IDs, new freeze or execution are produced.

## Unresolved Questions
Exact eligible N, candidate configurations, and T4 memory/session resources remain open after qualification.
