# MLPDataset native review preparation — 2026-10-19

The completed targeted notebook yielded48ready contexts and1771frames. Full sampled-window inspection reduced48requests to33distinct sequences without treating repeated frame arrays as repeated scientific events. Multiple changes appeared within fast dental and optimization-title windows. Same-heading nutrition pages also replaced their body content, while diagram builds and lecturer/outro changes required separate treatment.

The durable result is a bound82-row diagnostic ledger,37observed changes in the new contexts (33primary candidates,4auxiliary), and14explicit repeated-group mapping proposals. Six historical primary candidates remain a distinct coarse layer. All official dispositions stay HOLD; no native endpoint, annotation repair, eligible cohort or detector winner was invented.

Independent review found a real reproducibility risk: manual observations originally referenced a positional case number without pinning the reviewed receipt. Before delivery, receipt SHA, explicit case identity, source/time and frame-sequence fingerprint were bound and drift rejection tested. This was a preparation bug, not evidence that judgments had already moved to wrong sources.

A separate CPU Colab notebook now extracts64short source-bound windows with passthrough temporal cadence and an independent ffprobe PTS check. It preserves original/review caches, bounds runtime/storage/staging/inline output, and saves every job plus all82row statuses on interruption. Native means temporal cadence; images are resized for diagnosis. The inline budget was raised from24to128MiB because the queued footage may produce several thousand frames; lazy collapsed galleries retain explicit overflow reporting.

Final local verification passed54tests plus4subtests, including real FFmpeg synthetic fixtures and standalone notebook cells. Both executed research notebooks remain byte-identical. Actual research-native extraction remains a user Colab run, followed by manual endpoint/effect adjudication; extraction success alone will not close completeness/provenance/cohort gates.
