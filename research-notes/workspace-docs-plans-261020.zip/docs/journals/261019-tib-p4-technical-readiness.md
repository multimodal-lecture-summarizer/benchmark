# TIB P4 technical readiness — 2026-10-19

Scorer CPU-ready bằng actual pinned checkpoints và native/window/E2E fixtures; IDF=false, long-input extension giữ token IDs. Không coi fixture throughput là full-corpus budget.

Eligible train4.213/p95=333→350 words maximum theo user ratification. Validation/test references không chọn cap. Final cap lock chờ candidate feasibility; không outcome-driven reduction.

Unicode window review phát hiện decode/re-encode có thể thay token bằng U+FFFD; sửa giữ native IDs ở chat và reducer, regression pinned Qwen. Hash validation gaps ở output proxy và budget receipts được sửa, old evidence giữ version.

134 tests PASS; local staged CPU6/6 và native9plans PASS. Private source-only3-record ZIP/notebook upload Drive; T4 runtime connected, chưa model generation. Drive OAuth client Google Drive for desktop chờ specific authorization sau auto-review rejection; không bypass.

Runtime guard11.5h theo user<12h; A100 không thay T4 evidence. Giữ523 full-first rồi500/400 nếu projection yêu cầu,40diagnostics trong cohort. Checkpoint nodes/attempt ledger có hash/runtime bindings; actual cross-session Drive survival chưa đo.

Còn mở: OAuth/T4 actual profiles/final cap lock/store survival/numeric full-study budget/validation+final seal. Không commit/push.
