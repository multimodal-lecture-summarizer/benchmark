# MLPDataset preview resume — 2026-10-18

The full-release Colab run exposed a coverage problem: the 30-minute preview stage decoded343 images across38 videos, then left1423 requests pending. Every rerun restarted extraction in the same order because it never loaded successful frame records. Budget-dependent filenames also prevented stable reuse.

The revised runner binds each frame to its source hash, annotation/request and render version. It validates hashes, image readability and confined paths before reuse, migrates compatible v2 receipt-bound rows and atomically checkpoints new attempts. Mark triplets rotate across source groups/videos, prioritizing less-covered work; rendering happens after extraction. Cached frames remain decoded while explicitly recording that no new process started.

Eight local real-FFmpeg tests passed: repeat-run reuse, corrupt/missing/changed requests, legacy migration, three-group progress, interruption recovery, source/path invalidation, changed offsets and mark rotation with missing groups. Full333/9021 inventory and receipt replay checks passed, including historical states and artifact hashes. Semantic timestamps are unchanged.

New Colab execution remains pending. The202 downloaded videos can be reused with the same Drive/RUN_NAME;131 historical source failures require bot confirmation and this preview fix does not recover them. Local tests establish resume behavior, not dataset-wide semantic accuracy or remote availability.
