# MLPDataset: retry every remaining failed source

2026-10-18, Asia/Bangkok.

The saved representative run recovered12/12 sources in135.49 seconds, leaving214 downloaded and119 failed checkpoints. A12-source/10-minute sampler could not satisfy the next request to attempt every remaining failure.

The notebook now defaults to `RETRY_FAILED_SCOPE="all-failed"`, selecting every current failed checkpoint in the media selection. Selection derives from saved states, with no fixed119-ID list or12-source limit. The existing representative mode remains available. The legacy master switch and receipt/export names remain compatible, with explicit scope recorded.

Retry/global acquisition windows are300 minutes and media quota16 GiB; failed-source command timeout120 seconds, pause3 seconds. Per-video cap, actual free-space floor and analysis reserve remain enforced. These are bounds, not forecasts: selected, attempted, process-started and recovered counts are reported separately with exact pending reasons. Checkpoint history and validated video/frame cache remain reusable; recovery feeds unchanged preview/coverage logic.

The guide was checked against notebook config/acquisition/receipt and the new helper. Six focused all-failed tests passed against the saved119-failure/214-downloaded pool and local process/probe/hash/cache guards; representative, stage-budget and full333/9021 receipt regressions also passed. These local checks do not establish YouTube recovery. The all-failed revision has not been executed on Colab here. No authentication or annotation changes were made.

Unresolved: actual recovery of the remaining sources, resource availability, pending preview requests and semantic/timebase qualification. Keep Drive and `RUN_NAME`; use CPU Run all and save outputs for audit.
