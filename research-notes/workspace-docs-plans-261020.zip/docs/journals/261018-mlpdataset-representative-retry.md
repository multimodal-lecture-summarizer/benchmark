# MLPDataset representative retry — 2026-10-18

The latest audited Colab run had202 usable videos and131 historical failed states. Preview resume worked:343 verified cached images plus332 new images reached675 images,228 marks and118 videos. That run did not retry the131 sources; their old errors cannot describe current availability.

The revised notebook adds a bounded public-access retry sample from existing failed checkpoints. Defaults select up to12 sources, with a10-minute sample budget,120-second command timeout and3-second pauses. Selection covers source groups, then failure kinds and historical403/resource-limit diversity when slots allow, followed by balanced least-attempted fill. Other old failures remain unattempted in sample mode; all333 videos and9021 marks stay in inventory.

The existing downloader preserves cached media, attempt history, storage caps and logs. Recovery requires a completed source file, ffprobe and SHA-256. Inline tables and CSV/JSON receipts distinguish selection, actual new attempts, retained failures, skip reasons and verified recoveries. Recovered media joins normal preview resume. Disabling representative mode restores the general retry policy.

Five focused retry tests passed using the saved131 failures across9 source groups and controlled local processes with real ffprobe/hash checks. The existing eight preview-resume tests, stage-budget tests and full333/9021 inventory/receipt replay also passed; strict JSON, artifact hashes and historical states were checked. Media/frame identities and preview/coverage source logic were unchanged. No real YouTube download was attempted locally.

No cookies or authentication mechanism changed. Run the updated notebook on Colab CPU with the same Drive/RUN_NAME. Local validation cannot establish current YouTube availability; the next Colab execution supplies that evidence.

Unresolved: representative recovery results and full source availability; sampled retry outcomes do not certify all131 sources or semantic timestamp validity.
