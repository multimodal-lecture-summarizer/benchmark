# Read-only diagnostic: run in the Colab session that just failed reconstruction.
# Does not install packages, load a model, edit a seal, or change candidate config.
import json
import os
import sys
from pathlib import Path

sys.path.insert(0, '/content/cvid-spotting-t4/runner')
from experiments.scripts.spotting_colab_environments import environment_snapshot
from experiments.scripts.spotting_colab_artifacts import digest


def snapshot_difference(expected, actual):
    result = dict(python_changed=expected['python'] != actual['python'],
                  interpreter_changed=expected['executable_sha256'] != actual['executable_sha256'],
                  packages=[])
    original, rebuilt = expected['packages'], actual['packages']
    for name in sorted(set(original) | set(rebuilt)):
        before, after = original.get(name), rebuilt.get(name)
        if before == after:
            continue
        row = dict(package=name, expected_version=(before or {}).get('version'),
                   actual_version=(after or {}).get('version'))
        files_before, files_after = (before or {}).get('files', {}), (after or {}).get('files', {})
        row['missing_files'] = sorted(set(files_before) - set(files_after))
        row['added_files'] = sorted(set(files_after) - set(files_before))
        row['changed_files'] = [dict(path=p, expected=files_before[p], actual=files_after[p])
                                for p in sorted(set(files_before) & set(files_after)) if files_before[p] != files_after[p]]
        result['packages'].append(row)
    return result


cache_root = Path(os.environ.get('SPOTTING_CACHE_ROOT',
                  '/content/drive/MyDrive/OCR/cvid-spotting-t4-261015-v2-r2-runtime-cache'))
seal_path = cache_root / 'environments/orchestrator/environment-seal.json'
python = Path('/content/cvid-spotting-t4/environments/orchestrator/venv/bin/python')
assert seal_path.is_file(), 'Mount Drive and locate the r2 orchestrator cache seal first.'
assert python.is_file(), 'Actual rebuilt environment is no longer present; use the updated notebook to capture the next reconstruction failure.'
cached = json.loads(seal_path.read_text())
actual = environment_snapshot(python)
report = snapshot_difference(cached['installed'], actual)
report.update(expected_digest=cached['installed_digest'], actual_digest=digest(actual),
              cached_snapshot_self_consistent=digest(cached['installed']) == cached['installed_digest'])
out = Path('/content/drive/MyDrive/OCR/cvid-spotting-t4-261015-v2-r3')
out.mkdir(parents=True, exist_ok=True)
report_path = out / 'orchestrator-reconstruction-diff.json'
report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
print(json.dumps(report, ensure_ascii=False, indent=2))
print('Saved:', report_path)
