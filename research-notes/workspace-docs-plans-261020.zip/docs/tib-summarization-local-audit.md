# TIB summarization: local P1 audit

Status: 2026-10-19, Windows/PowerShell, 16 GB RAM; T4 availability unverified.
This slice inspects local evidence for the [P1 provenance gate](../plans/261019-0035-summarization-model-benchmark/phase-01-paper-and-dataset-provenance.md).
See the [benchmark workflow](../benchmark/README.md) and [five-phase plan](../plans/261019-0035-summarization-model-benchmark/plan.md).

## Run from `benchmark/`

Use an existing local snapshot directory whose basename is the full pinned SHA
`e6ab9fd7c6acd164f3284b8c4b17eb9d94681eee`. The Python environment needs `pyarrow`
when raw Parquet shards are present. No dependency installation occurs automatically.

```powershell
python -m experiments.scripts.tib_model_benchmark_audit --snapshot <local-full-SHA-path> --output <new-audit-dir>
```

Replace both placeholders with local paths; quote paths containing spaces.
The [CLI](../benchmark/experiments/scripts/tib_model_benchmark_audit.py) performs no
download, network access or model inference. It reads snapshot files without changing them.
Output must be a new directory outside the snapshot; existing output is rejected.
Choose a fresh output directory for every attempt. Do not overwrite earlier evidence.
Shard hashing and inspection use one open file and reject changes detected during the audit.

Exit **2** after a completed export is the intended **HOLD** result, not G1 success.
Argument errors also use exit 2: inspect stderr and require the completion receipt.
Invalid inputs or interrupted writes must not be treated as completed audits.

## Read the evidence

| File | Meaning |
|---|---|
| `dataset_manifest.json` | Card/raw shard SHA-256, byte sizes, schemas, observed counts and blocking reasons |
| `rights_ledger.json` | Released DOI/source URL/license labels; text and abstract reuse remain HOLD |
| `comparison_contract.json` | Development candidate roles, devices, recommendation IDs and paired contrasts |
| `audit_receipt.json` | Written last; `export_complete`, exported JSON checksums and audit-tool SHA-256 values |

The [snapshot inspector](../benchmark/experiments/scripts/tib_model_benchmark_snapshot.py)
keeps declared counts separate from observed Parquet metadata counts:
train **7,282**, valid **910**, test **911**; total **9,103** declared records.
Missing shards yield `null` observed counts, never inferred totals from the card.
Schema checks include required string fields and nested `transcript_segments` shape;
they do not establish row-level content, timing, ordering or semantic usability.
License labels are logged as evidence, never converted into permission automatically.

The completion receipt is `audit_unsealed`: checksums bind the export and tool bytes,
but do not certify G1 PASS, remote revision authenticity, rights or a frozen cohort.
The directory name alone is explicitly insufficient revision evidence. Even complete
local shards leave remote file/revision binding, rights and paper/source accounting pending.
Canonical normalization, offset mapping and cohort selection are not executed here.

## Development contract and limits

The [registry](../benchmark/experiments/registry/models/tib-summarization-pipelines-v1.json)
contains five IDs: `lead3`, `lexrank`, `bart`, `led`, `qwen3`.
Four are model families; Lead-3 is a fixed CPU control with no configuration search.
LexRank generation is CPU; BART, LED and Qwen3 declare CUDA generation for future execution.
All five enter between-family comparisons, giving **10 paired contrasts**;
only the four model families are recommendation nominees.
`transcript` is canonical input, segments are an audit sidecar, timestamps are excluded,
and the global output word cap remains unset.

The [policy helper](../benchmark/experiments/scripts/tib_model_benchmark_contract.py)
leaves unreviewed nonempty references at B. B is flagged but primary-eligible only when
both explicit rights and structure booleans pass; otherwise it remains HOLD.
A/C decisions on nonempty references require review evidence; empty references become C.
This is an uncalibrated proposed policy helper, not semantic annotation or a cohort seal.
Generation adapters, common comparison masks and evaluator execution remain future work.

## Focused unit verification

From `benchmark/`, with `pytest` and `pyarrow` already available:

```powershell
python -m pytest tests/test_tib_model_benchmark_contract.py tests/test_tib_model_benchmark_snapshot.py -q
```

This command targets offline contract/temporary-Parquet tests, not a model benchmark.

## Current blockers and unresolved questions

The old HF cache remains card-only, but the complete pinned snapshot is now retained in
`benchmark/research-data/tib-evidence-261019-1507/` (ignored local data).
The [new dataset evidence report](../plans/reports/dataset-evidence-261019-1507-tib-snapshot-rights-report.md)
records remote SHA/LFS/Git binding, all four shards and measured7,282/910/911 counts.
Its source-binding supplement verifies remote evidence separately from this offline CLI.
It also records5,592 supported CC0 reference matches and6,503 conditional source CC routes.
Overall G1/P1 remain incomplete for remaining field/use scope and canonical trace; P2 onward is pending.
Original Lead-3/Oracle paper attribution is verified; local reproduction settings are not.
