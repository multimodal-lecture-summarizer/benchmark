# Tự chạy CVID spotting comparison v2 trên Colab T4

16/10/2026. R4 evidence đã audit ALL6 train preflight PASS, EasyOCR1754/1754 test records (zero frame errors). Ba candidate bị runtime binding mismatch trước test; PP-OCRv6/PGNet chưa có inference log. Full comparison chưa hoàn tất; chưa có bảng so sánh đủ6 hoặc winner.

## Bản sửa runtime seal R5

Preflight và warm-up trước test dùng chung inference, validate_record, Image.open và geometry validation trên đúng9 train frames, cùng thứ tự rồi mới chụp native/runtime hashes. Giữ exact binding comparison, không bỏ hash hoặc tự đổi seal. Sau ALL6 preflight, notebook chạy ALL6 train replay trong process mới bằng lệnh verify, không đọc ảnh test. Chỉ sau khi tất cả replay PASS mới cho chạy test. Mismatch lưu expected/actual binding và toàn bộ runtime dưới OUT/<candidate>/diagnostics; notebook hiển thị full diff và evidence export chứa snapshot.

R4 ZIP không có actual runtime snapshot ở process mismatch; bất đối xứng warm-up được xác nhận từ source, nguyên nhân từng field của lỗi R4 vẫn chưa xác minh.51 tests local kiểm chứng contract. R5 train replay và đủ6 test aggregates hiện đã audit; một checkpoint docTR cần phục hồi, scoring chưa chạy.

Tải lại cả notebook và ZIP, dùng RUN_ID r5/CACHE_ID r2. Giữ nguyên r4 evidence, records EasyOCR và lock cũ. Vì source/bundle binding đổi, không copy receipt/checkpoint r4 sang r5. EasyOCR r4 vẫn là evidence riêng đã audit; full comparison R5 cần gates mới và test mới cho cả6. Cache wheels/seals r2 được kiểm trước reuse; model files chỉ reuse nếu còn trong WORK và đúng hash, runtime mới có thể tải lại weights đã khóa.

R5 giữ các sửa trước: PARSeq chỉ bỏ đúng4 legacy keys upstream xác nhận không còn được dùng rồi strict=True; cache replay original roots + resolved constraints và exact installed snapshot digest. Weights/config/thresholds/grouping/cohort/scorer không đổi.

## Hai file cần tải lại

- [Notebook comparison v2](../benchmark/experiments/notebooks/iiit-cvid-spotting-colab-t4-v2.ipynb)
- [Comparison bundle hiện hành](../benchmark/experiments/outputs/iiit-cvid-spotting-colab-t4-inputs-v2.zip), khoảng1,83MB. Đây là code, GT/protocol/config và qualification provenance; không chứa ảnh test hoặc model weights.

ZIP SHA256: `40291c603b60eb564a66a182d12ae50cf4b19579954fac5c69c22d87c8ae57df`.
Notebook SHA256: `11c15fea6025af2fe751aac9dbc5f652475f6bda6a7e7ac7c39c9dac8fde5090`.

Tên file ZIP giữ nguyên nhưng nội dung/hash đã cập nhật. Không dùng ZIP qualification hoặc comparison ZIP đã tải trước đó; không sửa EXPECTED_BUNDLE_SHA256 để bỏ qua mismatch.

## 1. Mở notebook và cấp GPU

Colab → File → Upload notebook → chọn notebook vừa tải. Runtime → Change runtime type → T4 GPU → Save → Connect. Chạy từng cell bằng nút ▶; chưa chọn Run all khi cần kiểm từng gate.

## 2. Mount Drive và xác định nơi lưu

Chạy cell đầu; đăng nhập/mount Google Drive theo UI. Phải thấy TeslaT4. Giữ:

- RUN_ID: `cvid-spotting-t4-261015-v2-r5`.
- OUT: `MyDrive/OCR/cvid-spotting-t4-261015-v2-r5`.
- Runtime cache: `MyDrive/OCR/cvid-spotting-t4-261015-v2-r2-runtime-cache`, giữ CACHE_ID r2 để reuse exact wheels/seals; OUT vẫn là r5 mới, không nhập receipt r2.
- BUNDLE_ZIP: `MyDrive/OCR/iiit-cvid-spotting-colab-t4-inputs-v2.zip`.

Nếu đã có run cũ dưới v2, không đổi nó thành r2 bằng cách chép checkpoint sang. R5 là identity mới vì code/bundle/runtime warm-up đã cập nhật; model configs/cohort không đổi.

SOURCE_ZIP mặc định None: notebook tải original IIIT-CVid.zip theo HF revision đã khóa rồi kiểm SHA. Nếu đã có ZIP nguồn nguyên bản trên Drive, sửa SOURCE_ZIP thành đường dẫn đó; không đưa một thư mục đã giải nén hoặc qualification ZIP vào đây.

## 3. Upload và kiểm bundle

Chạy cell verify. Nếu ZIP chưa có ở BUNDLE_ZIP, widget hỏi chọn file trên máy; chọn comparison bundle mới. Nếu ZIP cũ đã tồn tại trên Drive, thay file đó bằng bản mới trước khi chạy verify. Notebook dừng khi SHA không khớp.

Xem bảng sáu candidate/config hashes và bảng PGNet qualification. Mở các khung Frozen protocol/GT policy và Locked candidate để xem toàn bộ matching, normalization, failure rules, weights/config/packages. Qualification không cấp comparison preflight và không chứa test results.

## 4. Chuẩn bị môi trường và dữ liệu

**Cache replay đã sửa theo diff thực tế:** Python, interpreter và package versions không đổi;19 package chỉ thêm dist-info/REQUESTED. Replay cũ cài toàn bộ freeze như direct requirements nên tạo marker thừa. R5 cài đúng declared roots, dùng freeze làm constraints từ exact cached wheels; vẫn so digest toàn snapshot với seal r2, không bỏ qua metadata hoặc ghi đè seal. [Pip constraints](https://pip.pypa.io/en/stable/user_guide/#constraints-files) khóa phiên bản mà không tự yêu cầu cài package.

Chạy đúng3 code cells đầu (mount/verify/orchestrator). Khi in Orchestrator cùng installed_digest và không có traceback, tiếp tục cell acquisition/prepare. Nếu mismatch còn xảy ra, notebook in diff, ghi orchestrator-reconstruction-diff.json lên OUT r5, kiểm readback và gọi tải JSON trước khi báo lỗi. Dừng ở đó và giữ JSON/log; chưa chạy acquisition/model preparation. Runner chỉ dựng lại venv tạm chưa có seal, không xóa cache r2 hoặc output cũ.

Chạy cell setup/prepare. Không cài package vào kernel Colab; orchestrator Python3.11, scorer và từng model dùng venv riêng. Bootstrap tránh host ensurepip; worker giữ driver host sau NVIDIA wheels riêng.

Runtime mới có thể tải source, weights và dependencies nhiều GB. Chưa có dự báo thời lượng đã đo cho toàn bộ sáu pipeline. Khung log cập nhật trực tiếp và lưu đầy đủ trong OUT/orchestrator-logs; worker logs nằm dưới OUT/<candidate>/logs. Cuối phase có bảng prepared/preflight/committed/completion/failure theo candidate.

Prepare returncode0 riêng lẻ không chứng minh tất cả model đã sẵn sàng: runner vẫn lưu từng failure; bước preflight mới quyết định gate. Không bấm chạy lại cell khi process cũ còn hoạt động.

## 5. Kiểm cohort và chạy ALL6 preflight

Chạy cell kế tiếp: xem đầy đủ1.754 frame IDs, GT count per course và9 train inputs. Tổng phải là1.754 frames/40.063 objects. Cohort là7 course proxies/276 video-folder groups;1 frame geometry HOLD,97 metadata-only repairs. Không thay text/box hoặc bỏ frame khó.

Cell kiểm docTR trước để phát hiện sớm lỗi; nếu đạt mới tạo train preflight cho5 candidate còn lại trên r5. Sau preflight, notebook replay9 train frames của mỗi candidate trong process riêng. Phải in PASS ALL6 preflight + separate-process train replay. Bảng status có cột train_replay; mismatch hiện full binding/runtime diff, chưa đọc test. Worker traceback của candidate lỗi được hiển thị tự động. Nó kiểm receipt mới thuộc đúng data/registry/bundle, weights/config qua worker seals, runtime/prepared hashes và train inputs. Bước này và cell test đều kiểm gate; một required candidate lỗi chặn ANY test inference.

Nếu lỗi: xem latest_failure và worker log cụ thể; chạy export cuối, giữ evidence và gửi để audit. Không đổi threshold/grouping hoặc thay model nhằm chạy qua gate.

## 6. Chạy test trên cùng cohort

Chỉ sau ALL6 preflight + train replay PASS, chạy cell Full cohort. Theo dõi progress worker và committed frames. Mỗi candidate cần1.754 records; cả6 là10.524 frame-candidate records.

Failure ở một frame được giữ dưới status=error, zero predictions, GT vẫn tính FN; không retry frame đó bằng config khác. Candidate bị crash/missing completion làm comparison chưa đầy đủ. Không bỏ candidate để xuất bảng cuối.

## 7. Chấm điểm và xem đầy đủ kết quả

Chạy scoring cell sau completion. Notebook xác minh checkpoints/aggregate hashes và identity, dùng scorer/normalizer đã khóa rồi hiển thị:

- E2E spotting P/R/Hmean chính; detection P/R/F1, TP/FP/FN và denominators.
- Tất cả variants: primary, IoU>0.75, case-sensitive, observed-flag influence1.751frames/40.023GT; cùng predictions.
- Course/folder breakdown, macro-course means, exploratory paired bootstrap course/folder và failure ledger.
- Invalid geometry, empty transcription accounting, recorded frame-call costs; không coi đó là standardized latency benchmark hoặc GPU peak-memory measurement.
- Tất cả primary per-frame rows/IDs của6 candidate, coverage của full transcription export, artifact hashes và sáu plots.

Full sensitivity frame rows ở frame-scores.csv.gz; toàn bộ native text/polygon ở all-prediction-text.csv.gz. Không dump mọi transcription của10.524 records vào một output HTML khổng lồ: dùng viewer để xem đầy đủ từng frame, hoặc tải full gz export.

## 8. Xem bất kỳ frame nào

Chạy cell dropdown; chọn frame ID bất kỳ rồi chạy cell inspector kế tiếp. Mặc định frame đầu cohort, không chọn theo metric. Nếu widgets không có, sửa FRAME_ID rồi chạy inspector.

Viewer kiểm pixels/bundle/checkpoint identity và hiển thị toàn bộ GT text/boxes, native predictions của cả6, confidence nếu adapter cung cấp, status/error và overlays. PGNet không có region confidence nên không tạo score giả. GT xanh lá/prediction xanh dương không phải TP/FP colors; overlay không tự sửa/lọc polygon invalid.

Cell optional download cho phép đổi EXPORT_FILE sang artifact bất kỳ được liệt kê, mặc định all-prediction-text.csv.gz. CSV nén giữ mọi frame, full text và geometry; xem trực tiếp sau giải nén.

## 9. Export và lưu notebook

Chạy cell cuối để tạo `MyDrive/OCR/cvid-spotting-t4-261015-v2-r5-evidence.zip` và tải về máy. Có thể chạy riêng cell này sau prepare/preflight/inference lỗi, miễn ROOT đã verify và OUT đã tạo.

ZIP gồm logs, failures, prepared/runtime seals, train-replay receipts, mismatch diagnostics, immutable checkpoints, completion, metrics/CSV/plots và export-manifest hashes. Cache/wheels ngoài ZIP để resume. Export thành công không đồng nghĩa comparison complete.

File → Save rồi File → Download → Download.ipynb để giữ notebook có outputs. Giữ cả notebook và evidence ZIP; gửi cả hai để audit sau chạy.

## Resume hoặc runtime bị ngắt

- Giữ đúng notebook/bundle/RUN_ID/r5 và paths; chạy lại T4+Drive → verify → setup/prepare → preflight → test. Cached wheels/seals, model files còn ở WORK và immutable records sẽ được kiểm trước khi reuse. Runtime mới có thể tải lại weights.
- Khi bundle/config/native/runtime seal đổi, runner từ chối reuse; dùng RUN_ID mới, không xóa seal để ép chạy tiếp.
- Nếu báo .execution.lock sau gián đoạn, xem lock và kiểm không còn process run_spotting_colab/spotting_colab_worker đang chạy vào OUT đó. Chỉ xóa đúng file lock còn sót khi đã xác nhận process dừng; không xóa records/preflight/prepared. Trường hợp không chắc, giữ evidence và gửi log.
- Không chạy đồng thời hai notebook dùng cùng OUT.

## Giới hạn kết luận

Đây là released-label agreement trên test đã exposed qua EDA và annotation chọn lọc, không certified gold hoặc exhaustive visible-text correctness. Matching detection/spotting tối ưu độc lập; không diễn giải chênh lệch như recognition-error decomposition. Grouping native khác nhau nên so packaged systems, không causal architecture effect. Bảy course proxies hạn chế CI/generalization; không chọn production winner. Kết quả crop recognition trước đây luôn riêng với spotting.


## R5 sau resume: một checkpoint docTR rỗng (audit16/10)

Evidence r5 mới nhất đã audit đủ6 aggregates/10.524 records; một checkpoint docTR0bytes nhưng aggregate còn nguyên và đúng completion hash. Dùng script recover-cvid-r5-doctr-checkpoint.py riêng, không thay bundle. Script chỉ phục hồi frame Frames/test/14/18/00_02_05_00001.png từ sealed aggregate, kiểm receipts và readback, giữ journal trong OUT/recovery-audit. Không chạy OCR. Nếu target đã đúng thì ALREADY VERIFIED; nếu khác nội dung/ràng buộc hoặc runner còn hoạt động thì dừng.

Tải script, upload bằng google.colab.files.upload trong cell riêng, ghi file vào /content rồi chạy với Python host. Chờ RECOVERY PASS hoặc ALREADY VERIFIED, tiếp tục cell scoring của notebook hiện tại, không chạy lại Full cohort. Scorer vẫn kiểm toàn bộ checkpoint/aggregate/binding. Sau đó xem plots và export evidence mới. Giữ nguyên failure ledger và ZIP r5 gốc. Repair chưa áp dụng từ phía agent; metric chưa được đánh giá.

## Final R5 evidence audited16/10/2026

Evidence(2).zip has complete scoring, repaired checkpoint and six visualization files, all verified. Primary PGNet E2E45.60%, docTR38.13%; no_selection retained. All10,524 checkpoint records validate; no rerun required. Saved-output notebook supplied, audited and reviewed; original backup and notebook-review receipt retained. Full audit: ../plans/reports/spotting-results-audit-261016-2019-cvid-r5-final-report.md. Recovery and operational failure history retained; crop recognition remains separate.

## Notebook đã tải được review20:29 ngày16/10

Downloads/iiit_cvid_spotting_colab_t4_v2.ipynb đã cập nhật tổng kết, bảng kết quả/giới hạn và chú thích lỗi lịch sử; mọi code outputs gốc giữ nguyên.6PNG embedded byte-identical với receipt;12primary Hmeans đúng saved HTML; export SHA đúng evidence cuối. Original/reviewed copies và notebook-review receipt ở benchmark/experiments/outputs/cvid-r5-final-audit-261016/notebook/. Template sạch chỉ sửa MPLBACKEND=Agg cho subprocess render trước import, không đổi bundle/scorer/config/models. Không cần chạy lại OCR; không coi saved notebook là fresh-kernel sequential replay không lỗi.
