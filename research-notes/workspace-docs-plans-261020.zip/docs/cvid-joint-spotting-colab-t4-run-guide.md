# Hướng dẫn người dùng tự xác minh joint spotting trên Colab T4

15/10/2026. Theo yêu cầu mới: chỉ chuẩn bị/kiểm tra khả thi; người dùng tự chạy. Tác vụ demo trên Colab đã hủy, xác nhận không còn process con. Không upload code dự án hoặc ảnh CVID bằng agent.

## Kết luận khả thi

- **TESTR chưa sẵn sàng**: link tác giả dẫn tới Microsoft authentication, chưa lấy được checkpoint thật. Stack Python3.8/Torch1.10.1/nvcc11.3/Detectron2 khác runtime Colab đã quan sát (Python3.13/nvcc13). Không khẳng định TESTR không thể chạy trên T4; hiện thiếu weights và reproducible build.
- **PGNet là phương án thay thế có cơ sở**: joint localization–recognition qua shared CNN và point gathering, official weights tải được, native polygon+text, không cần Detectron2 custom ops. Đây là joint CNN, không phải mô hình Transformer.
- Đã tải/hash weights thật và chạy CPU diagnostic trên9 frame train:199 vùng,1 polygon native lỗi giữ nguyên. **Actual T4 qualification đã audit:9 train frames/199 vùng/1 polygon lỗi, receipt PASS; full comparison chưa chạy.**
- Notebook comparison v2 giữ nguyên năm candidate ban đầu và thêm PGNet làm candidate required thứ sáu; cohort1.754frames/40.063GT và scorer giữ nguyên.

## A. Chạy notebook preflight đã sửa trực tiếp

Chỉ cần hai file: [notebook preflight](../benchmark/experiments/notebooks/iiit-cvid-joint-spotting-t4-preflight.ipynb) và [qualification ZIP hiện hành](../benchmark/experiments/outputs/joint-spotting-t4-qualification-261015.zip). Không cần copy cell vá ngoài notebook. Tên ZIP giữ cố định nhưng nội dung/hash đã cập nhật; tải lại cả hai file, không dùng bản đã tải cũ.

1. Colab → File → Upload notebook → chọn notebook vừa tải. Chọn T4 GPU và Connect. Nếu sửa notebook trong cùng runtime đang lỗi, thay các cell bằng bản mới; không chạy cell upload cũ. Môi trường/weights đã tải trên cùng runtime sẽ được kiểm tra và dùng lại.
2. Chạy cell phần cứng: bảng phải thấy Tesla T4; HARDWARE ONLY chưa phải model chạy thành công.
3. Chạy cell upload, chọn ZIP canonical mới nguyên bản, không giải nén trước. Cell kiểm hash, membership và mọi member. Bảng phải PASS, Train=9/Test=0. SHA256 hiện hành:

```text
ee6c45d306f9684299cc0eb0492ffe962b1f3ac03cc0b31c2d3019456e01eb0a
```

4. Xem contact sheet9 ảnh và bảng đầy đủ frame IDs/kích thước/hashes. Trên runtime có log thất bại, cell upload giữ chúng trong `evidence/failure-history/` trước khi retry. Không cho thay gói của run đã có passed receipt bằng manifest khác.
5. Chạy Bước4 cài môi trường/forward: notebook tạo Python3.10.16/PaddleGPU2.6.2 riêng, giữ CUDA11/cuDNN8 wheels trước đường dẫn driver host. Bootstrap tránh ensurepip của Python host. Log40 dòng cuối cập nhật trực tiếp; toàn bộ log lưu file. Không bấm chạy lại khi cell còn hoạt động. Runtime mới vẫn cần tải packages nhiều GB/weights khoảng196MB; chưa có thời lượng đo cho GPU run.
6. Chạy receipt gate: mọi dòng phải PASS, process thành công, status=passed, device T4, đúng9 frame IDs/hashes, chỉ train, no_test_inference=true và accuracy_not_evaluated=true. Mở runtime/binding đầy đủ để xem identity. PROCESS COMPLETED hoặc cài package thành công riêng lẻ chưa đủ.
7. Chạy cell kết quả:9 overlay polygon đánh số, toàn bộ transcription/polygon, native-invalid counts, bảng tổng hợp và chart số vùng. Không sửa/lọc prediction native lỗi; không có GT/confidence giả. Số vùng không phải accuracy; wall seconds preflight không phải benchmark tốc độ.
8. Chạy cell export cuối để tải `pgnet-t4-preflight-evidence.zip`, xem danh sách file/kích thước/SHA256. Khi lỗi vẫn export partial evidence; nếu lỗi trước cell phần cứng thì lưu notebook outputs trước vì OUT chưa được tạo.
9. File → Save, rồi Download .ipynb để giữ outputs. Giữ notebook đã chạy và ZIP evidence cùng nhau.

Notebook local chưa chạy inference; chỉ bắt đầu comparison sau khi actual T4 train preflight đạt. Không đổi threshold0.5, TotalText/fast postprocess, resize768, dictionary hoặc grouping khi debug. Vocab36 ký tự0-9a-z giới hạn đọc dấu câu/diacritics; không lọc GT để ưu ái PGNet.

Nguyên nhân GPU trước đây đã chốt: ghi đè LD_LIBRARY_PATH làm mất `/usr/lib64-nvidia`; diagnostic cùng runtime xác nhận giữ đường dẫn này làm CUDA/Paddle device count từ0 lên1. Runner hiện hành sửa cả qualifier và comparison; điều đó chưa chứng minh model forward. Nếu còn lỗi mới, giữ log/evidence. [Cell chẩn đoán runtime](pgnet-colab-cuda-diagnostic-cell.py) chỉ dùng khi cần điều tra thêm, không thuộc chuỗi chạy thông thường.

Các ZIP trung gian bootstrap-fix/driver-fix đã xóa theo yêu cầu; [bản ghi kiểm kê](pgnet-delivery-cleanup-261015.md) giữ hashes và phạm vi. Bundlev1 vẫn giữ vì notebook lịch sử tham chiếu.

## B. Sau khi PGNet preflight đạt, chạy comparison

Dùng [hướng dẫn comparison v2 hiện hành](cvid-spotting-comparison-v2-colab-t4-run-guide.md), [notebook](../benchmark/experiments/notebooks/iiit-cvid-spotting-colab-t4-v2.ipynb) và [bundle canonical mới](../benchmark/experiments/outputs/iiit-cvid-spotting-colab-t4-inputs-v2.zip). Run mới dùng cvid-spotting-t4-261015-v2-r2. Không reuse standalone qualification như formal preflight/completion; ALL6 gate phải PASS trước ANY test inference. Cohort/config không đổi.

## Evidence cần giữ để audit

- Notebook đã lưu outputs.
- `visualizations/train-inputs.jpg`, chín overlay `frame-*-predictions.png`, `region-counts.png`, toàn bộ transcription `predictions.csv`/`prediction-tables.html` và `frame-summary.json` nếu cell hiển thị kết quả hoàn tất.
- `receipt-gates.json/html`, `hardware.json`, `process-status.json`, `qualification-manifest.json` và `evidence-manifest.json` theo các bước đã chạy. Partial ZIP có thể thiếu các file của bước chưa tới; không suy ra PASS chỉ vì export thành công.
- ZIP preflight và ZIP comparison, gồm logs, prepared/runtime seals, preflight.json, checkpoint, completion, prediction hashes và analysis/visualization receipts.
- Khi lỗi: cell bị lỗi và log đầy đủ; không chỉ ảnh chụp một dòng cuối.

## Còn chưa xác minh

Standalone PGNet T4 train-forward đã audit PASS; offline reconstruction và full comparison/test inference vẫn chưa xác minh; checkpoint TESTR truy cập hợp lệ; hiệu quả spotting CVID của PGNet. Chưa có production winner hoặc kết luận tổng quát ngoài released-label endpoint.
