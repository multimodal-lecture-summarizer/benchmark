---
title: 'Benchmark pipeline tóm tắt: từ paper đến lựa chọn model trên T4'
description: >-
  Một benchmark TIB text-only: bốn model families, fixed Lead-3 control,
  reference-usability và chi phí có điều kiện.
status: in-progress
priority: P1
effort: 48-70h công việc tương lai; runtime nhiều phiên và chờ quyền tính riêng
branch: N/A - workspace ngoài không phải Git repository
tags:
  - rq2
  - tib
  - summarization
  - t4
  - dataset-qualification-execution
blockedBy: []
blocks: []
created: '2026-10-19'
createdBy: 'ck:plan'
source: skill
---

# Benchmark pipeline tóm tắt trên TIB

## Overview

## P4b scorer implementation — prepared, actual Colab evidence pending

[Formal-runtime scorer substage](./phase-04b-formal-runtime-scorer.md) implements decision2341 with a versioned Colab amendment, pinned requirements and a scorer-only notebook for21 stored development outputs/three existing pilot IDs. Frozen metrics/windows/IDF=false, acceptance,350/40/300/523 and historic receipts remain unchanged. Local implementation/tests do not grant actual Colab readiness: current status **HOLD**; no generation/selection/final run.

## User decision — decode development closed, acceptance v1 frozen

[Decision2341](../reports/protocol-decision-261019-2341-tib-development-close-acceptance-report.md) là protocol hiện hành: giữ BARTcontrol, ưu tiên LEDngram3/Qwenr384 cho đánh giá tiếp; Lead-3/LexRank không đổi. Default search đóng;512optional/disabled, không bắt buộc0exhaustion. Frozen technical acceptance gồm completed/completed_with_warning/failed; warning outputs vẫn score/common coverage, không drop/retry theo điểm. Raw receipts/old bundles unchanged; next-stage runner phải bind policy+actual technical validators. Tiếp theo formal-runtime scorer → fresh-runtime recovery → pilot40 → admission/scorer/trial/budget freeze → selection300 hai tầng → final seal/test523→500→400. Cap350/cohort40/300/523 giữ nguyên; P4 vẫn in-progress/P5pending.

## P4.1 development — actual7trials audited, quality review pending

Đã kiểm tra [actual21outputs/123nodes](../reports/evidence-audit-261019-2222-tib-p41-returned-trials-report.md) từ7default profiles trên3staged sources/actualT4; integrity và offline replay PASS. BART/LED0 tái hiện baseline; LED3/4 giảm lặp nhưng còn output artifacts; Qwen384 còn2/2reduce truncation, concise256 không cải thiện exhaustion. [P4.1 amendment](./phase-04a-generation-development-trials.md) vẫn in-progress cho quality/intermediate policy;512 chưa chạy. Cap350/P1–P3/cohort40/300/523 giữ nguyên. Không audit-time inference/scoring/config changes; scorer formal-runtime, resume, fullpilot/resource/profile freeze còn cần evidence trước selection/final.

## P4 returned evidence — current audited status 2026-10-19

[Audit ZIP Colab](../reports/evidence-audit-261019-2013-tib-p4-returned-capacity-report.md) và [technical execution receipt v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/technical_execution_receipt_v2.json):159 files/155 JSON digests PASS;9 neural outputs replay offline, không inference/scoring mới. BART/LED/Qwen3 fresh3/3 trên actual Tesla T4 FP16, cùng3 staged pilot sources đã seal. LED failure đầu giữ lịch sử; corrected bundlev3 chạy thành công. Lead-3/LexRank có12 saved outputs qua hai lượt trên cùng3sources, không12unique records.

**Capacity PASS scoped3records; P4 vẫn in-progress/P5 pending.** LED repetition/incomplete endings và BART long final=first map cần development review. LED4/9 map và Qwen6/9 map+2/2 reduce chạm256tokens chưa EOS. Final9/9 EOS dưới768;0/9 cap350cuts. Giữ350maximum nhưng cap/profile chưa final-lock; không sửa config/cohort hoặc chọn model từ audit này. Numeric quotas/projection, formal-runtime scorer, effective runtime/config logging, expanded pilot và cross-session Drive reuse còn thiếu.40/300/523 giữ nguyên; full523→500→400 theo preoutcome budget;40diagnostics trong final. Không coi một mẫu mỗi stratum là measured p95/upper bound. `measured_profiles.json` projection-ready vẫn empty; raw observations lưu riêng.

Các snapshot18:02/17:03 bên dưới là lịch sử preparation/qualification; câu chưa generation/OAuth-pending ở đó đã được evidence hiện hành này thay thế. Cap/profile freeze trước selection; final seal sau lựa chọn, trước test generation.

## P4 technical execution — 2026-10-19 18:02 (historical snapshot)

- Later user-run amendment: BART exit0 reported; LED failed before model load because the downloader excluded its pinned `.bin` weights. Corrected local loader and LED-only v3 recovery pair;15 focused tests PASS, v3 unexecuted. Existing receipts kept historical; T4/cap/budget gates remain unverified by this fix. [Correction report](../reports/debug-261019-2004-tib-led-checkpoint-download-report.md).
- [Scorer-ready receipt](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/scorer_ready_receipt.json): pinned CPU/batch1/FP32 fixtures + actual pretrained native/window and five-metric E2E PASS; IDF=false, no corpus fit. Đây là CPU fixture scope, chưa full-corpus throughput hoặc T4/scorer budget.
- [Output policy](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/output_policy.json): user ratified eligible-train-only p95/ceil25;4.213 records,p95=333 → **350 English whitespace words maximum**, không target. [Evidence v2](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/output_cap_evidence_v2.json) verifies qualification/canonical/tokenizer hashes; native final reserve768 là proposal. Value derived350 thay current UNSET; **final cap lock vẫn chờ actual candidate feasibility trước selection**. Không dùng validation/test references để chọn cap.
- [Candidate profiles](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/candidate_profiles.json): năm IDs, full native token coverage/Unicode-preserving wrappers và reducers, fixed CPU Lead-3 + full-source LexRank. Local three-source smoke6/6CPU outputs và9 tokenizer plans PASS; model weights chưa chạy trên T4.
- [Compute budget](../../benchmark/experiments/registry/protocols/tib-model-benchmark-p4-261019-1802/compute_budget.json): full523 →500 →400, diagnostics40 nằm trong final cohort. User cho Colab/Drive và runtime dưới12h; guard11.5h. Không suy runtime/GPU-hours từ token plans hoặc A100. Numeric CPU/storage/call projections và store survival chưa đủ.
- [Colab notebook](../../benchmark/experiments/notebooks/tib-p4-feasibility-colab-261019-v2.ipynb) và source-only ZIP đã upload private Drive, chỉ3 staged pilot sources/attribution, không abstracts/selection/test. Runtime T4 đã kết nối; first mount-Drive cell đang chờ OAuth consent cho client Google Drive for desktop. Auto-review từ chối Continue khi chưa có client/scope approval; không model generation nào trên Colab được xác nhận. [Runbook](../../docs/tib-p4-colab-feasibility.md).
- 134 focused/regression tests PASS. Không pilot40/selection300/final523/formal model selection mới; development40/300 và eligible-test523 giữ nguyên. [Báo cáo](../reports/implementation-261019-1802-tib-p4-readiness-report.md).


**Đã thực thi dataset qualification và development seal — 2026-10-19.** P1 completed trong scoped conditional-use frame; P2/P3 in-progress, P4 in-progress/P5 pending. CPU EDA/rights/reference/source groups/exposure đã có evidence;40 pilot/300 selection đã seal. Final test chưa seal, chưa pretrained neural generation/benchmark/T4 pilot. Mỗi stage phụ thuộc gate riêng; hoàn thiện code không thay thế scorer/compute evidence.

[Báo cáo thực thi](../reports/implementation-261019-1703-tib-qualification-cohort-report.md), [executed notebook](../../benchmark/experiments/notebooks/diagnostics/tib-summarization-gap-closure-261019.ipynb) và [execution receipt](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/execution_receipt.json) ghi6 executed verification/render cells,0 errors; full9.103-record scan do CPU CLI thực hiện, không rescan trong notebook.

Hướng này thay đề xuất 60/120 mẫu và ba nhánh C−B primary trong [kế hoạch trước](../261018-2118-rq2-scientific-improvement/plan.md). Năm giai đoạn người dùng yêu cầu: paper/dataset → EDA bổ sung → qualification → tuyển chọn/benchmark → evaluation/lựa chọn. [Báo cáo phản biện](../reports/research-261018-2225-rq2-hypothesis-evaluation-reassessment-report.md) giữ vai trò lịch sử; route annotation không trở thành yêu cầu bắt buộc.

Đích hẹp: trên cohort TIB text-only hữu hạn, so sánh đồng thuận với creator abstract và chi phí **pipeline** tóm tắt đầy đủ. Không suy factuality, bảo toàn ý quan trọng hoặc chất lượng video đa phương thức từ cosine/ROUGE. Không xây key-idea gold hay human-annotation framework mới.

Revision theo [báo cáo xác minh 09:33](../reports/research-261019-0933-summarization-scientific-t4-verification-report.md): selection hai tầng thay comparison set gộp mọi config. Báo cáo là evidence lịch sử bất biến; các lỗ hổng thiết kế được xử lý ở đây không đồng nghĩa các mục cần đo/xác minh đã hoàn tất.

Revision attachment19/10: **một primary text-only TIB study**, fixed snapshot9.103 records/native splits; không tách benchmarks theo genre/domain, không tạo gold summary mới. Bốn model families LexRank/BART/LED/Qwen3-4B và **một fixed cheap CPU control Lead-3**. Old S1/S3/120/9-pilot giữ lịch sử, không scheduled auxiliary benchmark mới; optional diagnostics/input profiles không tự cấp quyền chạy study khác.

## Phases

| Phase | Name | Status |
|-------|------|--------|
| 1 | [Paper và provenance](./phase-01-paper-and-dataset-provenance.md) | Completed |
| 2 | [Bổ sung EDA và visualization](./phase-02-eda-and-visualization-gap-closure.md) | In Progress |
| 3 | [Qualification và cohort](./phase-03-dataset-qualification-and-cohort-freeze.md) | In Progress |
| 4 | [Ứng viên và protocol T4](./phase-04-candidate-selection-and-t4-benchmark-protocol.md) | In Progress |
| 5 | [Evaluation và lựa chọn](./phase-05-evaluation-and-model-selection.md) | Pending |

## Dependencies

P1 → P2 → P3 → P4 → P5. P4 tạo và khóa scorer spec/receipt theo metric contract mô tả trong tài liệu P5; scorer-ready/hash/IDF-fit là blocker P4 selection, không đợi thực hiện P5. P3 chốt qualification mọi split/A/B/C/group/exposure và hai validation roles. P4 pilot/model selection→P3/P4 final seal IDs/N/K_models/K_total/config/W_global/budget trước test predictions/scores. Chỉ evidence dữ liệu/quyền/task cho phép P3 qualification amendment trước seal; capacity/context xử lý development adapter/admission/K_models, không loại valid test vì dài/OOM/runtime.

Substage DAG (không thêm phase/status): `P1/P2/P3 development seal → P4 feasibility/pilot/scorer-ready → P4 A: config theo family → P4 B: giữa representatives → P3/P4 final seal → P4 final generation → P5 final analysis`. P4 sở hữu scorer spec/receipt và amendment/rescore/redecision cả hai tầng trước final seal. P3 khóa diagnostic spec/core IDs/thuật toán chọn extremes trước final seal, P4 bind hash. P5 đọc immutable specs để phân tích/báo cáo; extreme IDs chỉ được chọn cơ học sau final metrics. Dependencies trong frontmatter giữ đúng thứ tự phase.

| Phase / owner duy nhất | Artifact đã có / còn cần và gate | Giờ công |
|---|---|---|
| P1 / provenance reviewer | Completed pinned manifest/canonical trace/scoped rights ledger; remaining rows HOLD | 4-6h |
| P2 / EDA reviewer | Gap matrix, notebook bổ sung, figures/tables; đúng mẫu số | 6-8h |
| P3 / data steward | Qualification mọi split, group/exposure policy và các role; đủ frame | 8-12h |
| P4 / runtime designer | Registry/pilot/scorer-ready/validation selection/final protocol; capacity đo thực | 20-30h |
| P5 / evaluation reviewer | Final metrics/costs/paired intervals/A+B-vs-A-only sensitivity/40 unique diagnostics | 10-14h |

Owner độc quyền artifact từng phase; downstream chỉ đọc sealed versions, không hai phase sửa cùng file song song, amendment quay đúng owner/version.48–70h **provisional**, cần reassess sau normalization/rubric225 flags/EDA gaps/W_global/pilot evidence; không measured runtime/capacity/schedule commitment. Giữ năm phase; status chỉ cập nhật theo acceptance thực tế.

## Evidence hiện tại

## Evidence thực thi — 2026-10-19 17:03

Pinned snapshot `e6ab9fd7c6acd164f3284b8c4b17eb9d94681eee`: 9.103 canonical records có raw/normalized hashes và offset trace; native splits 7.282/910/911. Source-use policy khóa cho **local/private/noncommercial**, giữ attribution, không public text redistribution/external API transfer: 6.171 source conditional / 2.932 HOLD, 5.270 records qua combined source/reference rights. Không blanket allow toàn corpus; chuyển sang remote T4/store phải xác minh phạm vi sử dụng trước chuyển dữ liệu.

Reference policy đã calibrated/frozen trước outputs: **A=0, B=9.095, C=8 empty**. Toàn bộ225 historical reused flags được targeted review trong18 groups;226 casefold members tính cả một row ngoài historical structural frame, giữ B vì chưa đủ evidence usability chắc chắn. AI-assisted review dùng title/opening/anchor spans, không full-transcript factuality certification; A-only sensitivity hiện **unavailable**, không đổi labels để tạo A.

Source audit ghi22 accepted edges /37 records /9.082 components,7 cross-split components; tái hiện known three-record cluster. Retrieval gần đúng, recall unknown; tác giả/title/abstract reuse không tự tạo source group. Additive group replay đã kiểm lại9.103 hashes/22 accepted decisions/components sau import fix; không rerun mọi candidate comparisons, original runtime code identity chưa sealed đầy đủ.

| Native split | Source | Data eligible | Sau exposure filtering |
|---|---:|---:|---:|
| train | 7.282 | 4.215 | 4.213 |
| valid | 910 | 532 | 464 |
| test | 911 | 523 | 523 |

**40 pilot /300 selection validation đã seal, không kích hoạt fallback200**; không trùng ID/group giữa roles, old120/9 pilot hoặc protected eligible test groups. 523 là eligible test frame hiện tại, **final test chưa seal**; full-first và fallback600→500→400 giữ nguyên, chỉ xét N nhỏ hơn frame và đủ budget. Không generation/selection metrics/T4 pilot.

- [Source-use policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/source_use_policy.json), [reference policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/reference_policy.json), [reference summary](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/reference_summary.json), [source-group policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/group_policy.json).
- [Qualification policy](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/qualification_policy.json), [development cohort](../../benchmark/experiments/registry/datasets/tib-text-model-benchmark-v1/qualification-261019-1703/development_cohort.json) bind exact IDs/groups/counts/policy hashes. Full canonical/rights/reference/group/exposure ledgers và CPU EDA receipt giữ local ignored tại `benchmark/research-data/tib-qualification-261019-1703/`.
- CPU EDA đã chạy toàn9.103 rows,4 plots, native BART/LED/Qwen token counts từ pinned tokenizer files. Illustrative window counts chỉ lower bounds chưa gồm wrappers/overlap/reduce; actual native layouts và capacity còn P4-dependent.
- **W_global derived350; final feasibility lock pending**. Scorer-ready, candidate profiles/decode/scoring capacity, numeric quotas và actual persistent-store receipts còn thiếu. Host xác minh RTX4050 Laptop6GB/16GB RAM, **không phải T4**; không suy T4 feasibility.


- EDA lịch sử:10 executed cells/8 PNG/0 errors;9.103→9.002 structural usable→8.769 candidates sau8 empty+225 reused exclusions. [Inventory](../../benchmark/docs/DATASET_EDA.md), [source output](../../benchmark/experiments/notebooks/diagnostics/rq2-tib-all-splits-eda-colab.ipynb). Chỉ bổ sung gaps;8.769 không forced new eligible count, 225 đã adjudicate theo frozen policy mới (B uncertain); historical counts giữ bất biến.
- [Old120](../../benchmark/docs/results/rq2-tib-120-results-261013.md): 240 summaries, đủ ba metrics sau amendment; giữ **no_selection**, chỉ hồi cứu.
- Receipt/ledger Drive thực chưa audit độc lập; hash notebook discrepancy còn pending. [Code lưu intermediates](../../benchmark/experiments/scripts/rq2_tib_benchmark_pair.py) không chứng minh raw artifacts có local. [Audit lịch sử](../reports/research-261018-2225-rq2-hypothesis-evaluation-reassessment-report.md); không rerun study cũ.
- Thiếu receipt cũ giới hạn chứng nhận lịch sử, không tự khóa planning/qualification mới. Blockers còn lại: scope remote compute/storage, W_global, scorer/config/context và capacity.

## Dòng dữ liệu và phạm vi

Pinned raw bytes/transcript/reference/metadata → P1 canonical normalization+hash/offset manifest → P2 gap EDA → P3 A/B/C+rights/structural/group/exposure ledger → source-only native-split roles → P4 full canonical source/native algorithms+fixed control → raw/delivered summaries+receipts → pinned scorer đọc abstract riêng → P5 paired/resource/sensitivity/diagnostics → conditional model decision.

Canonical schema: `source_raw`, `source_normalized`, `reference_raw`, `reference_normalized`, `record_id` (DOI/released ID+row mapping), `group_id`, `source_length` (words+per-model native tokens), `quality_flags`, `eligibility_status` eligible/flagged/excluded/HOLD + reason. Chỉ NFC/whitespace/deterministic encoding repair, giữ bytes/hashes/offset mapping; không semantic rewrite. Canonical input là `transcript`; `transcript_segments` sidecar kiểm order/time/coverage, mismatch flag không tái dựng. Primary prompt không timestamps; timestamp profile ngoài primary scope cần freeze/authorization riêng.

A usable content+presentation relation, B uncertain short/generic/reused/unreviewed giữ primary nếu eligibility khác pass, C evidence-backed unusable loại reference scoring; rights/structural HOLD riêng. Đây là **research policy đã khóa cho version hiện tại**, không TIB labels/gold. Rubric calibrated train/development/frozen trước model outcomes,225 historical flags adjudicate; uncertain→B, không arbitrary30/50-word cutoff/ROUGE classification. Primary **A+B pooled**, A-only/exclude-B sensitivity cùng predictions/frozen labels/denominators rõ; không outcome filtering.

Shortlist bốn model families chưa chính thức: LexRank, facebook/bart-large-cnn, allenai/led-large-16384-arxiv, Qwen/Qwen3-4B; thêm Lead-3 first3 sentences theo một fixed splitter/profile, common delivered selector, không learned model/trials/GPU generation. Mọi pipeline có full canonical source; first3 là output algorithm của control, không input-preprocessor truncation/full map coverage claim. Năm tiêu chí model: paper/đa dạng/task fit/tái lập/T4 feasibility; comparison pipelines có transfer/adapters khác nhau, không causal architecture ranking.

**W_global derived350; final feasibility lock pending**: eligible native-train reference-length distribution+product constraint quyết định một global English-whitespace-word cap trước selection.250 không fixed/default scientific choice; native256/384 proposals phải reassess, words≠tokens. Common raw→delivered selector/capping/hash/cost/length reporting, không per-record test reference length hoặc reference fields đi generator/selector. P2 reuse EDA và đóng gaps source/ref p50/p90/p95/max, compression ratio, empty/short/generic/reused rates+A/B/C ledger, duplicates/exposure, genre+subject-by-split, ASR/segment anomalies, native-token/window tails.

## Quy mô nghiên cứu cập nhật

| Bước trong năm phase | Quy mô dự toán | Mục đích/gate |
|---|---|---|
| EDA / P2 | Toàn bộ9.103 bản ghi | Reuse tổng thể; bổ sung gap có lý do |
| Qualification / P3 | Toàn bộ train/validation/test | Quyền, cấu trúc, reference, duplicate/group/exposure |
| Train / P1–P4 | Eligible train, không cần generation toàn split | Policy/rubric/normalization/cutpoints/assets/IDF |
| Pilot / P4 | 40 validation | Model/context/RAM/VRAM/tốc độ/pipeline |
| Model selection / P4 | 300 validation rời pilot; availability fallback200 trước outputs | Chọn config/model, dưới200 stop/amend không lấy test |
| Final benchmark / P4–P5 | Toàn bộ native test hợp lệ, tối đa911 | Đánh giá lựa chọn đã khóa |
| Error analysis / P5 | 40 unique IDs cùng final cohort, default30 core+10 extremes | Rule/core IDs khóa trước outputs, extreme IDs cơ học sau metrics; shortfall báo thật |

Ưu tiên toàn bộ test hợp lệ qua nhiều phiên T4. [P4 budget contract](./phase-04-candidate-selection-and-t4-benchmark-protocol.md#budget-và-fallback-contract) yêu cầu numeric GPUh/CPUh/wall/session/storage/scoring/retry/checkpoint/recovery/trial caps trước stage; unknown = **REQUIRED_NO_START**, không giả feasibility. Nếu full không fit conservative projection, xét600→500→400 chỉ N nhỏ hơn qualified frame, chọn largest feasible N theo source-only representative/group/floor rule P3. Frame400–600 full-first, frame<400 dùng toàn bộ nếu fit; không có mức hợp lệ fit → blocked/no formal run. ExactN/quotas/order khóa trước test; không tự shrink sau seal.40/300 development đã seal;40 diagnostic là planned. Availability không chứng minh statistical power.

Hiện **40 pilot /300 selection validation đã seal; final test chưa seal**. Một profile/model + fixed Lead-3: pilot40→160 model+40 control=200 finals; selection300→1.200+300=1.500; fallback selection200→800+200=1.000; full final≤3.644+911=4.555; test fallback600/500/400 totals≤3.000/2.500/2.000. `K_models≤4`, `K_total=K_models+1≤5`; ưu tiên4 models+control nếu feasible. Max10 paired contrasts. Maps/reductions/retries/extra configs/scorers tốn thêm, tầng B reuse outputs không double-count. Neural generator GPU chỉ BART/LED/Qwen; LexRank+Lead-3 CPU, generation GPU/VRAM N/A, không zero-cost. Không capacity/time promise.

Hai tầng dùng cùng V=300 (availability-only fallback200), không thêm mẫu/split: A chọn một config/model family trên C_f bằng max mean/frozen exact-tie priority, không sibling-delta0.01; fixed Lead-3 không trials/tầng A. B khóa model representatives+fixed control, recompute C_between và mọi mean/delta trên tập chung này. Delta0.01 chỉ model-family recommendation; predeclared Lead-3 sanity guard đề xuất leader≥control trên common/source-length strata, guard fail→no_selection, control không learned-model winner. C_f means không ranking giữa families; không đổi representatives/control/membership để cứu common coverage.95% từng profile không đảm bảo common90%; floors trên predeclared source-length strata, không mọi rare genre/ABC cell. Giữ trial/failure/cost/membership ledgers, thiếu coverage→fail/no_selection, không hạ ngưỡng hậu nghiệm.

Primary full-test census giữ/group mọi legitimate released record khác ID, record-weighted; deduplicated/group-weighted sensitivity riêng. Repeated abstract không chứng minh source duplicate;225 historical flags adjudicate theo frozen rubric A/B/C, không blanket exclusion/reinstatement hoặc forced8.769 count.

Toàn source train/valid/test đã EDA-exposed, old120 outputs đã xem. EDA exposure được ghi riêng, không tự loại native test. Loại old120/9 pilot cũ và known tuning-linked groups khỏi development mới; test đã có liên kết tuning thì loại/HOLD có evidence trước outcomes. Với cross-split source duplicates chưa tuning, ưu tiên giữ test hợp lệ và loại validation liên kết trước tuning. Pilot/selection validation rời nhau theo group; author/title flags không tự là duplicates. Không gọi pristine unseen hoặc zero pretraining contamination.

Old S1/S3/120 **no_selection** và9-pilot history bất biến, chỉ hồi cứu; không new scheduled auxiliary S1/S3 benchmark trong plan này. Future independent study cần explicit user request. Lead-3/Oracle paper attribution đã verified tại HAL PDF section5.2/Table2 theo evidence15:07; local reproduction settings vẫn chưa xác minh. Extractive Oracle optional reference-aware ceiling, không candidate/deployable/new gold/ranking input. Optional EMNLP2024 TIB-group relevance citation/formula UNVERIFIED/default off, chỉ diagnostic nếu pin trước selection và đủ budget, không post-hoc tiebreak.

## Validation, compatibility và rollback

| Tầng kiểm chứng tương lai | Phạm vi |
|---|---|
| Unit | Raw/normalized schema/hashes/offsets; A/B/C/eligibility/groups;40/300→200 availability; native context; Lead-3 first3/W_global selector; null/failure; paired resampling |
| Integration | Reference-field isolation khỏi generation/selector; A+B/A-only same predictions; native adapters/scorer pins; C_f model-only/C_between representatives+control; raw/delivered/resume identity/cost |
| E2E | Staged pilot/long-tail/OOM/interruption/export; test sau seal; mọi selected ID có ledger |

Artifact mới dùng schema/study/candidate IDs version mới; không sửa frozen runtime/notebook/protocol/receipt cũ. Không migrate lịch sử; liên kết qua hashes. Rollback mỗi phase rút version mới khỏi đường thực thi, giữ evidence/attempts, quay sealed snapshot trước; không xóa failures hoặc trộn scores giữa versions.

## Risk Assessment và tiêu chí hoàn tất

| Rủi ro | Khả năng × tác động | Mitigation |
|---|---|---|
| Quyền/reference không phù hợp | Vừa × cao | P1 text rights, P3 scope/rules trước outcomes |
| Leakage/outcome-driven selection | Cao × cao | Group/exposure ledger, validation-only selection, seal trước test |
| OOM/context/session timeout | Cao × cao | Staged3/pilot, full-cost projection, nhiều phiên/resume |
| Overclaim winner | Cao × cao | Paired uncertainty, denominators, no_selection |

- [ ] Năm phase đủ acceptance và artifact versioned; mọi selected ID/attempt được accounting.
- [ ] Provenance/cohort/context/resource gates có evidence, không hứa 12h/power khi chưa đo.
- [ ] Báo agreement/resources/failures/limits; không chọn winner chỉ vì rẻ.
- [ ] Old120 giữ no_selection; không gold mới/benchmark genre-domain/auxiliary S1/S3 mới; fixed Lead-3 không model recommendation.
- [ ] Frozen A/B/C ledger và40 diagnostics cùng final cohort; W_global được evidence train/development hỗ trợ trước selection, không test-reference length steering.

## Traceability review và attachment

| Điểm | Hợp đồng đã bổ sung trong kế hoạch |
|---|---|
| 1. Scorer sẵn sàng trước selection | [P5 metric contract](./phase-05-evaluation-and-model-selection.md#metric-contract): P4 owner hash scorer/train-IDF, ALL tried model+control outputs rescore/rerun A/B trước test |
| 2. Selection estimand/search | [P4 development](./phase-04-candidate-selection-and-t4-benchmark-protocol.md#development-và-validation-selection-contract): model-only C_f→representatives+fixed Lead-3 C_between; no sibling delta, model-only recommendation/guard/floors |
| 3. Native context/recursive coverage | [P4 context](./phase-04-candidate-selection-and-t4-benchmark-protocol.md#context-và-output-contract): causal vs encoder/decoder; fan-in/progress/overflow/maxdepth |
| 4. T4 profile | [P4 profile](./phase-04-candidate-selection-and-t4-benchmark-protocol.md#t4-profile-đề-xuất-và-capacity-gate): per-stage FP16/batch1/native conservative caps/backend/memory gates |
| 5. Budget/fallback | [P4 budget](./phase-04-candidate-selection-and-t4-benchmark-protocol.md#budget-và-fallback-contract), [P3 sampling](./phase-03-dataset-qualification-and-cohort-freeze.md#quy-mô-và-sampling): required fields/full-first/600→500→400/no-start |
| 6. Durable resume | [P4 failure](./phase-04-candidate-selection-and-t4-benchmark-protocol.md#failure-và-resume-contract): atomic map/reduce nodes/dependency hashes/stable seed/scorer separation/cost/store verification |
| 7. Qualification/duplicates | [P3 qualification](./phase-03-dataset-qualification-and-cohort-freeze.md#qualification-policy-đề-xuất): frozen A/B/C/225 flags/A+B primary/A-only sensitivity/census/groups/test priority |
| 8. Error analysis | [P5 diagnostics](./phase-05-evaluation-and-model-selection.md#manual-diagnostics-và-decision):40 unique IDs same final cohort/default30 core+10 extremes/frozen rule/honest shortfall |
| 9. Canonical source | [P1 normalization](./phase-01-paper-and-dataset-provenance.md#canonical-normalization-contract): raw+normalized fields/hash/offsets, transcript canonical/segments sidecar, no timestamp primary |
| 10. EDA/output policy | [P2 development policy](./phase-02-eda-and-visualization-gap-closure.md#development-derived-output-policy): gap matrix/lengths/compression/anomalies/native windows→W_global UNSET until development freeze |

## Các mục còn cần xác minh theo báo cáo

Bảng dưới đây tách evidence đã xác minh với phần còn **PENDING**. Snapshot technical binding và original Lead-3/Oracle attribution đã VERIFIED bằng evidence15:07; document PASS không tự mở rights/runtime gates. Ledger tương lai phải ghi claim/source+revision/hash, scope/record IDs, owner, verification method, observed result/unknown và gate affected.

| Mục | Owner / evidence cần có | Gate và giới hạn hiện tại |
|---|---|---|
| Snapshot TIB và quyền reuse | P1: pinned API/LFS/Git bytes+hash/schema/counts và per-record scoped policy VERIFIED | 6.171 conditional source;5.270 combined rights; remaining HOLD, không public/remote transfer grant |
| Canonical normalization | P1:9.103 raw/normalized hashes+offsets/transcript-vs-segment trace đã có | Technical normalization only; primary no timestamps |
| Reference225 reused và source groups | P3:225 flags reviewed;A0/B9.095/C8;22 accepted source edges/9.082 components | A-only unavailable; approximate group recall unknown, limited-span review |
| Development policy/availability | P2/P3:train cutpoints,40 pilot/300 selection sealed từ464 validation eligible | W_global UNSET; final523 eligible frame chưa final seal/budget |
| Lead-3/optional metric provenance | P1: original Lead-3/Oracle attribution VERIFIED tại HAL section5.2/Table2; P4 fixed local profile và optional EMNLP citation/formula còn cần pin | Không gọi local reproduction; optional relevance UNVERIFIED/default off; Oracle không primary decision/new study |
| Metric provenance/implementation | P4: scorer pins/formula/window IDs/native equivalence receipt; trace source SBERTScore paper | Attribution chưa xác minh thì label project-specific source sentence similarity, không exact replication; scorer identity/capacity phải đủ trước selection |
| Model/library/backend/T4 fit | P4: actual revisions/decode defaults/dtype/backend, load/prefill/decode/scorer CPU-RAM/VRAM receipts | Main config, theoretical KV hoặc conservative4K không chứng nhận actual fit; không mặc định FlashAttention compatibility |
| Compute/storage/checkpoint | P4: numeric quotas/trial caps, measured call tails, actual-store readback/restore/loss-window receipts | REQUIRED_NO_START cho stage chưa đủ; chưa chứng nhận full-test throughput/multi-session durability |

## Kiểm tra bản thiết kế trước thực thi — 2026-10-19

**Historical validation only:** revision sau báo cáo09:33 từng ghi strict CLI valid/0 issues/5 phases pending,43 internal links/15 anchors và self-consistency PASS. Những kết quả đó không chứng nhận revision attachment hiện tại. **Historical design revision: PASS kiểm tra tài liệu** — strict CLI valid/0 issues,5 phases pending;45 internal links/17 anchors hợp lệ; whitespace diff ba tài liệu benchmark liên kết PASS. Root đã đọc cả sáu files và đối chiếu attachment/quy mô/ownership; independent read-only review P1–P3 và P4–P5 PASS, không còn mâu thuẫn cụ thể được phát hiện trong phạm vi rà này. Đây là checks của revision thiết kế trước execution, không chứng nhận revision thực thi hiện tại. Dataset/development evidence đã có như bảng17:03; runtime/measurement gates còn PENDING, không chứng nhận statistical power hoặc T4 feasibility.

Desk-check thiết kế (không benchmark): A/config1=0.300, A/config2=0.299 không tự gây no_selection sibling; A chọn max/tie rồi B recompute selected model representatives+fixed Lead-3 trên C_between, mới xét model delta/control guard.95% từng profile không bảo đảm intersection90%; failed floors giữ nguyên V/failure masks/no_selection.40 pilot×(4 models+control)=200,300 selection×5=1.500,200 fallback×5=1.000,911 final×5≤4.555;10 contrasts tối đa. Đây là arithmetic/design examples, không scores/throughput/capacity evidence.

Numeric coverage/delta/profile/case-layout defaults là engineering proposals cần freeze trước relevant stage, không statistical guarantee. Các kiểm tra và tuyên bố chưa thực thi ở trên ghi lại revision thiết kế trước10:35; không mô tả trạng thái code hiện tại. Sau17:03 đã có frozen development cohort40/300 và qualification receipts như evidence hiện tại; final cohort/profile/scorer chưa khóa. Host RTX4050 Laptop6GB/16GB RAM không phải T4; không có quyền Drive mặc định. Required numeric quotas/capacity/store receipts chưa đủ vẫn chặn stage phụ thuộc; PASS tài liệu không thay thế gates đo thực.

## Đồng bộ trạng thái thực thi

CLI status sync: P1 completed, P2/P3 in-progress, P4 in-progress/P5 pending. Strict plan validation kiểm lại sau sync: valid/0 issues. P2 owner đóng wrapper-aware/native CPU layout gaps qua P4 profiles; P3 owner giữ development IDs và hoàn tất final seal sau P4 selection/budget; P4 owner hoàn tất implementation/gates trước inference. Không đổi quy mô hoặc thêm benchmark.

## Câu hỏi còn mở

Snapshot/rights theo local scope/canonical trace/reference225/groups/eligible counts/development40/300 đã xác minh. Còn remote T4/store use scope; W_global UNSET tới train/development+product evidence; native wrappers/map-reduce/backend/T4 fit; K_models/K_total/ratified delta/coverage/control guard; numeric compute/storage/trial quotas/checkpoint durability/full-test-vs-fallbackN; scorer-ready và optional relevance provenance(default off). A-only unavailable hiện tại; group recall unknown và limited review là limitations giữ lại, không suy thành PASS factuality. P4 owner hoàn tất implementation plan/gates trước inference; P3 owner hoàn tất final seal sau P4 evidence; P5 owner chỉ phân tích khi có sealed outputs.
